﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using MySQL.Data.EntityFrameworkCore.Extensions;

namespace MySqlConsole

{
    public class UserDetailsContext : DbContext
    {
        public UserDetailsContext(DbContextOptions<UserDetailsContext> options) : base(options)
        { }
        public DbSet<UserDetail> Employees { get; set; }
    }

    /// <summary>
    /// Factory class for EmployeesContext
    /// </summary>
    public static class UserDetailsContextFactory
    {
        public static UserDetailsContext Create(string connectionString)
        {
            var optionsBuilder = new DbContextOptionsBuilder<UserDetailsContext>();
            optionsBuilder.UseMySQL(connectionString);

            //Ensure database creation
            var context = new UserDetailsContext(optionsBuilder.Options);
            context.Database.EnsureCreated();

            return context;
        }
    }


    /// <summary>
    /// A basic class for an Employee
    /// </summary>
    public class UserDetail
    {
        public UserDetail()
        {
        }

        [Key]
        public int UserId { get; set; }

        [MaxLength(50)]
        public string First_Name { get; set; }

        [MaxLength(50)]
        public string Last_Name { get; set; }

        public int Role { get; set; }

        public string ActiveInd { get; set; }
    }
}

