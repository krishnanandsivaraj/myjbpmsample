﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MySqlConsole
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = new ConfigurationBuilder()
            .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);

            var configuration = builder.Build();

            string connectionString = configuration.GetConnectionString("MySQLConnection");

            // Create an employee instance and save the entity to the database
            var entry = new UserDetail() { First_Name = "Suresh", Last_Name = "Kothandan" };

            using (var context = UserDetailsContextFactory.Create(connectionString))
            {
                context.Add(entry);
                context.SaveChanges();
            }

            Console.WriteLine($"User details saved Id: {entry.UserId}");
        }
    }
}

