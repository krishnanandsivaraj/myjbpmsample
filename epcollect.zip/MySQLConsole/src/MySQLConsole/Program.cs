﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace MySQLConsole
{
    public class Program
    {
        public static void Main(string[] args)
        {

            MySqlConnection connection = new MySqlConnection
            {
                ConnectionString = "Server=localhost;Database=epcollect;Uid=epcollect;Pwd=Verizon1!;SslMode=None"
            };
            connection.Open();
            MySqlCommand command = new MySqlCommand("SELECT * FROM epcollect.userdetails;", connection);

            using (MySqlDataReader reader = command.ExecuteReader())
            {
                System.Console.WriteLine("User Id\t\tName\t\tLast Update");
                while (reader.Read())
                {
                    string row = $"{reader["UserId"]}\t\t{reader["first_name"]}\t\t{reader["last_name"]}";
                    System.Console.WriteLine(row);
                }
            }

            connection.Close();

            System.Console.ReadKey();

            //var builder = new ConfigurationBuilder()
            //.AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);

            //var configuration = builder.Build();

            //string connectionString = configuration.GetConnectionString("MySQLConnection");

            //// Create an employee instance and save the entity to the database
            //var entry = new UserDetail() { First_Name = "Suresh", Last_Name = "Kothandan" };

            //using (var context = UserDetailsContextFactory.Create(connectionString))
            //{
            //    context.Add(entry);
            //    context.SaveChanges();
            //}

            Console.WriteLine($"User details saved Id:");// {entry.UserId}");
        }
    }
}
