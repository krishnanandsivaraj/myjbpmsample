﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using MySqlWebAPI.Data;

namespace MySqlWebAPI.Migrations
{
    [DbContext(typeof(UserDetailsContext))]
    [Migration("20161202143130_init")]
    partial class init
    {
        protected override void BuildTargetModel(ModelBuilder modelBuilder)
        {
            modelBuilder
                .HasAnnotation("ProductVersion", "1.0.1");
                //.HasAnnotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn);

            modelBuilder.Entity("MySqlWebAPI.Models.UserDetails", b =>
                {
                    b.Property<string>("UserId");

                    b.Property<string>("ActiveInd");

                    b.Property<string>("Email");

                    b.Property<string>("First_Name");

                    b.Property<string>("Last_Name");

                    b.Property<int>("Role");

                    b.HasKey("UserId");

                    b.ToTable("Contacts");
                });
        }
    }
}
