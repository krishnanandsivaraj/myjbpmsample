﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MySqlWebAPI.Models;

namespace MySqlWebAPI.Repository
{
    public interface IUserDetailsRepository
    {
        void Add(UserDetails item);
        IEnumerable<UserDetails> GetAll();
        UserDetails Find(string key);
        void Remove(string Id);
        void Update(UserDetails item);

    }
}
