﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MySqlWebAPI.Models;
using MySqlWebAPI.Data;

namespace MySqlWebAPI.Repository
{
    public class UserDetailsRepository : IUserDetailsRepository
    {
        static List<UserDetails> UserDetailsList = new List<UserDetails>();

        UserDetailsContext _UsrDetailscontext;
        public UserDetailsRepository(UserDetailsContext UsrDetailscontext)
        {
            _UsrDetailscontext = UsrDetailscontext;
        }

        public void Add(UserDetails item)
        {
            //UserDetailsList.Add(item);
            _UsrDetailscontext.UserDetails.Add(item);
            _UsrDetailscontext.SaveChanges();
            //throw new NotImplementedException();
        }

        public UserDetails Find(string key)
        {
            return UserDetailsList
                .Where(e => e.UserId.Equals(key))
                .SingleOrDefault();
            //throw new NotImplementedException();
        }

        public IEnumerable<UserDetails> GetAll()
        {
            return _UsrDetailscontext.UserDetails.ToList();
            //return UserDetailsList;
            //throw new NotImplementedException();
        }

        public void Remove(string Id)
        {
            var itemToRemove = UserDetailsList.SingleOrDefault(r => r.UserId == Id);
            if (itemToRemove != null)
                UserDetailsList.Remove(itemToRemove);
            //throw new NotImplementedException();
        }

        public void Update(UserDetails item)
        {
            var itemToUpdate = UserDetailsList.SingleOrDefault(r => r.UserId == item.UserId);
            if (itemToUpdate != null)
            {
                itemToUpdate.UserId = item.UserId;
                itemToUpdate.First_Name = item.First_Name;
                itemToUpdate.Last_Name = item.Last_Name;
                itemToUpdate.Email = item.Email;
                itemToUpdate.Role = item.Role;
                itemToUpdate.ActiveInd = item.ActiveInd;
            }

            //throw new NotImplementedException();
        }
    }
}
