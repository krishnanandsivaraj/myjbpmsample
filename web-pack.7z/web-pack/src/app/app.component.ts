import {Component} from "@angular/core";
@Component({
    selector:"my-app",
    template:"<h1>This is a sample application</h1>"

})
export class AppComponent{}