package com.sample;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.jbpm.bpmn2.xml.XmlBPMNProcessDumper;
import org.jbpm.ruleflow.core.RuleFlowProcess;
import org.jbpm.ruleflow.core.RuleFlowProcessFactory;
import org.kie.api.KieBase;
import org.kie.api.io.ResourceType;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.process.ProcessInstance;
import org.kie.internal.KnowledgeBase;
import org.kie.internal.builder.KnowledgeBuilder;
import org.kie.internal.builder.KnowledgeBuilderFactory;
import org.kie.internal.io.ResourceFactory;
import org.kie.internal.runtime.StatefulKnowledgeSession;
import org.kie.internal.utils.KieHelper;

//https://github.com/marianbuenosayres/jBPM6-Developer-Guide/blob/master/chapter-02/jBPM6-quickstart/src/test/java/com/wordpress/marianbuenosayres/quickstart/ProgrammedProcessExecutionTest.java
//https://github.com/droolsjbpm/jbpm/blob/master/jbpm-bpmn2/src/test/java/org/jbpm/bpmn2/ProcessFactoryTest.java
//http://mrdreambot.ddns.net/building-a-bpms-web-application-part-1-code-generation/

public class MainClass {

	public static void main(String[] args) {
		
		Date _Date=getInvoiceDate();
		
		RuleFlowProcessFactory factory =

			    RuleFlowProcessFactory.createProcess("com.sample.bpmn.hello");

			factory

			    // Header

			    .name("HelloWorldProcess")

			    .version("1.0")

			    .packageName("org.jbpm")

			    // Nodes

			    .startNode(1).name("Start").done()

			    .actionNode(2).name("Action")

			        .action("java", "System.out.println(\"hi\");").done()
			    //.action(getStatus())
			    .endNode(3).name("End").done()

			    // Connections

			    .connection(1, 2)

			    .connection(2, 3);

			RuleFlowProcess process = factory.validate().getProcess();
					
			
		// TODO Auto-generated method stub
			  KieHelper kieHelper = new KieHelper();

			  KieBase kieBase = kieHelper

			                    .addResource(ResourceFactory.newByteArrayResource(

			                    	    XmlBPMNProcessDumper.INSTANCE.dump(process).getBytes()), ResourceType.BPMN2)

			                    .build();


			KieSession ksession = kieBase.newKieSession();
			
			ksession.startProcess("com.sample.bpmn.hello");
			
		
			
					
	}

	private static String getStatus() {
		// TODO Auto-generated method stub
		
		return "transfer";
		
	}

	private static Date getInvoiceDate() {
		// TODO Auto-generated method stub
		String expectedPattern = "MM/dd/yyyy";
		Date d = null;
	    SimpleDateFormat formatter = new SimpleDateFormat(expectedPattern);
	    try {
			d = formatter.parse("03/07/2011");
			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    return d;
	}

}
