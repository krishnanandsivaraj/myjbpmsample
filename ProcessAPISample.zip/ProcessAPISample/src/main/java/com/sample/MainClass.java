package com.sample;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;



import java.util.HashMap;
import java.util.Map;





import org.drools.core.process.core.datatype.impl.type.ObjectDataType;
import org.drools.core.process.instance.WorkItem;
import org.drools.core.spi.ProcessContext;
import org.jbpm.bpmn2.xml.XmlBPMNProcessDumper;
import org.jbpm.ruleflow.core.RuleFlowProcess;
import org.jbpm.ruleflow.core.RuleFlowProcessFactory;
import org.jbpm.ruleflow.instance.RuleFlowProcessInstance;
import org.kie.api.KieBase;
import org.kie.api.io.ResourceType;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.process.ProcessInstance;
import org.kie.internal.builder.KnowledgeBuilder;
import org.kie.internal.builder.KnowledgeBuilderFactory;
import org.kie.internal.io.ResourceFactory;
import org.kie.internal.utils.KieHelper;

//https://github.com/marianbuenosayres/jBPM6-Developer-Guide/blob/master/chapter-02/jBPM6-quickstart/src/test/java/com/wordpress/marianbuenosayres/quickstart/ProgrammedProcessExecutionTest.java
//https://github.com/droolsjbpm/jbpm/blob/master/jbpm-bpmn2/src/test/java/org/jbpm/bpmn2/ProcessFactoryTest.java
//http://mrdreambot.ddns.net/building-a-bpms-web-application-part-1-code-generation/

public class MainClass {
	

	public static void main(String[] args) {
		MainModel model=new MainModel();
		Map<String,Object> mapping=new HashMap<String,Object>();
		mapping.put(model.Name, getStatus(model));
		//ProcessContext kcontext=null;
		KnowledgeBuilder kbuilder = 
				KnowledgeBuilderFactory.newKnowledgeBuilder();
		createWorkflow(kbuilder,mapping);
		
		
		
		/*RuleFlowProcess process = factory.validate().getProcess();
		KieBase kieBase = getResource(process);
		KieSession ksession = kieBase.newKieSession();
		kcontext=new ProcessContext(ksession);
		kcontext.setVariable(model.Name, getStatus(model));
		ksession.startProcess("com.sample.bpmn.hello",mapping);	*/			
	}

	private static KieBase getResource(RuleFlowProcess process) {
		KieHelper kieHelper = new KieHelper();

		  KieBase kieBase = kieHelper

		                    .addResource(ResourceFactory.newByteArrayResource(

		                    	    XmlBPMNProcessDumper.INSTANCE.dump(process).getBytes()), ResourceType.BPMN2)

		                    .build();
		return kieBase;
	}

	private static void createWorkflow(KnowledgeBuilder kbuilder,Map<String,Object> models) {
		MainModel model=new MainModel();
		models.put("status", getStatus(model));
		Map<String,Object> mapping=new HashMap<String,Object>();
		mapping.put("model.Name", getStatus(model));
		
		RuleFlowProcessFactory factory =
				
			    RuleFlowProcessFactory.createProcess("com.sample.bpmn.hello").packageName("org.jbpm").imports("java.util.HashMap").variable("results",new ObjectDataType("java.lang.String"));

			factory

			    // Header

			    .name("HelloWorldProcess")

			    .version("1.0")

			    .packageName("org.jbpm")

			    // Nodes

			    .startNode(1).name("Start").done()

			   
			    
		    	.actionNode(2).name("transfer")

			    .action("java","results=(String)kcontext.getVariable(\"model.Name\");"+"System.out.println(results);").done()

			   .endNode(3).name("End").done()

			    // Connections

			    .connection(1, 2)

			    .connection(2, 3);
			
			RuleFlowProcess process = factory.validate().getProcess();
			KieBase kieBase = getResource(process);
			KieSession ksession = kieBase.newKieSession();
			ProcessContext kcontext=new ProcessContext(ksession);
			//ProcessInstance processInstance = ksession.getProcessInstance();
			//ProcessInstance processInstance = ksession.getProcessInstance(work.getProcessInstanceId());
			ProcessInstance processInstance = ksession.startProcess("com.sample.bpmn.hello",mapping);
			kcontext.setProcessInstance(processInstance);
			//kcontext.setVariable(model.Name, getStatus(model));
			//kcontext.setVariable(model.Name.toString(), "Transferred");
			
	}

	//private static String getStatus(MainModel model) {
	private static String getStatus(MainModel model) {

		// TODO Auto-generated method stub
		model.Name="Transferred";
		
		return model.Name;
		
	}

}
