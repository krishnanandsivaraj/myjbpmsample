package com.sample;

public class MainModel {
	
	public String Name;

}
