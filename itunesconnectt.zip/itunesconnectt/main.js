var itc = require("itunesconnect");
var Report = itc.Report;
 
// Connect to iTunes 
var itunes = new itc.Connect('email', 'password');

console.log('connected');


var query =  Report
            .ranked()
            .date('2017-08-04', '2017-08-04')
            .group('platform')
            .measures(['units']);
            //.transaction(['1','2','3','4']);
// Simple ranked report 
itunes.request(query, function(error, result) {
    console.log(result);
});
 
// // Or 
// itunes.request(Report('timed').time(3, 'weeks').interval('week'), function(error, result) {
//     if(error){console.log(error);}
//     console.log('The result is '+result);
// });