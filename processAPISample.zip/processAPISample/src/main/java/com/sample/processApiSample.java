package com.sample;

import org.drools.core.impl.KnowledgeBaseImpl; 
import org.jbpm.process.instance.impl.Action; 
import org.jbpm.ruleflow.core.RuleFlowProcess; 
import org.jbpm.workflow.core.DroolsAction; 
import org.jbpm.workflow.core.impl.ConnectionImpl; 
import org.jbpm.workflow.core.node.ActionNode; 
import org.jbpm.workflow.core.node.EndNode; 
import org.jbpm.workflow.core.node.StartNode; 

import org.kie.api.KieBase; 
import org.kie.api.KieServices; 
import org.kie.api.runtime.KieSession; 
import org.kie.api.runtime.process.ProcessContext; 
import org.kie.api.runtime.process.ProcessInstance; 




//import org.drools.builder.KnowledgeBuilder;
//import org.drools.builder.KnowledgeBuilderFactory;
//import org.drools.builder.ResourceType;
//import org.kie.internal.builder.KnowledgeBuilder;
//import org.drools.io.ResourceFactory;

public class processApiSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RuleFlowProcess processDef = createProcessDefinition();
		
		KieSession ksession = createSessionForProcess(processDef); 
		ProcessInstance instance = ksession.startProcess("myProgramaticProcess");
		System.out.println(instance.getState());

	}
	
	private static KieSession createSessionForProcess(RuleFlowProcess process) { 
		 
		KieBase kbase = KieServices.Factory.get().getKieClasspathContainer().getKieBase();  
		KnowledgeBaseImpl intKbase = (KnowledgeBaseImpl) kbase; 
		intKbase.addProcess(process); 
		return kbase.newKieSession(); 
	} 

	
	/** 
	62 	 * Creates a process defininiton programmatically using the 
	63 	 * jBPM6 internal APIs 
	64 	 * @return a RuleFlowProcess instance (not to be confused with a RuleFlowProcessInstance instance) 
	65 	 */ 
	private static RuleFlowProcess createProcessDefinition() { 
			 
		//Process Definition 
	    	RuleFlowProcess process = new RuleFlowProcess(); 
	    	process.setId("myProgramaticProcess"); 
	    	 
	   	//Start Task 
	    	StartNode startTask = new StartNode(); 
	     	startTask.setId(1); 
	   	 
	    	//Script Task 
	    	ActionNode scriptTask = new ActionNode(); 
	    	scriptTask.setId(2); 
	   	DroolsAction action = new DroolsAction(); 
	     	action.setMetaData("Action", new Action() { 
				@Override 
				public void execute(ProcessContext context) throws Exception { 
					System.out.println("Executing the Action!!"); 
				} 
			}); 
			scriptTask.setAction(action); 
			 
			//End Task 
	  	EndNode endTask = new EndNode(); 
	   	endTask.setId(3); 
	
	 
	   	//Adding the connections to the nodes and the nodes to the process 
	    	new ConnectionImpl(startTask, "DROOLS_DEFAULT", scriptTask, "DROOLS_DEFAULT"); 
	    	new ConnectionImpl(scriptTask, "DROOLS_DEFAULT", endTask, "DROOLS_DEFAULT"); 
	    	process.addNode(startTask); 
	   	process.addNode(scriptTask); 
	   	process.addNode(endTask); 
	    	 
	    	return process; 
		} 


}
