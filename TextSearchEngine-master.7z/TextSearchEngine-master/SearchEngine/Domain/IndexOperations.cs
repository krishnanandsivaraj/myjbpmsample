﻿using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace SearchEngine
{
    public class IndexOperations : SearchBase, IFactory
    {
        SearchBase search = new SearchBase();
        public Dictionary<string, List<string>> Search(string[] s)
        {
            Dictionary<string, List<string>> output = search.BaseSearch(s);
            
            var items = output.SelectMany(d => d.Value).ToList();
            List<string> keys = new List<string>(output.Keys);

            if (!File.Exists("index.txt")) {
                StreamWriter file = File.CreateText("index.txt"); using (file)
                {
                    foreach (var key in keys)
                    {
                        file.Write(key + " contained in :");
                        foreach (var item in output[key])
                        {
                            file.Write(" " + item + ",");
                        }
                        file.WriteLine();
                    }
                }
            }
            else
            {
               
                    string line;
                    using (StreamReader file = new StreamReader(Directory.GetCurrentDirectory() + @"\index.txt"))
                    {
                        line = file.ReadLine();
                    }
                    foreach (var t in s) {
                        if (line.Contains(t)) {
                            System.Console.WriteLine(line);
                        }
                            }
                

            }
            return output;

        }

    }
}
