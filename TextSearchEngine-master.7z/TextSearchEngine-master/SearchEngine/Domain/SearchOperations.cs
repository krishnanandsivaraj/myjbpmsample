﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchEngine
{
    class SearchOperations : SearchBase, IFactory
    {
        SearchBase search = new SearchBase();
        public Dictionary<string, List<string>> Search(string[] s)
        {

            Dictionary<string, List<string>> output = search.BaseSearch(s);

            var items = output.SelectMany(d => d.Value).ToList();
            List<string> keys = new List<string>(output.Keys);
            foreach (var key in keys)
            {
                Console.Write(key + " contained in :");
                foreach (var item in output[key])
                {
                    Console.Write(" " + item + ",");
                }
                Console.WriteLine();
            }
            return output;

        }
    }
}
