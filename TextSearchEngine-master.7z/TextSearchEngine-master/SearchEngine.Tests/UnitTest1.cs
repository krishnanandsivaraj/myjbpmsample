﻿using System;
using NUnit;
using NUnit.Framework;

namespace SearchEngine.Tests
{
    [TestFixture]
    public class UnitTest1
    {
        [Test]
        public void TestMethod1()
        {
        }
    }
}
