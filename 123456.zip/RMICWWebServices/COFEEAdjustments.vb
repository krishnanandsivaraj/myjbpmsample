﻿''Public Class COFEEAdjustments

''End Class
Imports CommonLibrary
Imports System.Xml
Imports System.Xml.Serialization
Imports System.IO
Imports System.Web.Services
Imports System.Globalization
Imports System.Net
Imports System.Text.RegularExpressions
Imports Microsoft.Web.Services2.Security
Imports Microsoft.Web.Services2
Imports Microsoft.Web.Services2.Dime
Imports System.Web.Services.Protocols
Imports System.Diagnostics
Imports Microsoft.Web.Services2.Security.Tokens

Namespace Verizon.RMICW.WebServices

    Public Class COFEEAdjustments
        Inherits RMICWWSBase

        Public Sub New(ByVal strRegionId As String)
            MyBase.New(strRegionId)
        End Sub

        Dim objWSCommon As WSCommonClasses = New WSCommonClasses

        Public Function IssueCoffeAdj(ByVal objRequest As InpRequest) As String
            Dim i As Integer
            Dim ds1, ds2, ds3 As DataSet
            Dim dr1, dr2, dr3 As DataRow
            Dim objCofeeInp As InpRequest
            Dim strparmvalue As String

            Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(objRequest.strRegionId.Trim())
            strparmvalue = ObjDataAccess.usp_GetControlParmByName("ControlWEST", "COFEERSTURL")

            'Dim strparmvalue As String = strvalue.Tables(0).Rows(0).Item("strParmValue").ToString()
            Dim strURL As String = strparmvalue.Split(","c)(0)
            Dim struserid As String = strparmvalue.Split(","c)(1)
            Dim strpasswd As String = strparmvalue.Split(","c)(2)
            Dim CofeeLumpSumRequest1 As CofeeLumpSumRequest = New CofeeLumpSumRequest
            Dim Adjustment1 As Adjustmenty = New Adjustmenty

            Try

                ' Get the Reconnect Fee
                ds1 = ObjDataAccess.usp_GetReconnectFee(objRequest.strRegionId, objRequest.strOrg, objRequest.strActn, objRequest.strCompanyCd, objRequest.strLocationCd, objRequest.strClassOfService, objRequest.strlinetype)
                If (Not ObjDataAccess.IsEmptyRecordSet(ds1)) Then
                    If (ds1.Tables(0).Rows.Count > i) Then
                        dr1 = ds1.Tables(0).Rows(i)
                        objRequest.strAdjustmentCd = dr1("strAdjustmentCd")
                        objRequest.strRstFeeLevel = dr1("strRstFeeLevel")
                        objRequest.curAdjustmentAmt = dr1("curRestoreFee")

                        If objRequest.strRstFeeLevel = "A" Then
                            objRequest.curAdjustmentAmt = dr1("curRestoreFee")
                        Else
                            If objRequest.strRstFeeLevel = "L" Then
                                objRequest.curAdjustmentAmt = objRequest.strlinetype * objRequest.curAdjustmentAmt
                            End If
                        End If
                    End If
                End If

                CofeeLumpSumRequest1.strUserID = struserid
                CofeeLumpSumRequest1.strPasswd = strpasswd
                CofeeLumpSumRequest1.strAccountNum = Trim(objRequest.strAcctNum)
                CofeeLumpSumRequest1.strCompany = Trim(objRequest.strCompanyCd)
                CofeeLumpSumRequest1.strState = objRequest.strState
                CofeeLumpSumRequest1.strCallingParty = "iCollect"
                CofeeLumpSumRequest1.IsInterestIncluded = "false"
                CofeeLumpSumRequest1.IsTaxIncluded = "TRUE"
                CofeeLumpSumRequest1.STRRAO = ""
                CofeeLumpSumRequest1.BillCycle = objRequest.dtmBillDate
                CofeeLumpSumRequest1.Remarks = "iCollectAdjustment Lumpsumadjustment"
                CofeeLumpSumRequest1.TrackingID = objRequest.intRequestId
                Adjustment1.strSubCIC = ""
                Adjustment1.strPSP = "00000"
                CofeeLumpSumRequest1.AdjustmentDetails.Adjustment.DPCode = objRequest.strAdjustmentCd.Substring(0, 2)
                CofeeLumpSumRequest1.AdjustmentDetails.Adjustment.ActionCode = objRequest.strAdjustmentCd.Substring(2, 2)
                CofeeLumpSumRequest1.AdjustmentDetails.Adjustment.TypeCode = objRequest.strAdjustmentCd.Substring(4, 2)
                CofeeLumpSumRequest1.AdjustmentDetails.Adjustment.AdjustmentAmount = objRequest.curAdjustmentAmt

                Dim xmlSer As XmlSerializer = New XmlSerializer(GetType(CofeeLumpSumRequest))
                Dim strXML As String = CommonLibrary.GeneralRoutine.SerializeTxn(xmlSer, CofeeLumpSumRequest1)

                Dim objwebref As WSCoffeAdjustments.iCollectVoiceAdjustments = New WSCoffeAdjustments.iCollectVoiceAdjustments

                objwebref.Url = strURL
                Dim RequestContext As SoapContext
                RequestContext = objwebref.RequestSoapContext
                objwebref.Proxy = New WebProxy
                RequestContext.Security.Tokens.Clear()

                Dim userToken As UsernameToken = New UsernameToken("" + "RMW" + "", "" + "rmicw05" + "", PasswordOption.SendPlainText)
                RequestContext.Security.Tokens.Add(userToken)
                RequestContext.Security.MustUnderstand = False

                InsertIntoRequestFeedIL(objRequest)

                Dim COFFEERESULT As String
                COFFEERESULT = objwebref.postLumpSumAdjustment(strXML)

                'MsgBox(COFFEERESULT)
                Dim xmlDoc As XmlDocument = New XmlDocument
                Dim xmlelementroot As XmlElement
                xmlDoc.XmlResolver = Nothing
                xmlDoc.LoadXml(COFFEERESULT)
                xmlelementroot = xmlDoc.DocumentElement
                Dim Successful As String = xmlelementroot.GetAttribute("Successful")
                If Successful = "1" Then

                    Dim xmlEle As XmlElement
                    xmlEle = xmlDoc.DocumentElement
                    objRequest.strVoucherNum = xmlEle.GetElementsByTagName("VoucherNumber").Item(0).InnerXml()
                    objRequest.curVoucherAmt = xmlEle.GetElementsByTagName("VoucherAmount").Item(0).InnerXml()
                    objRequest.curVoucherAmt1 = Strings.Format(CDbl(objRequest.curVoucherAmt), "##,##0.00")
                    objRequest.STATUSCD = "CP"

                    InserttRecourseCarrierInfocofee(objRequest)
                    objRequest.REMARKS = objRequest.strVoucherNum
                    updateRequestFeed(objRequest)
                    InsertRequest(objRequest)
                    'MsgBox(objInp.strVoucherNum)
                    'MsgBox(objInp.curVoucherAmt)
                Else
                    LogErrorFile.WriteLog("ERROR from cofee webservice", COFFEERESULT)
                    Dim strpart1 As String = xmlelementroot.GetAttribute("Message")
                    objRequest.REMARKS = strpart1
                    objRequest.STATUSCD = "ER"
                    insertintoaudittrail(objRequest)
                    updateRequestFeed(objRequest)
                    InsertRequest(objRequest)
                End If

            Catch ex As Exception
                LogErrorFile.WriteLog("COFEEAdjustment", ex.ToString)
            End Try

        End Function

        Public Function insertintoaudittrail(ByVal objInp As InpRequest) As Integer
            Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(objInp.strRegionId.Trim())
            Dim i As Integer
            Try
                i = objDataAccess.usp_InsertAuditTrail("CFERST", "CFERST", objInp.strOrg, objInp.strActn, "L", objInp.strAcctNum, objInp.XML & objInp.RESULT)
            Catch ex As Exception
                LogErrorFile.WriteLog("COFEEAdjustment", "Cofee Adjustment Process Error " + ex.ToString())
            End Try
        End Function

        Public Function InserttRecourseCarrierInfocofee(ByVal objInp As InpRequest) As Integer
            Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(objInp.strRegionId.Trim())
            Dim i As Integer
            Try
                i = ObjDataAccess.usp_InsRecourseCarrierInfocofee(objInp.strVoucherNum, objInp.curAdjustmentAmt, objInp.strAcctNum, objInp.intRequestId, objInp.strAdjustmentCd, objInp.servicelines)
            Catch ex As Exception
                LogErrorFile.WriteLog("COFEEAdjustment", "Cofee Adjustment Process Error " + ex.ToString())
            End Try
        End Function



        Private Function InsertIntoRequestFeedIL(ByVal objInp As InpRequest) As Integer
            Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(objInp.strRegionId.Trim())
            Dim i As Integer
            Try
                Dim requestedby As String
                Dim returncode As String
                Dim requestfeedamt As String
                requestedby = "CFERST"
                objInp.STATUSCD = "IL"
                returncode = "CFJADJIL"
                requestfeedamt = "NULL"

                i = ObjDataAccess.usp_InsertRequestFeed1("REQ", objInp.intRequestIdO, objInp.strAcctNum, requestedby, "TRRST", requestedby, objInp.STATUSCD, "TRRST", "RST", returncode, "N", requestfeedamt, requestedby, objInp.dtmPrcsdTs)

            Catch ex As Exception
                'LogErrorFile.WriteLog("COFEEAdjustment", "Cofee Adjustment Process Error " + ex.ToString())
            End Try
        End Function

        Private Function updateRequestFeed(ByVal objInp As InpRequest) As Integer
            Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(objInp.strRegionId.Trim())
            Dim i As Integer
            Try
                Dim requestedby As String
                Dim returncode As String
                Dim requestfeedamt As String
                requestedby = "CFERST"
                If objInp.STATUSCD = "CP" Then
                    returncode = "CFJADJCP"
                    requestfeedamt = objInp.curVoucherAmt1
                Else
                    If objInp.STATUSCD = "ER" Then
                        returncode = "CFJADJER"
                        requestfeedamt = "NULL"
                    End If
                End If

                i = ObjDataAccess.usp_updateRequestFeedcf("REQ", objInp.intRequestIdO, objInp.strAcctNum, requestedby, "TRRST", requestedby, objInp.STATUSCD, "TRRST", "RST", returncode, "N", requestfeedamt, requestedby, objInp.dtmPrcsdTs)

            Catch ex As Exception
                'LogErrorFile.WriteLog("COFEEAdjustment", "Cofee Adjustment Process Error " + ex.ToString())
            End Try
        End Function

        Private Function InsertIntoRequestFeed2(ByVal objCofeeInp As InpRequest) As Integer

            Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(objCofeeInp.strRegionId.Trim())
            Dim i As Integer
            Try
                Dim requestedby As String
                Dim returncode As String
                Dim requestfeedamt As String
                requestedby = "CFERST"
                objCofeeInp.STATUSCD = "VD"
                returncode = "CFJADJVD"
                requestfeedamt = "NULL"

                i = ObjDataAccess.usp_InsertRequestFeed1("REQ", objCofeeInp.intRequestIdO, objCofeeInp.strAcctNum, requestedby, "TRRST", requestedby, objCofeeInp.STATUSCD, "TRRST", "RST", returncode, "N", requestfeedamt, requestedby, objCofeeInp.dtmPrcsdTs)

            Catch ex As Exception
                'LogErrorFile.WriteLog("COFEEAdjustment", "Cofee Adjustment Process Error " + ex.ToString())
            End Try
        End Function

        Private Function InsertRequest(ByVal objInp As InpRequest) As Integer

            Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(objInp.strRegionId.Trim())
            Dim i As Integer
            Dim returncode As String
            Dim condcode As String
            If objInp.STATUSCD = "CP" Then
                returncode = "CFJADJCP"
                'condcode = "CFJADJCP"
            Else
                If objInp.STATUSCD = "ER" Then
                    returncode = "CFJADJER"
                    'condcode = "CFJADJER"
                End If
            End If
            Try
                i = ObjDataAccess.usp_InsertRequest1(objInp.strAcctNum, objInp.strOrg, objInp.strClassOfService, "TRRST", objInp.STATUSCD, objInp.curVoucherAmt1, 0, "RMICW", "N", "RISO", returncode, "RB", "RST", "CFERST", "ALL", objInp.strBTNNum, objInp.REMARKS, System.DateTime.Now(), objInp.strEnv)

            Catch ex As Exception
                LogErrorFile.WriteLog("COFEEAdjustment", "Cofee Adjustment Process Error " + ex.ToString())
            End Try
        End Function

    End Class


    <System.Xml.Serialization.XmlRootAttribute("Request", [Namespace]:="", IsNullable:=False)> _
    Public Class CofeeLumpSumRequest
        Public strUserID As String
        Public strPasswd As String
        Public strAccountNum As String
        Public strCompany As String
        Public strState As String
        Public strCallingParty As String
        Public IsInterestIncluded As Boolean
        Public IsTaxIncluded As Boolean
        Public BillCycle As String
        Public STRRAO As String
        Public Remarks As String
        Public TrackingID As String
        Public AdjustmentDetails As Adjustmentn

        Public Sub New()
            strUserID = "RMICW2"
            strPasswd = Utilities.GetPwd()
            strAccountNum = ""
            strCompany = ""
            strState = ""
            strCallingParty = ""
            IsInterestIncluded = False
            IsTaxIncluded = True
            BillCycle = New DateTime(1900, 1, 1)
            Remarks = ""
            TrackingID = ""
            AdjustmentDetails = New Adjustmentn
        End Sub

    End Class

    <Serializable()>
    Public Class Adjustmentn
        Public Adjustment As Adjustmenty
        Public Sub New()
            Adjustment = New Adjustmenty
        End Sub
    End Class

    <Serializable()>
    Public Class Adjustmenty
        Public DPCode As String
        Public ActionCode As String
        Public TypeCode As String
        Public AdjustmentAmount As Double
        Public strSubCIC As String
        Public strPSP As String

        Public Sub New()
            DPCode = ""
            ActionCode = ""
            TypeCode = ""
            AdjustmentAmount = "0.00"
            strSubCIC = ""
            strPSP = "00000"
        End Sub
    End Class

    Public Class InpRequest
        Public userid As String
        Public password As String
        Public URLLUMPSUM As String
        Public strRegionId As String
        Public intRequestId As Long
        Public intRequestIdO As Long
        Public strAcctNum As String
        Public strBTNNum As String
        Public strActn As String
        Public ACTN As String
        Public strStatusCd As String
        Public dtmPrcsdTs As DateTime
        Public dtmMasterServiceDate As DateTime
        Public strClassOfService As String
        Public servicelines As Long
        Public strCompanyCd As String
        Public strLocationCd As String
        Public strOrg As String
        Public strEnv As String
        Public dtmBillDate As Date
        Public strlinetype As String
        Public strrao As String
        Public strState As String
        Public strAdjustmentCd As String
        Public REMARKS As String
        Public STATUSCD As String
        Public strRstFeeLevel As String
        Public strDPCd As String
        Public strActnCd As String
        Public strTypeCd As String
        Public curAdjustmentAmt As Double
        Public strVoucherNum As String
        Public curVoucherAmt As Double
        Public curVoucherAmt1 As String
        Public XML As String
        Public RESULT As String

        Public Sub New()
            userid = ""
            'password = ""
            URLLUMPSUM = ""
            intRequestId = 0
            intRequestIdO = 0
            strAcctNum = ""
            strBTNNum = ""
            strActn = ""
            ACTN = ""
            strStatusCd = ""
            dtmPrcsdTs = "1900/01/01"
            dtmMasterServiceDate = "1900/01/01"
            strClassOfService = ""
            servicelines = 0
            strCompanyCd = ""
            strLocationCd = ""
            strOrg = ""
            strEnv = ""
            dtmBillDate = "1900/01/01"
            strlinetype = ""
            strrao = ""
            strState = ""
            strAdjustmentCd = ""
            REMARKS = ""
            STATUSCD = ""
            strRstFeeLevel = ""
            strDPCd = ""
            strActnCd = ""
            strTypeCd = ""
            curAdjustmentAmt = "0.0"
            strVoucherNum = ""
            curVoucherAmt = "0.0"
            curVoucherAmt1 = ""
            XML = ""
            RESULT = ""

        End Sub

    End Class

End Namespace