﻿'***************************************************************************************************
' Page Name     : MDVW_RMVP_Strata.vb                                                                          
' 
'****************************************************************************************************
'                               CHANGE MANANGEMENT                                                   *
'                                                                                                    *
'*****************************************************************************************************
' Date      Author                  Purpose                                             Identified By   *
'*****************************************************************************************************
'04/20/11   Murugan/Sasi          For MDVW Strata - Calling iCollect WS                
'
'****************************************************************************************************

Imports System.IO
Imports System.Text
Imports System.Xml
Imports System.Xml.Serialization
Imports System.Xml.XmlDataDocument
Imports CommonLibrary
Imports Verizon.RMICW.DataAccess
Imports System.Threading.Thread
Imports System.Text.RegularExpressions
Imports System.Net
Imports Microsoft.Web.Services2
Imports Microsoft.Web.Services2.Security

Namespace Verizon.RMICW.WebServices


    'Public Class XBCLSPA3

    '    Public strAcctNum As String

    '    Public objAccountDtls As MDVW_RMVP_Strata.AccountDetails
    '    <System.Xml.Serialization.XmlElement(ElementName:="BillDetails", Type:=GetType(BillDetails))> _
    '    Public arrLstBalanceInfoDetails As ArrayList
    '    Public RequestStatus As StatusOfRequest

    '    Public Sub New()

    '        arrLstBalanceInfoDetails = New ArrayList
    '        objAccountDtls = New MDVW_RMVP_Strata.AccountDetails
    '        RequestStatus = New StatusOfRequest
    '    End Sub
    'End Class

    'Public Class BillDetail


    '    Public curTotBilled As Double
    '    Public curBalDueAmt As Double
    '    Public intMonthPastInd As Integer
    '    Public dtmBillDt As DateTime
    '    Public dtmPayByDt As DateTime
    '    Public curBasicAmt As Double
    '    Public curNonBasicAmt As Double
    '    Public curTollAmt As Double
    '    Public curOcarAmt As Double
    '    Public curWrlsAmt As Double
    '    Public curDAAmt As Double
    '    Public curIPAmt As Double
    '    Public curCPEAmt As Double

    '    Public Sub New()
    '        curTotBilled = 0.0
    '        curBalDueAmt = 0.0
    '        intMonthPastInd = 0
    '        dtmBillDt = "1900/01/01"
    '        dtmPayByDt = "1900/01/01"
    '        curBasicAmt = 0.0
    '        curNonBasicAmt = 0.0
    '        curTollAmt = 0.0
    '        curOcarAmt = 0.0
    '        curWrlsAmt = 0.0
    '        curIPAmt = 0.0
    '        curCPEAmt = 0.0
    '    End Sub
    'End Class


    Public Class MDVW_RMVP_Strata
        Inherits RMICWWSBase
        Public Shared strNPDRegID As String
        Public ObjDataAccess As WSDataAccessGeneric
        Private objWEDIOutputLayout As New RMICWDataInterfaceLayout
        Private objWEDIOutput As New RMICWDataInterfaceDetails

        Public objiCollectAcctDtls As New AccountDetails
        Public objiCollectPayDtls As New PAYNotationDetails

        Private dtAccountBalance As DataTable
        Private dtLetterDetails As DataTable
        Private dtAccountLive As DataTable

        Dim curTotBilled As String = "0.00"
        Dim strOrgCode As String

        Dim strWSTimeoutError As String
        Dim strOriginationId As String
        Dim strAction As String
        Dim curLetterTotalAmt As Double = "0.00"


#Region "REGION INFO"
        Public Sub RegionInfo(ByVal strreg As String)
            Dim strRegion As String = "Prod" + strreg
            strNPDRegID = Trim(strRegion)
        End Sub
#End Region

#Region "Constructor"
        Public Sub New(ByVal strRegionId As String)
            MyBase.New(strRegionId)
        End Sub
#End Region

#Region "get_XBCLSPA3"
        Public Function get_XBCLSPA3_Icollect(ByVal strRegionId As String, ByVal strAcctountNum As String) As XBCLSPA5

            Dim objXBCLSPA3 As XBCLSPA5 = New XBCLSPA5
            Dim objRequestContext As SoapContext
            Dim urlERROR As String
            Try

                Dim dsgetparmVal As New DataSet
                Dim logdate, logdate1, logdate2 As DateTime

                ' for logging time stamp
                Dim timelogval As String
                Dim dsgetparmValtimelog As New DataSet

                logdate1 = logdate.Now

                objiCollectAcctDtls = New AccountDetails
                objWEDIOutput.arrLstBalanceInfoDetails = New ArrayList
                objWEDIOutput.arrLstBalanceInfoDetails.Add(New BillDetails)
                objWEDIOutput.objLettersDetails = New LettersDetails
                objWEDIOutput.arrLstPAYNotationDetails = New ArrayList
                objWEDIOutput.arrLstHistDetails = New ArrayList


                logdate2 = logdate.Now

                Dim logdatecall1, logdatecall2, logdatenot1, logdatenot2 As DateTime
                Dim stracctnm As String
                Dim strUrl As String
                Dim strAccttemp, strAddInfo As String
                Dim objIcollAcctData As New IcollectWebServiceDataRetrieve.PA_Svc
                Dim objIcollRetAccData As New IcollectWebServiceDataRetrieve.AccountDataWest
                Dim objLetterDetails As New LettersDetails
                Dim errMsg As String
                Dim objBillDtls As BillDetails
                Dim objRequestStatus As New StatusOfRequest

                strAccttemp = ""
                strAddInfo = ""



                dsgetparmVal = usp_GetControlParmByName("ControlMDVW", "EDI")
                strURL = dsgetparmVal.Tables(0).Rows(0).Item("strParmValue").ToString()
                'strURL = "http://sacd1lrrmd01.ITSBI1.ITCENT.EBIZ.VERIZON.COM/iCollectwebServices/pa_svc.asmx"

                objRequestContext = objIcollAcctData.RequestSoapContext
                objIcollAcctData.Proxy = New WebProxy
                objRequestContext.Security.Tokens.Clear()
                Dim unt As Tokens.UsernameToken = New Tokens.UsernameToken("RMW", "rmicw05", Tokens.PasswordOption.SendPlainText)
                objRequestContext.Security.Tokens.Add(unt)
                objRequestContext.Security.MustUnderstand = False
                objIcollAcctData.Timeout = 90000
                objIcollAcctData.Url = strUrl.Trim()

                'objIcollAcctData.Proxy = New WebProxy
                'objIcollAcctData.Timeout = 90000
                'objIcollAcctData.Url = strURL
                'System.Threading.Thread.Sleep(25)                                           'MM08032009

                logdatecall1 = logdate.Now
                urlERROR = "TRUE"
                objIcollRetAccData = objIcollAcctData.PA_RMICW_RetrieveAccountDataWest(strAcctountNum)
                urlERROR = "FALSE"
                logdatecall2 = logdate.Now


                If objIcollRetAccData.datAcctGeneralDataWest.ResponseStatus > 0 And objIcollRetAccData.datAcctGeneralDataWest.ResponseStatusMinorCode.Trim = "101" Then
                    objRequestStatus.strMessageDescription = "NFNDICLT"
                    objRequestStatus.strMessageId = objIcollRetAccData.datAcctGeneralDataWest.ResponseStatusMinorCode.Trim
                ElseIf objIcollRetAccData.datAcctGeneralDataWest Is Nothing Or objIcollRetAccData.datAcctGeneralDataWest.ResponseStatus > 0 Then
                    errMsg = "IColl-WebSvcErr:" + objIcollRetAccData.datAcctGeneralDataWest.ResponseStatus.ToString.Trim + "-" + objIcollRetAccData.datAcctGeneralDataWest.ResponseStatusMinorCode.ToString.Trim + ":" + objIcollRetAccData.datAcctGeneralDataWest.ResponseStatusDetails.Trim
                    CommonLibrary.LogErrorFile.WriteLog("MDVW_RMVP_strata-" + strAcctountNum, errMsg, 1, 999, "Error")
                    urlERROR = "TRUE"
                Else

                    '******************      datAcctGeneralDataWest   ******************************
                    stracctnm = objIcollRetAccData.datAcctGeneralDataWest.strAccountNumber
                    If Not objIcollRetAccData.datAcctGeneralDataWest.strMasterAccount Is Nothing Then
                        objiCollectAcctDtls.strSBMId = objIcollRetAccData.datAcctGeneralDataWest.strMasterAccount.Trim
                    End If
                    If Not objIcollRetAccData.datAcctGeneralDataWest.strComplaints Is Nothing Then
                        If objIcollRetAccData.datAcctGeneralDataWest.strComplaints.Trim = "PUC" Then
                            strAccttemp = strAccttemp.Trim + "#PUC#"
                        ElseIf objIcollRetAccData.datAcctGeneralDataWest.strComplaints.Trim = "HML" Then
                            strAccttemp = strAccttemp.Trim + "#HML#"
                        End If
                    End If
                    If Not objIcollRetAccData.datAcctGeneralDataWest.strMedicalemergencyInd Is Nothing Then
                        If objIcollRetAccData.datAcctGeneralDataWest.strMedicalemergencyInd.Trim = "1" Then
                            strAccttemp = strAccttemp.Trim + "#ME#"
                        End If
                    End If

                    If Not objIcollRetAccData.datAcctGeneralDataWest.strVacationServices Is Nothing Then  'AR05212009
                        strAccttemp = objIcollRetAccData.datAcctGeneralDataWest.strVacationServices.ToString.Trim
                    End If
                    If Not objIcollRetAccData.datAcctGeneralDataWest.strBillingName Is Nothing Then
                        objiCollectAcctDtls.strCustName = objIcollRetAccData.datAcctGeneralDataWest.strBillingName.Trim
                    End If
                    If Not objIcollRetAccData.datAcctGeneralDataWest.BehaviourScore.ToString Is Nothing Then
                        objiCollectAcctDtls.strBehavScr = objIcollRetAccData.datAcctGeneralDataWest.BehaviourScore.ToString.Trim
                    End If
                    If Not objIcollRetAccData.datAcctGeneralDataWest.Class Is Nothing Then
                        objiCollectAcctDtls.strCurrentClass = objIcollRetAccData.datAcctGeneralDataWest.Class.Trim
                    End If
                    If Not objIcollRetAccData.datAcctGeneralDataWest.strPermenantCollFlag Is Nothing Then
                        If objIcollRetAccData.datAcctGeneralDataWest.strPermenantCollFlag.Trim = "Y" Then
                            objiCollectAcctDtls.blnPermCollFlag = True
                        End If
                    End If
                    If Not objIcollRetAccData.datAcctGeneralDataWest.Collector Is Nothing Then
                        objiCollectAcctDtls.strCollectorId = objIcollRetAccData.datAcctGeneralDataWest.Collector.Trim
                    End If
                    If Not objIcollRetAccData.datAcctGeneralDataWest.CBReachedPhone Is Nothing Then
                        objiCollectAcctDtls.strCBR = objIcollRetAccData.datAcctGeneralDataWest.CBReachedPhone.Trim
                    End If
                    If Not objIcollRetAccData.datAcctGeneralDataWest.ReasonCD Is Nothing Then
                        objiCollectAcctDtls.strCollectionRsnCd = objIcollRetAccData.datAcctGeneralDataWest.ReasonCD.Trim
                    End If
                    If Not objIcollRetAccData.datAcctGeneralDataWest.strCompanyCode Is Nothing Then
                        objiCollectAcctDtls.strCompanyCd = objIcollRetAccData.datAcctGeneralDataWest.strCompanyCode.Trim
                    End If
                    If Not objIcollRetAccData.datAcctGeneralDataWest.strLocationCode Is Nothing Then
                        objiCollectAcctDtls.strLocationCd = objIcollRetAccData.datAcctGeneralDataWest.strLocationCode.Trim
                    End If

                    If objIcollRetAccData.datAcctGeneralDataWest.strECFInd = "Y" And objIcollRetAccData.datAcctGeneralDataWest.strRCFInd = "Y" Then
                        objiCollectAcctDtls.strPrty = "Z"
                    Else
                        objiCollectAcctDtls.strPrty = " "
                    End If

                    If objIcollRetAccData.datAcctGeneralDataWest.strECFInd = "Y" Or objIcollRetAccData.datAcctGeneralDataWest.strRCFInd = "Y" Then
                        objiCollectAcctDtls.strPrty = "Z"
                    Else
                        objiCollectAcctDtls.strPrty = " "
                    End If


                    If Not (objIcollRetAccData.datAcctGeneralDataWest.strPortedin Is Nothing) And Not (objIcollRetAccData.datAcctGeneralDataWest.strPortedout Is Nothing) And Not (objIcollRetAccData.datAcctGeneralDataWest.strCLECInd Is Nothing) Then
                        If objIcollRetAccData.datAcctGeneralDataWest.strCLECInd = "Y" Then
                            objiCollectAcctDtls.strCLECId = "CLECR"
                        ElseIf ((objIcollRetAccData.datAcctGeneralDataWest.strPortedout = "" Or objIcollRetAccData.datAcctGeneralDataWest.strPortedout = "N") And objIcollRetAccData.datAcctGeneralDataWest.strPortedin = "P") Then
                            objiCollectAcctDtls.strCLECId = "CLECP"
                        ElseIf ((objIcollRetAccData.datAcctGeneralDataWest.strPortedout = "" Or objIcollRetAccData.datAcctGeneralDataWest.strPortedout = "N") And objIcollRetAccData.datAcctGeneralDataWest.strPortedin = "F") Then
                            objiCollectAcctDtls.strCLECId = "CLECW"
                        ElseIf (objIcollRetAccData.datAcctGeneralDataWest.strPortedout = "P") Then
                            objiCollectAcctDtls.strCLECId = "CLECP"
                        ElseIf (objIcollRetAccData.datAcctGeneralDataWest.strPortedout = "F") Then
                            objiCollectAcctDtls.strCLECId = "CLECF"
                        ElseIf (objIcollRetAccData.datAcctGeneralDataWest.strPortedout = "P" And objIcollRetAccData.datAcctGeneralDataWest.strPortedin = "P") Then
                            objiCollectAcctDtls.strCLECId = "CLECP"
                        ElseIf (objIcollRetAccData.datAcctGeneralDataWest.strPortedout = "F" And objIcollRetAccData.datAcctGeneralDataWest.strPortedin = "F") Then
                            objiCollectAcctDtls.strCLECId = "CLECW"
                        ElseIf (objIcollRetAccData.datAcctGeneralDataWest.strPortedout = "N" And objIcollRetAccData.datAcctGeneralDataWest.strPortedin = "N") Then
                            objiCollectAcctDtls.strCLECId = ""
                        End If
                    Else
                        objIcollRetAccData.datAcctGeneralDataWest.strCLECInd = ""
                    End If
                    If Not objIcollRetAccData.datAcctGeneralDataWest.strFullPartialPortOut Is Nothing Then
                        objiCollectAcctDtls.intNumLinesPortedOut = objIcollRetAccData.datAcctGeneralDataWest.strFullPartialPortOut
                    End If
                    If Not objIcollRetAccData.datAcctGeneralDataWest.strRecourseInd Is Nothing Then
                        objiCollectAcctDtls.strRecourseInd = objIcollRetAccData.datAcctGeneralDataWest.strRecourseInd.Trim
                    End If
                    If Not objIcollRetAccData.datAcctGeneralDataWest.strPositionNumber Is Nothing Then
                        objiCollectAcctDtls.strPositionNbr = objIcollRetAccData.datAcctGeneralDataWest.strPositionNumber.Trim
                    End If
                    If Not objIcollRetAccData.datAcctGeneralDataWest.AccountType Is Nothing Then
                        objiCollectAcctDtls.strClassOfService = objiCollectAcctDtls.strClassOfService.Trim + objIcollRetAccData.datAcctGeneralDataWest.AccountType.Trim
                    End If
                    If Not objIcollRetAccData.datAcctGeneralDataWest.strGradeofService Is Nothing Then
                        objiCollectAcctDtls.strClassOfService = objIcollRetAccData.datAcctGeneralDataWest.strGradeofService.Trim
                    End If
                    If Not objIcollRetAccData.datAcctGeneralDataWest.strBillSuppressionInd Is Nothing Then
                        If objIcollRetAccData.datAcctGeneralDataWest.strBillSuppressionInd.Length > 1 Then
                            strAddInfo = strAddInfo + "#BS=" + objIcollRetAccData.datAcctGeneralDataWest.strBillSuppressionInd.Trim + "#"
                        End If
                    End If
                    If Not objIcollRetAccData.datAcctGeneralDataWest.strConcessionCode Is Nothing Then
                        If objIcollRetAccData.datAcctGeneralDataWest.strConcessionCode.Length > 1 Then
                            strAddInfo = strAddInfo + "#CON=" + objIcollRetAccData.datAcctGeneralDataWest.strConcessionCode.Trim + "#"
                        End If
                    End If
                    If Not objIcollRetAccData.datAcctGeneralDataWest.strNoGeographicBoundary Is Nothing Then
                        If objIcollRetAccData.datAcctGeneralDataWest.strNoGeographicBoundary.Trim = "Y" Then
                            strAddInfo = strAddInfo + "#NGB=TRUE" + "#"
                        End If
                    End If
                    If Not objIcollRetAccData.datAcctGeneralDataWest.AccountGroup Is Nothing Then
                        objiCollectAcctDtls.strCreditClass = objIcollRetAccData.datAcctGeneralDataWest.AccountGroup.Trim
                    End If

                    If Not objIcollRetAccData.datAcctGeneralDataWest.CreditEstdDt.ToString Is Nothing Then
                        objiCollectAcctDtls.dtmDOI = checkdate(objIcollRetAccData.datAcctGeneralDataWest.CreditEstdDt)
                    End If


                    '******************  datAccountBillingDataWest     *****************
                    If objIcollRetAccData.datAccountBillingDataWest Is Nothing Then
                        'default
                    Else
                        'CommonLibrary.LogErrorFile.WriteLog("RMICW_West_EDI- BehaviourScore " + strAcctNum, "datAccountBillingDataWest", 1, 999, "Error")
                        If Not objIcollRetAccData.datAccountBillingDataWest.dtmBillDate.ToString Is Nothing Then
                            objiCollectAcctDtls.dtmCurrBilldt = checkdate(objIcollRetAccData.datAccountBillingDataWest.dtmBillDate)     'AR09062009
                            objiCollectAcctDtls.dtmOCM1CurBillDate = checkdate(objIcollRetAccData.datAccountBillingDataWest.dtmBillDate) 'AR09062009
                        End If
                        If Not objIcollRetAccData.datAccountBillingDataWest.strPayByDt.ToString Is Nothing Then
                            objiCollectAcctDtls.dtmPayByDt = checkdate(objIcollRetAccData.datAccountBillingDataWest.strPayByDt)         'AR09062009
                            objiCollectAcctDtls.dtmOCM1PayByDate = checkdate(objIcollRetAccData.datAccountBillingDataWest.strPayByDt)   'AR09062009
                        End If
                        If Not objIcollRetAccData.datAccountBillingDataWest.strNoGoodCheckHist Is Nothing Then
                            objiCollectAcctDtls.strNoGoodChkHist = objIcollRetAccData.datAccountBillingDataWest.strNoGoodCheckHist.Trim
                        End If

                        If Not objIcollRetAccData.datAccountBillingDataWest.dblClaimAmt.ToString Is Nothing Then
                            objiCollectAcctDtls.curClaimAmt = objIcollRetAccData.datAccountBillingDataWest.dblClaimAmt
                        End If
                        If Not objIcollRetAccData.datAccountBillingDataWest.dtmBillDate.ToString Is Nothing Then
                            objiCollectAcctDtls.dtmCurrBilldt = checkdate(objIcollRetAccData.datAccountBillingDataWest.dtmBillDate)     'AR09062009
                        End If
                        If Not objIcollRetAccData.datAccountBillingDataWest.strPayByDt.ToString Is Nothing Then
                            objiCollectAcctDtls.dtmPayByDt = checkdate(objIcollRetAccData.datAccountBillingDataWest.strPayByDt)         'AR09062009
                        End If
                        If Not objIcollRetAccData.datAccountBillingDataWest.QueueReviewDt.ToString Is Nothing Then
                            objiCollectAcctDtls.dtmNextReviewDate = checkdate(objIcollRetAccData.datAccountBillingDataWest.QueueReviewDt)
                        End If
                        If Not objIcollRetAccData.datAccountBillingDataWest.NumberofBrokenPayments.ToString Is Nothing Then
                            objiCollectAcctDtls.intNumBrokenPTP = objIcollRetAccData.datAccountTreatmentDataWest.intBrokenPTPCounter
                        End If
                        If Not objIcollRetAccData.datAccountBillingDataWest.DepositAmountHeld.ToString Is Nothing Then
                            objiCollectAcctDtls.curDepositHeld = objIcollRetAccData.datAccountBillingDataWest.DepositAmountHeld
                        End If
                        'Addition for getting the Lastpaymentdate
                        If Not objIcollRetAccData.datAccountBillingDataWest.dtmLastPayment.ToString Is Nothing Then
                            objiCollectAcctDtls.dtmBOSSR3dt = checkdate(objIcollRetAccData.datAccountBillingDataWest.dtmLastPayment)
                        End If
                        'Addition for getting the Lastpayment Amount
                        If Not objIcollRetAccData.datAccountBillingDataWest.LastPaymentAmt.ToString Is Nothing Then
                            objiCollectAcctDtls.curOCM1CPETotalDue = objIcollRetAccData.datAccountBillingDataWest.LastPaymentAmt
                        End If

                        If Not objIcollRetAccData.datAccountBillingDataWest.curPastDueBalance.ToString Is Nothing Then
                            objiCollectAcctDtls.curPastDue = objIcollRetAccData.datAccountBillingDataWest.curPastDueBalance
                        End If

                        If Not objIcollRetAccData.datAccountBillingDataWest.strPendingClaim Is Nothing Then
                            objiCollectAcctDtls.strClaimPot = objIcollRetAccData.datAccountBillingDataWest.strPendingClaim
                        End If

                    End If

                    '*****************    datAccountClaimDataWest    *****************
                    If objIcollRetAccData.datCFI_AccountBalances Is Nothing Then
                        'default
                    Else
                        ' CommonLibrary.LogErrorFile.WriteLog("RMICW_West_EDI- BehaviourScore " + strAcctNum, "datCFI_AccountBalances", 1, 999, "Error")
                        objiCollectAcctDtls.blnClaimInd = True
                        If Not objIcollRetAccData.datCFI_AccountBalances.cPA_Claim.curTotalBasicClaim.ToString Is Nothing Then
                            objiCollectAcctDtls.curClaimBasicAmt = objIcollRetAccData.datCFI_AccountBalances.cPA_Claim.curTotalBasicClaim
                        End If
                        If Not objIcollRetAccData.datCFI_AccountBalances.cPA_Claim.curTotalNonBasicClaim.ToString Is Nothing Then
                            objiCollectAcctDtls.curClaimNonBasicAmt = objIcollRetAccData.datCFI_AccountBalances.cPA_Claim.curTotalNonBasicClaim
                        End If
                        If Not objIcollRetAccData.datCFI_AccountBalances.cPA_Claim.curTotalTollClaim.ToString Is Nothing Then
                            objiCollectAcctDtls.curClaimTollAmt = objIcollRetAccData.datCFI_AccountBalances.cPA_Claim.curTotalTollClaim
                        End If
                        If Not objIcollRetAccData.datCFI_AccountBalances.cPA_Claim.curTotalDAClaim.ToString Is Nothing Then
                            objiCollectAcctDtls.curClaimDAAmt = objIcollRetAccData.datCFI_AccountBalances.cPA_Claim.curTotalDAClaim
                        End If
                        If Not objIcollRetAccData.datCFI_AccountBalances.cAccounbBalancesOverall.strACMSFlag Is Nothing Then
                            If objIcollRetAccData.datCFI_AccountBalances.cAccounbBalancesOverall.strACMSFlag = "Y" Then
                                strAccttemp = strAccttemp.Trim + "#ACMS#"
                            End If
                        End If

                    End If

                    '***************** datAccountTreatmentDataWest  *****************
                    If objIcollRetAccData.datAccountTreatmentDataWest Is Nothing Then
                        'default
                    Else
                        'CommonLibrary.LogErrorFile.WriteLog("RMICW_West_EDI- BehaviourScore " + strAcctNum, "datAccountTreatmentDataWest", 1, 999, "Error")
                        If Not objIcollRetAccData.datAccountTreatmentDataWest.intDialerCalls.ToString Is Nothing Then
                            If objIcollRetAccData.datAccountTreatmentDataWest.intDialerCalls > 0 Then
                                objiCollectAcctDtls.intNumBrokenEpar = objIcollRetAccData.datAccountTreatmentDataWest.intDialerCalls
                            End If
                        End If
                        If Not objIcollRetAccData.datAccountTreatmentDataWest.strInCollections Is Nothing Then
                            objiCollectAcctDtls.strInCollectionsInd = objIcollRetAccData.datAccountTreatmentDataWest.strInCollections
                        End If
                        If Not objIcollRetAccData.datAccountTreatmentDataWest.intPriorIndebtedness.ToString Is Nothing Then
                            If objIcollRetAccData.datAccountTreatmentDataWest.intPriorIndebtedness = 1 Then
                                strAccttemp = strAccttemp.Trim + "#PI#"
                            End If
                        End If
                        If Not objIcollRetAccData.datAccountTreatmentDataWest.strSuppressReconnect Is Nothing Then
                            If objIcollRetAccData.datAccountTreatmentDataWest.strSuppressReconnect.Trim = "Y" Then
                                strAccttemp = strAccttemp.Trim + "#NAR#"
                            End If
                        End If
                        If Not objIcollRetAccData.datAccountTreatmentDataWest.strPLTS Is Nothing Then
                            If objIcollRetAccData.datAccountTreatmentDataWest.strPLTS.Trim = "Y" Then
                                strAccttemp = strAccttemp.Trim + "#PLTS#"
                            End If
                        End If

                        If Not objIcollRetAccData.datAccountTreatmentDataWest.strMDVAaccountStatus Is Nothing Then
                            objiCollectAcctDtls.strAcctStatus = objIcollRetAccData.datAccountTreatmentDataWest.strMDVAaccountStatus
                        End If

                        If Not objIcollRetAccData.datAccountTreatmentDataWest.curACLOverLimit.ToString Is Nothing Then
                            objiCollectAcctDtls.curUsageAmt = objIcollRetAccData.datAccountTreatmentDataWest.curACLOverLimit
                        End If
                        If Not objIcollRetAccData.datAccountTreatmentDataWest.strTreatmentHistory Is Nothing Then
                            objiCollectAcctDtls.strTrtHist = objIcollRetAccData.datAccountTreatmentDataWest.strTreatmentHistory.Trim
                        End If
                        If Not objIcollRetAccData.datAccountTreatmentDataWest.TreatmentStatus Is Nothing Then
                            objiCollectAcctDtls.strTreatmentInd = objIcollRetAccData.datAccountTreatmentDataWest.TreatmentStatus.Trim
                        End If
                        If Not objIcollRetAccData.datAccountTreatmentDataWest.strCI1 Is Nothing And Not objIcollRetAccData.datAccountTreatmentDataWest.strCI2 Is Nothing Then
                            objiCollectAcctDtls.strCIinfo = objIcollRetAccData.datAccountTreatmentDataWest.strCI1.Trim + "#" + objIcollRetAccData.datAccountTreatmentDataWest.strCI2.Trim
                        End If

                        If Not objIcollRetAccData.datAccountTreatmentDataWest.strTEIIndicator Is Nothing Or Not objIcollRetAccData.datAcctGeneralDataWest.strCLECInd Is Nothing Then
                            If objIcollRetAccData.datAcctGeneralDataWest.strCLECInd = "Y" Then
                                objiCollectAcctDtls.strTEIInd = "R"
                            Else
                                If Not objIcollRetAccData.datAccountTreatmentDataWest.strTEIIndicator Is Nothing Then
                                    objiCollectAcctDtls.strTEIInd = objIcollRetAccData.datAccountTreatmentDataWest.strTEIIndicator.Trim
                                End If
                            End If
                        End If
                        If Not objIcollRetAccData.datAccountTreatmentDataWest.strLanguage Is Nothing Then
                            objiCollectAcctDtls.strLanguageCd = objIcollRetAccData.datAccountTreatmentDataWest.strLanguage.Trim
                        End If
                        If Not objIcollRetAccData.datAccountTreatmentDataWest.strPaymentOptionIndicator Is Nothing Then
                            objiCollectAcctDtls.strPaymentOptionCd = objIcollRetAccData.datAccountTreatmentDataWest.strPaymentOptionIndicator.Trim
                        End If
                        If Not objIcollRetAccData.datAccountTreatmentDataWest.strCashOnly Is Nothing Then
                            If objIcollRetAccData.datAccountTreatmentDataWest.strCashOnly = "Y" Then
                                objiCollectAcctDtls.strCheckAcceptInd = "N"
                            Else
                                objiCollectAcctDtls.strCheckAcceptInd = "Y"
                            End If
                        End If
                        If Not objIcollRetAccData.datAccountTreatmentDataWest.strDoNotSatisfy Is Nothing Then
                            If objIcollRetAccData.datAccountTreatmentDataWest.strDoNotSatisfy.Trim = "Y" Then
                                strAddInfo = strAddInfo + "#NOS#"
                            End If
                        End If
                        If Not objIcollRetAccData.datAccountTreatmentDataWest.strFTTP Is Nothing Then
                            If objIcollRetAccData.datAccountTreatmentDataWest.strFTTP.Trim = "Y" Then
                                strAddInfo = strAddInfo + "#FTTP#"

                            End If
                        End If
                        If Not objIcollRetAccData.datAccountTreatmentDataWest.strTPN Is Nothing Then
                            If objIcollRetAccData.datAccountTreatmentDataWest.strTPN.Trim.Length > 1 Then
                                strAddInfo = strAddInfo + "#TPN=" + objIcollRetAccData.datAccountTreatmentDataWest.strTPN.Trim + "#"
                            End If
                        End If
                        If Not objIcollRetAccData.datAccountTreatmentDataWest.strWTAPClientID Is Nothing Then

                            If objIcollRetAccData.datAccountTreatmentDataWest.strWTAP.Trim = "Y" Then
                                strAddInfo = strAddInfo + "#WTAP#"
                            End If
                        End If
                        If Not objIcollRetAccData.datAccountTreatmentDataWest.strRiskDesc Is Nothing Then
                            If objIcollRetAccData.datAccountTreatmentDataWest.strRiskDesc.Trim.Length > 1 Then
                                strAddInfo = strAddInfo + "#RISK=" + objIcollRetAccData.datAccountTreatmentDataWest.strRiskDesc.Trim + "#"
                            End If
                        End If
                        If Not objIcollRetAccData.datAccountTreatmentDataWest.strTEIIndicator Is Nothing Then
                            If objIcollRetAccData.datAccountTreatmentDataWest.strTEIIndicator.Trim = "L" Then
                                objiCollectAcctDtls.blnLifeLineInd = True
                            ElseIf objIcollRetAccData.datAccountTreatmentDataWest.strTEIIndicator.Trim = "R" Then
                                objiCollectAcctDtls.blnResellerInd = True
                            End If
                        End If
                        objiCollectAcctDtls.curRiskBalance = objIcollRetAccData.datAccountTreatmentDataWest.intRisk


                        If Not objIcollRetAccData.datAccountTreatmentDataWest.strFreedomPkgInd Is Nothing Then
                            If objIcollRetAccData.datAccountTreatmentDataWest.strFreedomPkgInd.Trim = "Y" Then
                                strAddInfo = strAddInfo + "#FREEDOM#"
                            End If
                        End If


                        If Not objIcollRetAccData.datAcctGeneralDataWest.strFiosBundleInd Is Nothing Then
                            If objIcollRetAccData.datAcctGeneralDataWest.strFiosBundleInd.Trim = "T" Or objIcollRetAccData.datAcctGeneralDataWest.strFiosBundleInd.Trim = "D" Then
                                strAddInfo = strAddInfo + "BUNDLE#"
                            End If
                        End If

                        If Not objIcollRetAccData.datAccountTreatmentDataWest.strSuppressReconnect Is Nothing Then   'MM08032009
                            If objIcollRetAccData.datAccountTreatmentDataWest.strSuppressReconnect = "Y" Then        'MM08032009
                                strAddInfo = strAddInfo + "DNR#"                                                     'MM08032009 
                            End If                                                                                   'MM08032009
                        End If                                                                                       'MM08032009
                    End If

                    objiCollectAcctDtls.strAdditionalInfo = strAddInfo.Trim

                    If objIcollRetAccData.datPaymentArrangements Is Nothing Then
                        'default
                    End If


                    objiCollectAcctDtls.curCycle0Amt = 0
                    objiCollectAcctDtls.curCycle1Amt = 0
                    objiCollectAcctDtls.curCycle2Amt = 0
                    objiCollectAcctDtls.curCycle3Amt = 0

                    If Not objIcollRetAccData.datAccountTreatmentDataWest.dblTmtThresholdPct > 0 Then
                        objiCollectAcctDtls.curCycle0Amt = objIcollRetAccData.datAccountTreatmentDataWest.dblTmtThresholdPct
                    End If
                    If Not objIcollRetAccData.datAccountTreatmentDataWest.dblAccountDelqThreshold > 0 Then
                        objiCollectAcctDtls.curCycle1Amt = objIcollRetAccData.datAccountTreatmentDataWest.dblAccountDelqThreshold
                    End If
                    If Not objIcollRetAccData.datAccountTreatmentDataWest.curAccountDelqThreshold > 0 Then
                        objiCollectAcctDtls.curCycle2Amt = objIcollRetAccData.datAccountTreatmentDataWest.curAccountDelqThreshold
                    End If

                    objiCollectAcctDtls.strAccntInd = strAccttemp.Trim
                    objiCollectAcctDtls.strSSN = " "

                    objiCollectAcctDtls.dtmPTPDt = "01/01/1900"

                    If Not objIcollRetAccData.datPaymentArrangements Is Nothing Then
                        If objIcollRetAccData.datPaymentArrangements.ActionType <> " " And Not objIcollRetAccData.datPaymentArrangements.ActionType Is Nothing Then
                            objiCollectAcctDtls.strPayAdjPtpInd = "PTP"
                            objiCollectAcctDtls.blnPTPInd = True
                        End If
                    End If
                    If Not objIcollRetAccData.datCFI_AccountBalances Is Nothing Then
                        If objIcollRetAccData.datCFI_AccountBalances.cPA_PPX.curTotalPPXAmount > 0 Then
                            objiCollectAcctDtls.curMemoPayments = objIcollRetAccData.datCFI_AccountBalances.cPA_PPX.curTotalPPXAmount
                            objiCollectAcctDtls.curRMIDirAdvAmt = objIcollRetAccData.datCFI_AccountBalances.cPA_PPX.curTotalPPXAmount
                            objiCollectAcctDtls.strPayAdjPtpInd = "PAY"
                        End If
                    End If




                    If Not objIcollRetAccData.datAccountTreatmentDataWest.strFreedomPkgInd Is Nothing Then
                        objiCollectAcctDtls.strBasicBundleInd = objIcollRetAccData.datAccountTreatmentDataWest.strFreedomPkgInd.Trim
                    End If


                    If (objiCollectAcctDtls.strBasicBundleInd = "") Or (objiCollectAcctDtls.strBasicBundleInd = "N") Then
                        If Not objIcollRetAccData.datAcctGeneralDataWest.ORG Is Nothing Then
                            If objIcollRetAccData.datAcctGeneralDataWest.ORG.StartsWith("DC") Then
                                If Not objIcollRetAccData.datAcctGeneralDataWest.strDCBundleInd Is Nothing Then
                                    objiCollectAcctDtls.strBasicBundleInd = objIcollRetAccData.datAcctGeneralDataWest.strDCBundleInd
                                End If
                            ElseIf objIcollRetAccData.datAcctGeneralDataWest.ORG.StartsWith("VA") Then
                                If Not objIcollRetAccData.datAcctGeneralDataWest.strVABundleInd Is Nothing Then
                                    objiCollectAcctDtls.strBasicBundleInd = objIcollRetAccData.datAcctGeneralDataWest.strVABundleInd
                                End If
                            ElseIf objIcollRetAccData.datAcctGeneralDataWest.ORG.StartsWith("DE") Then
                                If Not objIcollRetAccData.datAcctGeneralDataWest.strDEBundleInd Is Nothing Then
                                    objiCollectAcctDtls.strBasicBundleInd = objIcollRetAccData.datAcctGeneralDataWest.strDEBundleInd
                                End If
                            End If
                        End If
                    End If

                    



                    If Not objIcollRetAccData.datAccountTreatmentDataWest.dtmStatusUpdatedDate.ToString Is Nothing Then
                        objiCollectAcctDtls.dtmCreditVerificationDate = checkdate(objIcollRetAccData.datAccountTreatmentDataWest.dtmStatusUpdatedDate)
                    End If

                    'If Not objIcollRetAccData.datAccountTreatmentDataWest.dtmReviewDate.ToString Is Nothing Then
                    '    objiCollectAcctDtls.dtmNextReviewDate = checkdate(objIcollRetAccData.datAccountTreatmentDataWest.dtmReviewDate)
                    'End If

                    '***************** History   *****************
                    Dim objHistoryDtls As HistDetails
                    Dim iCollHistds As DataSet

                    Dim todt As DateTime
                    Dim I As Integer
                    Dim day, mth, yr As String
                    Dim Hsdate1, Hsdate2 As Date
                    Try
                        'This is added to increase the time in processing . we have commented out the History by Satish - 01/23/06
                        objHistoryDtls = New HistDetails
                        objHistoryDtls.dtmUpdtDt = "1900/01/01"
                        objHistoryDtls.strActn = " "
                        objHistoryDtls.dtmActnDt = "1900/01/01"
                        objHistoryDtls.curActnAmt = 0.0
                        objHistoryDtls.strDescription = " "
                        objWEDIOutput.arrLstHistDetails.Add(objHistoryDtls)
                    Catch ex As Exception
                        ' CommonLibrary.LogErrorFile.WriteLog("RMICW_West_EDI - History " + strAcctNum, ex.Message, 1, 999, "Error")
                    End Try

                    '***************** Bill Details - CFI   *****************
                    If objIcollRetAccData.datCFI_AccountBalances Is Nothing Or objIcollRetAccData.datCFI_AccountBalances.ResponseStatus > 0 Then
                        objWEDIOutput.objStatusDetails.strErrorDescription = "NFNDCFI"
                    Else


                        '********************* PAY Notattion Details **********************************   Added For WR22720  AR03/02/2009 
                        If Not objIcollRetAccData.datCFI_AccountBalances.cPayments.curPaymentDate.ToString Is Nothing Then
                            objiCollectPayDtls.dtmPAYDt1 = checkdate(objIcollRetAccData.datCFI_AccountBalances.cPayments.curPaymentDate)    'AR09062009
                            ' objiCollectPayDtls.dtmPAYDt2 = objIcollRetAccData.datCFI_AccountBalances.cPayments.curPaymentDate
                        End If
                        If Not objIcollRetAccData.datCFI_AccountBalances.cPayments.curPaymentAmount.ToString Is Nothing Then
                            objiCollectPayDtls.curPAYAmt1 = objIcollRetAccData.datCFI_AccountBalances.cPayments.curPaymentAmount
                        End If


                        Dim cfir As IcollectWebServiceDataRetrieve.PA_CFIBalanceSummarySegment
                        Dim cfirtrt As IcollectWebServiceDataRetrieve.PA_CFIBalanceSummaryTmtSegment



                        Dim cfiDAbal As IcollectWebServiceDataRetrieve.PA_CFIBalanceSegment
                        Dim cfiDAbalTrt As IcollectWebServiceDataRetrieve.PA_CFITreatableBalanceSegment


                        Dim cfiIPcharges As IcollectWebServiceDataRetrieve.PA_CFIIpCharges

                        Dim dtmBillDueDate As Date
                        dtmBillDueDate = "1900/01/01"

                        If Not objIcollRetAccData.datCFI_AccountBalances.cAccounbBalancesOverall.dtmBillDueDate Is Nothing Then
                            dtmBillDueDate = checkdate(objIcollRetAccData.datCFI_AccountBalances.cAccounbBalancesOverall.dtmBillDueDate)    'AR09062009
                        End If


                        For Each cfiIPcharges In objIcollRetAccData.datCFI_AccountBalances.cIpCharges
                            objiCollectAcctDtls.curUsageAmt = Math.Round(cfiIPcharges.dblcurWriteOffAmt, 2)
                        Next

                        objWEDIOutput.arrLstBalanceInfoDetails = New ArrayList
                        Dim fldNO, b As Integer
                        Dim curBucketCharges As Double
                        Dim curipCharges, curTotalIpCharges As Double
                        Dim blnmonthpastindZero As Boolean = False ' This indicator is used to calculate Total Ip Charges for intmonthpastind =0

                        b = 1
                        While b < 8
                            objBillDtls = New BillDetails
                            objBillDtls.curTotBilled = 0
                            objBillDtls.curBalDueAmt = 0
                            If b = 1 Then
                                objBillDtls.intMonthPastInd = 0

                                If blnmonthpastindZero = True Then                          'AR05072009


                                    For Each cfiDAbal In objIcollRetAccData.datCFI_AccountBalances.cCFIBalances
                                        If cfiDAbal.strProductServiceProviderId = "00DIR" And cfiDAbal.chrBillingCategoryCode = "N" Then
                                            If dtmBillDueDate.Equals(DateTime.MinValue) Or (dtmBillDueDate >= DateTime.Now) Then
                                                objBillDtls.curDAAmt = cfiDAbal.curTotalBillableAmount
                                            Else
                                                objBillDtls.curDAAmt = cfiDAbal.curTotalBillableAmount
                                            End If
                                        End If

                                        If cfiDAbal.strProductServiceProviderId = "09300" Or cfiDAbal.strProductServiceProviderId = "09301" Then
                                            objiCollectAcctDtls.strPrty = "V"
                                        End If

                                        If cfiDAbal.strProductServiceProviderId = "00860" Or cfiDAbal.strProductServiceProviderId = "00863" Or cfiDAbal.strProductServiceProviderId = "001GN" Then
                                            objiCollectAcctDtls.strAccntInd = objiCollectAcctDtls.strAccntInd.Trim + "#VOL#"
                                        End If

                                    Next

                                    For Each cfiDAbal In objIcollRetAccData.datCFI_AccountBalances.cCFIBalances
                                        If cfiDAbal.strProductServiceProviderId = "00860" Or cfiDAbal.strProductServiceProviderId = "00863" Then
                                            objiCollectAcctDtls.strPrty = objiCollectAcctDtls.strPrty.Trim + "D"
                                        End If
                                    Next

                                    For Each cfir In objIcollRetAccData.datCFI_AccountBalances.cRealBalances
                                        objBillDtls.dtmBillDt = checkdate(objIcollRetAccData.datAccountBillingDataWest.dtmBillDate)
                                        objBillDtls.dtmPayByDt = checkdate(objIcollRetAccData.datAccountBillingDataWest.strPayByDt)
                                        If cfir.chrBillingCategoryCode = "B" Then
                                            objBillDtls.curBasicAmt = Math.Round(cfir.curCurrentCharges + cfir.curPreviousBalance30Day + cfir.curPreviousBalance60Day + cfir.curPreviousBalance90Day, 2) '+ cfir.curPastDueCharges
                                            objiCollectAcctDtls.curRMIBasicTotalDue = objiCollectAcctDtls.curRMIBasicTotalDue + Math.Round(cfir.curCurrentCharges + cfir.curPreviousBalance30Day + cfir.curPreviousBalance60Day + cfir.curPreviousBalance90Day, 2)
                                            objiCollectAcctDtls.curOCM1BscTotalDue = objiCollectAcctDtls.curOCM1BscTotalDue + Math.Round(cfir.curCurrentCharges + cfir.curPreviousBalance30Day + cfir.curPreviousBalance60Day + cfir.curPreviousBalance90Day, 2)
                                        ElseIf cfir.chrBillingCategoryCode = "N" Then
                                            'If strOrgCode.StartsWith("AR") Then 'Added For Arbor  - WR22845
                                            '    objBillDtls.curNonBasicAmt = Math.Round(cfir.curCurrentCharges + cfir.curPastDueCharges, 2) 'Added For Arbor  - WR22845
                                            'Else
                                            objBillDtls.curNonBasicAmt = Math.Round(cfir.curCurrentCharges + cfir.curPreviousBalance30Day + cfir.curPreviousBalance60Day + cfir.curPreviousBalance90Day - objBillDtls.curDAAmt, 2)  '+ cfit.curPastDueCharges
                                            'End If

                                            objiCollectAcctDtls.curRMINonBasicTotalDue = objiCollectAcctDtls.curRMINonBasicTotalDue + Math.Round(cfir.curCurrentCharges + cfir.curPreviousBalance30Day + cfir.curPreviousBalance60Day + cfir.curPreviousBalance90Day, 2)
                                            objiCollectAcctDtls.curOCM1NBscTotalDue = objiCollectAcctDtls.curOCM1NBscTotalDue + Math.Round(cfir.curCurrentCharges + cfir.curPreviousBalance30Day + cfir.curPreviousBalance60Day + cfir.curPreviousBalance90Day, 2)
                                        ElseIf cfir.chrBillingCategoryCode = "T" Then
                                            objBillDtls.curTollAmt = Math.Round(cfir.curCurrentCharges + cfir.curPreviousBalance30Day + cfir.curPreviousBalance60Day + cfir.curPreviousBalance90Day, 2) '+ cfit.curPastDueCharges
                                            objiCollectAcctDtls.curRMITollTotalDue = objiCollectAcctDtls.curRMITollTotalDue + Math.Round(cfir.curCurrentCharges + cfir.curPreviousBalance30Day + cfir.curPreviousBalance60Day + cfir.curPreviousBalance90Day, 2)
                                            objiCollectAcctDtls.curOCM1TollTotalDue = objiCollectAcctDtls.curOCM1TollTotalDue + Math.Round(cfir.curCurrentCharges + cfir.curPreviousBalance30Day + cfir.curPreviousBalance60Day + cfir.curPreviousBalance90Day, 2)
                                        ElseIf cfir.chrBillingCategoryCode = "L" Then
                                            objBillDtls.curTollAmt = Math.Round(objBillDtls.curTollAmt + cfir.curCurrentCharges + cfir.curPreviousBalance30Day + cfir.curPreviousBalance60Day + cfir.curPreviousBalance90Day, 2) '+ cfit.curPastDueCharges
                                            objiCollectAcctDtls.curRMITollTotalDue = objiCollectAcctDtls.curRMITollTotalDue + Math.Round(cfir.curCurrentCharges + cfir.curPreviousBalance30Day + cfir.curPreviousBalance60Day + cfir.curPreviousBalance90Day, 2)
                                            objiCollectAcctDtls.curOCM1TollTotalDue = objiCollectAcctDtls.curOCM1TollTotalDue + Math.Round(cfir.curCurrentCharges + cfir.curPreviousBalance30Day + cfir.curPreviousBalance60Day + cfir.curPreviousBalance90Day, 2)
                                        ElseIf cfir.chrBillingCategoryCode = "D" Then

                                        End If

                                        objiCollectAcctDtls.curRMIIPTotalDue = (objiCollectAcctDtls.curRMIBasicTotalDue + objiCollectAcctDtls.curRMINonBasicTotalDue + objiCollectAcctDtls.curOCM1TollTotalDue)
                                        objBillDtls.curTotBilled = (objBillDtls.curBasicAmt + objBillDtls.curNonBasicAmt + objBillDtls.curTollAmt) ''AR 05052009
                                        objiCollectAcctDtls.curTotalDue = (objBillDtls.curBasicAmt + objBillDtls.curNonBasicAmt + objBillDtls.curTollAmt)
                                        objiCollectAcctDtls.curRMITotalAmtDue = (objBillDtls.curBasicAmt + objBillDtls.curNonBasicAmt + objBillDtls.curTollAmt)

                                    Next
                                    'Added For IP Charges Calculation     
                                    objBillDtls.curIPAmt = Math.Round(curTotalIpCharges, 2)             'AR05072009
                                End If

                            ElseIf b = 2 Then
                                objBillDtls.intMonthPastInd = 1

                                If blnmonthpastindZero = True Then                          'AR05202009

                                    '*****************  pastdue  ***************** 
                                    For Each cfiDAbal In objIcollRetAccData.datCFI_AccountBalances.cCFIBalances
                                        If cfiDAbal.strProductServiceProviderId = "00DIR" And cfiDAbal.chrBillingCategoryCode = "N" Then
                                            If dtmBillDueDate.Equals(DateTime.MinValue) Or (dtmBillDueDate >= DateTime.Now) Then
                                                objBillDtls.curDAAmt = cfiDAbal.curTotalBillableAmount - cfiDAbal.curProviderCurrentBillCharges
                                            Else
                                                objBillDtls.curDAAmt = cfiDAbal.curTotalBillableAmount
                                            End If
                                        End If
                                    Next
                                    For Each cfir In objIcollRetAccData.datCFI_AccountBalances.cRealBalances
                                        objBillDtls.dtmBillDt = checkdate(objIcollRetAccData.datAccountBillingDataWest.dtmBillDate)
                                        objBillDtls.dtmPayByDt = checkdate(objIcollRetAccData.datAccountBillingDataWest.strPayByDt)
                                        If cfir.chrBillingCategoryCode = "B" Then
                                            objBillDtls.curBasicAmt = Math.Round(cfir.curPreviousBalance30Day + cfir.curPreviousBalance60Day + cfir.curPreviousBalance90Day, 2)
                                        ElseIf cfir.chrBillingCategoryCode = "N" Then
                                            objBillDtls.curNonBasicAmt = Math.Round(cfir.curPreviousBalance30Day + cfir.curPreviousBalance60Day + cfir.curPreviousBalance90Day - objBillDtls.curDAAmt, 2)
                                        ElseIf cfir.chrBillingCategoryCode = "T" Then
                                            objBillDtls.curTollAmt = Math.Round(cfir.curPreviousBalance30Day + cfir.curPreviousBalance60Day + cfir.curPreviousBalance90Day, 2)
                                        ElseIf cfir.chrBillingCategoryCode = "L" Then
                                            objBillDtls.curTollAmt = Math.Round(objBillDtls.curTollAmt + cfir.curPreviousBalance30Day + cfir.curPreviousBalance60Day + cfir.curPreviousBalance90Day, 2)
                                        ElseIf cfir.chrBillingCategoryCode = "D" Then
                                        End If
                                        objBillDtls.curTotBilled = (objBillDtls.curBasicAmt + objBillDtls.curNonBasicAmt + objBillDtls.curTollAmt) ''AR 05052009
                                    Next
                                    'Added  Ip Charges for WR22720
                                    objBillDtls.curIPAmt = Math.Round(curTotalIpCharges, 2)
                                End If

                            ElseIf b = 3 Then
                                objBillDtls.intMonthPastInd = 2


                                If blnmonthpastindZero = True Then

                                    For Each cfiDAbalTrt In objIcollRetAccData.datCFI_AccountBalances.cCFITreatableBalances
                                        If cfiDAbalTrt.strProductServiceProviderId = "00DIR" And cfiDAbalTrt.chrBillingCategoryCode = "N" Then
                                            objBillDtls.curDAAmt = Math.Round(cfiDAbalTrt.curPreviousBalance30Day + cfiDAbalTrt.curPreviousBalance60Day + cfiDAbalTrt.curPreviousBalance90Day, 2)
                                        End If
                                    Next
                                    For Each cfirtrt In objIcollRetAccData.datCFI_AccountBalances.cTmtBalances
                                        objBillDtls.dtmBillDt = checkdate(objIcollRetAccData.datAccountBillingDataWest.dtmBillDate)
                                        objBillDtls.dtmPayByDt = checkdate(objIcollRetAccData.datAccountBillingDataWest.strPayByDt)
                                        If cfirtrt.chrBillingCategoryCode = "B" Then
                                            objBillDtls.curBasicAmt = Math.Round(cfirtrt.curPastDueCharges, 2)
                                        ElseIf cfirtrt.chrBillingCategoryCode = "N" Then
                                            objBillDtls.curNonBasicAmt = Math.Round(cfirtrt.curPastDueCharges - objBillDtls.curDAAmt, 2)
                                        ElseIf cfirtrt.chrBillingCategoryCode = "T" Then
                                            objBillDtls.curTollAmt = Math.Round(cfirtrt.curPastDueCharges, 2)
                                        ElseIf cfirtrt.chrBillingCategoryCode = "L" Then
                                            objBillDtls.curTollAmt = Math.Round(objBillDtls.curTollAmt + cfirtrt.curPastDueCharges, 2)
                                        ElseIf cfirtrt.chrBillingCategoryCode = "D" Then
                                        End If
                                        objBillDtls.curTotBilled = (objBillDtls.curBasicAmt + objBillDtls.curNonBasicAmt + objBillDtls.curTollAmt) 'AR 05052009
                                    Next

                                    If Not objIcollRetAccData.datCFI_AccountBalances.cAccounbBalancesOverall.curACMSTreatable.ToString Is Nothing Then
                                        If objIcollRetAccData.datCFI_AccountBalances.cAccounbBalancesOverall.curACMSTreatable > 0 Then
                                            objBillDtls.curCPEAmt = objIcollRetAccData.datCFI_AccountBalances.cAccounbBalancesOverall.curACMSTreatable
                                        Else
                                            objBillDtls.curCPEAmt = 0
                                        End If
                                    End If

                                    'Added  Ip Charges for WR22720
                                    objBillDtls.curIPAmt = Math.Round(curTotalIpCharges, 2)             'AR05202009
                                    b = 8

                                End If

                            ElseIf b = 4 Then
                                objBillDtls.intMonthPastInd = 3
                                For Each cfirtrt In objIcollRetAccData.datCFI_AccountBalances.cTmtBalances
                                    objBillDtls.dtmBillDt = checkdate(objIcollRetAccData.datAccountBillingDataWest.dtmBillDate)
                                    objBillDtls.dtmPayByDt = checkdate(objIcollRetAccData.datAccountBillingDataWest.strPayByDt)
                                    If cfirtrt.chrBillingCategoryCode = "B" Then
                                        objBillDtls.curBasicAmt = Math.Round(cfirtrt.curCurrentCharges, 2)
                                    ElseIf cfirtrt.chrBillingCategoryCode = "N" Then
                                        objBillDtls.curNonBasicAmt = Math.Round(cfirtrt.curCurrentCharges, 2)
                                    ElseIf cfirtrt.chrBillingCategoryCode = "T" Then
                                        objBillDtls.curTollAmt = Math.Round(cfirtrt.curCurrentCharges, 2)
                                    ElseIf cfirtrt.chrBillingCategoryCode = "L" Then
                                        objBillDtls.curTollAmt = Math.Round(objBillDtls.curTollAmt + cfirtrt.curCurrentCharges, 2)
                                    ElseIf cfirtrt.chrBillingCategoryCode = "D" Then
                                        objBillDtls.curDAAmt = Math.Round(cfirtrt.curCurrentCharges, 2)
                                    End If
                                Next


                                'Added For IP Charges Calculation                                           AR05072009
                                For Each cfiIPcharges In objIcollRetAccData.datCFI_AccountBalances.cIpCharges
                                    For Each cfiDAbal In objIcollRetAccData.datCFI_AccountBalances.cCFIBalances
                                        If cfiIPcharges.strProductServiceProviderId = cfiDAbal.strProductServiceProviderId Then
                                            If cfiDAbal.chrBillingCategoryCode = "N" Then
                                                curBucketCharges = Math.Round(cfiDAbal.curCurrentBillCharges, 2)
                                            End If
                                            curipCharges = Math.Round(cfiIPcharges.dblcurCurrentCharges, 2)
                                            objBillDtls.curIPAmt = objBillDtls.curIPAmt + CheckIPBalances(curipCharges, curBucketCharges)
                                        End If
                                    Next
                                Next
                                curTotalIpCharges = curTotalIpCharges + objBillDtls.curIPAmt



                            ElseIf b = 5 Then
                                objBillDtls.intMonthPastInd = 4
                                For Each cfirtrt In objIcollRetAccData.datCFI_AccountBalances.cTmtBalances
                                    objBillDtls.dtmBillDt = checkdate(objIcollRetAccData.datAccountBillingDataWest.dtmBillDate)
                                    objBillDtls.dtmPayByDt = checkdate(objIcollRetAccData.datAccountBillingDataWest.strPayByDt)
                                    If cfirtrt.chrBillingCategoryCode = "B" Then
                                        objBillDtls.curBasicAmt = Math.Round(cfirtrt.curPreviousBalance30Day, 2)
                                    ElseIf cfirtrt.chrBillingCategoryCode = "N" Then
                                        objBillDtls.curNonBasicAmt = Math.Round(cfirtrt.curPreviousBalance30Day, 2)
                                    ElseIf cfirtrt.chrBillingCategoryCode = "T" Then
                                        objBillDtls.curTollAmt = Math.Round(cfirtrt.curPreviousBalance30Day, 2)
                                    ElseIf cfirtrt.chrBillingCategoryCode = "L" Then
                                        objBillDtls.curTollAmt = Math.Round(objBillDtls.curTollAmt + cfirtrt.curPreviousBalance30Day, 2)
                                    ElseIf cfirtrt.chrBillingCategoryCode = "D" Then
                                        objBillDtls.curDAAmt = Math.Round(cfirtrt.curPreviousBalance30Day, 2)
                                    End If
                                Next


                                'Added For IP Charges Calculation                                               AR05072009
                                For Each cfiIPcharges In objIcollRetAccData.datCFI_AccountBalances.cIpCharges
                                    For Each cfiDAbal In objIcollRetAccData.datCFI_AccountBalances.cCFIBalances
                                        If cfiDAbal.strProductServiceProviderId = cfiIPcharges.strProductServiceProviderId Then
                                            If cfiDAbal.chrBillingCategoryCode = "N" Then
                                                curBucketCharges = Math.Round(cfiDAbal.curPreviousBalance30Day, 2)
                                            End If
                                            curipCharges = Math.Round(cfiIPcharges.dblcur30DaysCharges, 2)
                                            objBillDtls.curIPAmt = objBillDtls.curIPAmt + CheckIPBalances(curipCharges, curBucketCharges)
                                        End If
                                    Next
                                Next
                                curTotalIpCharges = curTotalIpCharges + objBillDtls.curIPAmt


                            ElseIf b = 6 Then
                                objBillDtls.intMonthPastInd = 5
                                For Each cfirtrt In objIcollRetAccData.datCFI_AccountBalances.cTmtBalances
                                    If cfirtrt.chrBillingCategoryCode = "B" Then
                                        objBillDtls.curBasicAmt = Math.Round(cfirtrt.curPreviousBalance60Day, 2)
                                    ElseIf cfirtrt.chrBillingCategoryCode = "N" Then
                                        objBillDtls.curNonBasicAmt = Math.Round(cfirtrt.curPreviousBalance60Day, 2)
                                    ElseIf cfirtrt.chrBillingCategoryCode = "T" Then
                                        objBillDtls.curTollAmt = Math.Round(cfirtrt.curPreviousBalance60Day, 2)
                                    ElseIf cfirtrt.chrBillingCategoryCode = "L" Then
                                        objBillDtls.curTollAmt = Math.Round(objBillDtls.curTollAmt + cfirtrt.curPreviousBalance60Day, 2)
                                    ElseIf cfirtrt.chrBillingCategoryCode = "D" Then
                                        objBillDtls.curDAAmt = Math.Round(cfirtrt.curPreviousBalance60Day, 2)
                                    End If
                                Next

                                'Added For IP Charges Calculation                                                   AR05072009
                                For Each cfiIPcharges In objIcollRetAccData.datCFI_AccountBalances.cIpCharges
                                    For Each cfiDAbal In objIcollRetAccData.datCFI_AccountBalances.cCFIBalances
                                        If cfiDAbal.strProductServiceProviderId = cfiIPcharges.strProductServiceProviderId Then
                                            If cfiDAbal.chrBillingCategoryCode = "N" Then
                                                curBucketCharges = Math.Round(cfiDAbal.curPreviousBalance60Day, 2)
                                            End If
                                            curipCharges = Math.Round(cfiIPcharges.dblcur60DaysCharges, 2)
                                            objBillDtls.curIPAmt = objBillDtls.curIPAmt + CheckIPBalances(curipCharges, curBucketCharges)

                                        End If
                                    Next
                                Next
                                curTotalIpCharges = curTotalIpCharges + objBillDtls.curIPAmt

                            ElseIf b = 7 Then
                                objBillDtls.intMonthPastInd = 6
                                For Each cfirtrt In objIcollRetAccData.datCFI_AccountBalances.cTmtBalances
                                    If cfirtrt.chrBillingCategoryCode = "B" Then
                                        objBillDtls.curBasicAmt = Math.Round(cfirtrt.curPreviousBalance90Day, 2)
                                    ElseIf cfirtrt.chrBillingCategoryCode = "N" Then
                                        objBillDtls.curNonBasicAmt = Math.Round(cfirtrt.curPreviousBalance90Day, 2)
                                    ElseIf cfirtrt.chrBillingCategoryCode = "T" Then
                                        objBillDtls.curTollAmt = Math.Round(cfirtrt.curPreviousBalance90Day, 2)
                                    ElseIf cfirtrt.chrBillingCategoryCode = "L" Then
                                        objBillDtls.curTollAmt = Math.Round(objBillDtls.curTollAmt + cfirtrt.curPreviousBalance90Day, 2)
                                    ElseIf cfirtrt.chrBillingCategoryCode = "D" Then
                                        objBillDtls.curDAAmt = Math.Round(cfirtrt.curPreviousBalance90Day, 2)
                                    End If
                                Next

                                'Added For IP Charges Calculation                                                   AR05072009
                                For Each cfiIPcharges In objIcollRetAccData.datCFI_AccountBalances.cIpCharges
                                    For Each cfiDAbal In objIcollRetAccData.datCFI_AccountBalances.cCFIBalances
                                        If cfiDAbal.strProductServiceProviderId = cfiIPcharges.strProductServiceProviderId Then
                                            If cfiDAbal.chrBillingCategoryCode = "N" Then
                                                curBucketCharges = Math.Round(cfiDAbal.curPreviousBalance90Day, 2)
                                            End If
                                            curipCharges = Math.Round(cfiIPcharges.dblcur90DaysCharges, 2)
                                            objBillDtls.curIPAmt = objBillDtls.curIPAmt + CheckIPBalances(curipCharges, curBucketCharges)
                                        End If
                                    Next
                                Next
                                curTotalIpCharges = curTotalIpCharges + objBillDtls.curIPAmt
                                blnmonthpastindZero = True
                                b = 0

                            End If


                            If blnmonthpastindZero = True Then                                   'AR05202009 
                                Dim intIndicator As Integer = objBillDtls.intMonthPastInd

                                Select Case (intIndicator)
                                    Case 0 To 1
                                        objWEDIOutput.arrLstBalanceInfoDetails.RemoveAt(intIndicator)
                                        objWEDIOutput.arrLstBalanceInfoDetails.Insert(intIndicator, objBillDtls)
                                    Case 2
                                        blnmonthpastindZero = False
                                        objWEDIOutput.arrLstBalanceInfoDetails.RemoveAt(intIndicator)
                                        objWEDIOutput.arrLstBalanceInfoDetails.Insert(intIndicator, objBillDtls)
                                    Case Else
                                        objWEDIOutput.arrLstBalanceInfoDetails.Add(objBillDtls)

                                End Select
                            Else
                                objWEDIOutput.arrLstBalanceInfoDetails.Add(objBillDtls)
                            End If

                            b = b + 1
                        End While
                    End If

                End If

                If urlERROR = "TRUE" Then
                    ' objWEDIOutput = Nothing
                Else

                    'objWEDIOutput.objAccountDetails = objiCollectAcctDtls
                    objWEDIOutput.arrLstPAYNotationDetails.Add(objiCollectPayDtls)
                End If
                If Not objIcollAcctData Is Nothing Then
                    objIcollAcctData.Dispose()
                End If
                logdate2 = logdate.Now



            Catch ex As Exception
                If urlERROR = "TRUE" Then
                    ' for time logging
                    CommonLibrary.LogErrorFile.WriteLog("WS SPA5-MDVW - Error from Icollect Web Service " + strAcctountNum, ex.Message, 1, 999, "Error")
                    objWEDIOutput = Nothing
                Else
                    CommonLibrary.LogErrorFile.WriteLog("WS SPA5-MDVW -" + strAcctountNum, ex.Message, 1, 999, "Error")
                    objWEDIOutput = Nothing
                End If
            End Try

            objXBCLSPA3.objAccountDtls = objiCollectAcctDtls
            If Not objWEDIOutput Is Nothing Then
                objXBCLSPA3.arrLstBalanceInfoDetails = objWEDIOutput.arrLstBalanceInfoDetails
            End If
            'objXBCLSPA3.RequestStatus = objRequestStatus
            Return objXBCLSPA3

        End Function
#End Region


#Region "Calculating IP Charges"
        Public Function CheckIPBalances(ByVal curIPCharges As Double, ByVal curBucketCharge As Double) As Double
            Dim curCharges As Double = 0.0

            If (curIPCharges > 0) Then
                Select Case True
                    Case curBucketCharge > curIPCharges
                        curCharges = curIPCharges
                    Case curIPCharges = curBucketCharge
                        curCharges = curIPCharges
                    Case curBucketCharge < curIPCharges
                        curCharges = curBucketCharge
                End Select
            Else
                curCharges = curIPCharges
            End If
            Return curCharges
        End Function
#End Region




#Region "toBOOLEan"
        Private Function toBoolean(ByVal value As String, ByVal text As String) As Boolean
            If value = "" Or value = "N" Or value = " " Or value = "0" Then
                Return False
            Else
                Return True
            End If

        End Function
#End Region

#Region "CHECK DATE"


        Private Function checkdate(ByVal value As Date) As Date
            Dim d1 As DateTime
            d1 = value
            If d1.Year < 1501 Then
                Return "1900/01/02"
            Else
                Return value
            End If
        End Function
#End Region

        Public Function usp_GetControlParmByName(ByVal strRegionId As String, ByVal strParmName As String) As DataSet

            Dim myreturnGetAcctTotalDataset As New DataSet
            Dim dataAccessObj As DataAccessComponent
            Try
                dataAccessObj = New DataAccessComponent(DbType.SQLServer, "prodmdvw")  'AG
                myreturnGetAcctTotalDataset = dataAccessObj.execStoreProcedure(strRegionId, strParmName)
                Return (myreturnGetAcctTotalDataset)
            Catch ex As Exception
                CommonLibrary.LogErrorFile.WriteLog("WS-SPA5[icollect]", ex.Message.ToString)
                Throw ex
                'handle exception
            Finally
            End Try

        End Function

        'Public Class AccountDetails


        '    Public strCustName As String
        '    Public strAcctStatus As String
        '    Public strAccntInd As String
        '    Public strCheckDigit As String
        '    Public strClassOfService As String
        '    Public strCSG As String
        '    Public dtmCurrBilldt As Date
        '    Public dtmPayByDt As Date
        '    Public strTrtHist As String
        '    Public strNoGoodChkHist As String
        '    Public strBehavScr As String
        '    Public dtmDOI As Date
        '    Public dtmBOSSR1dt As Date
        '    Public dtmBOSSR2dt As Date
        '    Public dtmBOSSR3dt As Date
        '    Public strTreatmentInd As String
        '    Public blnClaimInd As Boolean
        '    Public strClaimPot As String
        '    Public curClaimAmt As Single
        '    Public strCurrentClass As String
        '    Public blnPermCollFlag As Boolean
        '    Public strCollectorId As String
        '    Public blnTicklerInd As Boolean
        '    Public strCBR As String
        '    Public strPayAdjPtpInd As String
        '    Public dtmPTPDt As Date
        '    Public blnPTPInd As Boolean
        '    Public blnNTNInd As Boolean
        '    Public blnOTNInd As Boolean
        '    Public blnResellerInd As Boolean
        '    Public blnSRPPInd As Boolean
        '    Public blnLifeLineInd As Boolean
        '    Public strCIinfo As String
        '    Public dtmLastSNPdt As Date
        '    Public dtmLastRSTdt As Date
        '    Public dtmLNPdt As Date
        '    Public strCollectionRsnCd As String
        '    Public strCreditClass As String
        '    Public strPrty As String
        '    Public curTotalDue As Double
        '    Public curPastDue As Double
        '    Public curCycle0Amt As Double
        '    Public curCycle1Amt As Double
        '    Public curCycle2Amt As Double
        '    Public curCycle3Amt As Double
        '    Public curClaimBasicAmt As Double
        '    Public curClaimNonBasicAmt As Double
        '    Public curClaimTollAmt As Double
        '    Public curClaimDAAmt As Double
        '    Public curRMITotalAmtDue As Double
        '    Public curRMIBasicTotalDue As Double
        '    Public curRMINonBasicTotalDue As Double
        '    Public curRMITollTotalDue As Double
        '    Public curRMIOcarTotalDue As Double
        '    Public curRMIWrlsTotalDue As Double
        '    Public curRMIDATotalDue As Double
        '    Public curRMIIPTotalDue As Double
        '    Public curRMICPETotalDue As Double
        '    Public dtmRMIDirAdvDt As Date
        '    Public curRMIDirAdvAmt As Double
        '    Public curRMIDirAdvAmt30 As Double
        '    Public curRMIDirAdvAmt60 As Double
        '    Public curRMIDirAdvAmt90 As Double
        '    Public curRMIDirAdvAmt120 As Double
        '    Public strPermNoteInd As String
        '    Public dtmOCM1CurBillDate As DateTime
        '    Public dtmOCM1PayByDate As DateTime
        '    Public strPrferredPymntDay As String
        '    Public strPriorAcctHist As String
        '    Public strSSN As String
        '    Public curDepositHeld As Double
        '    Public dtmCreditVerificationDate As DateTime
        '    Public strCheckAcceptInd As String
        '    Public strPmtSchedule As String
        '    Public dtmNextReviewDate As DateTime
        '    Public strSupInfoFlag As String
        '    Public intTimeRemainingInClass As Int16
        '    Public strTimeRemainingIdentifier As String
        '    Public strNextScheduledLtr As String
        '    Public dtmNextScheduledLtrDate As DateTime
        '    Public intNumBrokenPTP As Int16
        '    Public intNumBrokenEpar As Int16
        '    Public intNumBrokenBpar As Int16
        '    Public curMemoPayments As Double
        '    Public curRiskBalance As Double
        '    Public strRefWOInd As String
        '    Public curOCM1BscTotalDue As Double
        '    Public curOCM1NBscTotalDue As Double
        '    Public curOCM1TollTotalDue As Double
        '    Public curOCM1DATotalDue As Double
        '    Public curOCM1WrlsTotalDue As Double
        '    Public curOCM1OcarTotalDue As Double
        '    Public curOCM1IPTotalDue As Double
        '    Public curOCM1CPETotalDue As Double
        '    Public curCreditLimitAmt As Double
        '    Public curUsageAmt As Double
        '    Public strCompanyCd As String
        '    Public strLocationCd As String
        '    Public strTEIInd As String
        '    Public intTotalNumLines As Integer
        '    Public intNumLinesPortedOut As Integer
        '    Public strLanguageCd As String
        '    Public strPaymentOptionCd As String
        '    Public strSBMId As String
        '    Public strRecourseInd As String
        '    Public strAdditionalInfo As String
        '    Public strPositionNbr As String
        '    Public strCLECId As String
        '    Public strInCollectionsInd As String
        '    Public strBasicBundleInd As String



        '    Public Sub New()


        '        strCustName = " "
        '        strAcctStatus = " "
        '        strAccntInd = " "
        '        strCheckDigit = " "
        '        strClassOfService = " "
        '        strCSG = " "
        '        dtmCurrBilldt = "1900/01/01"
        '        dtmPayByDt = "1900/01/01"
        '        strTrtHist = " "
        '        strNoGoodChkHist = " "
        '        strBehavScr = " "
        '        dtmDOI = "1900/01/01"
        '        dtmBOSSR1dt = "1900/01/01"
        '        dtmBOSSR2dt = "1900/01/01"
        '        dtmBOSSR3dt = "1900/01/01"
        '        strTreatmentInd = " "
        '        blnClaimInd = False
        '        strClaimPot = " "
        '        curClaimAmt = 0.0
        '        strCurrentClass = " "
        '        blnPermCollFlag = False
        '        strCollectorId = " "
        '        blnTicklerInd = False
        '        strCBR = " "
        '        strPayAdjPtpInd = " "
        '        dtmPTPDt = "1900/01/01"
        '        blnPTPInd = False
        '        blnNTNInd = False
        '        blnOTNInd = False
        '        blnResellerInd = False
        '        blnSRPPInd = False
        '        blnLifeLineInd = False
        '        strCIinfo = ""
        '        dtmLastSNPdt = "1900/01/01"
        '        dtmLastRSTdt = "1900/01/01"
        '        dtmLNPdt = "1900/01/01"
        '        strCollectionRsnCd = " "
        '        strCreditClass = " "
        '        strPrty = " "
        '        curTotalDue = 0.0
        '        curPastDue = 0.0
        '        curCycle0Amt = 0.0
        '        curCycle1Amt = 0.0
        '        curCycle2Amt = 0.0
        '        curCycle3Amt = 0.0
        '        curClaimBasicAmt = 0.0
        '        curClaimNonBasicAmt = 0.0
        '        curClaimTollAmt = 0.0
        '        curClaimDAAmt = 0.0
        '        curRMITotalAmtDue = 0.0
        '        curRMIBasicTotalDue = 0.0
        '        curRMINonBasicTotalDue = 0.0
        '        curRMITollTotalDue = 0.0
        '        curRMIOcarTotalDue = 0.0
        '        curRMIWrlsTotalDue = 0.0
        '        curRMIIPTotalDue = 0.0
        '        curRMICPETotalDue = 0.0
        '        curRMIDATotalDue = 0.0
        '        dtmRMIDirAdvDt = "1900/01/01"
        '        curRMIDirAdvAmt = 0.0
        '        curRMIDirAdvAmt30 = 0.0
        '        curRMIDirAdvAmt60 = 0.0
        '        curRMIDirAdvAmt90 = 0.0
        '        curRMIDirAdvAmt120 = 0.0

        '        strPermNoteInd = " "
        '        dtmOCM1CurBillDate = "1900/01/01"
        '        dtmOCM1PayByDate = "1900/01/01"
        '        strPrferredPymntDay = " "
        '        strPriorAcctHist = " "
        '        strSSN = " "
        '        curDepositHeld = 0.0
        '        dtmCreditVerificationDate = "1900/01/01"
        '        strCheckAcceptInd = " "
        '        strPmtSchedule = " "
        '        dtmNextReviewDate = "1900/01/01"
        '        strSupInfoFlag = " "
        '        intTimeRemainingInClass = 0
        '        strTimeRemainingIdentifier = " "
        '        strNextScheduledLtr = " "
        '        dtmNextScheduledLtrDate = "1900/01/01"
        '        intNumBrokenEpar = 0
        '        intNumBrokenBpar = 0
        '        curRiskBalance = 0.0
        '        strRefWOInd = " "

        '        curOCM1BscTotalDue = 0.0
        '        curOCM1NBscTotalDue = 0.0
        '        curOCM1TollTotalDue = 0.0
        '        curOCM1DATotalDue = 0.0
        '        curOCM1WrlsTotalDue = 0.0
        '        curOCM1OcarTotalDue = 0.0
        '        curOCM1IPTotalDue = 0.0
        '        curOCM1CPETotalDue = 0.0

        '        curCreditLimitAmt = 0.0
        '        curUsageAmt = 0.0
        '        strCompanyCd = " "
        '        strLocationCd = " "
        '        strTEIInd = " "
        '        intTotalNumLines = 0
        '        intNumLinesPortedOut = 0
        '        strLanguageCd = " "
        '        strPaymentOptionCd = " "
        '        strSBMId = " "
        '        strRecourseInd = " "
        '        strAdditionalInfo = " "
        '        strPositionNbr = " "
        '        strInCollectionsInd = " "
        '        strCLECId = " "

        '    End Sub

        'End Class

    End Class

End Namespace
