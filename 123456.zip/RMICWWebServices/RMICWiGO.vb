Imports System.Xml.Serialization
Imports CommonLibrary
Imports System.Xml
Imports Verizon.RMICW.DataAccess
Imports Verizon.RMICW.WebServices
Imports IBM.WMQ
Imports IBM

Imports Microsoft.Web.Services2.Security
Imports Microsoft.Web.Services2
Imports Microsoft.Web.Services2.Dime
Imports System.Web.Services.Protocols
Imports System.Diagnostics
Imports System.Web.Services
Imports System.Net

Namespace Verizon.RMICW.WebServices

#Region "Send iGO "

Public Class RMICWiGO
    Dim ds As New DataSet
    Dim dt As New DataTable
    Dim dr As DataRow

    Dim strvalue As String = ""
    Dim strName As String = ""
    Dim strRegionCd As String = ""
    ' Added
    Dim blnVideo As Boolean = False
    Dim blnData As Boolean = False
    Dim blnVoice As Boolean = False

    Dim objWsMain As WSMain = New WSMain
    Dim objarrServiceType As ArrayList = New ArrayList


    Dim objPut As clsIvappMain = New clsIvappMain
    Dim objiGoSLayout As iGO_SuccessLayout = New iGO_SuccessLayout
    Dim objiGoFLayout As iGO_FailureLayout = New iGO_FailureLayout
    Dim ObjIvapp As clsIvappMain = New clsIvappMain
    Dim ObjSspRqst As SSPRequestDetails = New SSPRequestDetails






#Region " Send iGO Success Message"
    Public Function SendiGoSuccessMsg(ByVal strActn As String, ByVal strOrg As String, ByVal strRegion As String, ByVal objiGoRqst As iGO_SuccessLayout) As iGO_SuccessLayout


        Dim iGOLayOutXML As String = ""
        Dim InitiationDate As New Date
        Dim InitiationTime As New Date

        Dim dtn As DateTime = DateTime.Now


        Try

            objiGoSLayout.strMessageName = "Status"
            objiGoSLayout.strMasterOrderNumber = objiGoRqst.strMasterOrderNumber
            objiGoSLayout.dtmOrderCreateDate = dtn.ToString("d")
            objiGoSLayout.strOrderNumber = objiGoRqst.strOrderNumber

            Select Case objiGoRqst.strOrderType.Trim()
                Case "S"
                    objiGoSLayout.strOrderType = "C"
                Case "D"
                    objiGoSLayout.strOrderType = "D"
                Case "R"
                    objiGoSLayout.strOrderType = "C"
                Case Else
                    LogErrorFile.WriteLog("iGO:", "Incorrect Order type")
            End Select

            objiGoSLayout.dtmDueDate = dtn.ToString("d")
            objiGoSLayout.strCurrentStatusName = "OrderRequested"
            objiGoSLayout.dtmTimestampTheOrderEnteredTheStatus = dtn.ToString("s")
            objiGoSLayout.strBillingTelephoneNumber = objiGoRqst.strBillingTelephoneNumber
            objiGoSLayout.strBAN = objiGoRqst.strBAN
            objiGoSLayout.strPCAN = objiGoRqst.strPCAN
            objiGoSLayout.strAcctNum = objiGoRqst.strAcctNum

            Select Case objiGoRqst.strOrderType.Trim()
                Case "S"
                    objiGoSLayout.strSuspendRestoreDisconnectflag = "S"
                Case "D"
                    objiGoSLayout.strSuspendRestoreDisconnectflag = "D"
                Case "R"
                    objiGoSLayout.strSuspendRestoreDisconnectflag = "R"
                Case Else
                    LogErrorFile.WriteLog("iGO:", "Incorrect Action")
            End Select

            objiGoSLayout.strLOB = objiGoRqst.strLOB

            If (objiGoRqst.strServiceTypes.Video) Then objiGoSLayout.strServiceTypes.Video = "Y"
            If (objiGoRqst.strServiceTypes.Data) Then objiGoSLayout.strServiceTypes.Data = "Y"
            If (objiGoRqst.strServiceTypes.Voice) Then objiGoSLayout.strServiceTypes.Voice = "Y"


            objiGoSLayout.SERVICEADDRESSFIELDS.strFirstName = objiGoRqst.SERVICEADDRESSFIELDS.strFirstName.Trim()
            objiGoSLayout.SERVICEADDRESSFIELDS.strLastName = objiGoRqst.SERVICEADDRESSFIELDS.strLastName.Trim()
            objiGoSLayout.SERVICEADDRESSFIELDS.strStreetNumber = objiGoRqst.SERVICEADDRESSFIELDS.strStreetNumber.Trim()
            objiGoSLayout.SERVICEADDRESSFIELDS.strStreetName = objiGoRqst.SERVICEADDRESSFIELDS.strStreetName.Trim()
            objiGoSLayout.SERVICEADDRESSFIELDS.strUnitType = objiGoRqst.SERVICEADDRESSFIELDS.strUnitType.Trim()
            objiGoSLayout.SERVICEADDRESSFIELDS.strUnitVal = objiGoRqst.SERVICEADDRESSFIELDS.strUnitVal.Trim()
            objiGoSLayout.SERVICEADDRESSFIELDS.strCity = objiGoRqst.SERVICEADDRESSFIELDS.strCity.Trim()
            objiGoSLayout.SERVICEADDRESSFIELDS.strState = objiGoRqst.SERVICEADDRESSFIELDS.strState.Trim()
            objiGoSLayout.SERVICEADDRESSFIELDS.strZip = objiGoRqst.SERVICEADDRESSFIELDS.strZip.Trim()
            strRegionCd = strRegion


            Dim xmlSer As XmlSerializer = New XmlSerializer(GetType(iGO_SuccessLayout))
            iGOLayOutXML = CommonLibrary.GeneralRoutine.SerializeTxn(xmlSer, objiGoSLayout)
            iGOLayOutXML = iGOLayOutXML.Replace("utf-16", "utf-8")

            ObjSspRqst.strDestSystem = "iGO"
            ObjSspRqst.strOrg = strOrg
            ObjSspRqst.strActn = strActn
            ObjSspRqst.strAcctNum = objiGoSLayout.strAcctNum

            ObjIvapp.putTheMessageIntoQueue(iGOLayOutXML, strRegion, "MQiGOPUT", ObjSspRqst)



        Catch ex As Exception
            LogErrorFile.WriteLog("RMICWWS-igo", ex.ToString())

        End Try

        Return objiGoRqst


    End Function
#End Region

#Region " Send iGO Failure Message"
    Public Function SendiGoFailureMsg(ByVal objiGoFRqst As iGO_FailureLayout, ByVal strRegioncd As String, ByVal strActn As String, ByVal strOrg As String, ByVal strAcctnum As String) As iGO_FailureLayout



        Dim iGOLayOutXML As String = ""
        Dim dtn As DateTime = DateTime.Now


        Try

            objiGoFLayout.strMessageName = "Fallout"
            objiGoFLayout.strMasterOrderNumber = objiGoFRqst.strMasterOrderNumber

            objiGoFLayout.strErrorCode = "Err100"
            objiGoFLayout.strErrorMessageDescription = "OrderError"
            objiGoFLayout.strFalloutSource = "SSP"
            objiGoFLayout.strFalloutType = "ServiceOrderError"
            objiGoFLayout.strWorkcenterassignedto = "RMCC"
            objiGoFLayout.dtmTimestampwhentheFallouthappened = dtn.ToString("s")

            If (objiGoFRqst.strServiceTypes.Video) Then objiGoFLayout.strServiceTypes.Video = "Y"
            If (objiGoFRqst.strServiceTypes.Data) Then objiGoFLayout.strServiceTypes.Data = "Y"
            If (objiGoFRqst.strServiceTypes.Voice) Then objiGoFLayout.strServiceTypes.Voice = "Y"

            Dim xmlSer As XmlSerializer = New XmlSerializer(GetType(iGO_FailureLayout))
            iGOLayOutXML = CommonLibrary.GeneralRoutine.SerializeTxn(xmlSer, objiGoFLayout)
            iGOLayOutXML = iGOLayOutXML.Replace("utf-16", "utf-8")

            ObjSspRqst.strDestSystem = "iGO"
            ObjSspRqst.strOrg = "N/A"
            ObjSspRqst.strActn = "S/D/R FAILURE"
            ObjSspRqst.strAcctNum = "ACCT# :"

            ObjIvapp.putTheMessageIntoQueue(iGOLayOutXML, strRegioncd, "MQiGOPUT", ObjSspRqst)



        Catch ex As Exception
            LogErrorFile.WriteLog("RMICWWS-igo", ex.ToString())

        End Try

        Return objiGoFRqst


    End Function
#End Region




#Region "Get the server details from controlparm"
    Public Function getiGODetails(ByVal strRegionID As String, ByVal strParmName As String) As String
        Dim strURL As String = ""
        Dim strCntl As String = "Control" + strRegionID


        Dim WSDataAccessObj As WSDataAccessGeneric = New WSDataAccessGeneric(strRegionID)
        strURL = WSDataAccessObj.usp_GetControlParmByName(strCntl, strParmName)
        Return strURL

    End Function
#End Region




End Class
#End Region


End Namespace