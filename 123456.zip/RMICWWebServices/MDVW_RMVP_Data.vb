'*****************************************************************************************************
'                                                                                                    *
'                               CHANGE MANANGEMENT                                                   *
'                                                                                                    *
'*****************************************************************************************************
' Date      Author                  Purpose                                          Identified By   *
'*****************************************************************************************************
'07/20/08   Murugan            Modified for WR22719 MDVW Echos Replacement          "see for WR22719"
'                                                         
'                              
'****************************************************************************************************

Imports System.Text
Imports System.Xml
Imports System.Xml.Serialization
Imports System.Xml.XmlDataDocument
Imports System.Threading
Imports System.Text.RegularExpressions
Imports System.Net
Imports System.Configuration
Imports System
Imports System.IO
Imports CommonLibrary
Imports IBM.Data.DB2
Imports Verizon.RMICW.DataAccess

Namespace Verizon.RMICW.WebServices


    Public Class XBCLSPA5

        Public strAcctNum As String

        Public objAccountDtls As AccountDetails
        <System.Xml.Serialization.XmlElement(ElementName:="BillDetails", Type:=GetType(BillDetails))> _
        Public arrLstBalanceInfoDetails As ArrayList
        Public RequestStatus As StatusOfRequest

        Public Sub New()

            arrLstBalanceInfoDetails = New ArrayList
            objAccountDtls = New AccountDetails
            RequestStatus = New StatusOfRequest
        End Sub
    End Class

    Public Class BillDetails


        Public curTotBilled As Double
        Public curBalDueAmt As Double
        Public intMonthPastInd As Integer
        Public dtmBillDt As DateTime
        Public dtmPayByDt As DateTime
        Public curBasicAmt As Double
        Public curNonBasicAmt As Double
        Public curTollAmt As Double
        Public curOcarAmt As Double
        Public curWrlsAmt As Double
        Public curDAAmt As Double
        Public curIPAmt As Double
        Public curCPEAmt As Double

        Public Sub New()
            curTotBilled = 0.0
            curBalDueAmt = 0.0
            intMonthPastInd = 0
            dtmBillDt = "1900/01/01"
            dtmPayByDt = "1900/01/01"
            curBasicAmt = 0.0
            curNonBasicAmt = 0.0
            curTollAmt = 0.0
            curOcarAmt = 0.0
            curWrlsAmt = 0.0
            curIPAmt = 0.0
            curCPEAmt = 0.0
        End Sub
    End Class


    Public Class MDVW_RMVP_Data

        Inherits RMICWWSBase
        Public objOC01Fields As New OCABFields

        Dim strConnString As String
        Dim strSchema As String
        Dim RES_RETURN_CODE As Int16

        Dim y As String
        Dim x As String
        Dim z As String
        Dim P As String
        Dim q As String
        Dim D As String
        Dim E As String
        Dim F As String
        Dim G As String
        Dim A As String
        Dim B As String
        Dim C As String
        Dim M As String
        Dim N As String

        Dim Pot1TitleTemp As String
        Dim Pot2TitleTemp As String
        Dim Pot3TitleTemp As String
        Dim Pot4TitleTemp As String

        Dim Pot5TitleTemp As String
        Dim Pot1TotalDuetemp As Double
        Dim Pot2TotalDuetemp As Double
        Dim Pot3TotalDuetemp As Double
        Dim Pot4TotalDuetemp As Double
        Dim Pot5TotalDuetemp As Double

        Dim Pot1PastDuetemp As Double
        Dim Pot2PastDuetemp As Double
        Dim Pot3PastDuetemp As Double
        Dim Pot4PastDuetemp As Double
        Dim Pot5PastDuetemp As Double


        Dim Pot1Month1Duetemp As Double
        Dim Pot2Month1Duetemp As Double
        Dim Pot3Month1Duetemp As Double
        Dim Pot4Month1Duetemp As Double
        Dim Pot5Month1Duetemp As Double

        Dim Pot1Month2Duetemp As Double
        Dim Pot2Month2Duetemp As Double
        Dim Pot3Month2Duetemp As Double
        Dim Pot4Month2Duetemp As Double
        Dim Pot5Month2Duetemp As Double

        Dim Pot1Month3Duetemp As Double
        Dim Pot2Month3Duetemp As Double
        Dim Pot3Month3Duetemp As Double
        Dim Pot4Month3Duetemp As Double
        Dim Pot5Month3Duetemp As Double

        Dim Pot1Month4Duetemp As Double
        Dim Pot2Month4Duetemp As Double
        Dim Pot3Month4Duetemp As Double
        Dim Pot4Month4Duetemp As Double
        Dim Pot5Month4Duetemp As Double

        Dim TotalTotalDue As Double
        Dim TotalPastDue As Double
        Dim TotalMonth1 As String
        Dim TOtalMonth2 As String
        Dim TotalMonth3 As String
        Dim TotalMonth4 As String
        Dim dbPot1TreatableDue, dbPot2TreatableDue, dbPot3TreatableDue, dbPot4TreatableDue, dbPot5TreatableDue As Double

        Public Sub New(ByVal strRegionId As String)
            MyBase.New(strRegionId)

        End Sub


        Public Function get_XBCLSPA5(ByVal strRegionId As String, ByVal strAcctountNum As String, ByVal strEnv As String, ByVal intReadKey As Integer) 'As XBCLSPA5

            Dim objXBCLSPA5 As XBCLSPA5 = New XBCLSPA5

            Try
                strRegionId = "Control" + Trim(strRegionId)

                Dim strXMLoutput, strDayValue As String
                Dim intHistDays As Integer
                Dim dsgetparmval As DataSet
                Dim blnDB2sp As Boolean

                Select Case True

                    Case strRegionId Is Nothing Or strRegionId.Trim = ""
                        objXBCLSPA5.RequestStatus.strMessageId = "INVRGNID"
                        objXBCLSPA5.RequestStatus.strMessageDescription = "Invalid Region Id passed."
                        Return objXBCLSPA5
                    Case strAcctountNum Is Nothing Or strAcctountNum.Trim = ""
                        objXBCLSPA5.RequestStatus.strMessageId = "INVACNBR"
                        objXBCLSPA5.RequestStatus.strMessageDescription = "Invalid Account Number passed as Input."
                        Return objXBCLSPA5
                End Select

                Dim strAcctNum As String = Trim(strAcctountNum)
                Dim strEnvSeg = strEnv.Substring(5, 1)
                Dim strParmName As String = "ERA-MDVW-" & strEnvSeg
                strConnString = Trim(getParmValue(strRegionId, strParmName))

                'Move RequestDetails, ActionDetails and StatusDetails from input to ouput XML
                Dim lsTempArray() As String

                lsTempArray = strConnString.Split("#")
                strConnString = lsTempArray(0)

                Try
                    CallAccountRetrieval_XBCLSPA5_DB2Provider(strAcctNum, intReadKey)

                    If objXBCLSPA5.RequestStatus.strMessageDescription = "NO ACCOUNT FOUND IN EXPRESS TRAK DATABASE" Then
                        Return objXBCLSPA5
                    End If
                Catch ex As Exception

                    If (ex.Message).StartsWith("NO ACCOUNT FOUND") Then
                        objXBCLSPA5.RequestStatus.strMessageId = "100"
                        objXBCLSPA5.RequestStatus.strMessageDescription = "NO ACCOUNT FOUND IN EXPRESS TRAK DATABASE"
                        Return objXBCLSPA5
                    Else
                        objXBCLSPA5.RequestStatus.strMessageId = "100"
                        objXBCLSPA5.RequestStatus.strMessageDescription = ex.Message
                        Return objXBCLSPA5
                    End If
                End Try
                Dim objAccountDtls = New AccountDetails

                'If intReadKey = "1" Or intReadKey = "2" Then
                objAccountDtls = getAccountDetails(objOC01Fields)
                'End If

                Dim arrLstBalanceInfoDetails = New ArrayList
                Dim objBillDtls As BillDetails
                Dim objRequestStatus = New StatusOfRequest
                'If intReadKey = "1" Or intReadKey = "3" Then
                'Get the pot money from OC01
                Dim dbPot1Month1, dbPot2Month1, dbPot3Month1, dbPot4Month1, dbPot5Month1 As Double
                Dim dbPot1Month2, dbPot2Month2, dbPot3Month2, dbPot4Month2, dbPot5Month2 As Double
                Dim dbPot1Month3, dbPot2Month3, dbPot3Month3, dbPot4Month3, dbPot5Month3 As Double
                Dim dbPot1Month4, dbPot2Month4, dbPot3Month4, dbPot4Month4, dbPot5Month4 As Double
                'Dim dbCurTotBilled, dbCurBasicAmt, dbCurNonBasicAmt, dbCurTollAmt As Double
                Dim dbPot1TotalDue, dbPot2TotalDue, dbPot3TotalDue, dbPot4TotalDue, dbPot5TotalDue As Double
                Dim dbPot1PastDue, dbPot2PastDue, dbPot3PastDue, dbPot4PastDue, dbPot5PastDue As Double
                'Dim dbCurOcarAmt, dbCurWrlsAmt, dbCurIPAmt, dbCurCPEAmt As Double
                'FOR BASIC BUCKET ------------------
                If LTrim(RTrim(objOC01Fields.Pot1TotalDue)) = "" Or LTrim(RTrim(objOC01Fields.Pot1TotalDue)) = ".00" Then
                    dbPot1TotalDue = 0.0
                Else
                    dbPot1TotalDue = CDbl(objOC01Fields.Pot1TotalDue)
                End If

                If LTrim(RTrim(objOC01Fields.Pot1PastDue)) = "" Or LTrim(RTrim(objOC01Fields.Pot1PastDue)) = ".00" Then
                    dbPot1PastDue = 0.0
                Else
                    dbPot1PastDue = CDbl(objOC01Fields.Pot1PastDue)
                End If

                If LTrim(RTrim(dbPot1TreatableDue)) = "" Or LTrim(RTrim(dbPot1TreatableDue)) = ".00" Then
                    dbPot1TreatableDue = 0.0
                Else
                    dbPot1TreatableDue = CDbl(dbPot1TreatableDue)
                End If

                If LTrim(RTrim(objOC01Fields.Pot1Month1Due)) = "" Or LTrim(RTrim(objOC01Fields.Pot1Month1Due)) = ".00" Then
                    dbPot1Month1 = 0.0
                Else
                    dbPot1Month1 = CDbl(objOC01Fields.Pot1Month1Due)
                End If

                If LTrim(RTrim(objOC01Fields.Pot1Month2Due)) = "" Or LTrim(RTrim(objOC01Fields.Pot1Month2Due)) = ".00" Then
                    dbPot1Month2 = 0.0
                Else
                    dbPot1Month2 = CDbl(objOC01Fields.Pot1Month2Due)
                End If

                If LTrim(RTrim(objOC01Fields.Pot1Month3Due)) = "" Or LTrim(RTrim(objOC01Fields.Pot1Month3Due)) = ".00" Then
                    dbPot1Month3 = 0.0
                Else
                    dbPot1Month3 = CDbl(objOC01Fields.Pot1Month3Due)
                End If

                If LTrim(RTrim(objOC01Fields.Pot1Month4Due)) = "" Or LTrim(RTrim(objOC01Fields.Pot1Month4Due)) = ".00" Then
                    dbPot1Month4 = 0.0
                Else
                    dbPot1Month4 = CDbl(objOC01Fields.Pot1Month4Due)
                End If
                'FOR BASIC BUCKET ------------------

                'FOR NON-BASIC BUCKET ------------------
                If LTrim(RTrim(objOC01Fields.Pot2TotalDue)) = "" Or LTrim(RTrim(objOC01Fields.Pot2TotalDue)) = ".00" Then
                    dbPot2TotalDue = 0.0
                Else
                    dbPot2TotalDue = CDbl(objOC01Fields.Pot2TotalDue)
                End If

                If LTrim(RTrim(objOC01Fields.Pot2PastDue)) = "" Or LTrim(RTrim(objOC01Fields.Pot2PastDue)) = ".00" Then
                    dbPot2PastDue = 0.0
                Else
                    dbPot2PastDue = CDbl(objOC01Fields.Pot2PastDue)
                End If

                If LTrim(RTrim(dbPot2TreatableDue)) = "" Or LTrim(RTrim(dbPot2TreatableDue)) = ".00" Then
                    dbPot2TreatableDue = 0.0
                Else
                    dbPot2TreatableDue = CDbl(dbPot2TreatableDue)
                End If


                If LTrim(RTrim(objOC01Fields.Pot2Month1Due)) = "" Or LTrim(RTrim(objOC01Fields.Pot2Month1Due)) = ".00" Then
                    dbPot2Month1 = 0.0
                Else
                    dbPot2Month1 = CDbl(objOC01Fields.Pot2Month1Due)
                End If

                If LTrim(RTrim(objOC01Fields.Pot2Month2Due)) = "" Or LTrim(RTrim(objOC01Fields.Pot2Month2Due)) = ".00" Then
                    dbPot2Month2 = 0.0
                Else
                    dbPot2Month2 = CDbl(objOC01Fields.Pot2Month2Due)
                End If

                If LTrim(RTrim(objOC01Fields.Pot2Month3Due)) = "" Or LTrim(RTrim(objOC01Fields.Pot2Month3Due)) = ".00" Then
                    dbPot2Month3 = 0.0
                Else
                    dbPot2Month3 = CDbl(objOC01Fields.Pot2Month3Due)
                End If

                If LTrim(RTrim(objOC01Fields.Pot2Month4Due)) = "" Or LTrim(RTrim(objOC01Fields.Pot2Month4Due)) = ".00" Then
                    dbPot2Month4 = 0.0
                Else
                    dbPot2Month4 = CDbl(objOC01Fields.Pot2Month4Due)
                End If
                'FOR NON-BASIC BUCKET ------------------

                'FOR TOOL BUCKET ------------------
                If LTrim(RTrim(objOC01Fields.Pot3TotalDue)) = "" Or LTrim(RTrim(objOC01Fields.Pot3TotalDue)) = ".00" Then
                    dbPot3TotalDue = 0.0
                Else
                    dbPot3TotalDue = CDbl(objOC01Fields.Pot3TotalDue)
                End If

                If LTrim(RTrim(objOC01Fields.Pot3PastDue)) = "" Or LTrim(RTrim(objOC01Fields.Pot3PastDue)) = ".00" Then
                    dbPot3PastDue = 0.0
                Else
                    dbPot3PastDue = CDbl(objOC01Fields.Pot3PastDue)
                End If

                If LTrim(RTrim(dbPot3TreatableDue)) = "" Or LTrim(RTrim(dbPot3TreatableDue)) = ".00" Then
                    dbPot3TreatableDue = 0.0
                Else
                    dbPot3TreatableDue = CDbl(dbPot3TreatableDue)
                End If

                If LTrim(RTrim(objOC01Fields.Pot3Month1Due)) = "" Or LTrim(RTrim(objOC01Fields.Pot3Month1Due)) = ".00" Then
                    dbPot3Month1 = 0.0
                Else
                    dbPot3Month1 = CDbl(objOC01Fields.Pot3Month1Due)
                End If

                If LTrim(RTrim(objOC01Fields.Pot3Month2Due)) = "" Or LTrim(RTrim(objOC01Fields.Pot3Month2Due)) = ".00" Then
                    dbPot3Month2 = 0.0
                Else
                    dbPot3Month2 = CDbl(objOC01Fields.Pot3Month2Due)
                End If

                If LTrim(RTrim(objOC01Fields.Pot3Month3Due)) = "" Or LTrim(RTrim(objOC01Fields.Pot3Month3Due)) = ".00" Then
                    dbPot3Month3 = 0.0
                Else
                    dbPot3Month3 = CDbl(objOC01Fields.Pot3Month3Due)
                End If

                If LTrim(RTrim(objOC01Fields.Pot3Month4Due)) = "" Or LTrim(RTrim(objOC01Fields.Pot3Month4Due)) = ".00" Then
                    dbPot3Month4 = 0.0
                Else
                    dbPot3Month4 = CDbl(objOC01Fields.Pot3Month4Due)
                End If

                'FOR TOLL BUCKET ------------------

                'FOR DIR ADV BUCKET ------------------
                If LTrim(RTrim(objOC01Fields.Pot4TotalDue)) = "" Or LTrim(RTrim(objOC01Fields.Pot4TotalDue)) = ".00" Then
                    dbPot4TotalDue = 0.0
                Else
                    dbPot4TotalDue = CDbl(objOC01Fields.Pot4TotalDue)
                End If

                If LTrim(RTrim(objOC01Fields.Pot4PastDue)) = "" Or LTrim(RTrim(objOC01Fields.Pot4PastDue)) = ".00" Then
                    dbPot4PastDue = 0.0
                Else
                    dbPot4PastDue = CDbl(objOC01Fields.Pot4PastDue)
                End If

                If LTrim(RTrim(dbPot4TreatableDue)) = "" Or LTrim(RTrim(dbPot4TreatableDue)) = ".00" Then
                    dbPot4TreatableDue = 0.0
                Else
                    dbPot4TreatableDue = CDbl(dbPot4TreatableDue)
                End If


                If LTrim(RTrim(objOC01Fields.Pot4Month1Due)) = "" Or LTrim(RTrim(objOC01Fields.Pot4Month1Due)) = ".00" Then
                    dbPot4Month1 = 0.0
                Else
                    dbPot4Month1 = CDbl(objOC01Fields.Pot4Month1Due)
                End If

                If LTrim(RTrim(objOC01Fields.Pot4Month2Due)) = "" Or LTrim(RTrim(objOC01Fields.Pot4Month2Due)) = ".00" Then
                    dbPot4Month2 = 0.0
                Else
                    dbPot4Month2 = CDbl(objOC01Fields.Pot4Month2Due)
                End If

                If LTrim(RTrim(objOC01Fields.Pot4Month3Due)) = "" Or LTrim(RTrim(objOC01Fields.Pot4Month3Due)) = ".00" Then
                    dbPot4Month3 = 0.0
                Else
                    dbPot4Month3 = CDbl(objOC01Fields.Pot4Month3Due)
                End If

                If LTrim(RTrim(objOC01Fields.Pot4Month4Due)) = "" Or LTrim(RTrim(objOC01Fields.Pot4Month4Due)) = ".00" Then
                    dbPot4Month4 = 0.0
                Else
                    dbPot4Month4 = CDbl(objOC01Fields.Pot4Month4Due)
                End If
                'FOR DIR ADV bucket ------------------

                'FOR NON TELECOME BUCKET ------------------

                If LTrim(RTrim(objOC01Fields.Pot5TotalDue)) = "" Or LTrim(RTrim(objOC01Fields.Pot5TotalDue)) = ".00" Then
                    dbPot5TotalDue = 0.0
                Else
                    dbPot5TotalDue = CDbl(objOC01Fields.Pot5TotalDue)
                End If

                If LTrim(RTrim(objOC01Fields.Pot5PastDue)) = "" Or LTrim(RTrim(objOC01Fields.Pot5PastDue)) = ".00" Then
                    dbPot5PastDue = 0.0
                Else
                    dbPot5PastDue = CDbl(objOC01Fields.Pot5PastDue)
                End If

                If LTrim(RTrim(dbPot5TreatableDue)) = "" Or LTrim(RTrim(dbPot5TreatableDue)) = ".00" Then
                    dbPot5TreatableDue = 0.0
                Else
                    dbPot5TreatableDue = CDbl(dbPot5TreatableDue)
                End If

                If LTrim(RTrim(objOC01Fields.Pot5Month1Due)) = "" Or LTrim(RTrim(objOC01Fields.Pot5Month1Due)) = ".00" Then
                    dbPot5Month1 = 0.0
                Else
                    dbPot5Month1 = CDbl(objOC01Fields.Pot5Month1Due)
                End If

                If LTrim(RTrim(objOC01Fields.Pot5Month2Due)) = "" Or LTrim(RTrim(objOC01Fields.Pot5Month2Due)) = ".00" Then
                    dbPot5Month2 = 0.0
                Else
                    dbPot5Month2 = CDbl(objOC01Fields.Pot5Month2Due)
                End If

                If LTrim(RTrim(objOC01Fields.Pot5Month3Due)) = "" Or LTrim(RTrim(objOC01Fields.Pot5Month3Due)) = ".00" Then
                    dbPot5Month3 = 0.0
                Else
                    dbPot5Month3 = CDbl(objOC01Fields.Pot5Month3Due)
                End If

                If LTrim(RTrim(objOC01Fields.Pot5Month4Due)) = "" Or LTrim(RTrim(objOC01Fields.Pot5Month4Due)) = ".00" Then
                    dbPot5Month4 = 0.0
                Else
                    dbPot5Month4 = CDbl(objOC01Fields.Pot5Month4Due)
                End If




                objBillDtls = New BillDetails
                Dim cnt As Integer = 0


                '******************************************
                'For Total Due Balances
                '******************************************

                If LTrim(RTrim(objOC01Fields.TotalDue)) = "" Or LTrim(RTrim(objOC01Fields.TotalDue)) = "0.0" Then
                    objBillDtls.curTotBilled = 0.0
                Else
                    objBillDtls.curTotBilled = LTrim(RTrim(objOC01Fields.TotalDue))
                End If


                objBillDtls.curBalDueAmt = 0.0


                objBillDtls.intMonthPastInd = 0
                objBillDtls.dtmBillDt = LTrim(RTrim(objOC01Fields.CurrBillDate))
                objBillDtls.dtmPayByDt = LTrim(RTrim(objOC01Fields.paybydate))

                objBillDtls.curBasicAmt = dbPot1TotalDue
                objBillDtls.curNonBasicAmt = dbPot2TotalDue
                objBillDtls.curTollAmt = dbPot3TotalDue
                objBillDtls.curDAAmt = dbPot4TotalDue
                objBillDtls.curWrlsAmt = 0.0
                'ocar bucket is used for Non-telecom in MDVW
                objBillDtls.curOcarAmt = dbPot5TotalDue
                objBillDtls.curIPAmt = 0.0
                objBillDtls.curCPEAmt = 0.0

                arrLstBalanceInfoDetails.Add(objBillDtls)


                '******************************************
                'For Past Due Balances
                '******************************************
                objBillDtls = New BillDetails

                If LTrim(RTrim(objOC01Fields.TotalDue)) = "" Or LTrim(RTrim(objOC01Fields.TotalDue)) = "0.0" Then
                    objBillDtls.curTotBilled = 0.0
                Else
                    objBillDtls.curTotBilled = LTrim(RTrim(objOC01Fields.TotalDue))
                End If

                objBillDtls.curBalDueAmt = 0.0

                objBillDtls.intMonthPastInd = 1
                objBillDtls.dtmBillDt = LTrim(RTrim(objOC01Fields.CurrBillDate))
                objBillDtls.dtmPayByDt = LTrim(RTrim(objOC01Fields.paybydate))

                objBillDtls.curBasicAmt = dbPot1PastDue
                objBillDtls.curNonBasicAmt = dbPot2PastDue
                objBillDtls.curTollAmt = dbPot3PastDue
                objBillDtls.curDAAmt = dbPot4PastDue
                objBillDtls.curWrlsAmt = 0.0
                'ocar bucket is used for Non-telecom in MDVW
                objBillDtls.curOcarAmt = dbPot5PastDue
                objBillDtls.curIPAmt = 0.0
                objBillDtls.curCPEAmt = 0.0

                arrLstBalanceInfoDetails.Add(objBillDtls)


                '******************************************
                'For Treatable Due Balances
                '******************************************
                objBillDtls = New BillDetails

                If LTrim(RTrim(objOC01Fields.TotalDue)) = "" Or LTrim(RTrim(objOC01Fields.TotalDue)) = "0.0" Then
                    objBillDtls.curTotBilled = 0.0
                Else
                    objBillDtls.curTotBilled = LTrim(RTrim(objOC01Fields.TotalDue))
                End If

                objBillDtls.curBalDueAmt = 0.0

                objBillDtls.intMonthPastInd = 2
                objBillDtls.dtmBillDt = LTrim(RTrim(objOC01Fields.CurrBillDate))
                objBillDtls.dtmPayByDt = LTrim(RTrim(objOC01Fields.paybydate))

                objBillDtls.curBasicAmt = dbPot1TreatableDue
                objBillDtls.curNonBasicAmt = dbPot2TreatableDue
                objBillDtls.curTollAmt = dbPot3TreatableDue
                objBillDtls.curDAAmt = dbPot4TreatableDue
                objBillDtls.curWrlsAmt = 0.0
                'ocar bucket is used for Non-telecom in MDVW
                objBillDtls.curOcarAmt = dbPot5TreatableDue
                objBillDtls.curIPAmt = 0.0
                objBillDtls.curCPEAmt = 0.0

                arrLstBalanceInfoDetails.Add(objBillDtls)


                '******************************************
                'For the Current Month Balances
                '******************************************
                objBillDtls = New BillDetails

                If LTrim(RTrim(objOC01Fields.TotalMonth1)) = "" Or LTrim(RTrim(objOC01Fields.TotalMonth1)) = "0.0" Then
                    objBillDtls.curTotBilled = 0.0
                Else
                    objBillDtls.curTotBilled = LTrim(RTrim(objOC01Fields.TotalMonth1))
                End If

                objBillDtls.curBalDueAmt = 0.0

                objBillDtls.intMonthPastInd = 3
                objBillDtls.dtmBillDt = LTrim(RTrim(objOC01Fields.DPDTE1))
                objBillDtls.dtmPayByDt = LTrim(RTrim(objOC01Fields.RFDTE1))

                objBillDtls.curBasicAmt = dbPot1Month1
                objBillDtls.curNonBasicAmt = dbPot2Month1
                objBillDtls.curTollAmt = dbPot3Month1
                objBillDtls.curDAAmt = dbPot4Month1
                objBillDtls.curWrlsAmt = 0.0
                'ocar bucket is used for Non-telecom in MDVW
                objBillDtls.curOcarAmt = dbPot5Month1
                objBillDtls.curIPAmt = 0.0
                objBillDtls.curCPEAmt = 0.0

                arrLstBalanceInfoDetails.Add(objBillDtls)


                '******************************************
                'For (Current Month - 1) Balances
                '******************************************
                objBillDtls = New BillDetails
                If LTrim(RTrim(objOC01Fields.TOtalMonth2)) = "" Or LTrim(RTrim(objOC01Fields.TOtalMonth2)) = "0.0" Then
                    objBillDtls.curTotBilled = 0.0
                Else
                    objBillDtls.curTotBilled = LTrim(RTrim(objOC01Fields.TOtalMonth2))
                End If

                objBillDtls.curBalDueAmt = 0.0

                objBillDtls.intMonthPastInd = 4
                'Public Function GetCalculatedDate(ByVal dtmInputDt As DateTime, ByVal intNumDays As Integer, ByVal strType As String)


                objBillDtls.dtmBillDt = LTrim(RTrim(objOC01Fields.DPDTE2))
                objBillDtls.dtmPayByDt = LTrim(RTrim(objOC01Fields.RFDTE2))
                objBillDtls.curBasicAmt = dbPot1Month2
                objBillDtls.curNonBasicAmt = dbPot2Month2
                objBillDtls.curTollAmt = dbPot3Month2
                objBillDtls.curDAAmt = dbPot4Month2
                objBillDtls.curWrlsAmt = 0.0
                'ocar bucket is used for Non-telecom in MDVW
                objBillDtls.curOcarAmt = dbPot5Month2
                objBillDtls.curIPAmt = 0.0
                objBillDtls.curCPEAmt = 0.0

                arrLstBalanceInfoDetails.Add(objBillDtls)


                '******************************************
                'For (Current Month - 2) Balancs
                '******************************************
                objBillDtls = New BillDetails
                If LTrim(RTrim(objOC01Fields.TotalMonth3)) = "" Or LTrim(RTrim(objOC01Fields.TotalMonth3)) = "0.0" Then
                    objBillDtls.curTotBilled = 0.0
                Else
                    objBillDtls.curTotBilled = LTrim(RTrim(objOC01Fields.TotalMonth3))
                End If

                objBillDtls.curBalDueAmt = 0.0

                objBillDtls.intMonthPastInd = 5
                objBillDtls.dtmBillDt = LTrim(RTrim(objOC01Fields.DPDTE3))
                objBillDtls.dtmPayByDt = LTrim(RTrim(objOC01Fields.RFDTE3))
                objBillDtls.curBasicAmt = dbPot1Month3
                objBillDtls.curNonBasicAmt = dbPot2Month3
                objBillDtls.curTollAmt = dbPot3Month3
                objBillDtls.curDAAmt = dbPot4Month3
                objBillDtls.curWrlsAmt = 0.0
                'ocar bucket is used for Non-telecom in MDVW
                objBillDtls.curOcarAmt = dbPot5Month3
                objBillDtls.curIPAmt = 0.0
                objBillDtls.curCPEAmt = 0.0

                arrLstBalanceInfoDetails.Add(objBillDtls)


                '******************************************
                'For (Current Month - 3) Balances
                '******************************************
                objBillDtls = New BillDetails
                If LTrim(RTrim(objOC01Fields.TotalMonth4)) = "" Or LTrim(RTrim(objOC01Fields.TotalMonth4)) = "0.0" Then
                    objBillDtls.curTotBilled = 0.0
                Else
                    objBillDtls.curTotBilled = LTrim(RTrim(objOC01Fields.TotalMonth4))
                End If

                objBillDtls.curBalDueAmt = 0.0

                objBillDtls.intMonthPastInd = 6
                objBillDtls.dtmBillDt = LTrim(RTrim(objOC01Fields.DPDTE4))
                objBillDtls.dtmPayByDt = LTrim(RTrim(objOC01Fields.RFDTE4))
                objBillDtls.curBasicAmt = dbPot1Month4
                objBillDtls.curNonBasicAmt = dbPot2Month4
                objBillDtls.curTollAmt = dbPot3Month4
                objBillDtls.curDAAmt = dbPot4Month4
                objBillDtls.curWrlsAmt = 0.0
                'ocar bucket is used for Non-telecom in MDVW
                objBillDtls.curOcarAmt = dbPot5Month4
                objBillDtls.curIPAmt = 0.0
                objBillDtls.curCPEAmt = 0.0

                arrLstBalanceInfoDetails.Add(objBillDtls)
                'End If

                'strXMLoutput = createOutputXML()
                '\
                'Serialize output object into Oputput XML and return it to the calling program.
                'Return strXMLoutput
                objXBCLSPA5.objAccountDtls = objAccountDtls
                objXBCLSPA5.arrLstBalanceInfoDetails = arrLstBalanceInfoDetails
                objXBCLSPA5.RequestStatus = objRequestStatus

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-XBCLSPA5", "AcctNum: " & strAcctountNum & " Erroring Out " & ex.ToString)
                objXBCLSPA5.RequestStatus.strMessageId = "RMIEXPTN"
                objXBCLSPA5.RequestStatus.strMessageDescription = ex.ToString
            End Try
            Return objXBCLSPA5

        End Function

        Private Sub CallAccountRetrieval_XBCLSPA5_DB2Provider(ByVal strAcctnum, ByVal intReadKey)

            Dim objXBCLSPA5 As XBCLSPA5 = New XBCLSPA5
            Dim conn As DB2Connection
            Dim cmd As DB2Command
            Dim Adapter As DB2DataAdapter
            Dim ds As DataSet


            Dim CUSTCODE As String
            Dim RES_PA_ERROR_CODE As Integer
            Dim RES_PA_ERROR_AREA As String
            Dim RES_SQLSTATE As String
            Dim RES_ERROR_AREA As String
            Dim rowCounter As Integer
            Dim RES_SQLCODE As Int16 = 9
            Dim strSPA1acct As String


            Try
                conn = New DB2Connection
                cmd = New DB2Command
                Adapter = New DB2DataAdapter
                ds = New DataSet
                conn.ConnectionString = Trim(strConnString.ToString)
                cmd.CommandType = CommandType.StoredProcedure
                cmd.CommandText = "XBCLSP00" & ".XCO_XBCLSPA5"
                cmd.CommandTimeout = 30
                cmd.Connection = conn

                With cmd.Parameters
                    .Add("@REQ_BLACT", DB2Type.Integer).Direction = ParameterDirection.Input
                    .Add("@REQ_READ_MODE", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("@RES_RETURN_CODE", DB2Type.Integer).Direction = ParameterDirection.Output
                    .Add("@RES_ERROR_AREA", DB2Type.VarChar, 200).Direction = ParameterDirection.Output
                    .Add("@RES_SQLCODE", DB2Type.Integer).Direction = ParameterDirection.Output
                    .Add("@RES_SQLSTATE", DB2Type.Char, 5).Direction = ParameterDirection.Output
                    .Add("@RES_PA_ERROR_CODE", DB2Type.Char, 5).Direction = ParameterDirection.Output
                    .Add("@RES_PA_ERROR_AREA", DB2Type.Char, 100).Direction = ParameterDirection.Output

                End With

                With cmd.Parameters
                    .Item("@REQ_READ_MODE").Value = intReadKey
                    .Item("@REQ_BLACT").Value = strAcctnum
                End With

                Adapter.SelectCommand = cmd
                Adapter.Fill(ds)
                RES_SQLCODE = cmd.Parameters("@RES_SQLCODE").Value
                RES_ERROR_AREA = Trim(cmd.Parameters("@RES_ERROR_AREA").Value)
                RES_SQLSTATE = cmd.Parameters("@RES_SQLSTATE").Value
                RES_RETURN_CODE = cmd.Parameters("@RES_RETURN_CODE").Value
                strSPA1acct = cmd.Parameters("@REQ_BLACT").Value


                If RES_RETURN_CODE = "0" Then
                    lfnProcessSPA5(strAcctnum, ds.Tables(0).Rows(0))
                Else
                    If RES_RETURN_CODE = "12" And RES_SQLCODE = 0 Then
                        CommonLibrary.LogErrorFile.WriteLog("RMICWMDVWData:CallAccountRetrieval_XBCLSPA5_DB2Provider :Error ", RES_ERROR_AREA & "   Account: " & strSPA1acct & "SQL STATE:  " & RES_SQLSTATE)
                        'objXBCLSPA5.RequestStatus.strMessageId = "100"
                        'objXBCLSPA5.RequestStatus.strMessageDescription = RES_ERROR_AREA ' "No Matching Account Found in MDVW"

                        Dim objexc As New Exception(RES_ERROR_AREA)
                        Throw objexc
                    Else
                        CommonLibrary.LogErrorFile.WriteLog("RMICWMDVWData:CallAccountRetrieval_XBCLSPA5_DB2Provider :Error ", RES_ERROR_AREA & "   Account: " & strSPA1acct & "SQL STATE:  " & RES_SQLSTATE)
                        'objXBCLSPA5.RequestStatus.strMessageId = "100"
                        'objXBCLSPA5.RequestStatus.strMessageDescription = RES_ERROR_AREA '"No Matching Account Found in MDVW"

                        Dim objexc1 As New Exception(RES_ERROR_AREA)
                        Throw objexc1

                    End If
                End If

            Catch e As Exception
                CommonLibrary.LogErrorFile.WriteLog("RMICWMDVWData:CallAccountRetrieval_XBCLSPA5_DB2Provider :Error: ", e.ToString())
                Throw e
            Finally
                If (conn Is Nothing) Then
                Else
                    If (conn.State = ConnectionState.Open) Then
                        conn.Close()
                    End If
                End If

                If (Not cmd Is Nothing) Then
                    cmd.Dispose()
                End If
                If (Not conn Is Nothing) Then
                    conn.Dispose()
                End If

            End Try

        End Sub

        Private Function lfnProcessSPA5(ByVal strAccountNo As String, ByVal DB2dr As DataRow) As OCABFields


            Try

                objOC01Fields.AccountNumber = Trim(DB2dr("BLACT_F"))
                objOC01Fields.AccountNumber = objOC01Fields.AccountNumber.Replace(" ", "")
                objOC01Fields.CustomerNAME = ""
                objOC01Fields.BillingAddress1 = ""
                objOC01Fields.BillingAddress2 = ""
                objOC01Fields.BillingAddress3 = ""
                objOC01Fields.BillingZip = ""
                objOC01Fields.strBasicBundleInd = Trim(DB2dr("FREEDOM_PKG_I")) ' DC Bucketing Change

                objOC01Fields.accountgroup = Trim(DB2dr("CU_CLS_C"))
                objOC01Fields.Name = ""
                objOC01Fields.TelephoneNumber = ""
                '2007/12/28' 1/1/2005,   1/28/2005,  12/1/2005
                objOC01Fields.DateOfInstall = Trim(DB2dr("BLBLCU_PA_START_DT"))
                If objOC01Fields.DateOfInstall = Nothing Then
                    objOC01Fields.DateOfInstall = getdate1(1011900)
                Else
                    D = (objOC01Fields.DateOfInstall.Substring(0, 2))
                    If D.Substring(1, 1) = "/" Then
                        D = (objOC01Fields.DateOfInstall.Substring(0, 1))
                        F = (objOC01Fields.DateOfInstall.Substring(2, 2))
                        If F.Substring(1, 1) = "/" Then
                            F = (objOC01Fields.DateOfInstall.Substring(2, 1))
                            e = (objOC01Fields.DateOfInstall.Substring(4, 4))
                        Else
                            F = (objOC01Fields.DateOfInstall.Substring(2, 2))
                            e = (objOC01Fields.DateOfInstall.Substring(5, 4))
                        End If
                    Else
                        If Not (D.Substring(1, 1) = "/") Then
                            F = (objOC01Fields.DateOfInstall.Substring(3, 2))
                            If F.Substring(1, 1) = "/" Then
                                F = (objOC01Fields.DateOfInstall.Substring(3, 1))
                                e = (objOC01Fields.DateOfInstall.Substring(5, 4))
                            Else
                                F = (objOC01Fields.DateOfInstall.Substring(3, 2))
                                e = (objOC01Fields.DateOfInstall.Substring(6, 4))
                            End If
                        Else
                            F = (objOC01Fields.DateOfInstall.Substring(3, 2))
                            e = (objOC01Fields.DateOfInstall.Substring(6, 4))
                        End If
                    End If

                    If D > System.DateTime.Now.ToString("MM") Then
                        objOC01Fields.DateOfInstall = objOC01Fields.DateOfInstall & (System.DateTime.Now.Year - 1)
                    Else
                        objOC01Fields.DateOfInstall = objOC01Fields.DateOfInstall & System.DateTime.Now.ToString("yyyy")
                    End If
                    objOC01Fields.DateOfInstall = e & "-" & D & "-" & F
                End If

                objOC01Fields.CbrNumber = ""
                objOC01Fields.spheslfileind = ""
                objOC01Fields.CredEstabDate = getdate1(1011900)
                objOC01Fields.CreditVerifDate = Trim(DB2dr("LAST_CRD_VRFYD_DT"))
                If objOC01Fields.CreditVerifDate = Nothing Then
                    objOC01Fields.CreditVerifDate = getdate1(1011900)
                Else
                    D = (objOC01Fields.CreditVerifDate.Substring(0, 2))
                    If D.Substring(1, 1) = "/" Then
                        D = (objOC01Fields.CreditVerifDate.Substring(0, 1))
                        F = (objOC01Fields.CreditVerifDate.Substring(2, 2))
                        If F.Substring(1, 1) = "/" Then
                            F = (objOC01Fields.CreditVerifDate.Substring(2, 1))
                            e = (objOC01Fields.CreditVerifDate.Substring(4, 4))
                        Else
                            F = (objOC01Fields.CreditVerifDate.Substring(2, 2))
                            e = (objOC01Fields.CreditVerifDate.Substring(5, 4))
                        End If
                    Else
                        If Not (D.Substring(1, 1) = "/") Then
                            F = (objOC01Fields.CreditVerifDate.Substring(3, 2))
                            If F.Substring(1, 1) = "/" Then
                                F = (objOC01Fields.CreditVerifDate.Substring(3, 1))
                                e = (objOC01Fields.CreditVerifDate.Substring(5, 4))
                            Else
                                F = (objOC01Fields.CreditVerifDate.Substring(3, 2))
                                e = (objOC01Fields.CreditVerifDate.Substring(6, 4))
                            End If
                        Else
                            F = (objOC01Fields.CreditVerifDate.Substring(3, 2))
                            e = (objOC01Fields.CreditVerifDate.Substring(6, 4))
                        End If
                    End If

                    If D > System.DateTime.Now.ToString("MM") Then
                        objOC01Fields.CreditVerifDate = objOC01Fields.CreditVerifDate & (System.DateTime.Now.Year - 1)
                    Else
                        objOC01Fields.CreditVerifDate = objOC01Fields.CreditVerifDate & System.DateTime.Now.ToString("yyyy")
                    End If
                    objOC01Fields.CreditVerifDate = e & "-" & D & "-" & F
                End If

                objOC01Fields.SSN = ""   ' Trim(DB2dr("SOCL_SCTY_B"))
                'objOC01Fields.TreatmentInd = Trim(DB2dr("BLACT_TMT_SCN_B")) 'WR22719 commented 
                objOC01Fields.TreatmentInd = ""
                objOC01Fields.treatmentstatus = Trim(DB2dr("TMT_EXCLN_C"))
                objOC01Fields.SVORDERSTATUS = ""
                objOC01Fields.AccountStatus = (DB2dr("BLACT_STTE_C"))
                objOC01Fields.spheslfileind = ""
                objOC01Fields.CurrBillDate = Trim(DB2dr("BILL_RND_DMY_1"))
                If objOC01Fields.CurrBillDate = Nothing Then
                    objOC01Fields.CurrBillDate = getdate1(1011900)
                Else
                    '2007/12/28'
                    D = (objOC01Fields.CurrBillDate.Substring(0, 2))
                    If D.Substring(1, 1) = "/" Then
                        D = (objOC01Fields.CurrBillDate.Substring(0, 1))
                        F = (objOC01Fields.CurrBillDate.Substring(2, 2))
                        If F.Substring(1, 1) = "/" Then
                            F = (objOC01Fields.CurrBillDate.Substring(2, 1))
                            e = (objOC01Fields.CurrBillDate.Substring(4, 4))
                        Else
                            F = (objOC01Fields.CurrBillDate.Substring(2, 2))
                            e = (objOC01Fields.CurrBillDate.Substring(5, 4))
                        End If
                    Else
                        If Not (D.Substring(1, 1) = "/") Then
                            F = (objOC01Fields.CurrBillDate.Substring(3, 2))
                            If F.Substring(1, 1) = "/" Then
                                F = (objOC01Fields.CurrBillDate.Substring(3, 1))
                                e = (objOC01Fields.CurrBillDate.Substring(5, 4))
                            Else
                                F = (objOC01Fields.CurrBillDate.Substring(3, 2))
                                e = (objOC01Fields.CurrBillDate.Substring(6, 4))
                            End If
                        Else
                            F = (objOC01Fields.CurrBillDate.Substring(3, 2))
                            e = (objOC01Fields.CurrBillDate.Substring(6, 4))
                        End If
                    End If

                    If D > System.DateTime.Now.ToString("MM") Then
                        objOC01Fields.CurrBillDate = objOC01Fields.CurrBillDate & (System.DateTime.Now.Year - 1)
                    Else
                        objOC01Fields.CurrBillDate = objOC01Fields.CurrBillDate & System.DateTime.Now.ToString("yyyy")
                    End If
                    objOC01Fields.CurrBillDate = e & "-" & D & "-" & F
                End If
                objOC01Fields.PastDueAmt = Getnegative(Trim(DB2dr("ACCT_PASTD_TOT")))
                'to code current charges
                objOC01Fields.TotalDue = Getnegative(Trim(DB2dr("ACCT_TTL_TOT")))
                objOC01Fields.paybydate = (Trim(DB2dr("PAY_DUE_DT_1")))
                If objOC01Fields.paybydate = Nothing Then
                    objOC01Fields.paybydate = getdate1(1011900)
                Else
                    D = (objOC01Fields.paybydate.Substring(0, 2))
                    If D.Substring(1, 1) = "/" Then
                        D = (objOC01Fields.paybydate.Substring(0, 1))
                        F = (objOC01Fields.paybydate.Substring(2, 2))
                        If F.Substring(1, 1) = "/" Then
                            F = (objOC01Fields.paybydate.Substring(2, 1))
                            e = (objOC01Fields.paybydate.Substring(4, 4))
                        Else
                            F = (objOC01Fields.paybydate.Substring(2, 2))
                            e = (objOC01Fields.paybydate.Substring(5, 4))
                        End If
                    Else
                        If Not (D.Substring(1, 1) = "/") Then
                            F = (objOC01Fields.paybydate.Substring(3, 2))
                            If F.Substring(1, 1) = "/" Then
                                F = (objOC01Fields.paybydate.Substring(3, 1))
                                e = (objOC01Fields.paybydate.Substring(5, 4))
                            Else
                                F = (objOC01Fields.paybydate.Substring(3, 2))
                                e = (objOC01Fields.paybydate.Substring(6, 4))
                            End If
                        Else
                            F = (objOC01Fields.paybydate.Substring(3, 2))
                            e = (objOC01Fields.paybydate.Substring(6, 4))
                        End If
                    End If

                    If D > System.DateTime.Now.ToString("MM") Then
                        objOC01Fields.paybydate = objOC01Fields.paybydate & (System.DateTime.Now.Year - 1)
                    Else
                        objOC01Fields.paybydate = objOC01Fields.paybydate & System.DateTime.Now.ToString("yyyy")
                    End If
                    objOC01Fields.paybydate = e & "-" & D & "-" & F
                End If

                objOC01Fields.LastPmtDate = "0101"
                objOC01Fields.LastPmtAmt = Trim(DB2dr("AR_LAST_BILL_AMT"))
                objOC01Fields.LastPmtAmt = Getnegative(objOC01Fields.LastPmtAmt)
                objOC01Fields.CYCLE0 = 0.0

                objOC01Fields.CYCLE1 = 0.0

                objOC01Fields.CYCLE2 = 0.0

                objOC01Fields.CYCLE3 = 0.0

                objOC01Fields.CYCLE4 = 0.0

                objOC01Fields.Behaviorscore = Trim(DB2dr("BLACT_ALND_SCR_B"))
                objOC01Fields.NoGoodCheckHist = ""
                objOC01Fields.chkdigit = Trim(DB2dr("BLACT_CHK_DIGIT_B"))
                objOC01Fields.ACCounttype = Trim(DB2dr("COMPET_SV_YC"))
                objOC01Fields.MSGBIND = Trim(DB2dr("SPCL_BLACT_YC")) ' used for Gift Billing-Residential for MDVW EDI
                objOC01Fields.noticeexpdate = "1900/01/01"
                objOC01Fields.CheckAcceptInd = Trim(DB2dr("BLACT_CHK_ACP_I"))
                objOC01Fields.Treatmenthist = Trim(DB2dr("BLACT_TMT_ACN_YC1")) & Trim(DB2dr("BLACT_TMT_ACN_YC2")) & Trim(DB2dr("BLACT_TMT_ACN_YC3")) _
                    & Trim(DB2dr("BLACT_TMT_ACN_YC4")) & Trim(DB2dr("BLACT_TMT_ACN_YC5")) & Trim(DB2dr("BLACT_TMT_ACN_YC6")) _
                    & Trim(DB2dr("BLACT_TMT_ACN_YC7")) & Trim(DB2dr("BLACT_TMT_ACN_YC8")) & Trim(DB2dr("BLACT_TMT_ACN_YC8")) _
                    & Trim(DB2dr("BLACT_TMT_ACN_YC10")) & Trim(DB2dr("BLACT_TMT_ACN_YC11")) & Trim(DB2dr("BLACT_TMT_ACN_YC12"))
                objOC01Fields.treatmentstatus = Trim(DB2dr("TMT_EXCLN_C"))
                objOC01Fields.PrefpaymentDate = Trim(DB2dr("PREFD_PYMT_DY_B"))
                objOC01Fields.MSGNOTE = ""
                objOC01Fields.Brokenptp = ""
                objOC01Fields.BrokenEPAR = ""
                objOC01Fields.TOLLCREDLMT = Trim(DB2dr("BLACT_TOLL_SHDW_A"))
                objOC01Fields.TOLLCREDLMT = objOC01Fields.TOLLCREDLMT.TrimStart("0"c)
                objOC01Fields.CLAIMBA = Trim(DB2dr("BLACT_CLM_BA_A"))
                objOC01Fields.CLAIMTL = Trim(DB2dr("BLACT_CLM_TL_A"))
                objOC01Fields.CLAIMNB = Trim(DB2dr("BLACT_CLM_NA_A"))
                objOC01Fields.CLAIMDA = Trim(DB2dr("BLACT_CLM_DA_A"))
                objOC01Fields.CLAIMNT = Trim(DB2dr("BLACT_CLM_NT_A"))

                If Trim(objOC01Fields.CLAIMBA) = "0" And _
                    Trim(objOC01Fields.CLAIMTL) = "0" And _
                    Trim(objOC01Fields.CLAIMNB) = "0" And _
                    Trim(objOC01Fields.CLAIMDA) = "0" And _
                    Trim(objOC01Fields.CLAIMNT) = "0" Then
                    objOC01Fields.ClaimInd = ""
                    objOC01Fields.ClaimPOT = ""
                    objOC01Fields.ClaimAMT = ""
                Else
                    objOC01Fields.ClaimInd = "Y"
                    objOC01Fields.ClaimPOT = "Y"
                    objOC01Fields.ClaimAMT = "0.0"
                End If


                objOC01Fields.CurrentClass = ""
                objOC01Fields.CLASSDATE = ""
                If objOC01Fields.CLASSDATE = Nothing Then
                    objOC01Fields.CLASSDATE = getdate1(1011900)
                Else
                    D = (objOC01Fields.CLASSDATE.Substring(0, 2))
                    If D.Substring(1, 1) = "/" Then
                        D = (objOC01Fields.CLASSDATE.Substring(0, 1))
                        F = (objOC01Fields.CLASSDATE.Substring(2, 2))
                        If F.Substring(1, 1) = "/" Then
                            F = (objOC01Fields.CLASSDATE.Substring(2, 1))
                            e = (objOC01Fields.CLASSDATE.Substring(4, 4))
                        Else
                            F = (objOC01Fields.CLASSDATE.Substring(2, 2))
                            e = (objOC01Fields.CLASSDATE.Substring(5, 4))
                        End If
                    Else
                        If Not (D.Substring(1, 1) = "/") Then
                            F = (objOC01Fields.CLASSDATE.Substring(3, 2))
                            If F.Substring(1, 1) = "/" Then
                                F = (objOC01Fields.CLASSDATE.Substring(3, 1))
                                e = (objOC01Fields.CLASSDATE.Substring(5, 4))
                            Else
                                F = (objOC01Fields.CLASSDATE.Substring(3, 2))
                                e = (objOC01Fields.CLASSDATE.Substring(6, 4))
                            End If
                        Else
                            F = (objOC01Fields.CLASSDATE.Substring(3, 2))
                            e = (objOC01Fields.CLASSDATE.Substring(6, 4))
                        End If
                    End If

                    If D > System.DateTime.Now.ToString("MM") Then
                        objOC01Fields.CLASSDATE = objOC01Fields.CLASSDATE & (System.DateTime.Now.Year - 1)
                    Else
                        objOC01Fields.CLASSDATE = objOC01Fields.CLASSDATE & System.DateTime.Now.ToString("yyyy")
                    End If
                    objOC01Fields.CLASSDATE = e & "-" & D & "-" & F
                End If



                objOC01Fields.dnrind = Trim(DB2dr("DNR_I"))


                Dim boolPayAdjPtp As Boolean = False
                Dim strPromiseToPayAmt1 As String
                Dim strPromiseToPayAmt2 As String
                Dim strAdjAmt As String
                Dim strPayAmt As String

                objOC01Fields.payind = ""


                If Not (strPayAmt = "0.00" Or strPayAmt = "0") Then
                    objOC01Fields.payind = "PAY"
                End If

                objOC01Fields.pvtind = ""



                objOC01Fields.Pot1Title = Trim(DB2dr("PA_ACT_BALNM_1"))
                If objOC01Fields.Pot1Title = "" Then
                    objOC01Fields.Pot1Title = " "
                End If


                If objOC01Fields.Pot1Title = "REGSVCT" Then

                    dbPot1TreatableDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_1")))
                    Pot1TotalDuetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_1")))
                    objOC01Fields.Pot1Month1Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH1_1")))
                    Pot1Month1Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH1_1")))
                    objOC01Fields.Pot1Month2Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_1")))
                    Pot1Month2Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_1")))
                    objOC01Fields.Pot1Month3Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_1")))
                    Pot1Month3Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_1")))
                    objOC01Fields.Pot1Month4Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_1")))
                    Pot1Month4Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_1")))
                Else
                    If objOC01Fields.Pot1Title = "NREGSVCT" Then
                        dbPot2TreatableDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_1")))
                        Pot2TotalDuetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_1")))
                        objOC01Fields.Pot2Month1Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH1_1")))
                        Pot2Month1Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH1_1")))
                        objOC01Fields.Pot2Month2Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_1")))
                        Pot2Month2Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_1")))
                        objOC01Fields.Pot2Month3Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_1")))
                        Pot2Month3Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_1")))
                        objOC01Fields.Pot2Month4Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_1")))
                        Pot2Month4Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_1")))
                    Else
                        If objOC01Fields.Pot1Title = "TOLLSVCT" Then
                            dbPot3TreatableDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_1")))
                            Pot3TotalDuetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_1")))

                            objOC01Fields.Pot3Month1Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH1_1")))
                            Pot3Month1Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH1_1")))
                            objOC01Fields.Pot3Month2Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_1")))
                            Pot3Month2Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_1")))
                            objOC01Fields.Pot3Month3Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_1")))
                            Pot3Month3Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_1")))
                            objOC01Fields.Pot3Month4Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_1")))
                            Pot3Month4Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_1")))
                        Else
                            If objOC01Fields.Pot1Title = "DIRECADV" Then
                                dbPot4TreatableDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_1")))
                                Pot4TotalDuetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_1")))
                                objOC01Fields.Pot4Month1Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH1_1")))
                                Pot4Month1Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH1_1")))
                                objOC01Fields.Pot4Month2Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_1")))
                                Pot4Month2Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_1")))
                                objOC01Fields.Pot4Month3Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_1")))
                                Pot4Month3Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_1")))
                                objOC01Fields.Pot4Month4Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_1")))
                                Pot4Month4Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_1")))
                            Else
                                If objOC01Fields.Pot1Title = "NTELSVCT" Then

                                    dbPot5TreatableDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_1")))
                                    Pot5TotalDuetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_1")))

                                    objOC01Fields.Pot5Month1Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH1_1")))
                                    Pot5Month1Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH1_1")))
                                    objOC01Fields.Pot5Month2Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_1")))
                                    Pot5Month2Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_1")))
                                    objOC01Fields.Pot5Month3Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_1")))
                                    Pot5Month3Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_1")))
                                    objOC01Fields.Pot5Month4Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_1")))
                                    Pot5Month4Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_1")))
                                End If
                            End If
                        End If
                    End If
                End If
                'End If



                objOC01Fields.Pot2Title = Trim(DB2dr("PA_ACT_BALNM_2"))
                If objOC01Fields.Pot2Title = "" Then
                    objOC01Fields.Pot2Title = " "
                End If
                'If (objOC01Fields.payind = "PTP" Or objOC01Fields.payind = "PAY" Or objOC01Fields.payind = "ADJ") Then
                If objOC01Fields.Pot2Title = "NREGSVCT" Then
                    'objOC01Fields.Pot2TotalDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_2")))
                    dbPot2TreatableDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_2")))
                    Pot2TotalDuetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_2")))
                    'objOC01Fields.Pot2PastDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_P_D_2")))
                    'Pot2PastDuetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_P_D_2")))
                    objOC01Fields.Pot2Month1Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH1_2")))
                    Pot2Month1Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH1_2")))
                    objOC01Fields.Pot2Month2Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_2")))
                    Pot2Month2Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_2")))
                    objOC01Fields.Pot2Month3Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_2")))
                    Pot2Month3Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_2")))
                    objOC01Fields.Pot2Month4Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_2")))
                    Pot2Month4Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_2")))
                Else
                    If objOC01Fields.Pot2Title = "TOLLSVCT" Then

                        dbPot3TreatableDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_2")))
                        Pot3TotalDuetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_2")))
                        objOC01Fields.Pot3Month1Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH1_2")))
                        Pot3Month1Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH1_2")))
                        objOC01Fields.Pot3Month2Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_2")))
                        Pot3Month2Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_2")))
                        objOC01Fields.Pot3Month3Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_2")))
                        Pot3Month3Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_2")))
                        objOC01Fields.Pot3Month4Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_2")))
                        Pot3Month4Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_2")))
                    Else
                        If objOC01Fields.Pot2Title = "DIRECADV" Then

                            dbPot4TreatableDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_2")))
                            Pot4TotalDuetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_2")))
                            objOC01Fields.Pot4Month1Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH1_2")))
                            Pot4Month1Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH1_2")))
                            objOC01Fields.Pot4Month2Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_2")))
                            Pot4Month2Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_2")))
                            objOC01Fields.Pot4Month3Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_2")))
                            Pot4Month3Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_2")))
                            objOC01Fields.Pot4Month4Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_2")))
                            Pot4Month4Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_2")))
                        Else
                            If objOC01Fields.Pot2Title = "NTELSVCT" Then
                                dbPot5TreatableDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_2")))
                                Pot5TotalDuetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_2")))
                                objOC01Fields.Pot5Month1Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH1_2")))
                                Pot5Month1Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH1_2")))
                                objOC01Fields.Pot5Month2Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_2")))
                                Pot5Month2Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_2")))
                                objOC01Fields.Pot5Month3Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_2")))
                                Pot5Month3Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_2")))
                                objOC01Fields.Pot5Month4Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_2")))
                                Pot5Month4Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_2")))
                            End If
                        End If
                    End If
                End If
                'End If


                objOC01Fields.Pot3Title = Trim(DB2dr("PA_ACT_BALNM_3"))
                If objOC01Fields.Pot3Title = "" Then
                    objOC01Fields.Pot3Title = " "
                End If


                If objOC01Fields.Pot3Title = "TOLLSVCT" Then
                    dbPot3TreatableDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_3")))
                    Pot3TotalDuetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_3")))


                    objOC01Fields.Pot3Month1Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH1_3")))
                    Pot3Month1Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH1_3")))
                    objOC01Fields.Pot3Month2Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_3")))
                    Pot3Month2Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_3")))
                    objOC01Fields.Pot3Month3Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_3")))
                    Pot3Month3Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_3")))
                    objOC01Fields.Pot3Month4Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_3")))
                    Pot3Month4Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_3")))
                Else
                    If objOC01Fields.Pot3Title = "NREGSVCT" Then
                        'objOC01Fields.Pot2TotalDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_3")))
                        dbPot2TreatableDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_3")))
                        Pot2TotalDuetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_3")))
                        'objOC01Fields.Pot2PastDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_P_D_3")))
                        'Pot2PastDuetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_P_D_3")))
                        objOC01Fields.Pot2Month1Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH1_3")))
                        Pot2Month1Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH1_3")))
                        objOC01Fields.Pot2Month2Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_3")))
                        Pot2Month2Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_3")))
                        objOC01Fields.Pot2Month3Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_3")))
                        Pot2Month3Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_3")))
                        objOC01Fields.Pot2Month4Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_3")))
                        Pot2Month4Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_3")))
                    Else
                        If objOC01Fields.Pot3Title = "DIRECADV" Then
                            'objOC01Fields.Pot4TotalDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_3")))
                            dbPot4TreatableDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_3")))
                            Pot4TotalDuetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_3")))
                            'objOC01Fields.Pot4PastDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_P_D_3")))
                            'Pot4PastDuetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_P_D_3")))
                            objOC01Fields.Pot4Month1Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH1_4")))
                            Pot4Month1Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH1_4")))
                            objOC01Fields.Pot4Month2Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_4")))
                            Pot4Month2Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_4")))
                            objOC01Fields.Pot4Month3Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_4")))
                            Pot4Month3Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_4")))
                            objOC01Fields.Pot4Month4Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_4")))
                            Pot4Month4Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_4")))
                        Else
                            If objOC01Fields.Pot3Title = "NTELSVCT" Then
                                'objOC01Fields.Pot5TotalDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_3")))
                                dbPot5TreatableDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_3")))
                                Pot5TotalDuetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_3")))
                                'objOC01Fields.Pot5PastDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_P_D_3")))
                                'Pot5PastDuetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_P_D_3")))
                                objOC01Fields.Pot5Month1Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH1_5")))
                                Pot5Month1Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH1_5")))
                                objOC01Fields.Pot5Month2Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_5")))
                                Pot5Month2Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_5")))
                                objOC01Fields.Pot5Month3Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_5")))
                                Pot5Month3Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_5")))
                                objOC01Fields.Pot5Month4Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_5")))
                                Pot5Month4Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_5")))
                            End If
                        End If
                    End If
                End If
                'End If


                objOC01Fields.Pot4Title = Trim(DB2dr("PA_ACT_BALNM_4"))
                If objOC01Fields.Pot4Title = "" Then
                    objOC01Fields.Pot4Title = " "
                End If

                'If (objOC01Fields.payind = "PTP" Or objOC01Fields.payind = "PAY" Or objOC01Fields.payind = "ADJ") Then
                If objOC01Fields.Pot4Title = "DIRECADV" Then
                    'objOC01Fields.Pot4TotalDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_4")))
                    dbPot4TreatableDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_4")))
                    Pot4TotalDuetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_4")))
                    'objOC01Fields.Pot4PastDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_P_D_4")))
                    'Pot4PastDuetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_P_D_4")))
                    Pot4Month1Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH1_4")))
                    objOC01Fields.Pot4Month2Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_4")))
                    Pot4Month2Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_4")))
                    objOC01Fields.Pot4Month3Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_4")))
                    Pot4Month3Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_4")))
                    objOC01Fields.Pot4Month4Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_4")))
                    Pot4Month4Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_4")))
                Else
                    If objOC01Fields.Pot4Title = "NTELSVCT" Then
                        'objOC01Fields.Pot5TotalDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_4")))
                        dbPot5TreatableDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_4")))
                        Pot5TotalDuetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_4")))
                        'objOC01Fields.Pot5PastDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_P_D_4")))
                        'Pot5PastDuetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_P_D_4")))
                        objOC01Fields.Pot5Month1Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH1_4")))
                        Pot5Month1Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH1_4")))
                        objOC01Fields.Pot5Month2Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_4")))
                        Pot5Month2Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_4")))
                        objOC01Fields.Pot5Month3Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_4")))
                        Pot5Month3Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_4")))
                        objOC01Fields.Pot5Month4Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_4")))
                        Pot5Month4Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_4")))
                    End If
                End If
                'End If

                objOC01Fields.Pot5Title = Trim(DB2dr("PA_ACT_BALNM_5"))
                If objOC01Fields.Pot5Title = "" Then
                    objOC01Fields.Pot5Title = " "
                End If

                'If (objOC01Fields.payind = "PTP" Or objOC01Fields.payind = "PAY" Or objOC01Fields.payind = "ADJ") Then
                If objOC01Fields.Pot5Title = "NTELSVCT" Then
                    'objOC01Fields.Pot5TotalDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_5")))
                    dbPot5TreatableDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_5")))
                    Pot5TotalDuetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_5")))
                    'objOC01Fields.Pot5PastDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_P_D_5")))
                    'Pot5PastDuetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_P_D_5")))
                    objOC01Fields.Pot5Month1Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH1_5")))
                    Pot5Month1Duetemp = Getnegative(Trim(DB2dr("ACCT_MTH1_AMT_5")))
                    objOC01Fields.Pot5Month2Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_5")))
                    Pot5Month2Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_5")))
                    objOC01Fields.Pot5Month3Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_5")))
                    Pot5Month3Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_5")))
                    objOC01Fields.Pot5Month4Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_5")))
                    Pot5Month4Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_5")))
                Else
                    If objOC01Fields.Pot5Title = "DIRECADV" Then
                        'objOC01Fields.Pot4TotalDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_5")))
                        dbPot4TreatableDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_5")))
                        Pot4TotalDuetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_TOT_5")))
                        'objOC01Fields.Pot4PastDue = Getnegative(Trim(DB2dr("PA_ACT_SMRY_P_D_5")))
                        'Pot4PastDuetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_P_D_5")))
                        objOC01Fields.Pot4Month1Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH1_5")))
                        Pot4Month1Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH1_5")))
                        objOC01Fields.Pot4Month2Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_5")))
                        Pot4Month2Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH2_5")))
                        objOC01Fields.Pot4Month3Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_5")))
                        Pot4Month3Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH3_5")))
                        objOC01Fields.Pot4Month4Due = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_5")))
                        Pot4Month4Duetemp = Getnegative(Trim(DB2dr("PA_ACT_SMRY_MTH4_5")))
                    End If
                End If
                'End If



                Pot1TitleTemp = Trim(DB2dr("ACCT_BAL_NM_1"))
                If Pot1TitleTemp = "" Then
                    Pot1TitleTemp = " "
                End If
                If Pot1TitleTemp = "REG TOTAL" Or Pot1TitleTemp = "BASIC TOTAL" Then

                    objOC01Fields.Pot1TotalDue = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_1")))
                    Pot1TotalDuetemp = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_1")))
                    objOC01Fields.Pot1PastDue = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_1")))
                    Pot1PastDuetemp = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_1")))

                ElseIf Pot1TitleTemp = "UNREG TOTAL" Or Pot2TitleTemp = "NONBASIC TOT" Then

                    objOC01Fields.Pot2TotalDue = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_1")))
                    Pot2TotalDuetemp = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_1")))
                    objOC01Fields.Pot2PastDue = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_1")))
                    Pot2PastDuetemp = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_1")))

                ElseIf Pot1TitleTemp = "TOLL TOTAL" Or Pot2TitleTemp = "TOLLSVCT" Then
                    objOC01Fields.Pot3TotalDue = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_1")))
                    Pot3TotalDuetemp = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_1")))
                    objOC01Fields.Pot3PastDue = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_1")))
                    Pot3PastDuetemp = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_1")))

                ElseIf Pot1TitleTemp = "NONTELCM TOT" Or Pot2TitleTemp = "NTELSVCT" Then

                    objOC01Fields.Pot5TotalDue = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_1")))
                    Pot5TotalDuetemp = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_1")))
                    objOC01Fields.Pot5PastDue = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_1")))
                    Pot5PastDuetemp = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_1")))

                ElseIf Pot1TitleTemp = "DIRECTORY AD" Then

                    objOC01Fields.Pot4TotalDue = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_1")))
                    Pot4TotalDuetemp = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_1")))
                    objOC01Fields.Pot4PastDue = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_1")))
                    Pot4PastDuetemp = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_1")))

                End If



                Pot2TitleTemp = Trim(DB2dr("ACCT_BAL_NM_2"))
                If Pot2TitleTemp = "" Then
                    Pot2TitleTemp = " "
                End If
                If Pot2TitleTemp = "UNREG TOTAL" Or Pot2TitleTemp = "NONBASIC TOT" Then

                    objOC01Fields.Pot2TotalDue = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_2")))
                    Pot2TotalDuetemp = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_2")))
                    objOC01Fields.Pot2PastDue = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_2")))
                    Pot2PastDuetemp = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_2")))

                ElseIf Pot2TitleTemp = "TOLL TOTAL" Or Pot2TitleTemp = "TOLLSVCT" Then

                    objOC01Fields.Pot3TotalDue = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_2")))
                    Pot3TotalDuetemp = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_2")))
                    objOC01Fields.Pot3PastDue = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_2")))
                    Pot3PastDuetemp = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_2")))
                ElseIf Pot2TitleTemp = "NONTELCM TOT" Or Pot2TitleTemp = "NTELSVCT" Then

                    objOC01Fields.Pot5TotalDue = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_2")))
                    Pot5TotalDuetemp = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_2")))
                    objOC01Fields.Pot5PastDue = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_2")))
                    Pot5PastDuetemp = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_2")))
                ElseIf Pot2TitleTemp = "DIRECTORY AD" Then

                    objOC01Fields.Pot4TotalDue = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_2")))
                    Pot4TotalDuetemp = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_2")))
                    objOC01Fields.Pot4PastDue = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_2")))
                    Pot4PastDuetemp = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_2")))
                End If



                Pot3TitleTemp = Trim(DB2dr("ACCT_BAL_NM_3"))
                If Pot2TitleTemp = "" Then
                    Pot2TitleTemp = " "
                End If
                If Pot3TitleTemp = "TOLL TOTAL" Or Pot3TitleTemp = "TOLLSVCT" Then

                    objOC01Fields.Pot3TotalDue = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_3")))
                    Pot3TotalDuetemp = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_3")))
                    objOC01Fields.Pot3PastDue = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_3")))
                    Pot3PastDuetemp = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_3")))

                ElseIf Pot3TitleTemp = "UNREG TOTAL" Or Pot3TitleTemp = "NONBASIC TOT" Then

                    objOC01Fields.Pot2TotalDue = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_3")))
                    Pot2TotalDuetemp = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_3")))
                    objOC01Fields.Pot2PastDue = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_3")))
                    Pot2PastDuetemp = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_3")))


                ElseIf Pot3TitleTemp = "NONTELCM TOT" Or Pot3TitleTemp = "NTELSVCT" Then
                    objOC01Fields.Pot5TotalDue = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_3")))
                    Pot5TotalDuetemp = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_3")))
                    objOC01Fields.Pot5PastDue = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_3")))
                    Pot5PastDuetemp = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_3")))

                ElseIf Pot3TitleTemp = "DIRECTORY AD" Then
                    objOC01Fields.Pot4TotalDue = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_3")))
                    Pot4TotalDuetemp = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_3")))
                    objOC01Fields.Pot4PastDue = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_3")))
                    Pot4PastDuetemp = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_3")))

                End If


                Pot4TitleTemp = Trim(DB2dr("ACCT_BAL_NM_4"))
                If Pot4TitleTemp = "" Then
                    Pot4TitleTemp = " "
                End If
                If Pot4TitleTemp = "NONTELCM TOT" Or Pot4TitleTemp = "NTELSVCT" Then
                    objOC01Fields.Pot5TotalDue = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_4")))
                    Pot5TotalDuetemp = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_4")))
                    objOC01Fields.Pot5PastDue = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_4")))
                    Pot5PastDuetemp = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_4")))
                ElseIf Pot4TitleTemp = "DIRECTORY AD" Then
                    objOC01Fields.Pot4TotalDue = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_4")))
                    Pot4TotalDuetemp = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_4")))
                    objOC01Fields.Pot4PastDue = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_4")))
                    Pot4PastDuetemp = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_4")))

                ElseIf Pot4TitleTemp = "UNREG TOTAL" Or Pot4TitleTemp = "NONBASIC TOT" Then
                    objOC01Fields.Pot2TotalDue = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_4")))
                    Pot2TotalDuetemp = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_4")))
                    objOC01Fields.Pot2PastDue = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_4")))
                    Pot2PastDuetemp = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_4")))

                ElseIf Pot4TitleTemp = "TOLL TOTAL" Or Pot4TitleTemp = "TOLLSVCT" Then
                    objOC01Fields.Pot3TotalDue = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_4")))
                    Pot3TotalDuetemp = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_4")))
                    objOC01Fields.Pot3PastDue = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_4")))
                    Pot3PastDuetemp = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_4")))

                End If


                Pot5TitleTemp = Trim(DB2dr("ACCT_BAL_NM_5"))
                If Pot5TitleTemp = "" Then
                    Pot5TitleTemp = " "
                End If
                If Pot5TitleTemp = "DIRECTORY AD" Then
                    objOC01Fields.Pot4TotalDue = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_5")))
                    Pot4TotalDuetemp = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_5")))
                    objOC01Fields.Pot4PastDue = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_5")))
                    Pot4PastDuetemp = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_5")))

                ElseIf Pot5TitleTemp = "NONTELCM TOT" Then
                    objOC01Fields.Pot5TotalDue = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_5")))
                    Pot5TotalDuetemp = Getnegative(Trim(DB2dr("ACCT_TTL_AMT_5")))
                    objOC01Fields.Pot5PastDue = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_5")))
                    Pot5PastDuetemp = Getnegative(Trim(DB2dr("ACCT_PASTD_AMT_5")))


                End If

                objOC01Fields.TotalTotalDue = Getnegative(Trim(DB2dr("ACCT_TTL_TOT")))
                If objOC01Fields.TotalTotalDue = "0" Then
                    objOC01Fields.TotalTotalDue = "0.00"
                End If
                objOC01Fields.TotalPastDue = Getnegative(Trim(DB2dr("ACCT_PASTD_TOT")))
                If objOC01Fields.TotalPastDue = "0" Then
                    objOC01Fields.TotalPastDue = "0.00"
                End If
                objOC01Fields.TotalMonth1 = Getnegative(Trim(DB2dr("ACCT_MTH1_TOT")))
                If objOC01Fields.TotalMonth1 = "0" Then
                    objOC01Fields.TotalMonth1 = "0.00"
                End If
                objOC01Fields.TOtalMonth2 = Getnegative(Trim(DB2dr("ACCT_MTH2_TOT")))
                If objOC01Fields.TOtalMonth2 = "0" Then
                    objOC01Fields.TOtalMonth2 = "0.00"
                End If
                objOC01Fields.TotalMonth3 = Getnegative(Trim(DB2dr("ACCT_MTH3_TOT")))
                If objOC01Fields.TotalMonth3 = "0" Then
                    objOC01Fields.TotalMonth3 = "0.00"
                End If
                objOC01Fields.TotalMonth4 = Getnegative(Trim(DB2dr("ACCT_MTH4_TOT")))
                If objOC01Fields.TotalMonth4 = "0" Then
                    objOC01Fields.TotalMonth4 = "0.00"
                End If

                objOC01Fields.Medemerg = Trim(DB2dr("BLACT_MED_EMERG_I"))

                objOC01Fields.DPDTE1 = Trim(DB2dr("BILL_RND_DMY_1"))
                If objOC01Fields.DPDTE1 = Nothing Then
                    objOC01Fields.DPDTE1 = getdate1(1011900)
                Else
                    D = (objOC01Fields.DPDTE1.Substring(0, 2))
                    If D.Substring(1, 1) = "/" Then
                        D = (objOC01Fields.DPDTE1.Substring(0, 1))
                        F = (objOC01Fields.DPDTE1.Substring(2, 2))
                        If F.Substring(1, 1) = "/" Then
                            F = (objOC01Fields.DPDTE1.Substring(2, 1))
                            e = (objOC01Fields.DPDTE1.Substring(4, 4))
                        Else
                            F = (objOC01Fields.DPDTE1.Substring(2, 2))
                            e = (objOC01Fields.DPDTE1.Substring(5, 4))
                        End If
                    Else
                        If Not (D.Substring(1, 1) = "/") Then
                            F = (objOC01Fields.DPDTE1.Substring(3, 2))
                            If F.Substring(1, 1) = "/" Then
                                F = (objOC01Fields.DPDTE1.Substring(3, 1))
                                e = (objOC01Fields.DPDTE1.Substring(5, 4))
                            Else
                                F = (objOC01Fields.DPDTE1.Substring(3, 2))
                                e = (objOC01Fields.DPDTE1.Substring(6, 4))
                            End If
                        Else
                            F = (objOC01Fields.DPDTE1.Substring(3, 2))
                            e = (objOC01Fields.DPDTE1.Substring(6, 4))
                        End If
                    End If

                    If D > System.DateTime.Now.ToString("MM") Then
                        objOC01Fields.DPDTE1 = objOC01Fields.DPDTE1 & (System.DateTime.Now.Year - 1)
                    Else
                        objOC01Fields.DPDTE1 = objOC01Fields.DPDTE1 & System.DateTime.Now.ToString("yyyy")
                    End If
                    objOC01Fields.DPDTE1 = e & "-" & D & "-" & F
                End If

                objOC01Fields.DPDTE2 = Trim(DB2dr("BILL_RND_DMY_2"))
                If objOC01Fields.DPDTE2 = Nothing Then
                    objOC01Fields.DPDTE2 = getdate1(1011900)
                Else
                    D = (objOC01Fields.DPDTE2.Substring(0, 2))
                    If D.Substring(1, 1) = "/" Then
                        D = (objOC01Fields.DPDTE2.Substring(0, 1))
                        F = (objOC01Fields.DPDTE2.Substring(2, 2))
                        If F.Substring(1, 1) = "/" Then
                            F = (objOC01Fields.DPDTE2.Substring(2, 1))
                            e = (objOC01Fields.DPDTE2.Substring(4, 4))
                        Else
                            F = (objOC01Fields.DPDTE2.Substring(2, 2))
                            e = (objOC01Fields.DPDTE2.Substring(5, 4))
                        End If
                    Else
                        If Not (D.Substring(1, 1) = "/") Then
                            F = (objOC01Fields.DPDTE2.Substring(3, 2))
                            If F.Substring(1, 1) = "/" Then
                                F = (objOC01Fields.DPDTE2.Substring(3, 1))
                                e = (objOC01Fields.DPDTE2.Substring(5, 4))
                            Else
                                F = (objOC01Fields.DPDTE2.Substring(3, 2))
                                e = (objOC01Fields.DPDTE2.Substring(6, 4))
                            End If
                        Else
                            F = (objOC01Fields.DPDTE2.Substring(3, 2))
                            e = (objOC01Fields.DPDTE2.Substring(6, 4))
                        End If
                    End If

                    If D > System.DateTime.Now.ToString("MM") Then
                        objOC01Fields.DPDTE2 = objOC01Fields.DPDTE2 & (System.DateTime.Now.Year - 1)
                    Else
                        objOC01Fields.DPDTE2 = objOC01Fields.DPDTE2 & System.DateTime.Now.ToString("yyyy")
                    End If
                    objOC01Fields.DPDTE2 = e & "-" & D & "-" & F
                End If


                objOC01Fields.DPDTE3 = Trim(DB2dr("BILL_RND_DMY_3"))
                If objOC01Fields.DPDTE3 = Nothing Then
                    objOC01Fields.DPDTE3 = getdate1(1011900)
                Else
                    D = (objOC01Fields.DPDTE3.Substring(0, 2))
                    If D.Substring(1, 1) = "/" Then
                        D = (objOC01Fields.DPDTE3.Substring(0, 1))
                        F = (objOC01Fields.DPDTE3.Substring(2, 2))
                        If F.Substring(1, 1) = "/" Then
                            F = (objOC01Fields.DPDTE3.Substring(2, 1))
                            e = (objOC01Fields.DPDTE3.Substring(4, 4))
                        Else
                            F = (objOC01Fields.DPDTE3.Substring(2, 2))
                            e = (objOC01Fields.DPDTE3.Substring(5, 4))
                        End If
                    Else
                        If Not (D.Substring(1, 1) = "/") Then
                            F = (objOC01Fields.DPDTE3.Substring(3, 2))
                            If F.Substring(1, 1) = "/" Then
                                F = (objOC01Fields.DPDTE3.Substring(3, 1))
                                e = (objOC01Fields.DPDTE3.Substring(5, 4))
                            Else
                                F = (objOC01Fields.DPDTE3.Substring(3, 2))
                                e = (objOC01Fields.DPDTE3.Substring(6, 4))
                            End If
                        Else
                            F = (objOC01Fields.DPDTE3.Substring(3, 2))
                            e = (objOC01Fields.DPDTE3.Substring(6, 4))
                        End If
                    End If

                    If D > System.DateTime.Now.ToString("MM") Then
                        objOC01Fields.DPDTE3 = objOC01Fields.DPDTE3 & (System.DateTime.Now.Year - 1)
                    Else
                        objOC01Fields.DPDTE3 = objOC01Fields.DPDTE3 & System.DateTime.Now.ToString("yyyy")
                    End If
                    objOC01Fields.DPDTE3 = e & "-" & D & "-" & F
                End If

                objOC01Fields.DPDTE4 = Trim(DB2dr("BILL_RND_DMY_4"))
                If objOC01Fields.DPDTE4 = Nothing Then
                    objOC01Fields.DPDTE4 = getdate1(1011900)
                Else
                    D = (objOC01Fields.DPDTE4.Substring(0, 2))
                    If D.Substring(1, 1) = "/" Then
                        D = (objOC01Fields.DPDTE4.Substring(0, 1))
                        F = (objOC01Fields.DPDTE4.Substring(2, 2))
                        If F.Substring(1, 1) = "/" Then
                            F = (objOC01Fields.DPDTE4.Substring(2, 1))
                            e = (objOC01Fields.DPDTE4.Substring(4, 4))
                        Else
                            F = (objOC01Fields.DPDTE4.Substring(2, 2))
                            e = (objOC01Fields.DPDTE4.Substring(5, 4))
                        End If
                    Else
                        If Not (D.Substring(1, 1) = "/") Then
                            F = (objOC01Fields.DPDTE4.Substring(3, 2))
                            If F.Substring(1, 1) = "/" Then
                                F = (objOC01Fields.DPDTE4.Substring(3, 1))
                                e = (objOC01Fields.DPDTE4.Substring(5, 4))
                            Else
                                F = (objOC01Fields.DPDTE4.Substring(3, 2))
                                e = (objOC01Fields.DPDTE4.Substring(6, 4))
                            End If
                        Else
                            F = (objOC01Fields.DPDTE4.Substring(3, 2))
                            e = (objOC01Fields.DPDTE4.Substring(6, 4))
                        End If
                    End If

                    If D > System.DateTime.Now.ToString("MM") Then
                        objOC01Fields.DPDTE4 = objOC01Fields.DPDTE4 & (System.DateTime.Now.Year - 1)
                    Else
                        objOC01Fields.DPDTE4 = objOC01Fields.DPDTE4 & System.DateTime.Now.ToString("yyyy")
                    End If
                    objOC01Fields.DPDTE4 = e & "-" & D & "-" & F
                End If

                objOC01Fields.RFDTE1 = Trim(DB2dr("PAY_DUE_DT_1"))
                If objOC01Fields.RFDTE1 = Nothing Then
                    objOC01Fields.RFDTE1 = getdate1(1011900)
                Else
                    D = (objOC01Fields.RFDTE1.Substring(0, 2))
                    If D.Substring(1, 1) = "/" Then
                        D = (objOC01Fields.RFDTE1.Substring(0, 1))
                        F = (objOC01Fields.RFDTE1.Substring(2, 2))
                        If F.Substring(1, 1) = "/" Then
                            F = (objOC01Fields.RFDTE1.Substring(2, 1))
                            e = (objOC01Fields.RFDTE1.Substring(4, 4))
                        Else
                            F = (objOC01Fields.RFDTE1.Substring(2, 2))
                            e = (objOC01Fields.RFDTE1.Substring(5, 4))
                        End If
                    Else
                        If Not (D.Substring(1, 1) = "/") Then
                            F = (objOC01Fields.RFDTE1.Substring(3, 2))
                            If F.Substring(1, 1) = "/" Then
                                F = (objOC01Fields.RFDTE1.Substring(3, 1))
                                e = (objOC01Fields.RFDTE1.Substring(5, 4))
                            Else
                                F = (objOC01Fields.RFDTE1.Substring(3, 2))
                                e = (objOC01Fields.RFDTE1.Substring(6, 4))
                            End If
                        Else
                            F = (objOC01Fields.RFDTE1.Substring(3, 2))
                            e = (objOC01Fields.RFDTE1.Substring(6, 4))
                        End If
                    End If

                    If D > System.DateTime.Now.ToString("MM") Then
                        objOC01Fields.RFDTE1 = objOC01Fields.RFDTE1 & (System.DateTime.Now.Year - 1)
                    Else
                        objOC01Fields.RFDTE1 = objOC01Fields.RFDTE1 & System.DateTime.Now.ToString("yyyy")
                    End If

                    objOC01Fields.RFDTE1 = e & "-" & D & "-" & F
                End If

                objOC01Fields.RFDTE2 = Trim(DB2dr("PAY_DUE_DT_2"))
                If objOC01Fields.RFDTE2 = Nothing Then
                    objOC01Fields.RFDTE2 = getdate1(1011900)
                Else
                    D = (objOC01Fields.RFDTE2.Substring(0, 2))
                    If D.Substring(1, 1) = "/" Then
                        D = (objOC01Fields.RFDTE2.Substring(0, 1))
                        F = (objOC01Fields.RFDTE2.Substring(2, 2))
                        If F.Substring(1, 1) = "/" Then
                            F = (objOC01Fields.RFDTE2.Substring(2, 1))
                            e = (objOC01Fields.RFDTE2.Substring(4, 4))
                        Else
                            F = (objOC01Fields.RFDTE2.Substring(2, 2))
                            e = (objOC01Fields.RFDTE2.Substring(5, 4))
                        End If
                    Else
                        If Not (D.Substring(1, 1) = "/") Then
                            F = (objOC01Fields.RFDTE2.Substring(3, 2))
                            If F.Substring(1, 1) = "/" Then
                                F = (objOC01Fields.RFDTE2.Substring(3, 1))
                                e = (objOC01Fields.RFDTE2.Substring(5, 4))
                            Else
                                F = (objOC01Fields.RFDTE2.Substring(3, 2))
                                e = (objOC01Fields.RFDTE2.Substring(6, 4))
                            End If
                        Else
                            F = (objOC01Fields.RFDTE2.Substring(3, 2))
                            e = (objOC01Fields.RFDTE2.Substring(6, 4))
                        End If
                    End If

                    If D > System.DateTime.Now.ToString("MM") Then
                        objOC01Fields.RFDTE2 = objOC01Fields.RFDTE2 & (System.DateTime.Now.Year - 1)
                    Else
                        objOC01Fields.RFDTE2 = objOC01Fields.RFDTE2 & System.DateTime.Now.ToString("yyyy")
                    End If

                    objOC01Fields.RFDTE2 = e & "-" & D & "-" & F
                End If

                objOC01Fields.RFDTE3 = Trim(DB2dr("PAY_DUE_DT_3"))
                If objOC01Fields.RFDTE3 = Nothing Then
                    objOC01Fields.RFDTE3 = getdate1(1011900)
                Else
                    D = (objOC01Fields.RFDTE3.Substring(0, 2))
                    If D.Substring(1, 1) = "/" Then
                        D = (objOC01Fields.RFDTE3.Substring(0, 1))
                        F = (objOC01Fields.RFDTE3.Substring(2, 2))
                        If F.Substring(1, 1) = "/" Then
                            F = (objOC01Fields.RFDTE3.Substring(2, 1))
                            e = (objOC01Fields.RFDTE3.Substring(4, 4))
                        Else
                            F = (objOC01Fields.RFDTE3.Substring(2, 2))
                            e = (objOC01Fields.RFDTE3.Substring(5, 4))
                        End If
                    Else
                        If Not (D.Substring(1, 1) = "/") Then
                            F = (objOC01Fields.RFDTE3.Substring(3, 2))
                            If F.Substring(1, 1) = "/" Then
                                F = (objOC01Fields.RFDTE3.Substring(3, 1))
                                e = (objOC01Fields.RFDTE3.Substring(5, 4))
                            Else
                                F = (objOC01Fields.RFDTE3.Substring(3, 2))
                                e = (objOC01Fields.RFDTE3.Substring(6, 4))
                            End If
                        Else
                            F = (objOC01Fields.RFDTE3.Substring(3, 2))
                            e = (objOC01Fields.RFDTE3.Substring(6, 4))
                        End If
                    End If

                    If D > System.DateTime.Now.ToString("MM") Then
                        objOC01Fields.RFDTE3 = objOC01Fields.RFDTE3 & (System.DateTime.Now.Year - 1)
                    Else
                        objOC01Fields.RFDTE3 = objOC01Fields.RFDTE3 & System.DateTime.Now.ToString("yyyy")
                    End If

                    objOC01Fields.RFDTE3 = e & "-" & D & "-" & F
                End If

                objOC01Fields.RFDTE4 = Trim(DB2dr("PAY_DUE_DT_4"))
                If objOC01Fields.RFDTE4 = Nothing Then
                    objOC01Fields.RFDTE4 = getdate1(1011900)
                Else
                    D = (objOC01Fields.RFDTE4.Substring(0, 2))
                    If D.Substring(1, 1) = "/" Then
                        D = (objOC01Fields.RFDTE4.Substring(0, 1))
                        F = (objOC01Fields.RFDTE4.Substring(2, 2))
                        If F.Substring(1, 1) = "/" Then
                            F = (objOC01Fields.RFDTE4.Substring(2, 1))
                            e = (objOC01Fields.RFDTE4.Substring(4, 4))
                        Else
                            F = (objOC01Fields.RFDTE4.Substring(2, 2))
                            e = (objOC01Fields.RFDTE4.Substring(5, 4))
                        End If
                    Else
                        If Not (D.Substring(1, 1) = "/") Then
                            F = (objOC01Fields.RFDTE4.Substring(3, 2))
                            If F.Substring(1, 1) = "/" Then
                                F = (objOC01Fields.RFDTE4.Substring(3, 1))
                                e = (objOC01Fields.RFDTE4.Substring(5, 4))
                            Else
                                F = (objOC01Fields.RFDTE4.Substring(3, 2))
                                e = (objOC01Fields.RFDTE4.Substring(6, 4))
                            End If
                        Else
                            F = (objOC01Fields.RFDTE4.Substring(3, 2))
                            e = (objOC01Fields.RFDTE4.Substring(6, 4))
                        End If
                    End If

                    If D > System.DateTime.Now.ToString("MM") Then
                        objOC01Fields.RFDTE4 = objOC01Fields.RFDTE4 & (System.DateTime.Now.Year - 1)
                    Else
                        objOC01Fields.RFDTE4 = objOC01Fields.RFDTE4 & System.DateTime.Now.ToString("yyyy")
                    End If

                    objOC01Fields.RFDTE4 = e & "-" & D & "-" & F
                End If

                Return objOC01Fields
            Catch e As Exception
                CommonLibrary.LogErrorFile.WriteLog("RMICW_MDVW_EDI:lfnProcessResult:Error: ", e.Message.ToString)
                CommonLibrary.LogErrorFile.WriteLog("RMICW_MDVW_EDI:lfnProcessResult:Error:Account number: ", strAccountNo)
            End Try
        End Function



        Private Function getAccountDetails(ByVal objOC01Fields As OCABFields) As AccountDetails
            Dim sn, strOC01Paybydate, strOC01Currbilldate As String
            Dim objAccountdtls = New AccountDetails
            Try


                objAccountdtls.strCustName = objOC01Fields.CustomerNAME

                objAccountdtls.strAcctStatus = objOC01Fields.AccountStatus

                objAccountdtls.strAccntInd = objOC01Fields.spheslfileind


                objAccountdtls.strCheckDigit = objOC01Fields.chkdigit


                objAccountdtls.strClassOfService = ""

                objAccountdtls.dtmCurrBilldt = objOC01Fields.CurrBillDate


                objAccountdtls.dtmPayByDt = objOC01Fields.paybydate

                objAccountdtls.strTrtHist = objOC01Fields.Treatmenthist

                objAccountdtls.strBehavScr = objOC01Fields.Behaviorscore
                objAccountdtls.strBasicBundleInd = objOC01Fields.strBasicBundleInd

                Try
                    If (objOC01Fields.DateOfInstall.Length) <= 4 Then
                        objAccountdtls.dtmDOI = "01/01/1900"
                    Else
                        objAccountdtls.dtmDOI = objOC01Fields.DateOfInstall
                    End If
                Catch ex As Exception
                    objAccountdtls.dtmDOI = "01/01/1900"
                End Try
                If (LTrim(RTrim(objAccountdtls.dtmBOSSR1dt)) = "") Or (LTrim(RTrim(objAccountdtls.dtmBOSSR1dt)) = "0000") Then
                    objAccountdtls.dtmBOSSR1dt = "01/01/1900"
                Else

                    objAccountdtls.dtmBOSSR1dt = objOC01Fields.R1Date
                End If

                If objOC01Fields.ClaimInd = "Y" Then
                    objAccountdtls.blnClaimInd = True
                    objAccountdtls.strClaimPot = objOC01Fields.ClaimPOT
                    objAccountdtls.curClaimAmt = CDbl(objOC01Fields.ClaimAMT)
                Else
                    objAccountdtls.blnClaimInd = False
                    objAccountdtls.strClaimPot = objOC01Fields.ClaimPOT
                    objAccountdtls.curClaimAmt = 0.0
                End If

                objAccountdtls.strCurrentClass = objOC01Fields.CurrentClass


                If LTrim(RTrim(objAccountdtls.strCollectorId)) = "" Or LTrim(RTrim(objAccountdtls.strCollectorId)) = Nothing Then
                    objAccountdtls.strCollectorId = ""
                Else
                    objAccountdtls.strCollectorId = objOC01Fields.Collector
                End If

                If LTrim(RTrim(objAccountdtls.strCollectorId)) = "" Then
                    objAccountdtls.blnPermCollFlag = False
                Else
                    objAccountdtls.blnPermCollFlag = True
                End If

                objAccountdtls.blnTicklerInd = False
                objAccountdtls.strCBR = objOC01Fields.CbrNumber
                objAccountdtls.strPayAdjPtpInd = objOC01Fields.payind
                objAccountdtls.blnPTPInd = False  '"N"
                objAccountdtls.strCIinfo = objOC01Fields.CreditInfo1 & " CI2" & Trim(objOC01Fields.CreditInfo2)
                sn = Regex.Replace(objAccountdtls.strCIinfo, "[^\w$.* ]", "")
                objAccountdtls.strCIinfo = sn

                objAccountdtls.dtmLNPdt = "01/01/1900"
                objAccountdtls.strCollectionRsnCd = " "
                objAccountdtls.strCreditClass = objOC01Fields.accountgroup
                objAccountdtls.strPrty = " "
                If LTrim(RTrim(objOC01Fields.TotalDue)) = "" Or LTrim(RTrim(objOC01Fields.TotalDue)) = ".00" Or LTrim(RTrim(objOC01Fields.TotalDue)) = "0" Then
                    objAccountdtls.curTotalDue = 0.0
                    objAccountdtls.curRMITotalAmtDue = 0.0
                Else
                    objAccountdtls.curTotalDue = CDbl(objOC01Fields.TotalDue)
                    objAccountdtls.curRMITotalAmtDue = CDbl(objOC01Fields.TotalDue)
                End If
                If LTrim(RTrim(objOC01Fields.PastDueAmt)) = "" Or LTrim(RTrim(objOC01Fields.PastDueAmt)) = ".00" Or LTrim(RTrim(objOC01Fields.PastDueAmt)) = "0" Then
                    objAccountdtls.curPastDue = 0.0
                Else
                    objAccountdtls.curPastDue = CDbl(objOC01Fields.PastDueAmt)
                End If
                If LTrim(RTrim(objOC01Fields.CYCLE0)) = "" Or LTrim(RTrim(objOC01Fields.CYCLE0)) = ".00" Or LTrim(RTrim(objOC01Fields.CYCLE0)) = "0" Then
                    objAccountdtls.curCycle0Amt = 0.0
                Else
                    objAccountdtls.curCycle0Amt = CDbl(objOC01Fields.CYCLE0)
                End If
                If LTrim(RTrim(objOC01Fields.CYCLE1)) = "" Or LTrim(RTrim(objOC01Fields.CYCLE1)) = ".00" Or LTrim(RTrim(objOC01Fields.CYCLE1)) = "0" Then
                    objAccountdtls.curCycle1Amt = 0.0
                Else
                    objAccountdtls.curCycle1Amt = CDbl(objOC01Fields.CYCLE1)
                End If
                If LTrim(RTrim(objOC01Fields.CYCLE2)) = "" Or LTrim(RTrim(objOC01Fields.CYCLE2)) = ".00" Or LTrim(RTrim(objOC01Fields.CYCLE2)) = "0" Then
                    objAccountdtls.curCycle2Amt = 0.0
                Else
                    objAccountdtls.curCycle2Amt = CDbl(objOC01Fields.CYCLE2)
                End If
                If LTrim(RTrim(objOC01Fields.CYCLE3)) = "" Or LTrim(RTrim(objOC01Fields.CYCLE3)) = ".00" Or LTrim(RTrim(objOC01Fields.CYCLE3)) = "0" Then
                    objAccountdtls.curCycle3Amt = 0.0
                Else
                    objAccountdtls.curCycle3Amt = CDbl(objOC01Fields.CYCLE3)
                End If
                If LTrim(RTrim(objOC01Fields.CLAIMBA)) = "" Or LTrim(RTrim(objOC01Fields.CLAIMBA)) = ".00" Or LTrim(RTrim(objOC01Fields.CLAIMBA)) = "0" Then
                    objAccountdtls.curClaimBasicAmt = 0.0
                Else
                    objAccountdtls.curClaimBasicAmt = CDbl(objOC01Fields.CLAIMBA)
                End If
                'objAccountDtls.curClaimBasicAmt = objOC01Fields.ClaimAmtBasic
                If LTrim(RTrim(objOC01Fields.CLAIMNB)) = "" Or LTrim(RTrim(objOC01Fields.CLAIMNB)) = ".00" Or LTrim(RTrim(objOC01Fields.CLAIMNB)) = "0" Then
                    objAccountdtls.curClaimNonBasicAmt = 0.0
                Else
                    objAccountdtls.curClaimNonBasicAmt = CDbl(objOC01Fields.CLAIMNB)
                End If
                If LTrim(RTrim(objOC01Fields.CLAIMTL)) = "" Or LTrim(RTrim(objOC01Fields.CLAIMTL)) = ".00" Or LTrim(RTrim(objOC01Fields.CLAIMTL)) = "0" Then
                    objAccountdtls.curClaimTollAmt = 0.0
                Else
                    objAccountdtls.curClaimTollAmt = CDbl(objOC01Fields.CLAIMTL)
                End If
                If LTrim(RTrim(objOC01Fields.CLAIMDA)) = "" Or LTrim(RTrim(objOC01Fields.CLAIMDA)) = ".00" Or LTrim(RTrim(objOC01Fields.CLAIMDA)) = "0" Then
                    objAccountdtls.curClaimDAAmt = 0.0
                Else
                    objAccountdtls.curClaimDAAmt = CDbl(objOC01Fields.CLAIMDA)
                End If

                'Adding the new Fields for the EDI Interface for the NY Infrastructure

                objAccountdtls.strPermNoteInd = " "

                If (objOC01Fields.CurrBillDate.Length) <= 4 Then
                    objAccountdtls.dtmOCM1CurBillDate = "01/01/1900"
                Else
                    objAccountdtls.dtmOCM1CurBillDate = objOC01Fields.CurrBillDate
                End If



                'New code to check the Pay By date comparing with Bill date
                If (objAccountdtls.dtmOCM1CurBillDate <> "01/01/1900") And ((objOC01Fields.paybydate.Length) <= 4) And (objOC01Fields.paybydate <> "") And (objOC01Fields.paybydate <> "0") Then
                    strOC01Currbilldate = CType(objAccountdtls.dtmOCM1CurBillDate, String)
                    strOC01Paybydate = objOC01Fields.paybydate + strOC01Currbilldate.Substring((strOC01Currbilldate.Length - 4), 4)
                    objOC01Fields.paybydate = strOC01Paybydate
                    Dim strdtmpaybydate As String = objOC01Fields.paybydate.Substring(0, 2) + "/" + objOC01Fields.paybydate.Substring(2, 2) + "/" + objOC01Fields.paybydate.Substring(4, 4)
                    objOC01Fields.paybydate = strdtmpaybydate
                End If

                'end
                Try
                    If ((objOC01Fields.paybydate.Length) <= 4) Then
                        If (objOC01Fields.paybydate = "") Or (objOC01Fields.paybydate = "0") Then
                            objOC01Fields.paybydate = "01/01/1900"
                        End If
                        If (CType(objOC01Fields.paybydate, Date)) < (objAccountdtls.dtmOCM1CurBillDate) Then
                            objAccountdtls.dtmOCM1PayByDate = "01/01/1900"
                        End If

                    Else
                        objAccountdtls.dtmOCM1PayByDate = objOC01Fields.paybydate
                    End If
                Catch ex As Exception
                    objOC01Fields.paybydate = "01/01/1900"
                End Try
                Try
                    If (objOC01Fields.PrefpaymentDate.Length) <= 4 Then
                        objAccountdtls.strPrferredPymntDay = "01/01/1900"
                    Else
                        objAccountdtls.strPrferredPymntDay = objOC01Fields.PrefpaymentDate
                    End If
                Catch ex As Exception
                    objAccountdtls.strPrferredPymntDay = "01/01/1900"
                End Try

                ''mm-need attention objAccountDtls.strPriorAcctHist = objOC01Fields.PriorAcctHist
                objAccountdtls.strPriorAcctHist = " "

                objAccountdtls.strSSN = objOC01Fields.SSN

                objAccountdtls.curDepositHeld = 0.0

                Try
                    If (objOC01Fields.CreditVerifDate.Length) <= 4 Then
                        objAccountdtls.dtmCreditVerificationDate = "01/01/1900"
                    Else
                        objAccountdtls.dtmCreditVerificationDate = objOC01Fields.CreditVerifDate
                    End If
                Catch ex As Exception
                    objAccountdtls.dtmCreditVerificationDate = "01/01/1900"
                End Try

                objAccountdtls.strCheckAcceptInd = objOC01Fields.CheckAcceptInd

                objAccountdtls.strPmtSchedule = " "

                objAccountdtls.dtmNextReviewDate = "01/01/1900"
                objAccountdtls.strSupInfoFlag = " "
                objAccountdtls.intTimeRemainingInClass = 0 'per siva

                objAccountdtls.strTimeRemainingIdentifier = " "
                objAccountdtls.strNextScheduledLtr = " "

                If LTrim(RTrim(objOC01Fields.Brokenptp)) = "" Or LTrim(RTrim(objOC01Fields.Brokenptp)) = ".00" Or LTrim(RTrim(objOC01Fields.Brokenptp)) = "0" Then
                    objAccountdtls.intNumBrokenPTP = 0.0
                Else
                    objAccountdtls.intNumBrokenPTP = CType(objOC01Fields.Brokenptp, Integer)
                End If

                If LTrim(RTrim(objOC01Fields.BrokenEPAR)) = "" Or LTrim(RTrim(objOC01Fields.BrokenEPAR)) = ".00" Or LTrim(RTrim(objOC01Fields.BrokenEPAR)) = "0" Then
                    objAccountdtls.intNumBrokenEpar = 0.0
                Else
                    objAccountdtls.intNumBrokenEpar = CType(objOC01Fields.BrokenEPAR, Integer)
                End If

                objAccountdtls.intNumBrokenBpar = 0.0

                If LTrim(RTrim(objOC01Fields.memopay)) = "" Or LTrim(RTrim(objOC01Fields.memopay)) = ".00" Or LTrim(RTrim(objOC01Fields.memopay)) = "0" Then
                    objAccountdtls.curMemoPayments = 0.0
                Else
                    objAccountdtls.curMemoPayments = CDbl(objOC01Fields.memopay)
                End If
                objAccountdtls.curRiskBalance = 0.0


                If LTrim(RTrim(objOC01Fields.Pot1TotalDue)) = "" Or LTrim(RTrim(objOC01Fields.Pot1TotalDue)) = ".00" Or LTrim(RTrim(objOC01Fields.Pot1TotalDue)) = "0" Then
                    objAccountdtls.curOCM1BscTotalDue = 0.0
                    objAccountdtls.curRMIBasicTotalDue = 0.0
                Else
                    objAccountdtls.curOCM1BscTotalDue = CDbl(objOC01Fields.Pot1TotalDue)
                    objAccountdtls.curRMIBasicTotalDue = CDbl(objOC01Fields.Pot1TotalDue)
                End If

                If LTrim(RTrim(objOC01Fields.Pot3TotalDue)) = "" Or LTrim(RTrim(objOC01Fields.Pot3TotalDue)) = ".00" Or LTrim(RTrim(objOC01Fields.Pot3TotalDue)) = "0" Then
                    objAccountdtls.curOCM1TollTotalDue = 0.0
                    objAccountdtls.curRMITollTotalDue = 0.0
                Else
                    objAccountdtls.curOCM1TollTotalDue = CDbl(objOC01Fields.Pot3TotalDue)
                    objAccountdtls.curRMITollTotalDue = CDbl(objOC01Fields.Pot3TotalDue)
                End If

                If LTrim(RTrim(objOC01Fields.Pot2TotalDue)) = "" Or LTrim(RTrim(objOC01Fields.Pot2TotalDue)) = ".00" Or LTrim(RTrim(objOC01Fields.Pot2TotalDue)) = "0" Then
                    objAccountdtls.curOCM1NBscTotalDue = 0.0
                    objAccountdtls.curRMINonBasicTotalDue = 0.0
                Else
                    objAccountdtls.curOCM1NBscTotalDue = CDbl(objOC01Fields.Pot2TotalDue)
                    objAccountdtls.curRMINonBasicTotalDue = CDbl(objOC01Fields.Pot2TotalDue)
                End If

                If LTrim(RTrim(objOC01Fields.Pot5TotalDue)) = "" Or LTrim(RTrim(objOC01Fields.Pot5TotalDue)) = ".00" Or LTrim(RTrim(objOC01Fields.Pot5TotalDue)) = "0" Then
                    objAccountdtls.curOCM1OcarTotalDue = 0.0
                    objAccountdtls.curRMIOcarTotalDue = 0.0
                Else
                    objAccountdtls.curOCM1OcarTotalDue = CDbl(objOC01Fields.Pot5TotalDue)
                    objAccountdtls.curRMIOcarTotalDue = CDbl(objOC01Fields.Pot5TotalDue)
                End If

                If LTrim(RTrim(objOC01Fields.Pot4TotalDue)) = "" Or LTrim(RTrim(objOC01Fields.Pot4TotalDue)) = ".00" Or LTrim(RTrim(objOC01Fields.Pot4TotalDue)) = "0" Then
                    objAccountdtls.curOCM1DATotalDue = 0.0
                    objAccountdtls.curRMIDATotalDue = 0.0
                Else
                    objAccountdtls.curOCM1DATotalDue = CDbl(objOC01Fields.Pot4TotalDue)
                    objAccountdtls.curRMIDATotalDue = CDbl(objOC01Fields.Pot4TotalDue)
                End If

                If LTrim(RTrim(objOC01Fields.Pot5TotalDue)) = "" Or LTrim(RTrim(objOC01Fields.Pot5TotalDue)) = ".00" Or LTrim(RTrim(objOC01Fields.Pot5TotalDue)) = "0" Then
                    objAccountdtls.curOCM1IPTotalDue = 0.0
                    objAccountdtls.curRMIIPTotalDue = 0.0
                Else
                    objAccountdtls.curOCM1IPTotalDue = CDbl(objOC01Fields.Pot5TotalDue)
                    objAccountdtls.curRMIIPTotalDue = CDbl(objOC01Fields.Pot5TotalDue)
                End If
                objAccountdtls.curOCM1CPETotalDue = 0.0

                objAccountdtls.curOCM1WrlsTotalDue = 0.0

                objAccountdtls.strAdditionalInfo = ""

                If objOC01Fields.dnrind = "1" Then
                    objAccountdtls.strAdditionalInfo = objAccountdtls.strAdditionalInfo & "#DNR#"
                Else
                    objAccountdtls.strAdditionalInfo = ""
                End If

                If objOC01Fields.Medemerg = "1" Then
                    objAccountdtls.strAdditionalInfo = objAccountdtls.strAdditionalInfo & "#ME#"
                End If

                'MSGBIND field is used for Gift Billing Indicator to pass thru EDI
                If objOC01Fields.MSGBIND = "GB-B" Then
                    objAccountdtls.strAdditionalInfo = objAccountdtls.strAdditionalInfo & "#GB-B#"
                Else
                    If objOC01Fields.MSGBIND = "GB-R" Then
                        objAccountdtls.strAdditionalInfo = objAccountdtls.strAdditionalInfo & "#GB-R#"
                    End If
                End If



                Return objAccountdtls
            Catch ex As Exception
                ' If ex.Message = "Error: Account Not found in OC01" Then
                'CommonLibrary.LogErrorFile.WriteLog("RMICW_OC01_Data", ex.Message)
                CommonLibrary.LogErrorFile.WriteLog("RMICW_EDI_MDVW", ex.Message, 1, 999, "Error")
                Throw ex
                ' CommonLibrary.LogErrorFile.WriteIntoEventLog(300, errnumber, className1, Msg)
                'dtOC01 = dttable
                'Return objAccountDtls
                ' End If
            End Try

        End Function

        Public Function getParmValue(ByVal strRegionId As String, ByVal strParmName As String)
            Dim dsgetparmval As DataSet

            Try
                dsgetparmval = usp_GetControlParm(strRegionId, strParmName)

                Dim strParmValue As String = dsgetparmval.Tables(0).Rows(0).Item("strParmValue").ToString()
                Return strParmValue

            Catch ex As Exception
                LogErrorFile.WriteLog("Error in getting parmvalues from tControlParm table for MDVW ", ex.ToString())
            End Try

        End Function

        Public Function usp_GetControlParm(ByVal strRegionId As String, ByVal strParmName As String)
            Dim dataAccessObj As DataAccessComponent
            Dim ds As DataSet
            Try
                dataAccessObj = New DataAccessComponent(dbType.SQLServer, "prodmdvw")  'AG
                'dataAccessObj = New DataAccessComponent(Verizon.RMICW.DataAccess.dbType.SQLServer, "prodny") 'AG
            Catch ex As Exception
                Throw ex
            End Try
            Try

                ds = dataAccessObj.execStoreProcedure(strRegionId, strParmName)

            Catch ex As Exception
                'handle exception
                Throw ex
            Finally
                dataAccessObj.Dispose()
            End Try

            Return ds

        End Function

        Private Function toPTPBoolean(ByVal dbvalue As Double) As Boolean

            If dbvalue > 0 Then
                Return True
            Else
                Return False
            End If

        End Function

        Public Function Getnegative(ByVal val As String)
            If val.Length > 0 Then
                If val.Substring(val.Length - 1) = "-" Then
                    val = val.Replace("-", "")
                    val = val.Insert(0, "-")
                End If
            End If
            Return val
        End Function

        Private Function getdate1(ByVal instr As String)
            Dim strdtout As String
            Dim restr As Date
            Try
                If IsDate(instr) Then
                    '"s" - Date format  Specifier
                    restr = CDate(instr)
                    strdtout = restr.ToString("s")
                    'getdate = strdtout
                Else
                    Dim y, m, d, dt
                    Dim strDate = CStr(instr & "")
                    If Len(strDate) = 6 Then
                        y = Right(instr, 2)
                        d = Mid(instr, 3, 2)
                        m = Left(instr, 2)
                        If Len(m) = 1 Then
                            m = "0" & m
                        End If

                        If Len(d) = 1 Then
                            d = "0" & d
                        End If
                        dt = (m & "-" & d & "-" & y)
                        If IsDate(dt) Then
                            restr = CDate(dt)
                            '"s" - Date format  Specifier
                            strdtout = restr.ToString("s")
                        Else
                            strdtout = "1900-01-02"
                            'getdate = strdtout
                        End If
                    Else
                        strdtout = "1900-01-02"
                        'getdate = "1900-01-02"
                    End If
                End If


            Catch ex As Exception
                strdtout = "1900-01-02"
                Dim errnumber As String
                Dim err As String
                err = ex.ToString
                errnumber = 9999
                Dim Msg As String
                Dim className As String
                className = " OC01FinalOutPutFormatter "
                'Msg = "OC01 EXCEPTION:" & acctNum & " : " & className & "; Exception Details: " & ex.ToString()
                ' 7 July 2003 - J. Ambrose Little
                ' Changed logging to use the logging functionality in the Logging class.
                'EchosUtilities.Logging.LogData(Msg, True, 2701)
            End Try
            Return strdtout
        End Function

        Private Function getamnt(ByVal inamnt As String) As Single
            Try
                inamnt = inamnt.Replace(" ", "")
                'inamnt = inamnt.Replace(".", "")
                If inamnt = "" Or inamnt = "0" Or inamnt = ".00" Or inamnt = "0.00" Then
                    inamnt = "00.00"
                Else
                    If inamnt.Length > 1 Then
                        inamnt = inamnt.Insert(inamnt.Length - 2, ".")
                    Else
                        inamnt = inamnt.Insert(0, "0")
                        inamnt = inamnt.Insert(inamnt.Length - 2, ".")
                    End If
                End If
                Return Convert.ToSingle(inamnt)
            Catch ex As Exception
                CommonLibrary.LogErrorFile.WriteLog("RMICW_EDI_MDVW", ex.Message, 1, 999, "Error")
            End Try
        End Function

    End Class



    <System.Xml.Serialization.XmlRootAttribute("RMICWDataInterfaceLayout", [Namespace]:="http://www.verizon.com/RMICWDataInterfaceLayout", IsNullable:=False)> _
Public Class RMICWDataInterfaceLayout
        <System.Xml.Serialization.XmlElementAttribute("RMICWDataInterfaceDetails")> _
       Public Items() As RMICWDataInterfaceDetails
    End Class






    '<remarks/>
    '<System.Xml.Serialization.XmlRootAttribute([Namespace]:="", IsNullable:=False)> _
    Public Class AccountDetails


        Public strCustName As String
        Public strAcctStatus As String
        Public strAccntInd As String
        Public strCheckDigit As String
        Public strClassOfService As String
        Public strCSG As String
        Public dtmCurrBilldt As Date
        Public dtmPayByDt As Date
        Public strTrtHist As String
        Public strNoGoodChkHist As String
        Public strBehavScr As String
        Public dtmDOI As Date
        Public dtmBOSSR1dt As Date
        Public dtmBOSSR2dt As Date
        Public dtmBOSSR3dt As Date
        Public strTreatmentInd As String
        Public blnClaimInd As Boolean
        Public strClaimPot As String
        Public curClaimAmt As Single
        Public strCurrentClass As String
        Public blnPermCollFlag As Boolean
        Public strCollectorId As String
        Public blnTicklerInd As Boolean
        Public strCBR As String
        Public strPayAdjPtpInd As String
        Public dtmPTPDt As Date
        Public blnPTPInd As Boolean
        Public blnNTNInd As Boolean
        Public blnOTNInd As Boolean
        Public blnResellerInd As Boolean
        Public blnSRPPInd As Boolean
        Public blnLifeLineInd As Boolean
        Public strCIinfo As String
        Public dtmLastSNPdt As Date
        Public dtmLastRSTdt As Date
        Public dtmLNPdt As Date
        Public strCollectionRsnCd As String
        Public strCreditClass As String
        Public strPrty As String
        Public curTotalDue As Double
        Public curPastDue As Double
        Public curCycle0Amt As Double
        Public curCycle1Amt As Double
        Public curCycle2Amt As Double
        Public curCycle3Amt As Double
        Public curClaimBasicAmt As Double
        Public curClaimNonBasicAmt As Double
        Public curClaimTollAmt As Double
        Public curClaimDAAmt As Double
        Public curRMITotalAmtDue As Double
        Public curRMIBasicTotalDue As Double
        Public curRMINonBasicTotalDue As Double
        Public curRMITollTotalDue As Double
        Public curRMIOcarTotalDue As Double
        Public curRMIWrlsTotalDue As Double
        Public curRMIDATotalDue As Double
        Public curRMIIPTotalDue As Double
        Public curRMICPETotalDue As Double
        Public dtmRMIDirAdvDt As Date
        Public curRMIDirAdvAmt As Double
        Public curRMIDirAdvAmt30 As Double
        Public curRMIDirAdvAmt60 As Double
        Public curRMIDirAdvAmt90 As Double
        Public curRMIDirAdvAmt120 As Double
        Public strPermNoteInd As String
        Public dtmOCM1CurBillDate As DateTime
        Public dtmOCM1PayByDate As DateTime
        Public strPrferredPymntDay As String
        Public strPriorAcctHist As String
        Public strSSN As String
        Public curDepositHeld As Double
        Public dtmCreditVerificationDate As DateTime
        Public strCheckAcceptInd As String
        Public strPmtSchedule As String
        Public dtmNextReviewDate As DateTime
        Public strSupInfoFlag As String
        Public intTimeRemainingInClass As Int16
        Public strTimeRemainingIdentifier As String
        Public strNextScheduledLtr As String
        Public dtmNextScheduledLtrDate As DateTime
        Public intNumBrokenPTP As Int16
        Public intNumBrokenEpar As Int16
        Public intNumBrokenBpar As Int16
        Public curMemoPayments As Double
        Public curRiskBalance As Double
        Public strRefWOInd As String
        Public curOCM1BscTotalDue As Double
        Public curOCM1NBscTotalDue As Double
        Public curOCM1TollTotalDue As Double
        Public curOCM1DATotalDue As Double
        Public curOCM1WrlsTotalDue As Double
        Public curOCM1OcarTotalDue As Double
        Public curOCM1IPTotalDue As Double
        Public curOCM1CPETotalDue As Double
        Public curCreditLimitAmt As Double
        Public curUsageAmt As Double
        Public strCompanyCd As String
        Public strLocationCd As String
        Public strTEIInd As String
        Public intTotalNumLines As Integer
        Public intNumLinesPortedOut As Integer
        Public strLanguageCd As String
        Public strPaymentOptionCd As String
        Public strSBMId As String
        Public strRecourseInd As String
        Public strAdditionalInfo As String
        Public strPositionNbr As String
        Public strCLECId As String
        Public strInCollectionsInd As String
        Public strBasicBundleInd As String



        Public Sub New()


            strCustName = " "
            strAcctStatus = " "
            strAccntInd = " "
            strCheckDigit = " "
            strClassOfService = " "
            strCSG = " "
            dtmCurrBilldt = "1900/01/01"
            dtmPayByDt = "1900/01/01"
            strTrtHist = " "
            strNoGoodChkHist = " "
            strBehavScr = " "
            dtmDOI = "1900/01/01"
            dtmBOSSR1dt = "1900/01/01"
            dtmBOSSR2dt = "1900/01/01"
            dtmBOSSR3dt = "1900/01/01"
            strTreatmentInd = " "
            blnClaimInd = False
            strClaimPot = " "
            curClaimAmt = 0.0
            strCurrentClass = " "
            blnPermCollFlag = False
            strCollectorId = " "
            blnTicklerInd = False
            strCBR = " "
            strPayAdjPtpInd = " "
            dtmPTPDt = "1900/01/01"
            blnPTPInd = False
            blnNTNInd = False
            blnOTNInd = False
            blnResellerInd = False
            blnSRPPInd = False
            blnLifeLineInd = False
            strCIinfo = ""
            dtmLastSNPdt = "1900/01/01"
            dtmLastRSTdt = "1900/01/01"
            dtmLNPdt = "1900/01/01"
            strCollectionRsnCd = " "
            strCreditClass = " "
            strPrty = " "
            curTotalDue = 0.0
            curPastDue = 0.0
            curCycle0Amt = 0.0
            curCycle1Amt = 0.0
            curCycle2Amt = 0.0
            curCycle3Amt = 0.0
            curClaimBasicAmt = 0.0
            curClaimNonBasicAmt = 0.0
            curClaimTollAmt = 0.0
            curClaimDAAmt = 0.0
            curRMITotalAmtDue = 0.0
            curRMIBasicTotalDue = 0.0
            curRMINonBasicTotalDue = 0.0
            curRMITollTotalDue = 0.0
            curRMIOcarTotalDue = 0.0
            curRMIWrlsTotalDue = 0.0
            curRMIIPTotalDue = 0.0
            curRMICPETotalDue = 0.0
            curRMIDATotalDue = 0.0
            dtmRMIDirAdvDt = "1900/01/01"
            curRMIDirAdvAmt = 0.0
            curRMIDirAdvAmt30 = 0.0
            curRMIDirAdvAmt60 = 0.0
            curRMIDirAdvAmt90 = 0.0
            curRMIDirAdvAmt120 = 0.0

            strPermNoteInd = " "
            dtmOCM1CurBillDate = "1900/01/01"
            dtmOCM1PayByDate = "1900/01/01"
            strPrferredPymntDay = " "
            strPriorAcctHist = " "
            strSSN = " "
            curDepositHeld = 0.0
            dtmCreditVerificationDate = "1900/01/01"
            strCheckAcceptInd = " "
            strPmtSchedule = " "
            dtmNextReviewDate = "1900/01/01"
            strSupInfoFlag = " "
            intTimeRemainingInClass = 0
            strTimeRemainingIdentifier = " "
            strNextScheduledLtr = " "
            dtmNextScheduledLtrDate = "1900/01/01"
            intNumBrokenEpar = 0
            intNumBrokenBpar = 0
            curRiskBalance = 0.0
            strRefWOInd = " "

            curOCM1BscTotalDue = 0.0
            curOCM1NBscTotalDue = 0.0
            curOCM1TollTotalDue = 0.0
            curOCM1DATotalDue = 0.0
            curOCM1WrlsTotalDue = 0.0
            curOCM1OcarTotalDue = 0.0
            curOCM1IPTotalDue = 0.0
            curOCM1CPETotalDue = 0.0

            curCreditLimitAmt = 0.0
            curUsageAmt = 0.0
            strCompanyCd = " "
            strLocationCd = " "
            strTEIInd = " "
            intTotalNumLines = 0
            intNumLinesPortedOut = 0
            strLanguageCd = " "
            strPaymentOptionCd = " "
            strSBMId = " "
            strRecourseInd = " "
            strAdditionalInfo = " "
            strPositionNbr = " "
            strInCollectionsInd = " "
            strCLECId = " "
            strBasicBundleInd = ""

        End Sub



    End Class


    Public Structure OCABFields

        Public AccountNumber As String
        Public CustomerNAME As String
        Public BillingAddress1 As String
        Public BillingAddress2 As String
        Public BillingAddress3 As String
        Public BillingZip As String
        Public accountgroup As String
        Public Name As String
        Public TelephoneNumber As String
        Public DateOfInstall As String
        Public CbrNumber As String
        Public CredEstabDate As String
        Public CreditVerifDate As String
        Public SSN As String
        Public AccountStatus As String
        Public SVORDERSTATUS As String
        Public spheslfileind As String
        Public CurrBillDate As String
        Public PastDueAmt As String
        Public CURRENTCHRGS As String
        Public TotalDue As String
        Public paybydate As String
        Public PTPAmount As String
        Public LastPmtDate As String
        Public LastPmtAmt As String
        Public CYCLE0 As String
        Public CYCLE1 As String
        Public CYCLE2 As String
        Public CYCLE3 As String
        Public CYCLE4 As String
        Public Behaviorscore As String
        Public NoGoodCheckHist As String
        Public chkdigit As String
        Public ACCounttype As String
        Public MSGBIND As String
        Public noticeexpdate As String
        Public PTPDate As String
        Public CheckAcceptInd As String
        Public Treatmenthist As String
        Public treatmentstatus As String
        Public TreatmentInd As String
        Public PrefpaymentDate As String
        Public Medemerg As String
        Public MSGNOTE As String
        Public Brokenptp As String
        Public BrokenEPAR As String

        Public TOLLCREDLMT As String
        Public memopay As String
        Public CLAIMBA As String
        Public CLAIMTL As String
        Public CLAIMNB As String
        Public CLAIMDA As String
        Public CLAIMNT As String
        Public CurrentClass As String
        Public CLASSDATE As String
        Public Collector As String
        Public R1Date As String
        Public RDate As String
        Public reasoncd As String
        Public AUTHPERSON As String
        Public CreditInfo1 As String
        Public CreditInfo2 As String
        Public COMPLAINTS As String
        Public ClaimInd As String
        Public ClaimPOT As String
        Public ClaimAMT As String
        Public DTE1 As String
        Public DTE2 As String
        Public DTE3 As String
        Public DTE4 As String
        Public DTE5 As String
        Public DTE6 As String
        Public TYP1 As String
        Public TYP2 As String
        Public TYP3 As String
        Public TYP4 As String
        Public TYP5 As String
        Public TYP6 As String
        Public AMT1 As String
        Public AMT2 As String
        Public AMT3 As String
        Public AMT4 As String
        Public AMT5 As String
        Public AMT6 As String
        Public DPDTE1 As String
        Public DPDTE2 As String
        Public DPDTE3 As String
        Public DPDTE4 As String
        Public DPAMT1 As String
        Public DPAMT2 As String
        Public DPAMT3 As String
        Public DPAMT4 As String
        Public RFDTE1 As String
        Public RFDTE2 As String
        Public RFDTE3 As String
        Public RFDTE4 As String
        Public RFAMT1 As String
        Public RFAMT2 As String
        Public RFAMT3 As String
        Public RFAMT4 As String
        Public MTH1 As String
        Public MTH2 As String
        Public MTH3 As String
        Public MTH4 As String
        Public PerMnotes1 As String
        Public PerMnotes2 As String
        Public PerMnotes3 As String
        Public PerMnotes4 As String
        Public PerMnotes5 As String
        Public PerMnotes6 As String
        Public Pendingpayamt1 As String
        Public Pendingpayamt2 As String
        Public Pendingpayamt3 As String
        Public Pendingpayamt4 As String
        Public Pendingpaydte1 As String
        Public Pendingpaydte2 As String
        Public Pendingpaydte3 As String
        Public Pendingpaydte4 As String
        Public pvtind As String
        Public payind As String
        Public Pot1Title As String
        Public Pot1TotalDue As String
        Public Pot1PastDue As String
        Public Pot1Month1Due As String
        Public Pot1Month2Due As String
        Public Pot1Month3Due As String
        Public Pot1Month4Due As String
        Public Pot2Title As String
        Public Pot2TotalDue As String
        Public Pot2PastDue As String
        Public Pot2Month1Due As String
        Public Pot2Month2Due As String
        Public Pot2Month3Due As String
        Public Pot2Month4Due As String
        Public Pot3Title As String
        Public Pot3TotalDue As String
        Public Pot3PastDue As String
        Public Pot3Month1Due As String
        Public Pot3Month2Due As String
        Public Pot3Month3Due As String
        Public Pot3Month4Due As String
        Public Pot4Title As String
        Public Pot4TotalDue As String
        Public Pot4PastDue As String
        Public Pot4Month1Due As String
        Public Pot4Month2Due As String
        Public Pot4Month3Due As String
        Public Pot4Month4Due As String
        Public Pot5Title As String
        Public Pot5Month1Due As String
        Public Pot5TotalDue As String
        Public Pot5PastDue As String
        Public Pot5Month2Due As String
        Public Pot5Month3Due As String
        Public Pot5Month4Due As String
        Public TotalTotalDue As String
        Public TotalPastDue As String
        Public TotalMonth1 As String
        Public TOtalMonth2 As String
        Public TotalMonth3 As String
        Public TotalMonth4 As String
        Public multballine1 As String
        Public mballin1 As String
        Public mballin2 As String
        Public mballin3 As String
        Public mballin4 As String
        Public mballin5 As String
        Public mballin6 As String
        Public mballin7 As String
        Public mballin8 As String
        Public mballin9 As String
        Public mballin10 As String
        Public mballin11 As String
        Public mballin12 As String
        Public mballin13 As String
        Public mballin14 As String
        Public mballin15 As String
        Public mballin16 As String
        Public mballin17 As String
        Public mballin18 As String
        Public multbalPANEL5 As String
        Public multbalPANEL6 As String
        Public dnrind As String
        Public strBasicBundleInd As String ' Changes done for DC bucketing
    End Structure


End Namespace





