Imports CommonLibrary
Imports System.Text.RegularExpressions
Imports System.Web
Imports System.Net
Imports InternalWS
Imports System.Threading


Namespace Verizon.RMICW.WebServices
    Public Enum EnPrcsFlag
        enPrcsFlagNormal
        enPrcsFlagSkip
        enPrcsFlagError
    End Enum



    Public Class RMICWRequestIssue
        Inherits RMICWWSBase
        Dim enPrcsStatusFlag As EnPrcsFlag

        Public Sub New(ByVal strRegionId As String)
            MyBase.New(strRegionId)
        End Sub



        Public Function RMICWRequestIssueTest(ByVal strVisionCustomerId As String, ByVal strVisionAccountId As String,ByVal strAcctNum As String, _
        ByVal strAppId As String, ByVal strBTN As String, ByVal strClass As String, _
        ByVal strConditionCd As String, ByVal strLogonId As String, _
        ByVal strNotationCd As String, ByVal strOrg As String, _
        ByVal strOriginationId As String, ByVal strRegionId As String, _
        ByVal strActn As String, ByVal strRequestType As String, ByVal strSBM As String, _
        ByVal strEnvironment As String, ByVal strremarks As String, ByVal strReturnCD As String) As RMICWRequestWS_Output

            Dim objRequest As RMICWRequestWS_Input = New RMICWRequestWS_Input
            Try

                objRequest.strAcctNum = strAcctNum
				objRequest.strVisionCustomerId = strVisionCustomerId
                objRequest.strVisionAccountId = strVisionAccountId
                objRequest.strApplicationId = strAppId
                objRequest.strBTNNum = strBTN
                objRequest.strClass = strClass
                objRequest.strConditionCd = strConditionCd
                objRequest.strLogonId = strLogonId
                objRequest.strNotationCd = strNotationCd
                objRequest.strOrg = strOrg
                objRequest.strOriginationId = strOriginationId
                objRequest.strRegionId = strRegionId
                objRequest.strRequestActn = strActn
                objRequest.strRequestActnType = strRequestType
                objRequest.strRestoreFeeInd = "Y"
                objRequest.strSBMAcctNum = strSBM
                objRequest.strEnvironment = strEnvironment
                objRequest.strRemarks = strremarks
                objRequest.strReturnCD = strReturnCD
                objRequest.strApplicationId = strAppId
				If strRegionId = "VISION" Then
                    objRequest.strAcctNum = objRequest.strVisionCustomerId + objRequest.strVisionAccountId
                End If
				
            Catch ex As Exception

                LogErrorFile.WriteLog("RMICWWS", ex.ToString())
            End Try
            Return RMICWRequestIssue(objRequest)

        End Function
#Region "RMICW Request Issue Web method"

        Public Function RMICWRequestIssue(ByVal Request As RMICWRequestWS_Input) As RMICWRequestWS_Output


            Dim RequestOut As RMICWRequestWS_Output = New RMICWRequestWS_Output

            Try

                'LogErrorFile.WriteLog("RMICWWS", Request.getInput() + "strVisionAccountId:" + Request.strVisionAccountId + "strVisionAccountId:" + Request.strVisionCustomerId)



                If (Request.strOrg Is Nothing) Then
                    Request.strOrg = ""
                End If

                If (Request.strOrg.Length < 2) Then
                    Request.strOrg = "NAV"
                End If

                If (Request.strBTNNum Is Nothing) Then
                    Request.strBTNNum = ""
                End If

                If (Request.strBTNNum.Length < 2) Then
                    Request.strBTNNum = "NAVL"
                End If

                If (Request.strClass Is Nothing) Then
                    Request.strClass = ""
                End If

                If (Request.strClass.Length < 2) Then
                    Request.strClass = "000"
                End If

                If (Request.strRegionId Is Nothing) Then
                    Request.strRegionId = ""
                End If

                If (Not Request.strNotationCd Is Nothing) Then
                    Request.strNotationCd = Regex.Replace(Request.strNotationCd, "[^\w$.* ];", "")
                    Request.strNotationCd = Regex.Replace(Request.strNotationCd, "[""]", String.Empty)
                    Request.strNotationCd = Regex.Replace(Request.strNotationCd, "[+~!@#$%^><&*()_+{}|]", "")


                End If
                
                If Request.strRegionId = "VISION" Then
                    RequestOut.strAcctNum = Request.strVisionCustomerId.Trim() + Request.strVisionAccountId.Trim()
                End If

                Select Case True
                    Case Request.strRegionId Is Nothing Or Request.strRegionId.Trim() = ""
                        RequestOut.strMessageId = "RMWTS001"
                        RequestOut.strMessageDescription = "Invalid RegionId Specified"
                        Request.strRegionId = " "

                    Case Not WSCommonClasses.CheckRegionType(Request.strRegionId.Trim)
                        RequestOut.strMessageId = "RMWTS001"
                        RequestOut.strMessageDescription = "Invalid RegionId Specified"
                        Request.strRegionId = " "

                    Case Request.strAcctNum Is Nothing Or Request.strAcctNum.Trim() = ""
                        RequestOut.strMessageId = "RMWTS010"
                        RequestOut.strMessageDescription = "AcctNum Invalid"
                        Request.strAcctNum = " "
                    Case Request.strVisionAccountId Is Nothing Or Request.strVisionAccountId.Trim() = "" Or Request.strVisionAccountId.Length < 4
                        If Request.strRegionId = "VISION" Then
                            RequestOut.strMessageId = "RMWTS010"
                            RequestOut.strMessageDescription = "Vision AccountID Empty or Invalid"
                            Request.strAcctNum = " "
                        End If
                        
                    Case Request.strVisionCustomerId Is Nothing Or Request.strVisionCustomerId.Trim() = "" Or Request.strVisionCustomerId.Length < 9
                        RequestOut.strMessageId = "RMWTS010"
                        RequestOut.strMessageDescription = "Vision CustomerID Empty or Invalid"
                        Request.strAcctNum = " "

                    Case Request.strBTNNum Is Nothing Or Request.strBTNNum.Trim() = "" Or Request.strBTNNum.Length < 2
                        RequestOut.strMessageId = "RMWTS020"
                        RequestOut.strMessageDescription = "BTN Invalid"
                        Request.strBTNNum = " "
                    Case Request.strOrg Is Nothing Or Request.strOrg.Trim() = ""
                        RequestOut.strMessageId = "RMWTS030"
                        RequestOut.strMessageDescription = "Org Invalid"
                        Request.strOrg = " "
                    Case Request.strClass Is Nothing Or Request.strClass.Trim() = ""
                        RequestOut.strMessageId = "RMWTS040"
                        RequestOut.strMessageDescription = "Class Invalid"
                        Request.strClass = " "
                    Case Request.strRequestActnType Is Nothing

                        RequestOut.strMessageId = "RMWTS050"
                        RequestOut.strMessageDescription = "Request Actn Type Invalid"
                        Request.strRequestActnType = " "
                    Case (Not Request.strRequestActnType = "A" And Not Request.strRequestActnType = "C" And Not Request.strRequestActnType = "R")
                        RequestOut.strMessageId = "RMWTS060"
                        RequestOut.strMessageDescription = "Request Actn Type Invalid"

                    Case (Request.strRequestActn Is Nothing Or Request.strRequestActn.Trim = "")
                        RequestOut.strMessageId = "RMWTS070"
                        RequestOut.strMessageDescription = "Request Actn Invalid"
                        Request.strRequestActn = " "
                    Case (Request.strOriginationId Is Nothing Or Request.strOriginationId.Trim = "")
                        RequestOut.strMessageId = "RMWTS080"
                        RequestOut.strMessageDescription = "OriginationId Invalid"
                        Request.strOriginationId = " "
                    Case Else
                        RequestOut.strMessageId = " "
                        RequestOut.strMessageDescription = " "
                End Select
                ' for RMVP
                If Request.strApplicationId = "VRU" Then

                    If Request.strRemarks = "" Then
                        RequestOut.strMessageId = "RMWTS090"
                        RequestOut.strMessageDescription = "Remarks Invalid"
                        Request.strOriginationId = " "
                    End If

                    If Request.strReturnCD = "" Then
                        RequestOut.strMessageId = "RMWTS100"
                        RequestOut.strMessageDescription = "ReturnCD Invalid"
                        Request.strOriginationId = " "
                    End If
                End If
                '-------------------------

                RequestOut.strAcctNum = Request.strAcctNum




                If RequestOut.strMessageId.Trim = "" Then
                    If Request.strConditionCd Is Nothing Or Request.strConditionCd.Trim = "" Then
                        Request.strConditionCd = "ALL"
                    End If
                    RequestOut.intRequestId = _
                    MyBase.WSDataAccessObj.usp_InsertRISORequest(Request.strRegionId, _
                    Request.strAcctNum, Request.strOrg, Request.strClass, Request.strRequestActn, _
                    Request.strNotationCd, Request.strLogonId, New DateTime(1900, 1, 1), _
                    Request.strBTNNum, Request.strSBMAcctNum, Request.strRemarks, Request.strOriginationId, _
                    Request.strRequestActnType, 0, Request.strConditionCd, Request.strEnvironment, Request.strApplicationId, Request.strReturnCD)
                End If

                'LogErrorFile.WriteLog("RISO INSERT", "DONE")


            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS - RMICWRequestIssue", ex.ToString())
                RequestOut.strMessageId = "RMIEXCPTN"
                RequestOut.strMessageDescription = ex.Message

            End Try

            Try

                MyBase.WSDataAccessObj.usp_InsertAuditTrail("RequestWS", WSCommonClasses.CheckNull(Request.strApplicationId), WSCommonClasses.CheckNull(Request.strOrg), WSCommonClasses.CheckNull(Request.strRequestActnType), "I", WSCommonClasses.CheckNull(Request.strAcctNum), WSCommonClasses.CheckNull(Request.getInput()))
                If Not RequestOut.strMessageId.Trim = "" Then
                    MyBase.WSDataAccessObj.usp_InsertAuditTrail("RequestWS", WSCommonClasses.CheckNull(Request.strApplicationId), WSCommonClasses.CheckNull(Request.strOrg), WSCommonClasses.CheckNull(Request.strRequestActnType), "I", WSCommonClasses.CheckNull(Request.strAcctNum), "RISO Request Issued. Message Id: " + RequestOut.strMessageId + " Description: " + RequestOut.strMessageDescription)
                End If

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS - RMICWRequestIssue", ex.ToString())
            End Try

            Try
                'LogErrorFile.WriteLog("getProcessRequests", "BEGIN")

                If MyBase.WSDataAccessObj.usp_GetControlParmByName("Control" & Request.strRegionId, "RISOE2E").ToUpper.Trim = "TRUE" Then

                    'getProcessRequests(RequestOut, Request.strRegionId)
                    RequestOut.strRegionId = Request.strRegionId

                    Dim paramThreadStart As New ParameterizedThreadStart(AddressOf getProcessRequests)
                    Dim newThread As New Thread(paramThreadStart)
                    newThread.Start(RequestOut)

                End If



                'LogErrorFile.WriteLog("getProcessRequests", "END")

            Catch exReq As Exception
                'LogErrorFile.WriteLog("RMICWWS - RMICWRequestIssue", exReq.ToString())
                LogErrorFile.WriteLog("RMICWWS - getProcessRequests", Request.strAcctNum + "/" + Request.strApplicationId + "/" + Request.strClass + "/" + Request.strConditionCd + "/" + Request.strEnvironment + "/" + Request.strNotationCd + "/" + Request.strOriginationId + "/" + Request.strRegionId + "/" + Request.strRequestActn + "/" + exReq.ToString())

            End Try

            Return RequestOut

        End Function

#End Region


#Region "RMICW Result Response"


        Public Function getResponseForRequestTest(ByVal strRegionId As String, ByVal strAppId As String, ByVal strAcctNum As String, ByVal intRequestId As String) As ResultResponseWS_Output

            Dim objRequest As ResultResponseWS_Input = New ResultResponseWS_Input

            Try

                objRequest.intRequestId = intRequestId
                objRequest.strAcctNum = strAcctNum
                objRequest.strApplicationId = strAppId
                objRequest.strRegionId = strRegionId

                Return (getResponseForRequest(objRequest))

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS", ex.ToString())
            End Try
        End Function



        Public Function getResponseForRequest(ByVal Request As ResultResponseWS_Input) As ResultResponseWS_Output


            Dim ResultOut As ResultResponseWS_Output = New ResultResponseWS_Output
            ResultOut.strStatusCd = " "

            Try



                Select Case True
                    Case Not WSCommonClasses.CheckRegionType(Request.strRegionId.Trim)
                        ResultOut.strMessageId = "RMWTS001"
                        ResultOut.strMessageDescription = "Invalid RegionId Specified"

                    Case Request.intRequestId <= 0
                        ResultOut.strMessageId = "INVRQST"
                        ResultOut.strMessageDescription = "RequestId is Invalid"
                    Case Else
                        ResultOut.strMessageId = " "
                        ResultOut.strMessageDescription = " "
                End Select


                If ResultOut.strMessageId.Trim = "" Then

                    Dim ds As DataSet = MyBase.WSDataAccessObj.usp_GetResponseForRequest(Request.strRegionId, Request.intRequestId)
                    Dim dtRequestDetails As DataTable
                    Dim dtServiceRequestDetails As DataTable
                    Dim dr As DataRow


                    Try
                        dtRequestDetails = ds.Tables(0)
                        dtServiceRequestDetails = ds.Tables(1)

                        Dim arrLstRequest As ArrayList = New ArrayList
                        Dim arrLstServiceRequest As ArrayList = New ArrayList

                        'For Each dr In dtRequestDetails.Rows
                        For i As Integer = 0 To dtRequestDetails.Rows.Count - 1
                            dr = dtRequestDetails.Rows(i)
                            Dim objResponseDetails As ResultResponseWS_Output.ResponseDetails = New ResultResponseWS_Output.ResponseDetails
                            objResponseDetails.intRequestId = dr("intRequestId")
                            objResponseDetails.strAcctNum = dr("strAcctNum")
                            objResponseDetails.strActn = dr("strActn")
                            objResponseDetails.strReturnCd = dr("strReturnCd")
                            objResponseDetails.strReturnCdDesc = dr("strLongDesc")
                            objResponseDetails.strStatusCd = dr("strStatusCd")
                            objResponseDetails.dtmPrcsdTs = dr("dtmPrcsdTs")
                            arrLstRequest.Add(objResponseDetails)

                            Select Case objResponseDetails.strStatusCd.Trim
                                Case "RQ", "IL", "SV", "VC"
                                    ResultOut.strStatusCd = "IP"
                                Case Else
                            End Select

                        Next
                        ResultOut.Response = CType(arrLstRequest.ToArray(GetType(ResultResponseWS_Output.ResponseDetails)), ResultResponseWS_Output.ResponseDetails())

                        'For Each dr In dtServiceRequestDetails.Rows
                        For i As Integer = 0 To dtServiceRequestDetails.Rows.Count - 1
                            dr = dtServiceRequestDetails.Rows(i)
                            Dim objOrderDetails As ResultResponseWS_Output.OrderDetails = New ResultResponseWS_Output.OrderDetails
                            objOrderDetails.strActn = dr("strActn")
                            objOrderDetails.strOrderId = dr("strOrderId")
                            objOrderDetails.strOrderStatusCd = dr("strStatusCd")
                            objOrderDetails.strOrderType = dr("strOrderType")
                            arrLstServiceRequest.Add(objOrderDetails)
                        Next
                        ResultOut.OrderInformation = CType(arrLstServiceRequest.ToArray(GetType(ResultResponseWS_Output.OrderDetails)), ResultResponseWS_Output.OrderDetails())

                        If dtRequestDetails.Rows.Count = 0 Then
                            ResultOut.strMessageId = "RQSTNAVL"
                            ResultOut.strMessageDescription = "RequestId Not Available"
                        End If

                    Catch ex As Exception
                        LogErrorFile.WriteLog("RMICWWS - RMICWResultResponse", ex.ToString())
                    End Try

                End If


            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS - RMICWResultResponse", ex.ToString())
                ResultOut.strMessageId = "RMIEXCPTN"
                ResultOut.strMessageDescription = ex.Message
            End Try

            Return ResultOut

        End Function

#End Region


        Public Function getProcessRequests(ByVal RequestOut As RMICWRequestWS_Output) As String

            Dim objInternalWS As InternalWS.ServiceMain = New InternalWS.ServiceMain

            Dim strMsgBody As String = ""
            Dim strParmRegion As String = ""
            Dim strRegionId As String = ""
            strRegionId = RequestOut.strRegionId


            strParmRegion = "Control" + strRegionId

            strMsgBody = GetMainDriverXml(RequestOut.intRequestId, 0, strRegionId)
            Try
                If strMsgBody.Trim() = "" Then
                    LogErrorFile.WriteLog("E2EDriverxml Is Empty:", RequestOut.intRequestId)
                End If



                If strMsgBody.Trim() <> "" Then

                    'LogErrorFile.WriteLog("RISO CALL INTERNAL WS", "BEGIN")



                    'objInternalWS.Url = "http://113.130.72.167/Rmicwwebservices/ServiceMain.asmx"
                    objInternalWS.Url = MyBase.WSDataAccessObj.usp_GetControlParmByName(strParmRegion, "RMICWInternalWS")
                    objInternalWS.Proxy = New WebProxy()
                    objInternalWS.RequestManagerMain(strMsgBody, 0)

                    'LogErrorFile.WriteLog("RISO CALL INTERNAL WS", "END")

                End If


            Catch ex As Exception

                LogErrorFile.WriteLog("RMICWWS - getProcessRequests Internal WS", RequestOut.intRequestId + "/" + strParmRegion + "/" + RequestOut.strAcctNum + "/" + RequestOut.strActn + "/" + RequestOut.strMessageDescription + "/" + ex.ToString())
                Throw (ex)

            End Try







        End Function



        Public Function GetMainDriverXml(ByVal intRequestId As Long, ByRef intStatus As Integer, ByVal strParmRegion As String) As String

            Dim strMsgBody As String = " "
            Dim ds As RMICWMainDriverLayout
            Dim dr As RMICWMainDriverLayout.RMICWMainDriverDetailsRow
            Dim i As Integer
            Dim strAcctNum As String
            Dim blnContinue As Boolean = False
            enPrcsStatusFlag = EnPrcsFlag.enPrcsFlagNormal
            intStatus = 1

            Try
                'ds = MyBase.WSDataAccessObj.usp_GetRequestMainDriverByRequestId("RMICWMainDriverDetails", "ControlNE", intRequestId, intStatus)
                ds = MyBase.WSDataAccessObj.usp_GetRequestMainDriverByRequestId("RMICWMainDriverDetails", strParmRegion, intRequestId, Environment.MachineName, intStatus)
                If (Not MyBase.WSDataAccessObj.IsEmptyRecordSet(ds)) Then
                    If (ds.RMICWMainDriverDetails.Rows.Count > i) Then
                        dr = ds.RMICWMainDriverDetails.Rows(i)
                        strAcctNum = dr.strAcctNum
                        blnContinue = True
                        ValidateEachRequest(dr)
                    End If
                End If

                If blnContinue Then
                    InitialValidation(dr)
                    If enPrcsStatusFlag = EnPrcsFlag.enPrcsFlagNormal Then
                        If CheckMSORRequests(dr) Then
                            enPrcsStatusFlag = EnPrcsFlag.enPrcsFlagSkip
                        End If
                    End If

                    If enPrcsStatusFlag = EnPrcsFlag.enPrcsFlagNormal Then
                        If Not MyBase.WSDataAccessObj.usp_CheckPrecedenceLevel(dr.intRequestId, dr.strAcctNum, "SV", "RmicwWS", 0) Then
                            enPrcsStatusFlag = EnPrcsFlag.enPrcsFlagSkip
                        End If
                    End If

                    If enPrcsStatusFlag = EnPrcsFlag.enPrcsFlagNormal Then
                        UpdateRequest(dr.intRequestId, "STUDSV00", "RmicwWS")
                        'dr.strStatusCd = "SV"
                    End If

                    If enPrcsStatusFlag = EnPrcsFlag.enPrcsFlagNormal Then
                        strMsgBody = GetDriverInterfaceLayoutFromDataRow(dr)
                    End If
                Else
                    intStatus = 0
                End If


            Catch e As Exception
                intStatus = 0
                strMsgBody = " "
                LogErrorFile.WriteLog("MDFeedRqst", e.ToString())
                LogErrorFile.WriteLog("MDFeedRqst : Error Request Id:", intRequestId.ToString())
            End Try

            Return strMsgBody

        End Function

        Private Sub ValidateEachRequest(ByVal drReqMD As RMICWMainDriverLayout.RMICWMainDriverDetailsRow)

            Dim strMsgBody As String

            enPrcsStatusFlag = EnPrcsFlag.enPrcsFlagNormal
            InitialValidation(drReqMD)

            If enPrcsStatusFlag = EnPrcsFlag.enPrcsFlagNormal Then
                If CheckMSORRequests(drReqMD) Then
                    enPrcsStatusFlag = EnPrcsFlag.enPrcsFlagSkip
                End If
            End If

            If enPrcsStatusFlag = EnPrcsFlag.enPrcsFlagNormal Then
                If Not MyBase.WSDataAccessObj.usp_CheckPrecedenceLevel(drReqMD.intRequestId, drReqMD.strAcctNum, "IL", "RmicwWS", 0) Then
                    enPrcsStatusFlag = EnPrcsFlag.enPrcsFlagSkip
                End If

            End If

            If enPrcsStatusFlag = EnPrcsFlag.enPrcsFlagNormal Then
                UpdateRequest(drReqMD.intRequestId, "STUDSV00", "RmicwWS")
                'drReqMD.strStatusCd = "SV"
            End If

            strMsgBody = GetDriverInterfaceLayoutFromDataRow(drReqMD)

            'If enPrcsStatusFlag = EnPrcsFlag.enPrcsFlagNormal Then
            '    strMsgBody = GetDriverInterfaceLayoutFromDataRow(drReqMD)

            'End If

        End Sub

        Private Sub InitialValidation(ByVal drReqMD As RMICWMainDriverLayout.RMICWMainDriverDetailsRow)

            Dim blnExcptn As Boolean = False
            Select Case True
                Case String.Compare(Trim(drReqMD.strActnPrcsInd), "Y", True) <> 0
                    UpdateRequest(drReqMD.intRequestId, "ACTNNFND", "RmicwWS")
                    blnExcptn = True
                Case String.Compare(Trim(drReqMD.strOrgPrcsInd), "Y", True) <> 0
                    UpdateRequest(drReqMD.intRequestId, "ORGINVLD", "RmicwWS")
                    blnExcptn = True
                Case String.Compare(Trim(drReqMD.strExcptnCd), "Y", True) <> 0
                    UpdateRequest(drReqMD.intRequestId, "INVOACTN", "RmicwWS")
                Case CheckExcptns(drReqMD)
                    blnExcptn = True
                Case CheckOrgActn(drReqMD)
                    blnExcptn = True
                Case Else
            End Select
            If blnExcptn Then
                enPrcsStatusFlag = EnPrcsFlag.enPrcsFlagSkip
            End If

        End Sub

        Private Function CheckMSORRequests(ByVal drReqMD As RMICWMainDriverLayout.RMICWMainDriverDetailsRow) As Boolean
            Dim blnExcptn As Boolean = False


            If drReqMD.strNotationCd.Trim = "MSOR" Or _
               drReqMD.strDestSystem.Trim = "MSOR" Or _
               drReqMD.strDestSystem.Trim = "COMB" Or _
               drReqMD.blnCombinedActnInd.Trim.ToUpper = "TRUE" Then
                blnExcptn = True

                If drReqMD.blnCombinedActnInd.ToUpper.Trim = "TRUE" Then

                    If (UpdateCombinedRequest(drReqMD.intRequestId, drReqMD.strActn) = 1) Then
                        blnExcptn = False
                    End If
                Else
                    UpdateRequest(drReqMD.intRequestId, drReqMD.strActnReturnCd, "RISO WS")
                End If


            End If
                Return blnExcptn
        End Function

        Private Sub UpdateRequest(ByVal intRequestId As Long, ByVal strReturnCd As String, ByVal strUpdtId As String)
            Dim intUpdtcnt As Integer
            MyBase.WSDataAccessObj.usp_UpdateStatusDLRorOtherRequest("SOR", intRequestId, strReturnCd, "RmicwWS")

        End Sub

        Private Function GetDriverInterfaceLayoutFromDataRow(ByVal dr As DataRow) As String

            Dim strXml As String = "<RMICWDriverInterfaceLayout><RMICWDriverInterfaceDetails>"
            strXml += GetRequestDetails(dr)
            strXml += GetActionDetails(dr)
            strXml += GetStatusDetails(dr)
            strXml += "</RMICWDriverInterfaceDetails></RMICWDriverInterfaceLayout>"
            Return strXml
        End Function


        Private Function GetRequestDetails(ByVal dr As DataRow) As String

            Dim strXml As String
            strXml = "<RequestDetails "
            strXml += GeneralRoutine.GetAttribute(dr, "strRegionId")
            strXml += GeneralRoutine.GetAttribute(dr, "intRequestId")
            strXml += GeneralRoutine.GetAttribute(dr, "strAcctNum")
            strXml += GeneralRoutine.GetAttribute(dr, "dtmRequestTs")
            strXml += GeneralRoutine.GetAttribute(dr, "strOrg")
            strXml += GeneralRoutine.GetAttribute(dr, "strClass")
            strXml += GeneralRoutine.GetAttribute(dr, "strActn")
            strXml += GeneralRoutine.GetAttribute(dr, "dtmPrcsdTs")
            strXml += GeneralRoutine.GetAttribute(dr, "strStatusCd")
            strXml += GeneralRoutine.GetAttribute(dr, "strNotationCd")
            strXml += GeneralRoutine.GetAttribute(dr, "intInstalBlngCd")
            strXml += GeneralRoutine.GetAttribute(dr, "strLogonId")
            strXml += GeneralRoutine.GetAttribute(dr, "strRstFeeInd")
            strXml += GeneralRoutine.GetAttribute(dr, "strOriginationId")
            strXml += GeneralRoutine.GetAttribute(dr, "dtmPymntRcvdDt")
            strXml += GeneralRoutine.GetAttribute(dr, "intRetryCnt")
            strXml += GeneralRoutine.GetAttribute(dr, "dtmRequestDueDt")
            strXml += GeneralRoutine.GetAttribute(dr, "dtmRequeueDt")
            strXml += GeneralRoutine.GetAttribute(dr, "strResultType")
            strXml += GeneralRoutine.GetAttribute(dr, "strResultId")
            strXml += GeneralRoutine.GetAttribute(dr, "strReturnCd")
            strXml += GeneralRoutine.GetAttribute(dr, "intParentRqstId")
            strXml += GeneralRoutine.GetAttribute(dr, "strArchiveInd")
            strXml += GeneralRoutine.GetAttribute(dr, "strUpdtId")
            strXml += GeneralRoutine.GetAttribute(dr, "dtmUpdtTs")
            strXml += GeneralRoutine.GetAttribute(dr, "strBTNNum")
            strXml += GeneralRoutine.GetAttribute(dr, "strRemarks")
            strXml += GeneralRoutine.GetAttribute(dr, "strEnvironment")
            strXml += GeneralRoutine.GetAttribute(dr, "strStrataInd")
            strXml += "/>"

            Return strXml
        End Function


        Private Function GetActionDetails(ByVal dr As DataRow) As String

            Dim strXml As String
            strXml = "<ActionDetails "
            strXml += GeneralRoutine.GetAttribute(dr, "strActn")
            strXml += GeneralRoutine.GetAttribute(dr, "strActnClsCd")
            strXml += GeneralRoutine.GetAttribute(dr, "strDestSystem")
            strXml += GeneralRoutine.GetAttribute(dr, "strActnReturnCd")
            strXml += GeneralRoutine.GetAttribute(dr, "blnCombinedActnInd")
            strXml += GeneralRoutine.GetAttribute(dr, "blnValidationInd")
            strXml += GeneralRoutine.GetAttribute(dr, "curRequestRstFee", "curRstFee")

            strXml += ">"

            strXml += GetUseActionDetails(dr)
            strXml += GetGenActionDetails(dr)
            strXml += "</ActionDetails>"
            Return strXml
        End Function

        Private Function GetUseActionDetails(ByVal dr As DataRow) As String
            Dim strXml As String

            Try
                If (dr("strUseActn1") = Nothing Or Trim(dr("strUseActn1")) = "") Then
                    strXml = "<UseActionDetails "
                    strXml += GeneralRoutine.GetAttribute(dr, "strUseActn", "strActn")
                    strXml += GeneralRoutine.GetAttribute(dr, "curRstFee", "curRstFee")
                    strXml += GeneralRoutine.GetAttribute("strResultActn", " ")
                    strXml += "/>"
                Else
                    If Trim(dr("strUseActn1")) <> "" Then
                        strXml = "<UseActionDetails "
                        strXml += GeneralRoutine.GetAttribute(dr, "strUseActn", "strUseActn1")
                        strXml += GeneralRoutine.GetAttribute("strResultActn", " ")
                        strXml += "/>"
                    End If

                    If Trim(dr("strUseActn2")) <> "" Then
                        strXml += "<UseActionDetails "
                        strXml += GeneralRoutine.GetAttribute(dr, "strUseActn", "strUseActn2")
                        strXml += GeneralRoutine.GetAttribute("strResultActn", " ")
                        strXml += "/>"
                    End If

                    If Trim(dr("strUseActn3")) <> "" Then
                        strXml += "<UseActionDetails "
                        strXml += GeneralRoutine.GetAttribute(dr, "strUseActn", "strUseActn3")
                        strXml += GeneralRoutine.GetAttribute("strResultActn", " ")
                        strXml += "/>"
                    End If

                    If Trim(dr("strUseActn4")) <> "" Then
                        strXml += "<UseActionDetails "
                        strXml += GeneralRoutine.GetAttribute(dr, "strUseActn", "strUseActn4")
                        strXml += GeneralRoutine.GetAttribute("strResultActn", " ")
                        strXml += "/>"
                    End If

                    If Trim(dr("strUseActn5")) <> "" Then
                        strXml += "<UseActionDetails "
                        strXml += GeneralRoutine.GetAttribute(dr, "strUseActn", "strUseActn5")
                        strXml += GeneralRoutine.GetAttribute("strResultActn", " ")
                        strXml += "/>"
                    End If

                    If Trim(dr("strUseActn6")) <> "" Then
                        strXml += "<UseActionDetails "
                        strXml += GeneralRoutine.GetAttribute(dr, "strUseActn", "strUseActn6")
                        strXml += GeneralRoutine.GetAttribute("strResultActn", " ")
                        strXml += "/>"
                    End If
                End If

            Catch e As Exception
                LogErrorFile.WriteLog("RmicwWS", "Error in Parsing UseAction Details, Defaulting to Main Action.")
                strXml = "<UseActionDetails "
                strXml += GeneralRoutine.GetAttribute(dr, "strUseActn", "strActn")
                strXml += GeneralRoutine.GetAttribute(dr, "curRstFee", "curRstFee")
                strXml += GeneralRoutine.GetAttribute("strResultActn", " ")
                strXml += "/>"
            End Try

            Return strXml
        End Function


        Private Function GetGenActionDetails(ByVal dr As DataRow) As String
            Dim strXml As String
            If (dr("strGenActn1") = Nothing Or Trim(dr("strGenActn1")) = "") Then
                strXml = "<GenAction "
                strXml += GeneralRoutine.GetAttribute(dr, "strGenActn", "strActn")
                strXml += "/>"
            Else
                If Trim(dr("strGenActn1")) <> "" Then
                    strXml = "<GenAction "
                    strXml += GeneralRoutine.GetAttribute(dr, "strGenActn", "strGenActn1")
                    strXml += "/>"
                End If

                If Trim(dr("strGenActn2")) <> "" Then
                    strXml += "<GenAction "
                    strXml += GeneralRoutine.GetAttribute(dr, "strGenActn", "strGenActn2")
                    strXml += "/>"
                End If

                If Trim(dr("strGenActn3")) <> "" Then
                    strXml += "<GenAction "
                    strXml += GeneralRoutine.GetAttribute(dr, "strGenActn", "strGenActn3")
                    strXml += "/>"
                End If

                If Trim(dr("strGenActn4")) <> "" Then
                    strXml += "<GenAction "
                    strXml += GeneralRoutine.GetAttribute(dr, "strGenActn", "strGenActn4")
                    strXml += "/>"
                End If
            End If
            Return strXml
        End Function

        Private Function GetStatusDetails(ByVal dr As DataRow) As String
            Dim strXml As String
            strXml = "<StatusDetails blnErrorFlag = ""false"" strErrorCd = """"  strErrorDescription = "" "" />"
            Return strXml
        End Function

        


        Public Function UpdateCombinedRequest(ByVal intRequestId As Long, ByVal strActn As String) As Integer

            Dim blnResult As Boolean = True
            Dim strMsg As String
            Dim i As Integer
            i = MyBase.WSDataAccessObj.usp_UpdateCombinedRequest(intRequestId, strActn, "RmicwWS", "STUDDN00", 0)

            Return i
        End Function

        Private Function CheckExcptns(ByVal drReqMD As RMICWMainDriverLayout.RMICWMainDriverDetailsRow) As Boolean

            Dim blnExcptn As Boolean = False
            If drReqMD.strExcptnNpaNxxInd.Trim = "Y" Then
                UpdateRequest(drReqMD.intRequestId, "EXNPANXX", "RmicwWS")
                blnExcptn = True
            Else

            End If
            Return blnExcptn
        End Function

        Private Function CheckOrgActn(ByVal drReqMD As RMICWMainDriverLayout.RMICWMainDriverDetailsRow) As Boolean

            Dim blnExcptn As Boolean = False
            Dim objOrgActn As OrgActn = MyBase.WSDataAccessObj.SelectOrgActionFromDS(drReqMD.strOrg, drReqMD.strActn)

            If drReqMD.blnCombinedActnInd.Trim = "TRUE" Then
                objOrgActn = MyBase.WSDataAccessObj.SelectOrgActionFromDS(drReqMD.strOrg, drReqMD.strActn)
                If objOrgActn Is Nothing Then
                    UpdateRequest(drReqMD.intRequestId, "INVOACTN", "RmicwWS")
                    Return True
                End If
            Else

                If drReqMD.strUseActn1.Trim <> "" Then
                    objOrgActn = MyBase.WSDataAccessObj.SelectOrgActionFromDS(drReqMD.strOrg, drReqMD.strUseActn1)
                    If objOrgActn Is Nothing Then
                        UpdateRequest(drReqMD.intRequestId, "INVOACTN", "RmicwWS")
                        Return True
                    End If
                End If

                If drReqMD.strUseActn2.Trim <> "" Then
                    objOrgActn = MyBase.WSDataAccessObj.SelectOrgActionFromDS(drReqMD.strOrg, drReqMD.strUseActn2)
                    If objOrgActn Is Nothing Then
                        UpdateRequest(drReqMD.intRequestId, "INVOACTN", "RmicwWS")
                        Return True
                    End If
                End If

                If drReqMD.strUseActn3.Trim <> "" Then
                    objOrgActn = MyBase.WSDataAccessObj.SelectOrgActionFromDS(drReqMD.strOrg, drReqMD.strUseActn3)
                    If objOrgActn Is Nothing Then
                        UpdateRequest(drReqMD.intRequestId, "INVOACTN", "RmicwWS")
                        Return True
                    End If
                End If

                If drReqMD.strUseActn4.Trim <> "" Then
                    objOrgActn = MyBase.WSDataAccessObj.SelectOrgActionFromDS(drReqMD.strOrg, drReqMD.strUseActn4)
                    If objOrgActn Is Nothing Then
                        UpdateRequest(drReqMD.intRequestId, "INVOACTN", "RmicwWS")
                        Return True
                    End If
                End If

            End If

            Return blnExcptn
        End Function


    End Class
End Namespace
