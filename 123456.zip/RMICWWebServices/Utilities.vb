﻿Public Class Utilities

    Public Shared Function GetPwd() As String
        Return "verizon123"
    End Function

End Class