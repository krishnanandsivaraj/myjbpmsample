Imports System.Web.Services
Imports CommonLibrary
Imports System.Xml
Imports System.Xml.Serialization
Imports System.IO
Imports System.Globalization
Imports System.Net
Imports System.Text.RegularExpressions
Imports Microsoft.Web.Services2.Security
Imports Microsoft.Web.Services2
Imports Microsoft.Web.Services2.Dime
Imports System.Web.Services.Protocols
Imports System.Diagnostics
Imports System.Threading
Imports System.ServiceModel
Imports Microsoft.Web.Services2.Security.Tokens
Imports NsopWebService
Imports Verizon.RMICW.WebServices.Profile
Imports System.Xml.Linq
Imports GetAccountRelationResponse_NACRNEWService


Namespace Verizon.RMICW.WebServices


    <ServiceContract(Namespace:="http://tempuri.org/RMICWWebServices/WSMain")> _
    <System.Web.Services.WebService(Namespace:="http://tempuri.org/RMICWWebServices/WSMain")> _
    Public Class WSMain
        Inherits System.Web.Services.WebService
        'Private Shared dsMainParm As DataSet
        Public Shared dsMainParm As DataSet
        Private WSDataAccess As WSDataAccessGeneric

        Private Shared strSNPIndField As String = ""
        Private Shared strRSTIndField As String = ""
        Private Shared strDSCIndField As String = ""
        Private Shared blnSSPBackup As Boolean = False
        Private Shared strAcctLvlOrder As String = ""
        Private strRegionCd As String = "VISION"
        ' Private objFIOS As getFIOSDataInputDetails = New getFIOSDataInputDetails




        Public Property strSNPInd() As String
            Get
                Return WSMain.strSNPIndField
            End Get
            Set(ByVal value As String)
                WSMain.strSNPIndField = value
            End Set
        End Property


        Public Property strRSTInd() As String
            Get
                Return WSMain.strRSTIndField
            End Get
            Set(ByVal value As String)
                WSMain.strRSTIndField = value
            End Set
        End Property


        Public Property strDSCInd() As String
            Get
                Return WSMain.strDSCIndField
            End Get
            Set(ByVal value As String)
                WSMain.strDSCIndField = value
            End Set
        End Property







#Region " Web Services Designer Generated Code "

        Public Sub New()
            MyBase.New()

            'This call is required by the Web Services Designer.
            InitializeComponent()

            'Add your own initialization code after the InitializeComponent() call       



        End Sub

        'Required by the Web Services Designer
        Private components As System.ComponentModel.IContainer

        'NOTE: The following procedure is required by the Web Services Designer
        'It can be modified using the Web Services Designer.  
        'Do not modify it using the code editor.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
            components = New System.ComponentModel.Container
        End Sub

        Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
            'CODEGEN: This procedure is required by the Web Services Designer
            'Do not modify it using the code editor.
            If disposing Then
                If Not (components Is Nothing) Then
                    components.Dispose()
                End If
            End If
            MyBase.Dispose(disposing)
        End Sub

#End Region


#Region "Treatment Status Webmethod"

        <WebMethod(Description:="Get Treatment Status")> _
        Public Function getTreatmentStatus(ByVal Request As TS_Request) As TS_Response
            Dim obj As TreatmentStatus = New TreatmentStatus(Request.strRegionId.Trim)
            Return obj.getTreatmentStatus(Request)
        End Function

#End Region



#Region "Product Status Webmethod"


        <WebMethod(MessageName:="getFIOSProductStatus_RML")> _
        Public Function getFIOSProductStatus(ByVal strRegionCd As String, ByVal strOrg As String, ByVal enInpType As enInpType, ByVal inpValue As String, ByVal strAppId As String) As TS_ProdStatus


            Dim objPS As TS_ProdStatus = New TS_ProdStatus

            If strAppId.Trim() = "" Then
                strAppId = "RMW"
            End If

            Try
                Dim obj As ProfileAccess = New ProfileAccess(strRegionCd)
                Dim objSSPRqst As SSPRequestDetails = New SSPRequestDetails
                'objPS = obj.getProductStatus(strOrg, enInpType, inpValue)
                objSSPRqst.strRegionId = strRegionCd
                objSSPRqst.strOrg = strOrg

                objPS = obj.getSSPProductStatus(strRegionCd, strOrg, enInpType, inpValue, objSSPRqst, strAppId)


            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWebservices", ex.ToString() + strRegionCd + "/" + strOrg + "/" + inpValue)
                If (objPS Is Nothing) Then
                    objPS = New TS_ProdStatus
                End If
                objPS.RequestStatus.strMessageId = "ERMIEXPTN"
                objPS.RequestStatus.strMessageDescription = ex.ToString()

            End Try
            Return objPS

        End Function

#End Region

#Region "Product Status Webmethod"

        <WebMethod(Description:="Get Product Status")> _
        Public Function getFIOSProductStatus(ByVal strRegionCd As String, ByVal strOrg As String, ByVal enInpType As enInpType, ByVal inpValue As String) As TS_ProdStatus

            Dim objPS As TS_ProdStatus = New TS_ProdStatus

            Dim strAppId As String = ""

            If strAppId.Trim() = "" Then
                strAppId = "RMW"
            End If

            Try
                Dim obj As ProfileAccess = New ProfileAccess(strRegionCd)
                Dim objSSPRqst As SSPRequestDetails = New SSPRequestDetails
                'objPS = obj.getProductStatus(strOrg, enInpType, inpValue)
                objSSPRqst.strRegionId = strRegionCd
                objSSPRqst.strOrg = strOrg

                objPS = obj.getSSPProductStatus(strRegionCd, strOrg, enInpType, inpValue, objSSPRqst, strAppId)


            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWebservices", ex.ToString() + strRegionCd + "/" + strOrg + "/" + inpValue)
                If (objPS Is Nothing) Then
                    objPS = New TS_ProdStatus
                End If
                objPS.RequestStatus.strMessageId = "ERMIEXPTN"
                objPS.RequestStatus.strMessageDescription = ex.ToString()

            End Try
            Return objPS
        End Function

#End Region


#Region "Get Profile West Webmethod"

        <WebMethod(Description:="Get Profile West")> _
        Public Function getProfileWest(ByVal strRegionCd As String, ByVal enInpType As enInpType, ByVal inpValue As String, ByVal strProfileCAN As String) As COGWestProfile.fullProfileResultType

            Dim objProf As COGWestProfile.fullProfileResultType = New COGWestProfile.fullProfileResultType
            Try
                Dim obj As ProfileAccess = New ProfileAccess(strRegionCd)
                objProf = obj.getProfileWest(strRegionCd, enInpType, inpValue, strProfileCAN)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWebservices", ex.ToString())
                If (objProf Is Nothing) Then
                    objProf = New COGWestProfile.fullProfileResultType
                End If

                If (objProf.accountData Is Nothing) Then
                    objProf.accountData = New COGWestProfile.accountDataType
                End If
                objProf.accountData.arrearBillingInd = "ERMIEXPTN"
                objProf.accountData.accountServiceName = ex.ToString()

            End Try
            Return objProf
        End Function

#End Region


#Region "Get Profile East Webmethod"

        <WebMethod(Description:="Get Profile East")> _
        Public Function getProfileEast(ByVal strRegionCd As String, ByVal enInpType As enInpType, ByVal inpValue As String, ByVal strProfileCAN As String) As COGEastProfileResult.OneSearchResults


            Dim objResult As COGEastProfileResult.OneSearchResults
            Try
                Dim obj As ProfileAccess = New ProfileAccess(strRegionCd)
                objResult = obj.getProfileEast(strRegionCd, enInpType, inpValue, strProfileCAN)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWebservices", ex.ToString())
                If (objResult Is Nothing) Then
                    objResult = New COGEastProfileResult.OneSearchResults
                End If

                If (objResult.ResponseMessage Is Nothing) Then
                    objResult.ResponseMessage = New COGEastProfileResult.ResponseMessageType
                End If
                objResult.ResponseMessage.Code = "RMIEXPTN"
                objResult.ResponseMessage.Desc = ex.ToString()
            End Try
            Return objResult

        End Function

#End Region

#Region "Treatment Status SBM Webmethod"

        <WebMethod(Description:="Get Treatment Status For SBM")> _
        Public Function getTreatmentStatusForSBM(ByVal strRegionId As String, ByVal strAcctNum As String, ByVal strOrg As String, ByVal strRshipCode As String) As TS_ResponseForSBM
            Dim obj As TreatmentStatus = New TreatmentStatus(strRegionId.Trim)
            Return obj.getTreatmentStatusForSBM(strRegionId, strAcctNum, strOrg, strRshipCode)
        End Function

#End Region

#Region "Get Live/Final value based on CAN"

        <WebMethod(Description:="Get Live/Final value based on AcctNum")> _
        Public Function getLiveFinalValueForAccNum(ByVal strRegionId As String, ByVal strAcctNum As String) As String
            If strRegionId = "" Then strRegionId = "WEST"
            Dim objTretStatus As TreatmentStatus
            Dim strLifeFinalValue As String
            Try
                objTretStatus = New TreatmentStatus(strRegionId.Trim)
                strLifeFinalValue = objTretStatus.getLiveFinalValueForAccNum(strAcctNum, strRegionId)
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getLiveFinalValueForAccNum", ex.ToString())
            Finally
                objTretStatus.Dispose()
                objTretStatus = Nothing
            End Try
            Return strLifeFinalValue

        End Function

#End Region


#Region "RMICWRequestIssue Webmethod"

        <WebMethod(Description:="Issue Requests to RMiCW")> _
        <OperationContract()> _
        Public Function RMICWRequestIssue(ByVal Request As RMICWRequestWS_Input) As RMICWRequestWS_Output
            Dim obj As RMICWRequestIssue = New RMICWRequestIssue(Request.strRegionId.Trim)
            Return obj.RMICWRequestIssue(Request)
        End Function

#End Region

#Region "getResponseForRequest Webmethod"

        <WebMethod(Description:="Get Response for the Request Issued")> _
        Public Function getResponseForRequest(ByVal Request As ResultResponseWS_Input) As ResultResponseWS_Output
            Dim obj As RMICWRequestIssue = New RMICWRequestIssue(Request.strRegionId.Trim)
            Return obj.getResponseForRequest(Request)
        End Function

#End Region

#Region "getCBSS_CBSPERA1 Webmethod"

        <WebMethod(Description:="Get Account Profile from CBSPERA1")> _
        Public Function getCBSS_CBSPERA1(ByVal strRegionId As String, ByVal strAcctNum As String) As CBSPERA1

            Dim objCBSPERA1 As CBSPERA1 = New CBSPERA1
            Try
                Dim objERAAccess As CBSSERAAccess = New CBSSERAAccess(strRegionId)
                objCBSPERA1 = objERAAccess.getCBSS_CBSPERA1(strRegionId, strAcctNum)
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getCBSS_CBSPERA1", ex.ToString())
                objCBSPERA1.RequestStatus.strMessageId = "RMIEXPTN"
                objCBSPERA1.RequestStatus.strMessageDescription = ex.ToString
            End Try
            Return objCBSPERA1
        End Function
#End Region

#Region "getCBSS_AcctLineInfo Webmethod"

        <WebMethod(Description:="Get Account Line Level Profile from CBSPERA2")> _
        Public Function getCBSS_AcctLineInfo(ByVal strRegionId As String, ByVal strAcctNum As String) As AcctLineLevelInfo

            Dim objAcctLineInfo As AcctLineLevelInfo = New AcctLineLevelInfo
            Try
                Dim objERAAccess As CBSSERAAccess = New CBSSERAAccess(strRegionId)
                objAcctLineInfo = objERAAccess.getCBSS_AcctLineInfo(strRegionId, strAcctNum)
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getCBSS_CBSPERA2", ex.ToString())
                objAcctLineInfo.RequestStatus.strMessageId = "RMIEXPTN"
                objAcctLineInfo.RequestStatus.strMessageDescription = ex.ToString
            End Try
            Return objAcctLineInfo
        End Function
#End Region

#Region "getCBSS_CBSEZRA9 Webmethod"

        '<WebMethod()> _
        'Public Function getCBSS_CBSEZRA9(ByVal strRegionId As String, ByVal strAcctNum As String) As CBSEZRA9

        '    Dim objCBSEZRA9 As CBSEZRA9 = New CBSEZRA9
        '    Try
        '        Dim objERAAccess As CBSSERAAccess = New CBSSERAAccess(strRegionId)
        '        objCBSEZRA9 = objERAAccess.getCBSS_CBSEZRA9(strRegionId, strAcctNum)
        '    Catch ex As Exception
        '        LogErrorFile.WriteLog("RMICWWS-getCBSS_CBSEZRA9", ex.ToString())
        '        objCBSEZRA9.RequestStatus.strMessageId = "RMIEXPTN"
        '        objCBSEZRA9.RequestStatus.strMessageDescription = ex.ToString
        '    End Try
        '    Return objCBSEZRA9
        'End Function
#End Region

#Region "getCBSS_CBSPTRA9_CreditInfo Webmethod "
        <WebMethod(Description:="Get Credit Information from CBSPTRA9")> _
        Public Function getCBSS_CBSPTRA9_Full(ByVal strRegionId As String, ByVal strAcctNum As String, ByVal strReqType As String, ByVal strExtInput As String, ByVal strAppId As String, ByVal strGetOption As String) As XmlDocument

            Dim objAcctBalanceInfo As AcctBalanceInfo = New AcctBalanceInfo
            Dim xmlTRA9 As XmlDocument = New XmlDocument()

            Try
                Dim objERAAccess As CBSSERAAccess = New CBSSERAAccess(strRegionId)
                xmlTRA9 = objERAAccess.getCBSS_CBSPTRA9_Full(strRegionId, strAcctNum, strReqType, strExtInput, strAppId, strGetOption)
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getCBSS_CBSPTRA9_CreditInfo", ex.ToString())
                objAcctBalanceInfo.RequestStatus.strMessageId = "RMIEXPTN"
                objAcctBalanceInfo.RequestStatus.strMessageDescription = ex.ToString
            End Try
            Return xmlTRA9
        End Function
#End Region

#Region "getCBSS_CBSPTRA9_CreditInfo Webmethod "
        <WebMethod(Description:="Get Credit Information from CBSPTRA9")> _
        Public Function getCBSS_CBSPTRA9_CreditInfo(ByVal strRegionId As String, ByVal strAcctNum As String) As CBSPTRA9_CreditInfo

            Dim objCreditInfo As CBSPTRA9_CreditInfo = New CBSPTRA9_CreditInfo
            Try
                Dim objERAAccess As CBSSERAAccess = New CBSSERAAccess(strRegionId)
                objCreditInfo = objERAAccess.getCBSS_CBSPTRA9_CreditInfo(strRegionId, strAcctNum)
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getCBSS_CBSPTRA9_CreditInfo", ex.ToString())
                objCreditInfo.RequestStatus.strMessageId = "RMIEXPTN"
                objCreditInfo.RequestStatus.strMessageDescription = ex.ToString
            End Try
            Return objCreditInfo
        End Function
#End Region

#Region "getCBSS_CBSPTRA9_CustomerBalance Webmethod "
        <WebMethod(Description:="Get Balance Information from CBSPTRA9")> _
        Public Function getCBSS_CBSPTRA9_CustomerBalance(ByVal strRegionId As String, ByVal strAcctNum As String, ByVal strReqType As String, ByVal strExtInput As String, ByVal strAppId As String, ByVal strGetOption As String) As AcctBalanceInfo

            Dim objAcctBalanceInfo As AcctBalanceInfo = New AcctBalanceInfo

            Try
                Dim objERAAccess As CBSSERAAccess = New CBSSERAAccess(strRegionId)

                objAcctBalanceInfo = objERAAccess.getCBSS_CBSPTRA9_CustomerBalance(strRegionId, strAcctNum, strReqType, strExtInput, strAppId, strGetOption)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getCBSS_CBSPTRA9_CreditInfo", ex.ToString())
                objAcctBalanceInfo.RequestStatus.strMessageId = "RMIEXPTN"
                objAcctBalanceInfo.RequestStatus.strMessageDescription = ex.ToString
            End Try

            If objAcctBalanceInfo.arrLstBalanceDetails.Count = 0 Then
                objAcctBalanceInfo.RequestStatus.strMessageId = "NOTFOUND"
                objAcctBalanceInfo.RequestStatus.strMessageDescription = "No Results Returned for:" + strAcctNum + ":" + strReqType + ":" + strExtInput + ":" + strAppId + ":" + strGetOption
            End If

            Return objAcctBalanceInfo
        End Function
#End Region

        '--adjustment
#Region "getCBSS_CBSPTRA9_Adjustment Webmethod "
        <WebMethod(Description:="Get Balance Information from CBSPTRA9")> _
        Public Function getCBSS_CBSPTRA9_Adjustment(ByVal strRegionId As String, ByVal strAcctNum As String) As AdjustmentInfo

            'Dim objAcctBalanceInfo As AcctBalanceInfo = New AcctBalanceInfo
            Dim objAdjustmentInfo As AdjustmentInfo = New AdjustmentInfo

            Try
                Dim objERAAccess As CBSSERAAccess = New CBSSERAAccess(strRegionId)

                'objAcctBalanceInfo = objERAAccess.getCBSS_CBSPTRA9_CustomerBalance(strRegionId, strAcctNum)
                objAdjustmentInfo = objERAAccess.getCBSS_CBSPTRA9_Adjustment(strRegionId, strAcctNum)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getCBSS_CBSPTRA9_CreditInfo", ex.ToString())
                objAdjustmentInfo.RequestStatus.strMessageId = "RMIEXPTN"
                objAdjustmentInfo.RequestStatus.strMessageDescription = ex.ToString
            End Try

            Return objAdjustmentInfo
        End Function
#End Region

#Region "get uCSR Details"

        <WebMethod(Description:="Get uCSR Data ")> _
        Public Function getuCSRData(ByVal uCSRRequest As uCSR_DetailsInp) As uCSR_DetailsOut

            Dim uCSRDetailOut As uCSR_DetailsOut = New uCSR_DetailsOut

            Try

                Dim objuCSRData As TreatmentStatus = New TreatmentStatus("WEST")
                uCSRDetailOut = objuCSRData.getuCSRData(uCSRRequest)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-uCSR", ex.ToString())
                uCSRDetailOut.strStatus = "RMICWEXPTN"
            End Try
            Return uCSRDetailOut
        End Function
#End Region

#Region "get Account Relationship - uses uCSR GetAccountRelationships"

        <WebMethod(Description:="Get info from uCSR/NACR ")> _
        Public Function getAccountRelationships(ByVal strEastWestInd As String, ByVal strInputValue As String, ByVal strInputType As String, ByVal strBaseRegion As String) As GetAcctRelationship_Response

            Dim objGetAcctRelationship_Response As GetAcctRelationship_Response = New GetAcctRelationship_Response

            Try

                Dim objUCSRAccess As UCSRAccess = New UCSRAccess(strBaseRegion.Trim)
                objGetAcctRelationship_Response = objUCSRAccess.getAccountRelationships(strEastWestInd, strInputValue, strInputType)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getAccountRelationships", ex.ToString())

            End Try
            Return objGetAcctRelationship_Response
        End Function
#End Region

#Region "get Account RelationshipCOG - uses uCSR GetAccountRelationshipsCOG"

        <WebMethod(Description:="Get info from uCSR/NACR ")> _
        Public Function getAccountRelationshipsCOG(ByVal strRegionId As String, ByVal strEastWestInd As String, ByVal strInputValue As String, ByVal strInputType As String, ByVal intRequestid As String) As GetAcctRelationship_Response

            Dim objGetAcctRelationship_Response As GetAcctRelationship_Response = New GetAcctRelationship_Response

            Try

                Dim objUCSRAccess As UCSRAccess = New UCSRAccess(strRegionId.Trim)
                objGetAcctRelationship_Response = objUCSRAccess.getAccountRelationshipsCOG(strRegionId, strEastWestInd, strInputValue, strInputType, intRequestid)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getAccountRelationshipsCOG", ex.ToString())

            End Try
            Return objGetAcctRelationship_Response
        End Function
#End Region


#Region "getEOI_EOIFS010 Webmethod "

        <WebMethod(Description:="Get List of Pending Orders")> _
        Public Function getEOI_EOIFS010(ByVal strRegionId As String, ByVal strAcctNum As String) As EOIFS010

            Dim objEOIFS010 As EOIFS010 = New EOIFS010
            Try
                Dim objEOIAccess As EOIERAAccess = New EOIERAAccess(strRegionId)
                objEOIFS010 = objEOIAccess.getEOI_EOIFS010(strRegionId, strAcctNum)
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getEOI_EOIFS010", ex.ToString())
                objEOIFS010.RequestStatus.strMessageId = "RMIEXPTN"
                objEOIFS010.RequestStatus.strMessageDescription = ex.ToString
            End Try
            Return objEOIFS010
        End Function
#End Region



#Region "getAcctsForSBM Webmethod "

        <WebMethod(Description:="Get List of Account Numbers and BTN for an SBM")> _
        Public Function getAcctsForSBM(ByVal strRegionId As String, ByVal strAcctNum As String, ByVal strRshipCode As String) As SummaryBillDetails

            Dim objSBMList As SummaryBillDetails = New SummaryBillDetails
            Try
                Dim objERAAccess As CBSSERAAccess = New CBSSERAAccess(strRegionId)
                objSBMList = objERAAccess.getAcctsForSBM(strRegionId, strAcctNum, strRshipCode)
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getAcctsForSBM", ex.ToString())
                objSBMList.RequestStatus.strMessageId = "RMIEXPTN"
                objSBMList.RequestStatus.strMessageDescription = ex.ToString
            End Try
            Return objSBMList
        End Function
#End Region


#Region "getMessageResponse Webmethod "

        <WebMethod(Description:="Get Message Response from AAIS for the Request")> _
        Public Function getMessageResponse(ByVal strRegionId As String, ByVal strInpType As String, ByVal intRequestId As Long) As MessageResponse

            Dim MsgResp As MessageResponse = New MessageResponse
            Try
                Dim objAAIS As AAISAccess = New AAISAccess(strRegionId)
                MsgResp = objAAIS.getMessageResponse(strRegionId, strInpType, intRequestId)
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getMessageResponse", ex.ToString())
                MsgResp.RequestStatus.strMessageId = "RMIEXPTN"
                MsgResp.RequestStatus.strMessageDescription = ex.ToString
            End Try
            Return MsgResp
        End Function
#End Region

#Region "AAIS Starts"
#Region "SubmitMessageRequest"

        <WebMethod(Description:="SubmitMessageRequest ")> _
        Public Function SubmitMessageRequest(ByVal Request As MessageRequestInp) As MessageRequestOut
            Dim RequestOut As MessageRequestOut = New MessageRequestOut

            Try
                Dim objAAISAccess As AAISAccess = New AAISAccess(Request.strRegionId)
                RequestOut = objAAISAccess.submitMessageRequest(Request)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-SubMitMessageRequest", ex.ToString())
                RequestOut.RequestStatus.strMessageId = "RMIEXPTN"
                RequestOut.RequestStatus.strMessageDescription = ex.ToString
            End Try
            Return RequestOut
        End Function
#End Region

#Region "SubmitChildRequestForAAIS"
        <WebMethod(Description:="SubmitChildRequestForAAIS  - Send Multiple Child Requests To AAIS")> _
        <OperationContract()> _
        Public Function SubmitChildRequestForAAIS(ByVal strRegionId As String, ByVal arrLstAAISRequest As ArrayList, ByVal ReqType As AAISRequest) As String
            Dim strMsg As String = " "
            Try
                Dim objAAISAccess As AAISAccess = New AAISAccess(strRegionId)
                strMsg = objAAISAccess.SubmitChildRequestForAAIS(arrLstAAISRequest, ReqType)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-SubMitMessageRequest", ex.ToString())
                strMsg = ex.ToString
            End Try
            Return strMsg
        End Function
#End Region


#Region "SubmitRequestToAAISByAcct"
        <WebMethod(Description:="SubmitRequestToAAISByAcct  - Submit Request To AAIS By Acct Num")> _
        Public Function SubmitRequestToAAISByAcct(ByVal MsgInp As MessagePrcsParm) As StatusOfRequest
            Dim RequestStatus As StatusOfRequest = New StatusOfRequest
            Try
                Dim objAAISAccess As AAISAccess = New AAISAccess(MsgInp.Request.strRegionId)
                RequestStatus = objAAISAccess.ProcessAAISRequest(MsgInp)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-SubmitRequestToAAISByAcct", ex.ToString())
                RequestStatus.strMessageId = "RMIEXPTN"
                RequestStatus.strMessageDescription = ex.ToString
            End Try
            Return RequestStatus
        End Function
#End Region

#End Region

#Region "getAccountInfo Webmethod "

        <WebMethod(Description:="Get Account Info from RMICW Profile")> _
        Public Function getAccountInfo(ByVal strRegionId As String, ByVal strInpType As String, ByVal strAcctNum As String, ByVal strOrg As String) As AccountInfo

            Dim objAcctInfo As AccountInfo = New AccountInfo
            Try
                Dim objTrtStatus As TreatmentStatus = New TreatmentStatus(strRegionId)
                objAcctInfo = objTrtStatus.getAccountInfo(strRegionId, strInpType, strAcctNum, strOrg)
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getAccountInfo", ex.ToString())
                objAcctInfo.RequestStatus.strMessageId = "RMIEXPTN"
                objAcctInfo.RequestStatus.strMessageDescription = ex.ToString
            End Try
            Return objAcctInfo
        End Function
#End Region


#Region "get uCSR Account - uses uCSR GetAccount"

        <WebMethod(Description:="Get info from uCSR ")> _
        Public Function getCSRAccountData(ByVal strAcctnum As String, ByVal objSSPRqst As SSPRequestDetails) As CSRGetAccount.Account

            'Dim objGetAcctRelationship_Response As GetAcctRelationship_Response = New GetAcctRelationship_Response
            Dim objuCSRAccountData As CSRGetAccount.CSRGet = New CSRGetAccount.CSRGet
            Dim objUSCRGetAccount As CSRGetAccount.Account = New CSRGetAccount.Account
            Dim getURL As wsGETURL = New wsGETURL
            Dim posturl As String = ""
            Dim dtParm As DataTable
            Dim drParm As DataRow
            Dim strName As String = ""
            Dim strvalue As String = ""


            Try

                'ITW Enable - SS 100907
                Dim RequestContext As SoapContext
                RequestContext = objuCSRAccountData.RequestSoapContext
                objuCSRAccountData.Proxy = New WebProxy
                RequestContext.Security.Tokens.Clear()
                Dim unt As Tokens.UsernameToken = New Tokens.UsernameToken("RMW", "rmicw05", Tokens.PasswordOption.SendPlainText)
                RequestContext.Security.Tokens.Add(unt)
                RequestContext.Security.MustUnderstand = False
                posturl = getURL.getSSPURL(objSSPRqst.strRegionId.Trim(), "uCSRGETURL")

                objuCSRAccountData.Url = posturl.Trim()
                objuCSRAccountData.Timeout = 60000
                objuCSRAccountData.RequestSoapContext.Addressing.MustUnderstand = False
                objUSCRGetAccount = objuCSRAccountData.GetAccount(strAcctnum)

                'ITW Enable

                'posturl = getURL.getSSPURL(objSSPRqst.strRegionId.Trim(), "uCSRGETURL")
                'objuCSRAccountData.Url = posturl.Trim()
                'objUSCRGetAccount = objuCSRAccountData.GetAccount(strAcctnum)
                '*****************************************************************

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getCSRAccountData", ex.ToString())
                objUSCRGetAccount = Nothing
            End Try
            Return objUSCRGetAccount
        End Function
#End Region


#Region "get SSP ID - To Get SSP Account ID"
        <WebMethod(Description:="Get SSP Account ID from CSR")> _
        <OperationContract()> _
        Public Function GetGenIndexByAcctNum(ByVal strBBNum As String, ByVal objSSPRqst As SSPRequestDetails) As String
            Dim strSSPIDXML As String = ""
            Dim strSSPID As String = ""
            Dim strIndexType As String = "SA"
            Dim objuCSRAccountData As CSRGetAccount.CSRGet = New CSRGetAccount.CSRGet
            Dim getURL As wsGETURL = New wsGETURL
            Dim posturl As String = ""
            'Dim dtParm As DataTable
            'Dim drParm As DataRow
            'Dim strName As String = ""
            Dim strvalue As String = ""

            Try

                'ITW Enable - SS 100907
                Dim RequestContext As SoapContext
                RequestContext = objuCSRAccountData.RequestSoapContext
                objuCSRAccountData.Proxy = New WebProxy
                RequestContext.Security.Tokens.Clear()
                Dim unt As Tokens.UsernameToken = New Tokens.UsernameToken("RMW", "rmicw05", Tokens.PasswordOption.SendPlainText)
                RequestContext.Security.Tokens.Add(unt)
                RequestContext.Security.MustUnderstand = False
                'posturl = getURL.getSSPURL(objSSPRqst.strRegionId.Trim(), "uCSRGETURL")
                'strvalue = MyBase.WSDataAccessObj.usp_GetControlParmByName("ControlWEST", "UCSRURL")
                posturl = getURL.getSSPURL(objSSPRqst.strRegionId.Trim(), "uCSRGETURL")

                'objuCSRAccountData.Url = strvalue.Trim()
                objuCSRAccountData.Url = posturl.Trim()
                objuCSRAccountData.Timeout = 90000
                objuCSRAccountData.RequestSoapContext.Addressing.MustUnderstand = False
                strSSPIDXML = objuCSRAccountData.GetGenIndexByAcctNum(strBBNum.Trim(), strIndexType)
                If (strSSPIDXML.IndexOf("Generic Index Not Found in NACR for Account Number") >= 0) Then
                    strSSPID = ""
                Else
                    strSSPID = strSSPIDXML.Trim()
                End If


                'ITW Enable        
                '*****************************************************************   
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-GetGenIndexByAcctNum:strBBNum" + strBBNum, ex.ToString())
                strSSPID = ""
            End Try
            Return strSSPID.Trim()


        End Function
#End Region




#Region "get FIOS Info - uses FIOS Info"

        <WebMethod(Description:="Get info from uCSR For FIOS")> _
        Public Function getFIOSData(ByVal getFIOSRequest As getFIOSDataInputDetails) As sspResponseDetails

            Dim objSSPRp As sspResponseDetails = New sspResponseDetails
            Dim objclsIvappMain As clsIvappMain = New clsIvappMain





            Select Case getFIOSRequest.strSSPActn.Trim()
                Case "IVAPP", "B-ALL", "U-ALL", "B-INTL", "U-INTL"
                    objSSPRp = RequestIssueToIVAPP(getFIOSRequest)
                    Return objSSPRp
                Case "CPPO"
                    objSSPRp = objclsIvappMain.fnPutSSPPortOutRequest(getFIOSRequest)

                    Return objSSPRp

            End Select



            Dim getURL As wsGETURL = New wsGETURL


            Dim arrSNP() As String = Nothing
            Dim arrDSC() As String = Nothing
            Dim arrRST() As String = Nothing
            Dim separator As Char = ","

            'Tech Refresh 2015
            Try
                'If (strSNPInd = Nothing) Or strSNPInd = "" Then
                '    strSNPInd = getURL.getSSPURL(getFIOSRequest.strRegionId.Trim(), "FIOSSNP")
                'End If

                'If (strRSTInd = Nothing) Or strRSTInd = "" Then
                '    strRSTInd = getURL.getSSPURL(getFIOSRequest.strRegionId.Trim(), "FIOSRST")
                'End If
                'If (strDSCInd = Nothing) Or strDSCInd = "" Then
                '    strDSCInd = getURL.getSSPURL(getFIOSRequest.strRegionId.Trim(), "FIOSDSC")
                'End If
                strSNPInd = "TRUE,TRUE,TRUE,999,TRUE"
                strRSTInd = "TRUE,TRUE,TRUE,999,TRUE"
                strDSCInd = "TRUE,TRUE,TRUE,999,TRUE"

                arrSNP = strSNPInd.Split(separator)
                arrRST = strRSTInd.Split(separator)
                arrDSC = strDSCInd.Split(separator)



            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getFIOSData-Chk parm FIOSSNP/FIOSRST/FIOSDSC/strAcctnum/strOrg/strActn:" + getFIOSRequest.strAcctNum + "/" + getFIOSRequest.strOrg + "/" + getFIOSRequest.strActn, ex.ToString())

            End Try

            'If (getURL.getSSPURL(getFIOSRequest.strRegionId.Trim(), "SSPBACKUP").Trim() = "TRUE") Then
            '    blnSSPBackup = True
            'End If


            'DOMAIN Value 
            'ACCTLVL/SVCLVL
            'blnBackUP - Thru EA
            'For DVOL both Actn and ACCTLVL need to be checked 

            'Tech Refresh 2015
            'strAcctLvlOrder = getURL.getSSPURL(getFIOSRequest.strRegionId.Trim(), "SSPORDERTYPE").Trim()

            strAcctLvlOrder = "SVCLVL"



            Dim objclsFIOS As clsFIOS = New clsFIOS
            objclsFIOS.getFIOSData(getFIOSRequest, arrSNP, arrRST, arrDSC, blnSSPBackup, strAcctLvlOrder)


            Return objSSPRp


        End Function
#End Region

        Public Sub getFIOSDataDirect()
            'Dim getURL As wsGETURL = New wsGETURL


            'Dim arrSNP() As String = Nothing
            'Dim arrDSC() As String = Nothing
            'Dim arrRST() As String = Nothing
            'Dim separator As Char = ","

            'Try
            '    If (strSNPInd = Nothing) Or strSNPInd = "" Then
            '        strSNPInd = getURL.getSSPURL(objFIOS.strRegionId.Trim(), "FIOSSNP")
            '    End If

            '    If (strRSTInd = Nothing) Or strRSTInd = "" Then
            '        strRSTInd = getURL.getSSPURL(objFIOS.strRegionId.Trim(), "FIOSRST")
            '    End If
            '    If (strDSCInd = Nothing) Or strDSCInd = "" Then
            '        strDSCInd = getURL.getSSPURL(objFIOS.strRegionId.Trim(), "FIOSDSC")
            '    End If


            '    arrSNP = strSNPInd.Split(separator)
            '    arrRST = strRSTInd.Split(separator)
            '    arrDSC = strDSCInd.Split(separator)



            'Catch ex As Exception
            '    LogErrorFile.WriteLog("RMICWWS-getFIOSData-Chk parm FIOSSNP/FIOSRST/FIOSDSC/strAcctnum/strOrg/strActn:" + objFIOS.strAcctNum + "/" + objFIOS.strOrg + "/" + objFIOS.strActn, ex.ToString())

            'End Try

            'If (getURL.getSSPURL(objFIOS.strRegionId.Trim(), "SSPBACKUP").Trim() = "TRUE") Then
            '    blnSSPBackup = True
            'End If


            ''DOMAIN Value 
            ''ACCTLVL/SVCLVL
            ''blnBackUP - Thru EA
            ''For DVOL both Actn and ACCTLVL need to be checked 


            'strAcctLvlOrder = getURL.getSSPURL(objFIOS.strRegionId.Trim(), "SSPORDERTYPE").Trim()




            'Dim objclsFIOS As clsFIOS = New clsFIOS
            'objclsFIOS.getFIOSData(objFIOS, arrSNP, arrRST, arrDSC, blnSSPBackup, strAcctLvlOrder)



        End Sub

#Region "Intialize"
        Public Sub Intialize(ByVal objSSPRqst As SSPRequestDetails, ByVal objAcctRelation As GetAcctRelation)
            objSSPRqst.strVideoCAN = objAcctRelation.strBBANNum
            objSSPRqst.strProfileCAN = objAcctRelation.strPACNNum
            objSSPRqst.strSSPBAN = objAcctRelation.strSSPBANNum
            If objSSPRqst.strStatusCd = "SE" Or objSSPRqst.strStatusCd = "CP" Or objSSPRqst.strStatusCd = "VC" Then
                objSSPRqst.strReturnCd = objSSPRqst.strReturnCd
                objSSPRqst.strNotationCd = objSSPRqst.strNotationCd

            Else
                objSSPRqst.strStatusCd = objAcctRelation.strStatuscd
                objSSPRqst.strReturnCd = objAcctRelation.strReturncd
            End If


            insertValiationData(objSSPRqst)


        End Sub
#End Region

#Region "IntializeInput"
        Public Sub IntializeInput(ByVal objSSPRqst As SSPRequestDetails, ByVal getFIOSRequest As getFIOSDataInputDetails)


            objSSPRqst.intRequestId = getFIOSRequest.intRequestId
            objSSPRqst.strSSPAccountID = getFIOSRequest.strSSPAccountID
            objSSPRqst.intSSPMasterId = getFIOSRequest.intSSPMasterId
            objSSPRqst.intSSPChildRequestId = getFIOSRequest.intSSPChildRequestId
            objSSPRqst.strAcctNum = getFIOSRequest.strAcctNum
            objSSPRqst.strVideoCAN = getFIOSRequest.strVideoCAN
            objSSPRqst.strProfileCAN = getFIOSRequest.strProfileCAN
            objSSPRqst.strSSPBAN = getFIOSRequest.strSSPBAN
            objSSPRqst.strWTN = getFIOSRequest.strWTN
            objSSPRqst.strOrg = getFIOSRequest.strOrg
            objSSPRqst.strActn = getFIOSRequest.strActn
            objSSPRqst.strSSPActn = getFIOSRequest.strSSPActn
            objSSPRqst.strDestSystem = getFIOSRequest.strDestSystem
            objSSPRqst.strStatusCd = getFIOSRequest.strStatusCd
            objSSPRqst.strOriginationId = getFIOSRequest.strOriginationId
            objSSPRqst.strReturnCd = getFIOSRequest.strReturnCd
            objSSPRqst.strNotationCd = getFIOSRequest.strDestSystem
            objSSPRqst.strEnvironment = getFIOSRequest.strEnvironment
            objSSPRqst.strUpdtId = "getFIOS"
            objSSPRqst.strResultId = getFIOSRequest.strResultId
            objSSPRqst.strResultDesc = getFIOSRequest.strResultDesc
            objSSPRqst.strRegionId = getFIOSRequest.strRegionId
            objSSPRqst.strExtendedParm = getFIOSRequest.strExtendedParm

            Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(getFIOSRequest.strRegionId.Trim())
            Dim ds As DataSet

            Try 'WR57588
                ds = ObjDataAccess.usp_RMI_getOrgByOrg(getFIOSRequest.strOrg.Trim())
                objSSPRqst.strOrgInd = ds.Tables(0).Rows(0).Item("strOrgInd").ToString()
                objSSPRqst.strCustGroup = ds.Tables(0).Rows(0).Item("strCustomerGroup").ToString()

            Catch ex As Exception
                objSSPRqst.strOrgInd = "F"
                objSSPRqst.strCustGroup = "WEST"
                LogErrorFile.WriteLog("WEBSVC-usp_RMI_getOrgByOrg", ex.ToString() + "/" + objSSPRqst.intRequestId.ToString() + "/" + objSSPRqst.strOrg)

            End Try

            If (getFIOSRequest.strRegionId.Trim() = "MDVW") Then
                Try
                    Dim intFrmt As Integer
                    intFrmt = CType(objSSPRqst.strAcctNum, Integer)
                    objSSPRqst.strAcctNum = String.Format("{0:000000000000}", intFrmt)
                    getFIOSRequest.strAcctNum = objSSPRqst.strAcctNum
                Catch exfrmt As Exception
                    objSSPRqst.strAcctNum = objSSPRqst.strAcctNum
                End Try

            End If


        End Sub
#End Region

#Region "FindBillMethod"

        Public Function FindBillMethod(ByVal objUSCRGetAccount As CSRGetAccount.Account, ByVal objAcctRelation As GetAcctRelation, ByVal objSSPRqst As SSPRequestDetails) As CSRGetAccount.Account
            Dim strBillMethod As String = ""
            Try
                objUSCRGetAccount = getCSRAccountData(objAcctRelation.strBBANNum.Trim(), objSSPRqst)
                If objUSCRGetAccount Is Nothing Then
                    'If objUSCRGetAccount.billingInfo Is Nothing Then
                    strBillMethod = ""
                    'End If
                ElseIf objUSCRGetAccount.billingInfo Is Nothing Then
                    strBillMethod = ""
                Else
                    strBillMethod = objUSCRGetAccount.billingInfo.billMethod.ToString()
                End If
                objUSCRGetAccount.billingInfo.billMethod = strBillMethod.Trim()
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getAccountRelationships", ex.ToString())
            End Try
            Return objUSCRGetAccount

        End Function
#End Region

#Region "insertValiationData"
        Public Function insertValiationData(ByVal objSSPRqst As SSPRequestDetails) As String
            'MDVW 9 Digit Format SS-082807

            Dim intFrmtAct As Integer

            If objSSPRqst.strRegionId.Trim() = "MDVW" Then
                Try

                    intFrmtAct = CType(objSSPRqst.strAcctNum, Integer)
                    objSSPRqst.strAcctNum = String.Format("{0:000000000}", intFrmtAct)

                Catch exfrmt As Exception
                    objSSPRqst.strAcctNum = objSSPRqst.strAcctNum
                    LogErrorFile.WriteLog("Error", exfrmt.ToString())
                End Try
            End If



            Dim strXML As String = ""
            Dim xmlSer As XmlSerializer = New XmlSerializer(GetType(SSPRequestDetails))
            strXML = CommonLibrary.GeneralRoutine.SerializeTxn(xmlSer, objSSPRqst)
            Dim objFIOSData As TreatmentStatus = New TreatmentStatus(objSSPRqst.strRegionId)
            objFIOSData.insertFIOSData(objSSPRqst.strRegionId, strXML.Trim(), objSSPRqst.strExtendedParm, objSSPRqst.strEnvironment.Trim())


        End Function
#End Region

#Region "fnValidBillMethod"
        Public Function fnValidBillMethod(ByVal objSSPRqst As SSPRequestDetails, ByVal strBillMethod As String) As Boolean
            Dim blnBillMethod As Boolean = False

            If (objSSPRqst.strOrg.Trim().StartsWith("VD")) Then 'A
                blnBillMethod = True
            Else 'A
                If strBillMethod.Trim() <> "V" Then 'A
                    blnBillMethod = False
                Else 'A
                    If strBillMethod.Trim() = "V" Then 'A
                        blnBillMethod = True
                    End If 'A
                End If 'A
            End If 'A

            Return blnBillMethod



        End Function
#End Region
#Region "fnValidVidoPID"
        Public Function fnValidVidoPID(ByVal objSSPRqst As SSPRequestDetails, ByVal objUSCRGetAccount As CSRGetAccount.Account) As Boolean
            Dim blnVideo As Boolean = False
            Dim eachSvcs As CSRGetAccount.AccountServiceInstance
            Dim eachPrducts As CSRGetAccount.AccountServiceInstanceProduct
            Dim strProdId As String = ""
            Dim arrPrducts As Array
            Dim blnProviderID As Boolean = False
            For i As Integer = 0 To objUSCRGetAccount.serviceInstances.Length - 1
                eachSvcs = objUSCRGetAccount.serviceInstances(i)
                'For Each eachSvcs In objUSCRGetAccount.serviceInstances
                arrPrducts = eachSvcs.products
                For j As Integer = 0 To arrPrducts.Length - 1
                    eachPrducts = arrPrducts(j)
                    'For Each eachPrducts In arrPrducts
                    strProdId = eachPrducts.ProductServiceProviderId.Trim()
                    If (strProdId = "09300") Or (strProdId = "09301") Then 'B
                        blnVideo = True
                        blnProviderID = True
                    End If 'B
                Next
            Next
            If (blnVideo = False) Then 'B
                blnProviderID = False
            End If 'B
            Return blnVideo
        End Function
#End Region



#Region "FindAccountRelationShip"
        Public Function FindAccountRelationShip(ByVal objAcctRelation As GetAcctRelation, ByVal GetAcctReq As GetAcctRelationship_Response.RelationshipDetails) As GetAcctRelation
            Select Case GetAcctReq.strType
                Case "BROADBAND"
                    objAcctRelation.strBBANNum = GetAcctReq.strAcctNum.Trim()
                    objAcctRelation.strBBNCompany = GetAcctReq.strCompany.Trim()
                    objAcctRelation.strBBNState = GetAcctReq.strState.Trim()
                    objAcctRelation.dtmBBNDate = GetAcctReq.dtmEffectiveDate
                    objAcctRelation.strBBNStatus = GetAcctReq.strStatus.Trim()
                    If objAcctRelation.strBBANNum = "" Or objAcctRelation.strBBANNum = Nothing Then
                        objAcctRelation.strStatuscd = "VD"
                        objAcctRelation.strReturncd = "NOBBAN"
                        objAcctRelation.blnBROADBAND = False
                    Else
                        objAcctRelation.blnBROADBAND = True
                    End If
                Case "VOICE"
                    objAcctRelation.strVOICENum = GetAcctReq.strAcctNum.Trim()
                    objAcctRelation.strVOICECompany = GetAcctReq.strCompany.Trim()
                    objAcctRelation.strVOICEState = GetAcctReq.strState.Trim()
                    objAcctRelation.dtmVOICEDate = GetAcctReq.dtmEffectiveDate
                    objAcctRelation.strVOICEStatus = GetAcctReq.strStatus.Trim()
                    If objAcctRelation.strVOICENum = "" Or objAcctRelation.strVOICENum = Nothing Then
                        objAcctRelation.strStatuscd = "VD"
                        objAcctRelation.strReturncd = "NOVOICE"
                        objAcctRelation.blnVOICE = False
                    End If
                Case "SSPBAN"
                    objAcctRelation.strSSPBANNum = GetAcctReq.strAcctNum.Trim()
                    objAcctRelation.strSSPBANCompany = GetAcctReq.strCompany.Trim()
                    objAcctRelation.strSSPBANState = GetAcctReq.strState.Trim()
                    objAcctRelation.dtmSSPBANDate = GetAcctReq.dtmEffectiveDate
                    objAcctRelation.strSSPBANState = GetAcctReq.strStatus.Trim()
                    If objAcctRelation.strSSPBANNum = "" Or objAcctRelation.strSSPBANNum = Nothing Then
                        objAcctRelation.strStatuscd = "VD"
                        objAcctRelation.strReturncd = "NOSSPBAN"
                        objAcctRelation.blnSSPBAN = False
                    Else
                        objAcctRelation.blnSSPBAN = True
                    End If
                Case "PROFILE"
                    objAcctRelation.strPACNNum = GetAcctReq.strAcctNum.Trim()
                    objAcctRelation.strPACNCompany = GetAcctReq.strCompany.Trim()
                    objAcctRelation.strPACNState = GetAcctReq.strState.Trim()
                    objAcctRelation.dtmPACNDate = GetAcctReq.dtmEffectiveDate
                    objAcctRelation.strPACNStatus = GetAcctReq.strStatus.Trim()
                    If objAcctRelation.strPACNNum = "" Or objAcctRelation.strPACNNum = Nothing Then
                        objAcctRelation.strStatuscd = "VD"
                        objAcctRelation.strReturncd = "NOPCAN"
                        objAcctRelation.blnPCAN = False
                    End If
            End Select
            Return objAcctRelation
        End Function
#End Region

#Region "get STRA XBCLSP05 sproc details Webmethod "

        <WebMethod(Description:="Get List of Pending Orders in STRA")> _
        Public Function get_XBCLSP05(ByVal strRegionId As String, ByVal strAcctNum As String, ByVal strEnv As String, ByVal strSVRQ As String, ByVal intReadKey As Integer) As XBCLSP05

            Dim objXBCLSP05 As XBCLSP05 = New XBCLSP05
            Try
                Dim objSTRAAccess As STRAdb2Access = New STRAdb2Access(strRegionId)

                objXBCLSP05 = objSTRAAccess.get_XBCLSP05(strRegionId, strAcctNum, strEnv, strSVRQ, intReadKey)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getEOI_EOIFS010", ex.ToString())
                objXBCLSP05.RequestStatus.strMessageId = "RMIEXPTN"
                objXBCLSP05.RequestStatus.strMessageDescription = ex.ToString
            End Try
            Return objXBCLSP05
        End Function
#End Region

#Region "get XBCLSPA3 details from ICollect Webmethod for RMVP-MDVW and WEbPortal"

        <WebMethod(Description:="Get Balances from iCollect WebService for RMVP_MDVW")> _
        Public Function get_XBCLSPA3_ICollect(ByVal strRegionId As String, ByVal strAcctountNum As String) As XBCLSPA5

            Dim objXBCLSPA3 As XBCLSPA5 = New XBCLSPA5
            Try

                Dim objDB2Access As MDVW_RMVP_Strata = New MDVW_RMVP_Strata(strRegionId)
                objXBCLSPA3 = objDB2Access.get_XBCLSPA3_Icollect(strRegionId, strAcctountNum)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-ICollect[SPA3-MDVW]", ex.ToString())
                objXBCLSPA3.RequestStatus.strMessageId = "RMIEXPTN"
                objXBCLSPA3.RequestStatus.strMessageDescription = ex.ToString
            End Try
            Return objXBCLSPA3
        End Function
#End Region


#Region "get XBCLSPA5 sproc details Webmethod for RMVP-MDVW data"

        <WebMethod(Description:="Get Balances from XBCLSPA5 for RMVP_MDVW")> _
        Public Function get_XBCLSPA5(ByVal strRegionId As String, ByVal strAcctountNum As String, ByVal strEnv As String, ByVal intReadkey As Integer) As XBCLSPA5

            Dim objXBCLSPA5 As XBCLSPA5 = New XBCLSPA5
            Try
                Dim objDB2Access As MDVW_RMVP_Data = New MDVW_RMVP_Data(strRegionId)
                'Dim RMVPdb2Access As New MDVW_RMVPdb2Access
                objXBCLSPA5 = objDB2Access.get_XBCLSPA5(strRegionId, strAcctountNum, strEnv, intReadkey)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getEOI_EOIFS010", ex.ToString())
                objXBCLSPA5.RequestStatus.strMessageId = "RMIEXPTN"
                objXBCLSPA5.RequestStatus.strMessageDescription = ex.ToString
            End Try
            Return objXBCLSPA5
        End Function
#End Region


#Region "STRATA RESPONSE"

        <WebMethod(Description:="GET STRATA RESPONSE")> _
        Public Function GetStrataResponse(ByVal strAccoutNumber As String, ByVal strEventType As String, ByVal strAppId As String) As XmlDocument

            Dim objresp As New IcollectSTRATAService.StrataResponse
            Dim strataclient As New IcollectSTRATAService.SDEServiceClient()
            If strAppId.Trim() = "" Then
                strAppId = "RMICW"
            End If
            objresp = strataclient.PA_STRATA_Communicator(strAccoutNumber, strEventType, strAppId)
            Dim strXML As String = ""
            Dim xmlDoc As XmlDocument = New XmlDocument
            Try

                Dim xmlSer As XmlSerializer = New XmlSerializer(GetType(IcollectSTRATAService.StrataResponse))
                strXML = CommonLibrary.GeneralRoutine.SerializeTxn(xmlSer, objresp)

                xmlDoc.LoadXml(strXML)

                xmlDoc.LoadXml(System.Text.RegularExpressions.Regex.Replace(xmlDoc.OuterXml, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline)))
            Catch ex As Exception
                LogErrorFile.WriteLog("STRATARESPONSE", strAccoutNumber + ex.ToString())

            End Try
            'Return objresp
            Return xmlDoc

        End Function
#End Region

#Region "STRATA REAL TIME NOTIFICATION"

        <WebMethod(Description:="GET STRATA REAL TIME NOTIFICATION")> _
        Public Function GetStrataRealTimeNotification(ByVal strAcctNum As String, ByVal StrataRealTimeNotification As StrataRealTimeNotification, ByVal strRegionId As String) As RMICWMessage

            Dim objRMICWMessage As RMICWMessage = New RMICWMessage()
            Dim objStrataRealTimeNotification As StrataRealTimeNotification = New StrataRealTimeNotification()

            Dim xmlSer As XmlSerializer = New XmlSerializer(GetType(StrataRealTimeNotification))
            Dim test As String = ""
            Try
                Dim strStrataOutcome As String = ""
                Dim xmlDoc As XmlDocument = New XmlDocument
                strStrataOutcome = CommonLibrary.GeneralRoutine.SerializeTxn(xmlSer, StrataRealTimeNotification)
                test = strStrataOutcome
                Dim WSDataAccessObj As WSDataAccessGeneric = New WSDataAccessGeneric(strRegionId)
                'LogErrorFile.WriteLog("AcctNum:", strAcctNum)
                'LogErrorFile.WriteLog("strStrataOutcome:", strStrataOutcome)
                'LogErrorFile.WriteLog("strRegionId:", strRegionId)

                Dim dsStrataRealTime As DataSet = WSDataAccessObj.usp_UpdateSTRATARealTimeNotification(strAcctNum, strStrataOutcome, strRegionId)
                objRMICWMessage.messageDesc = ""
                objRMICWMessage.messageCode = "Success"

            Catch ex As Exception
                LogErrorFile.WriteLog("STRATAREALTIMENOTIFICATION", strAcctNum + ex.ToString())
                objRMICWMessage.messageDesc = ex.ToString()
                objRMICWMessage.messageCode = "RMIEXCPTN"
                'LogErrorFile.WriteLog("AcctNum:", strAcctNum)
                'LogErrorFile.WriteLog("strStrataOutcome:", test)
                'LogErrorFile.WriteLog("strRegionId:", strRegionId)

            End Try

            Return objRMICWMessage

        End Function
#End Region


#Region "Treatment Details Webmethod for RMVP"
        <WebMethod(Description:="Get Treatment Details")> _
        <OperationContract()> _
        Public Function getTreatmentDetails(ByVal strRegionId As String, ByVal strOrg As String, ByVal InpRequestType As String, ByVal strAppId As String, ByVal strAcctNum As String) As TD_Response

            Try

                Dim objTDResp As TD_Response = New TD_Response

                Dim objTDRespStatus As TD_Response.TD_Response_Status = New TD_Response.TD_Response_Status
                objTDResp.ResponseStatus = objTDRespStatus



                If (Not WSCommonClasses.CheckRegionType(strRegionId.Trim)) Then
                    objTDRespStatus.strMessageId = "RMWTS001"
                    objTDRespStatus.strMessageDescription = "Invalid RegionId Specified"
                    Return objTDResp
                End If



                Dim obj As TreatmentStatus = New TreatmentStatus(strRegionId.Trim)
                Dim objRequest As TD_Request = New TD_Request

                objRequest.strAcctNum = strAcctNum
                objRequest.strApplicationId = strAppId
                objRequest.strInputRequestType = InpRequestType
                objRequest.strOrg = strOrg
                objRequest.strRegionId = strRegionId

                objTDResp = obj.getTreatmentDetails(objRequest)

                Try
                    Dim strXML As String = ""
                    Dim xmlSer As XmlSerializer = New XmlSerializer(GetType(TD_Response))
                    strXML = CommonLibrary.GeneralRoutine.SerializeTxn(xmlSer, objTDResp)

                    Dim WSDataAccessObj As WSDataAccessGeneric = New WSDataAccessGeneric(objRequest.strRegionId)
                    Dim dsPS As DataSet = WSDataAccessObj.usp_InsertBalanceResponse(objRequest.strAcctNum, objRequest.strRegionId, objRequest.strApplicationId, strXML.Trim())

                Catch exInsert As Exception
                    LogErrorFile.WriteLog("RMICWWS - getTreatmentDetails", strAcctNum + ";" + strAppId + ";" + InpRequestType + ";" + strOrg + ";" + strRegionId + ";" + exInsert.ToString())

                End Try

                Return objTDResp

                'Return obj.getTreatmentDetails(objRequest)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS - getTreatmentDetails", strAcctNum + ";" + strAppId + ";" + InpRequestType + ";" + strOrg + ";" + strRegionId + ";" + ex.ToString())
            End Try
        End Function
#End Region

#Region "getCBSS_CBSPCFA1_BalanceInfo Webmethod "

        <WebMethod(Description:="Get Customer Balance Information from CBSPCFA1")> _
        Public Function getCBSS_CBSPCFA1_BalanceInfo(ByVal strRegionId As String, ByVal strAcctNum As String) As CFIBalanceInfo

            Dim objBalanceInfo As CFIBalanceInfo = New CFIBalanceInfo
            'CBSPCFA1
            Try
                Dim objERAAccess As CBSSERAAccess = New CBSSERAAccess(strRegionId)
                objBalanceInfo = objERAAccess.getCBSS_CBSPCFA1_BalanceInfo(strRegionId, strAcctNum)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getCBSS_CBSPCFA1_BalanceInfo", ex.ToString())
                objBalanceInfo.RequestStatus.strMessageId = "RMIEXPTN"
                objBalanceInfo.RequestStatus.strMessageDescription = ex.ToString
            End Try
            Return objBalanceInfo
        End Function
#End Region

#Region "getCBSS_CBSPCFA1_BalanceInfoEast Webmethod "

        <WebMethod(Description:="Get Customer Balance Information from East CFI - CBSPCFA1")> _
        Public Function getCBSS_CBSPCFA1_BalanceInfoEast(ByVal objCFIInput As CFIBalanceInput) As CFIBalanceInfoAccum

            Dim objBalanceInfo As CFIBalanceInfoAccum = New CFIBalanceInfoAccum
            'CBSPCFA1
            Try
                objCFIInput.strRegioncd = UCase(objCFIInput.strRegioncd)
                Dim objERAAccess As CBSSERAAccess = New CBSSERAAccess(objCFIInput.strRegioncd)
                objBalanceInfo = objERAAccess.getCBSS_CBSPCFA1_BalanceInfoEast(objCFIInput)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getCBSS_CBSPCFA1_BalanceInfo", ex.ToString())
                objBalanceInfo.RequestStatus.strMessageId = "RMIEXPTN"
                objBalanceInfo.RequestStatus.strMessageDescription = ex.ToString
            End Try
            Return objBalanceInfo
        End Function
#End Region

#Region "getCBSS_CBSPCFA3  Webmethod Test"
        'CBSPCFA3 - Calculate Customer Balances

        <WebMethod(Description:="Get Customer Balance Information from CBSPCFA3")> _
        Public Function getCBSS_CBSPCFA3(ByVal strRegionId As String, ByVal strAcctnum As String, ByVal strXMLLog As String) As XmlDocument

            'Dim objCreditInfo As CBSPTRA9_CreditInfo = New CBSPTRA9_CreditInfo
            Dim objBalanceInfo As CFIBalanceInfo = New CFIBalanceInfo
            Dim xmlCFA3 As XmlDocument = New XmlDocument()
            'CBSPCFA3
            Try
                Dim objERAAccess As CBSSERAAccess = New CBSSERAAccess(strRegionId)
                xmlCFA3 = objERAAccess.getCBSS_CBSPCFA3(strRegionId, strAcctnum, strXMLLog)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getCBSS_CBSPCFA3_BalanceInfo", ex.ToString())
                objBalanceInfo.RequestStatus.strMessageId = "RMIEXPTN"
                objBalanceInfo.RequestStatus.strMessageDescription = ex.ToString
            End Try
            Return xmlCFA3
        End Function
#End Region

#Region "FIOS Treatment Status Test Webmethod"
        <WebMethod(MessageName:="Get Treatment Status FIOS Vision")> _
        Public Function getTreatmentStatusFIOS(ByVal VisionCustomerId As String, ByVal VisionAccountId As String, ByVal strRegionId As String) As TSFIOS_Response

            Try
                Dim obj As TreatmentStatus = New TreatmentStatus(strRegionId.Trim)
                Dim objRequest As TS_Request = New TS_Request
                If strRegionId = "VISION" Then
                    objRequest.strAcctNum = CommonFunctions.getAcctNumValue("", VisionCustomerId, VisionAccountId)
                Else
                    objRequest.strAcctNum = VisionCustomerId
                End If


                objRequest.strRegionId = strRegionId

                Return obj.getTreatmentStatusFIOS(objRequest)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWebServices", ex.ToString())
            End Try
        End Function
#End Region

#Region "FIOS Treatment Status Test Webmethod"
        <WebMethod(Description:="Get Treatment Status FIOS")> _
        Public Function getTreatmentStatusFIOS(ByVal strRegionId As String, ByVal strAcctNum As String) As TSFIOS_Response

            Try


                If strAcctNum.Trim() = "0001" Then
                    strAcctNum = strRegionId.Trim() + strAcctNum.Trim()
                    strRegionId = "VISION"
                End If

                Dim obj As TreatmentStatus = New TreatmentStatus(strRegionId.Trim)
                Dim objRequest As TS_Request = New TS_Request


                objRequest.strAcctNum = strAcctNum
                objRequest.strRegionId = strRegionId

                Return obj.getTreatmentStatusFIOS(objRequest)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWebServices", ex.ToString())
            End Try
        End Function
#End Region


#Region "issue IVAPP Request "

        <WebMethod(Description:="Issue Request to IVAPP")> _
        <OperationContract()> _
        Public Function RequestIssueToIVAPP(ByVal getFIOSRequest As getFIOSDataInputDetails) As sspResponseDetails
            ' Public Function RequestIssueToIVAPP(ByVal objSSPRqst As SSPRequestDetails) As sspResponseDetails

            Dim blnSucess As Boolean = False
            Dim strIvappInputXml As String = ""
            Dim objAcctLineInfo As AcctLineLevelInfo = New AcctLineLevelInfo
            Dim objAddBlockVoiceOrder As AddBlockVoiceOrder = New AddBlockVoiceOrder()
            Dim xmlDoc As XmlDocument
            Dim objSSPResp As sspResponseDetails = New sspResponseDetails
            'LogErrorFile.WriteLog("objSSPRqst.intRequestId", objSSPRqst.intRequestId + objSSPRqst.strActn.Trim())

            Try
                Dim wsM As WSMain = New WSMain
                Dim objRMWIVAPP As clsIvappMain = New clsIvappMain
                Dim objUSCRGetAccount As CSRGetAccount.Account = New CSRGetAccount.Account

                objSSPResp = objRMWIVAPP.fnPutIvappRequest(getFIOSRequest.strAcctNum, getFIOSRequest, objAddBlockVoiceOrder, objUSCRGetAccount)
                If objSSPResp.strMsgID.Trim() = "" Then
                    objSSPResp.strMsgID = "RMI100"
                    objSSPResp.strMsgDescription = "iVAPPPUTFAILURE"
                End If

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-RequestIssueToIVAPP", ex.ToString() + getFIOSRequest.strAcctNum)
                strIvappInputXml = ex.ToString
                objSSPResp.strMsgID = "RMI100"
                objSSPResp.strMsgDescription = "iVAPPPUTFAILURE"
            End Try
            Return objSSPResp

        End Function
#End Region

#Region "RMICW Product Status"

        <WebMethod(Description:="RMICW Product Status")> _
        <OperationContract()> _
        Public Function GetRMICWProductStatus(ByVal strRegioncd As String, ByVal strAcctnum As String, ByVal strFIOSInd As String) As ProductStatus_Response

            Dim blnSucess As Boolean = False
            Dim strIvappInputXml As String = ""
            Dim stroutput As String = ""

            'Dim xmlDoc As XmlDocument

            Dim objRequest As ProductStatus_Request = New ProductStatus_Request
            Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric

            'strvalue = ObjDataAccess.usp_GetControlParmByName(strRegion, "MQiGOEnable")

            objRequest.strAcctNum = strAcctnum.Trim()
            objRequest.strRegionId = strRegioncd.ToUpper().Trim()
            objRequest.strFIOSInd = strFIOSInd.ToUpper().Trim()


            Dim objProductStatus As ProductStatus = New ProductStatus(strRegioncd)

            Try
                'objWireless1Bill.getWireless1BillStatus(objBqtrequest)

                Return objProductStatus.GetRMICWProductStatus(objRequest)
                'Return stroutput


            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS- ProductStatus", ex.ToString())
                strIvappInputXml = ex.ToString
            End Try

        End Function
#End Region


#Region "get SSP PROFILE  - uses SSP Info"
        <WebMethod(Description:="Get SSP Profile Test")> _
        Public Function getSSPPROFILE(ByVal strAcctnum As String, ByVal strRegionId As String, ByVal strProfileCAN As String) As XmlDocument

            Dim objSSPRp As sspResponseDetails = New sspResponseDetails

            Dim objclsSSPTxn As clsSSPTxn = New clsSSPTxn
            Dim objSSPRqst As SSPRequestDetails = New SSPRequestDetails




            Dim getURL As wsGETURL = New wsGETURL
            Dim posturl As String = ""
            Dim postProfileurl As String = ""
            Dim strProfileXml As String = ""


            Dim xmlDoc As XmlDocument = New XmlDocument
            Dim xmlProfileDoc As XmlDocument = New XmlDocument
            If strRegionId = "VISION" Then
                objSSPRqst.strAcctNum = strAcctnum
                objSSPRqst.strvisionCustomerId = objSSPRqst.strAcctNum.Substring(0, 9)
                objSSPRqst.strvisionAccountId = objSSPRqst.strAcctNum.Substring(9, 4)

            End If


            Try

                objSSPRqst.strRegionId = strRegionId.Trim()
                'objSSPRqst.strSSPAccountID = strSSPAccountID.Trim()
                objSSPRqst.strProfileCAN = strProfileCAN.Trim()

                postProfileurl = getURL.getSSPURL(objSSPRqst.strRegionId.Trim(), "SSPPROFILE")

                If postProfileurl.Trim() = "" Then
                    'postProfileurl = "https://sspsac.verizon.com/RetrievalWebService-COG_itw/RetrievalService"
                    LogErrorFile.WriteLog("RMICWWebServices-getSSPPROFILE", "Empty Profile URL:" + postProfileurl)

                End If



                strProfileXml = objclsSSPTxn.RetrievalServiceTxn(objSSPRqst, postProfileurl)

                If strProfileXml.Trim() <> "" Then

                    xmlDoc.LoadXml(strProfileXml)

                    xmlDoc.LoadXml(System.Text.RegularExpressions.Regex.Replace(xmlDoc.OuterXml, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline)))


                    Dim nav As System.Xml.XPath.XPathNavigator = xmlDoc.CreateNavigator()

                    'Dim expr As System.Xml.XPath.XPathExpression = nav.Compile("//Publisher[. = 'MSPress']/parent::node()/Title")
                    'Dim expr As System.Xml.XPath.XPathExpression = nav.Compile("//accountInformation")
                    'Dim iterator As System.Xml.XPath.XPathNodeIterator = nav.Select(expr)
                    'Dim iterator As System.Xml.XPath.XPathNodeIterator = nav.Select("//Service/@serviceId")
                    Dim iterator As System.Xml.XPath.XPathNodeIterator = nav.Select("//Service")


                    Dim objnavRespinfo As System.Xml.XPath.XPathNavigator = xmlDoc.CreateNavigator()
                    Dim objRespit As System.Xml.XPath.XPathNodeIterator = nav.Select("//ResponseInfo/Description")
                    Do While objRespit.MoveNext
                        objSSPRqst.strResultDesc = objRespit.Current.Value
                    Loop


                    Dim objRespCatIT As System.Xml.XPath.XPathNodeIterator = nav.Select("//ResponseInfo/Category")
                    Do While objRespCatIT.MoveNext
                        objSSPRqst.strReturnCd = objRespCatIT.Current.Value
                    Loop

                    Dim objRespCodeIT As System.Xml.XPath.XPathNodeIterator = nav.Select("//ResponseInfo/Code")
                    Do While objRespCodeIT.MoveNext
                        objSSPRqst.strReturnCd = objSSPRqst.strReturnCd + objRespCodeIT.Current.Value
                    Loop



                    'System.Diagnostics.Debug.WriteLine(iterator.Current.Value)



                    'Do While iterator.MoveNext

                    'PPV()
                    'FIOS_VOICE()
                    'FIOS_DATA()
                    'FIOS_VIDEO()
                    'DSL()
                    'DialUp()
                    'VASIP()
                    'DNR()
                    'WebSecurity()
                    'CVSType()

                    If (Not objSSPRqst.blnFDataON) Then
                        'Dim itFiber As System.Xml.XPath.XPathNodeIterator = nav.Select("//Service/FiberService")
                        Dim itFiberID As System.Xml.XPath.XPathNodeIterator = nav.Select("//Service/@serviceId[FiberService]")

                        Do While itFiberID.MoveNext
                            objSSPRqst.RestoreOverride = itFiberID.Current.Value
                        Loop
                    End If



                    If (Not objSSPRqst.blnFDataON) Then
                        Dim itFiber As System.Xml.XPath.XPathNodeIterator = nav.Select("//Service/FiberService")
                        'Dim itFiber As System.Xml.XPath.XPathNodeIterator = nav.Select("//Service[.@serviceId]/FiberService")
                        Do While itFiber.MoveNext
                            objSSPRqst.blnFDataON = True

                        Loop
                    End If

                    If (Not objSSPRqst.blnFVideoON) Then
                        Dim itVideo As System.Xml.XPath.XPathNodeIterator = nav.Select("//Service/VideoService")
                        Do While itVideo.MoveNext
                            objSSPRqst.blnFVideoON = True
                        Loop
                    End If

                    If (Not objSSPRqst.blnFVoiceON) Then
                        Dim itVoice As System.Xml.XPath.XPathNodeIterator = nav.Select("//Service/FiosVoice")
                        Do While itVoice.MoveNext
                            objSSPRqst.blnFVoiceON = True
                        Loop
                    End If

                    If (Not objSSPRqst.blnVASIPON) Then
                        Dim itVASIP As System.Xml.XPath.XPathNodeIterator = nav.Select("//Service/VASIPService")
                        Do While itVASIP.MoveNext
                            objSSPRqst.blnVASIPON = True
                        Loop
                    End If

                    If (Not objSSPRqst.blnDSLON) Then
                        Dim itDSL As System.Xml.XPath.XPathNodeIterator = nav.Select("//Service/DSLService")
                        Do While itDSL.MoveNext
                            objSSPRqst.blnDSLON = True
                        Loop
                    End If


                    If (Not objSSPRqst.blnDIALUPON) Then
                        Dim itDIAL As System.Xml.XPath.XPathNodeIterator = nav.Select("//Service/DialService")
                        Do While itDIAL.MoveNext
                            objSSPRqst.blnDIALUPON = True
                        Loop
                    End If


                    If (Not objSSPRqst.blnDNRON) Then
                        Dim itDNR As System.Xml.XPath.XPathNodeIterator = nav.Select("//Service/DNRService")
                        Do While itDNR.MoveNext
                            objSSPRqst.blnDNRON = True
                        Loop
                    End If




                    'Loop



                    Dim itSSPID As System.Xml.XPath.XPathNodeIterator = nav.Select("//Account/@accountId")
                    Do While itSSPID.MoveNext
                        objSSPRqst.strSSPAccountID = itSSPID.Current.Value
                    Loop



                    Dim itBAN As System.Xml.XPath.XPathNodeIterator = nav.Select("//Account/@volAccountNumber")
                    Do While itBAN.MoveNext
                        objSSPRqst.strSSPBAN = itBAN.Current.Value
                    Loop


                    Dim itLECBILL As System.Xml.XPath.XPathNodeIterator = nav.Select("//BillingInfo/Payment/LECBilling")
                    Do While itLECBILL.MoveNext
                        objSSPRqst.IsLECBilledInd = "Y"
                    Loop

                    Dim itSvcHouseNo As System.Xml.XPath.XPathNodeIterator = nav.Select("//ServiceAddress/HouseNo")
                    Do While itSvcHouseNo.MoveNext
                        If objSSPRqst.AccountDetails.strAddHouseNo = "" Then
                            objSSPRqst.AccountDetails.strAddHouseNo = itSvcHouseNo.Current.Value
                        End If
                    Loop

                    Dim itSvcSt As System.Xml.XPath.XPathNodeIterator = nav.Select("//ServiceAddress/Street")
                    Do While itSvcSt.MoveNext
                        If objSSPRqst.AccountDetails.strAddStreet = "" Then
                            objSSPRqst.AccountDetails.strAddStreet = itSvcSt.Current.Value
                        End If

                    Loop

                    Dim itSvcCity As System.Xml.XPath.XPathNodeIterator = nav.Select("//ServiceAddress/City")
                    Do While itSvcCity.MoveNext
                        If objSSPRqst.AccountDetails.strAddCity = "" Then
                            objSSPRqst.AccountDetails.strAddCity = itSvcCity.Current.Value
                        End If

                    Loop

                    Dim itSvcState As System.Xml.XPath.XPathNodeIterator = nav.Select("//ServiceAddress/State")
                    Do While itSvcState.MoveNext
                        If objSSPRqst.AccountDetails.strAddState = "" Then
                            objSSPRqst.AccountDetails.strAddState = itSvcState.Current.Value
                        End If

                    Loop

                    Dim itSvcZip As System.Xml.XPath.XPathNodeIterator = nav.Select("//ServiceAddress/Zip")
                    Do While itSvcZip.MoveNext
                        If objSSPRqst.AccountDetails.strAddZip = "" Then
                            objSSPRqst.AccountDetails.strAddZip = itSvcZip.Current.Value
                        End If

                    Loop



                    'Release the XPathDocument and XPathNavigator.
                    xmlProfileDoc = xmlDoc
                    xmlDoc = Nothing
                    nav = Nothing




                End If



            Catch exprofile As Exception
                LogErrorFile.WriteLog("RMICWWebServices-getSSPPROFILE", exprofile.ToString())

            End Try


            Return xmlProfileDoc
        End Function
#End Region


#Region "DTV Request"

        <WebMethod(Description:="Affliate Notification Request")> _
        <OperationContract()> _
        Public Function AffliateNotification(ByVal strXmlDoc As String) As AffiliateResponse
            'Public Function IssueDTVRequest(ByVal strRegionId As String, ByVal intRequestId As String, ByVal strAcctNum As String, ByVal strOrg As String, ByVal strActn As String, ByVal strDestSystem As String, ByVal strStatusCd As String, ByVal strOriginationId As String, ByVal strReturnCd As String, ByVal strNotationCd As String, ByVal strEnvironment As String, ByVal strUpdtId As String, ByVal strResultId As String, ByVal strResultDesc As String) As DTVResponse
            'test
            Dim objDTVResponse As AffiliateResponse = New AffiliateResponse
            Dim blnSucess As Boolean = False
            Dim strvalue As String = ""
            Dim xmlDoc As XmlDocument

            Dim ObjRequest As AffiliateNotification = New AffiliateNotification
            'Dim objDTVResponse As DTVResponse = New DTVResponse
            Dim objDataLay As AffiliateNotification = New AffiliateNotification
            Dim sReader As StringReader
            Dim tReader As TextReader

            sReader = New StringReader(strXmlDoc)
            Dim xmlDTVResponseDeSer As XmlSerializer = New XmlSerializer(GetType(AffiliateNotification))
            objDataLay = CType(xmlDTVResponseDeSer.Deserialize(sReader), AffiliateNotification)

            Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(objDataLay.strRegionId.Trim())

            strvalue = ObjDataAccess.usp_GetControlParmByName(objDataLay.strRegionId.Trim(), "DTVEnable")

            If strvalue.ToUpper().Trim() = "TRUE" Then

                Dim ObjReq As DTVWebservices = New DTVWebservices(objDataLay.strRegionId.Trim)

                Try
                    'objReqDTVSuspend.SendDTVRequest(strRegionId, intRequestId, strAcctNum, strOrg, strActn, strDestSystem, strStatusCd, strOriginationId, strReturnCd, strNotationCd, strEnvironment, strUpdtId, strResultId, strResultDesc)

                    objDTVResponse = ObjReq.SendAffiliateNotification(objDataLay)

                Catch ex As Exception
                    LogErrorFile.WriteLog("RMICWWS- DTVInterface", ex.ToString())
                End Try

                Return objDTVResponse
            Else
                LogErrorFile.WriteLog("RMICWWS- DTVInterface", objDataLay.strRegionId & " " & "Not Calling DTV - Chk Controlparm")
            End If


        End Function
#End Region


#Region "DTV Account Status"

        <WebMethod(Description:="DTV Account Status")> _
        <OperationContract()> _
        Public Function GetDTVAccountStatus(ByVal strregioncd As String, ByVal strAcctnum As String, ByVal strDTVAcctNum As String) As AffiliateStatus
            Dim blnSucess As Boolean = False
            Dim strIvappInputXml As String = ""
            Dim stroutput As String = ""

            'Dim xmlDoc As XmlDocument

            Dim objDTVStatusReq As AffiliateStatus = New AffiliateStatus

            objDTVStatusReq.strAcctNum = strAcctnum.Trim()
            objDTVStatusReq.StrRegioncd = strregioncd.ToUpper().Trim()
            objDTVStatusReq.strDTVAcctNum = strDTVAcctNum.Trim()

            Dim ObjReq As DTVWebservices = New DTVWebservices(objDTVStatusReq.StrRegioncd.Trim())

            Try
                'objWireless1Bill.getWireless1BillStatus(objBqtrequest)

                Return ObjReq.GetDTVAccountStatus(objDTVStatusReq)
                'Return stroutput


            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS- BQTInterface", ex.ToString())
                strIvappInputXml = ex.ToString
            End Try

        End Function
#End Region



#Region "Webservice to call Arbor webservice"
        <WebMethod(Description:="Get Balance Information from Arbor")> _
        <OperationContract()> _
        Public Function Get_Arbor_BalanceInfo(ByVal strAcctnum As String) As ARBOR_TRX_RESPONSE
            Dim objGetBal As New ArborWebservices
            Dim objResponse As ARBOR_TRX_RESPONSE
            objResponse = objGetBal.PostArborValues(strAcctnum)
            Return objResponse
        End Function
#End Region

#Region "AAIS Starts"
#Region "TreatmentStatusUpdateFromAAIS"
        <WebMethod(Description:="TreatmentStatusUpdateFromAAIS  - Receive Response Message from AAIS")> _
        Public Function TreatmentStatusUpdateFromAAIS(ByVal strCompanyCode As String, ByVal strNPA As String, ByVal strNXX As String, ByVal strLineNumber As String, ByVal strRequestId As String, ByVal strMitsFeature As String, ByVal strIsdnfeature As String, ByVal strReturnCode As String, ByVal strErrorMsg As String) As String
            'Public Function TreatmentStatusUpdateFromAAIS(ByVal strCompanyCode As String, ByVal strNPA As String, ByVal strNXX As String, ByVal strLineNumber As String, ByVal strRequestId As String, ByVal strReturnCode As String, ByVal strErrorMsg As String) As String

            Dim strMsg As String = " "
            Dim strRegionId As String = "WEST"

            'Dim strMitsFeature As String = ""
            'Dim strIsdnfeature As String = ""

            Try
                'strMsg = "strCompanyCode = " + strCompanyCode + "- strNPA = " + strNPA + "- strNXX = " + strNXX + "- strLineNumber = " + strLineNumber + "- strRequestId = " + strRequestId + "- strReturnCode = " + strReturnCode + "- strErrorMsg = " + strErrorMsg
                'strMsg = "testing reply message" + strMsg
                'LogErrorFile.WriteLog("RMICWWS-getAAISResponse", strMsg)
                Dim objAAISAccess As AAISAccess = New AAISAccess(strRegionId)
                strMsg = objAAISAccess.fnUpdateAAISResponse(strCompanyCode, strNPA, strNXX, strLineNumber, strRequestId, strMitsFeature, strIsdnfeature, strReturnCode, strErrorMsg)


            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-TreatmentStatusUpdateFromAAIS", ex.ToString())
                strMsg = ex.ToString
            End Try
            Return strMsg
        End Function
#End Region

#Region "AAISRequestIssue"
        <WebMethod(Description:="AAISRequestIssue  - Issue Request to AAIS")> _
        <OperationContract()> _
        Public Function AAISRequestIssue(ByVal strAcctNum As String, ByVal strRequestId As String, ByVal strAAISActn As String, ByVal strWTN As String, ByVal strsyncFlag As String, ByVal strEnv As String) As String

            Dim strMsg As String = " "
            Dim strRegionId As String = "WEST"

            Try
                Dim objAAISAccess As AAISAccess = New AAISAccess(strRegionId)
                Dim AAISReq As AAISRequest = New AAISRequest

                AAISReq.strAcctNum = strAcctNum
                AAISReq.strRequestId = strRequestId
                AAISReq.strAAISActn = strAAISActn
                AAISReq.strWTN = strWTN
                AAISReq.strSyncFlag = strsyncFlag

                strMsg = objAAISAccess.fnSendAAISRequest(AAISReq, strEnv)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getAAISResponse", ex.ToString())
                strMsg = ex.ToString
            End Try
            Return strMsg
        End Function
#End Region

#End Region

#Region "Webservice to call iFinals webservice"
        <WebMethod(Description:="Get BTNFTIN Information from iFinals")> _
        <OperationContract()> _
        Public Function GetFinalAccountsForBTN(ByVal strBTNNum As String, ByVal strRegionCd As String) As XmlDocument
            Dim objIFinalsNPD As IFinalsNPD.iFinalsWsMain = New IFinalsNPD.iFinalsWsMain
            Dim striFinalsResponse As String = ""
            Dim RequestContext As SoapContext
            Dim posturl As String = ""
            Dim strRegion As String = ""
            Dim xmliFinalDoc As XmlDocument = New XmlDocument
            Dim getURL As wsGETURL = New wsGETURL

            Try

                RequestContext = objIFinalsNPD.RequestSoapContext
                objIFinalsNPD.Proxy = New WebProxy
                RequestContext.Security.Tokens.Clear()
                Dim unt As Tokens.UsernameToken = New Tokens.UsernameToken("RMW", "rmicw05", Tokens.PasswordOption.SendPlainText)
                RequestContext.Security.Tokens.Add(unt)
                RequestContext.Security.MustUnderstand = False

                If strRegionCd.ToUpper().Trim() = "FWEST" Then
                    strRegion = "WEST"
                Else
                    strRegion = strRegionCd
                End If

                posturl = getURL.getSSPURL(strRegion, "uIFINALS")
                'LogErrorFile.WriteLog("RMICWWS-GetFinalAccountsForBTN:URL: " + strBTNNum + "/" + strRegionCd, posturl.ToString())

                objIFinalsNPD.Url = posturl.Trim()
                objIFinalsNPD.Timeout = 60000
                objIFinalsNPD.RequestSoapContext.Addressing.MustUnderstand = False

                striFinalsResponse = objIFinalsNPD.getFinalAcctsForBTN(strBTNNum, strRegionCd)

                If striFinalsResponse.Trim() <> "" Then
                    striFinalsResponse = System.Text.RegularExpressions.Regex.Replace(striFinalsResponse, "[+~!@#$%^&*()_+{}|]", "")
                    xmliFinalDoc.LoadXml(striFinalsResponse)
                    xmliFinalDoc.LoadXml(System.Text.RegularExpressions.Regex.Replace(xmliFinalDoc.OuterXml, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline)))

                End If



            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-GetFinalAccountsForBTN:strBTNNum/strRegionCd:" + strBTNNum + "/" + strRegionCd, ex.ToString())
                striFinalsResponse = "<Response><Msg>RMIEXCPTN</Msg><MsgDesc>" + ex.ToString() + "</MsgDesc></Response>"
                xmliFinalDoc.LoadXml(striFinalsResponse)

            End Try

            Return xmliFinalDoc
        End Function
#End Region

#Region "getOrderImage"
        <WebMethod(Description:="Get getOrderImage")> _
        Public Function wmGetOrderImage(ByVal strJuristication As String, ByVal strOrder As String, ByVal strBTN As String) As XmlDocument ' As String
            ' for Rule #RL013060
            Dim objImage As getNSOP = New getNSOP()
            Dim respXml As String = String.Empty
            Dim xmlstrResponseDoc As XmlDocument = New XmlDocument

            Try
                respXml = objImage.CallgetOrderImage(strOrder, strJuristication, strBTN)
                xmlstrResponseDoc.LoadXml(respXml)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWebservices", ex.ToString())
            End Try
            Return xmlstrResponseDoc
        End Function
#End Region
#Region "Wireless Request"
        <WebMethod(Description:="Affliate Notification Request to Wireless")> _
        <OperationContract()> _
        Public Function NotifyWireless(ByVal strXmlDoc As String) As VZWResponse
            'for testing purpose logging driver xml
            LogErrorFile.WriteLog("Driver calling VZW WS", strXmlDoc)
            Dim objVZWResponse As VZWResponse = New VZWResponse
            Dim blnSucess As Boolean = False
            Dim strvalue As String = ""
            Dim xmlDoc As XmlDocument


            Dim objDataLay As AffiliateNotification = New AffiliateNotification

            Dim sReader As StringReader
            Dim tReader As TextReader

            'Removing Xml namespace from input xml
            Dim startIndex As Integer = strXmlDoc.ToString().IndexOf(">")
            strXmlDoc = strXmlDoc.Remove(0, startIndex + 1)

            startIndex = strXmlDoc.ToString().IndexOf(">")
            strXmlDoc = strXmlDoc.Remove(0, startIndex + 1)
            strXmlDoc = strXmlDoc.Insert(0, "<AffiliateNotification>")
            strXmlDoc = strXmlDoc.Replace(vbCrLf, "")

            sReader = New StringReader(strXmlDoc)

            Dim xmlDTVResponseDeSer As XmlSerializer = New XmlSerializer(GetType(AffiliateNotification))
            objDataLay = CType(xmlDTVResponseDeSer.Deserialize(sReader), AffiliateNotification)

            Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(objDataLay.strRegionId.Trim())

            strvalue = ObjDataAccess.usp_GetControlParmByName("Control" + objDataLay.strRegionId.Trim(), "VZWEnable")

            'To Control Go or No Go to wireless
            If strvalue.ToUpper().Trim() = "TRUE" Then

                Dim ObjReq As VZWWebservices = New VZWWebservices(objDataLay.strRegionId.Trim)
                Try
                    objVZWResponse = ObjReq.SendAffiliateNotification(objDataLay)
                Catch ex As Exception
                    LogErrorFile.WriteLog("RMICWWS- VZWInterface", ex.ToString())
                End Try

                Return objVZWResponse
            Else 'No Go to Wireless
                LogErrorFile.WriteLog("RMICWWS- VZWInterface", objDataLay.strRegionId & " " & "Not Calling Wireless - Disabled in Controlparm")
            End If
        End Function
#End Region

#Region "COFFE Adjustment webmethod "
        <WebMethod(Description:="COFEE Adjustment Webmethod")> _
        Public Function IssueCOFFEAdjustments(ByVal strRegionCd As String, ByVal intRequestId As String, ByVal strAcctNum As String, ByVal strActn As String, ByVal strCompanyCode As String, ByVal strStateCode As String, ByVal dtmBillDate As Date, ByVal strAdjustmentCode As String, ByVal curAdjAmt As Double, ByVal strOrg As String, ByVal strLocationCd As String, ByVal strLineType As String, ByVal strCOS As String) As String
            Dim strResponse As String = ""
            Dim posturl As String = ""
            Dim xmliFinalDoc As XmlDocument = New XmlDocument
            Dim objRequest As InpRequest = New InpRequest
            Dim ObjCoffeAdj As COFEEAdjustments = New COFEEAdjustments(strRegionCd)



            Try
                objRequest.strRegionId = strRegionCd
                objRequest.intRequestId = intRequestId
                objRequest.strAcctNum = strAcctNum
                objRequest.strCompanyCd = strCompanyCode
                objRequest.strState = strStateCode
                objRequest.dtmBillDate = dtmBillDate
                objRequest.strAdjustmentCd = strAdjustmentCode
                objRequest.curAdjustmentAmt = curAdjAmt
                objRequest.strOrg = strOrg
                objRequest.strLocationCd = strLocationCd
                objRequest.strlinetype = strLineType
                objRequest.strClassOfService = strCOS
                objRequest.strActn = strActn


                strResponse = ObjCoffeAdj.IssueCoffeAdj(objRequest)
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-GetFinalAccountsForBTN:strBTNNum/strRegionCd:" + strAcctNum + "/" + strRegionCd, ex.ToString())

            End Try

            Return strResponse
        End Function
#End Region



#Region "FULL CSR Profile webmethod "
        <WebMethod(Description:="FULL CSR Profile webmethod")> _
        Public Function GetCSRProfile(ByVal strRegionCd As String, ByVal strAcctNum As String) As String
            Dim strResponse As String = ""
            Dim posturl As String = ""
            Dim xmliFinalDoc As XmlDocument = New XmlDocument
            Dim strUrl As String
            Dim strOutput As String = ""

            Try


                Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(strRegionCd.Trim())
                strUrl = ObjDataAccess.usp_GetControlParmByName("Control" + strRegionCd.Trim(), "uCSRGWY")


                Dim Objws As CSRProfile.uCSRService = New CSRProfile.uCSRService
                Objws.Url = strUrl
                Dim RequestContext As SoapContext
                RequestContext = Objws.RequestSoapContext
                Objws.Proxy = New WebProxy
                RequestContext.Security.Tokens.Clear()

                Dim userToken As UsernameToken = New UsernameToken("" + "RMW" + "", "" + "rmicw05" + "", PasswordOption.SendPlainText)
                RequestContext.Security.Tokens.Add(userToken)
                RequestContext.Security.MustUnderstand = False

                Objws.Timeout = 90000
                Objws.RequestSoapContext.Addressing.MustUnderstand = False

                Dim Objinp As CSRProfile.input = New CSRProfile.input

                Select Case strRegionCd
                    Case "WEST"
                        Objinp.can = strAcctNum
                    Case "NPD", "NY", "NE"
                        Objinp.btn = strAcctNum
                    Case "MDVW"
                        Objinp.blact = strAcctNum.PadLeft(12, "0")
                End Select

                'Objinp.btn = strAcctNum
                Objinp.appId = "RMW"

                Objinp.level = CSRProfile.CSRLevel.FullCSR
                Objinp.noteBillingDate = 1
                Objinp.clientId = "RMICW"


                'strOutput = Objws.GetCustomerServiceRecord(Objinp)
                'Return strOutput



                Dim objCSRFinancialInfo As CSRProfile.config = New CSRProfile.config()
                objCSRFinancialInfo.name = CSRProfile.CSRConfigOptions.getFinancialInfo
                objCSRFinancialInfo.Value = CSRProfile.ConfigOptionValues.True



                Dim objCSRincludeBalances As CSRProfile.config = New CSRProfile.config()
                objCSRincludeBalances.name = CSRProfile.CSRConfigOptions.includeBalances
                objCSRincludeBalances.Value = CSRProfile.ConfigOptionValues.True


                Dim objCSRUseExpress As CSRProfile.config = New CSRProfile.config()
                objCSRUseExpress.name = CSRProfile.CSRConfigOptions.UseExpress
                objCSRUseExpress.Value = CSRProfile.ConfigOptionValues.True



                Dim objCSRincludeWTNListToCSRList As CSRProfile.config = New CSRProfile.config()
                objCSRincludeWTNListToCSRList.name = CSRProfile.CSRConfigOptions.includeWTNListToCSRList
                objCSRincludeWTNListToCSRList.Value = CSRProfile.ConfigOptionValues.True

                Dim objCSRenableBillingDataForList As CSRProfile.config = New CSRProfile.config()
                objCSRenableBillingDataForList.name = CSRProfile.CSRConfigOptions.enableBillingDataForList
                objCSRenableBillingDataForList.Value = CSRProfile.ConfigOptionValues.True

                'Dim ObjCSRinpList As CSRProfile.input = New CSRProfile.input
                'ObjCSRinpList.appId = "RMW"
                'ObjCSRinpList.level = CSRProfile.CSRLevel.FullCSR
                'ObjCSRinpList.noteBillingDate = 1
                'ObjCSRinpList.clientId = "RMICW"
                'ObjCSRinpList.configlist() = New CSRProfile.config() {objCSRFinancialInfo, objCSRincludeBalances, objCSRUseExpress, objCSRincludeWTNListToCSRList, objCSRenableBillingDataForList}

                Objinp.configlist() = New CSRProfile.config() {objCSRFinancialInfo, objCSRincludeBalances, objCSRUseExpress, objCSRincludeWTNListToCSRList, objCSRenableBillingDataForList}

                strOutput = Objws.GetCustomerServiceRecord(Objinp)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-GetFuLLCSR:" + strAcctNum + "/" + strRegionCd, ex.ToString())

            End Try
            Return strOutput


        End Function

#End Region


#Region "CSR Video Profile webmethod "
        <WebMethod(Description:="CSR Video Profile webmethod")> _
        Public Function GetCSRVideoProfile(ByVal strRegionCd As String, ByVal strAcctNum As String) As String
            Dim strResponse As String = ""
            Dim posturl As String = ""
            Dim xmliFinalDoc As XmlDocument = New XmlDocument
            Dim strUrl As String
            Try
                Dim strOutput As String = ""

                Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(strRegionCd.Trim())
                strUrl = ObjDataAccess.usp_GetControlParmByName("Control" + strRegionCd.Trim(), "uCSRGWY")


                Dim Objws As CSRProfile.uCSRService = New CSRProfile.uCSRService

                Objws.Url = strUrl
                Dim RequestContext As SoapContext
                RequestContext = Objws.RequestSoapContext
                Objws.Proxy = New WebProxy
                RequestContext.Security.Tokens.Clear()

                Dim userToken As UsernameToken = New UsernameToken("" + "RMW" + "", "" + "rmicw05" + "", PasswordOption.SendPlainText)
                RequestContext.Security.Tokens.Add(userToken)
                RequestContext.Security.MustUnderstand = False

                Objws.Timeout = 90000
                Objws.RequestSoapContext.Addressing.MustUnderstand = False

                Dim Objinp As CSRProfile.GetVideoServiceInput = New CSRProfile.GetVideoServiceInput
                Objinp.inputTypeIndicator = CSRProfile.InputTypeIndicator.BROADBAND
                Objinp.includeFiosVoice = "Y"
                Objinp.region = strRegionCd
                Objinp.appId = "RMICW"
                Objinp.inputValue = strAcctNum

                strOutput = Objws.GetVideoProfile(Objinp)
                strOutput = strOutput.Replace("\\", String.Empty)
                Return strOutput

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-GetCSRVideoProfile:" + strAcctNum + "/" + strRegionCd, ex.ToString())

            End Try


        End Function

#End Region

#Region "GAR A2R - uses uCSR BillingGetAccountRelationshipsA2R"

        <WebMethod(Description:="Get info from uCSR/GAR A2R ")> _
        Public Function getBillingGetAccountRelationshipsA2R(ByVal strRegionId As String, ByVal strEastWestInd As String, ByVal strInputValue As String, ByVal strInputType As String, ByVal strAppId As String, ByVal intLogId As String) As Response

            Dim objResponseLayoutRp As Response = New Response

            objResponseLayoutRp.results.BROADBAND.RelationshipCode = ""
            objResponseLayoutRp.results.BROADBAND.effectiveDate = ""
            objResponseLayoutRp.results.BROADBAND.PreviousCAN = ""
            objResponseLayoutRp.results.BROADBAND.RelationshipInvLevel = ""
            objResponseLayoutRp.results.BROADBAND.WADSL = ""
            objResponseLayoutRp.results.BROADBAND.A2RDataDate = ""
            objResponseLayoutRp.results.BROADBAND.InvoiceCAN = ""
            objResponseLayoutRp.results.BROADBAND.A2RConvStatus = ""
            objResponseLayoutRp.results.BROADBAND.ShellAccount = ""
            objResponseLayoutRp.results.BROADBAND.FDVPrimaryTN = ""
            objResponseLayoutRp.results.BROADBAND.FIOSType = ""
            objResponseLayoutRp.results.BROADBAND.ContBillShellDate = ""
            objResponseLayoutRp.results.BROADBAND.ParentCAN = ""
            objResponseLayoutRp.results.BROADBAND.company = ""
            objResponseLayoutRp.results.BROADBAND.TypeOfAccount = ""
            objResponseLayoutRp.results.BROADBAND.status = ""
            objResponseLayoutRp.results.BROADBAND.state = ""
            objResponseLayoutRp.results.BROADBAND.BBTermDate = ""
            objResponseLayoutRp.results.BROADBAND.SSPAcctId = ""
            objResponseLayoutRp.results.profileCAN.Value = ""
            objResponseLayoutRp.results.BROADBAND.BBCAN = ""
            objResponseLayoutRp.results.BROADBAND.HOA_IDENTIFIER = ""
            objResponseLayoutRp.results.BROADBAND.HOA_LEVEL = ""
            objResponseLayoutRp.results.BROADBAND.BillCycle = ""
            objResponseLayoutRp.results.voiceIdentifier.Value = ""
            objResponseLayoutRp.results.BROADBAND.BillMethod = ""
            objResponseLayoutRp.results.BROADBAND.SSPBAN = ""
            objResponseLayoutRp.results.BROADBAND.LECBillingAccount = ""
            objResponseLayoutRp.results.BROADBAND.ContBiller = ""


            Dim objRes As GetAccountRelationResponse_NACRNEWService.getAccountRelationshipResponse = New GetAccountRelationResponse_NACRNEWService.getAccountRelationshipResponse()

            Dim xdoc As XDocument
            Dim xmldoc As XmlDocument = New XmlDocument
            Dim xRoot As XmlRootAttribute = New XmlRootAttribute()
            xRoot.ElementName = "getAccountRelationshipResponse"
            xRoot.IsNullable = True

            Try

                If strRegionId.ToUpper() = "VISION" Then
                    strInputType = "VisionId"
                End If

                xmldoc = getAccountRelationShip(strInputValue, strInputType, strRegionId, Guid.NewGuid.ToString())


                Dim xmlSSPResponseDeSer As XmlSerializer = New XmlSerializer(GetType(getAccountRelationshipResponse), xRoot)
                objRes = CType(xmlSSPResponseDeSer.Deserialize(New StringReader(xmldoc.OuterXml)), getAccountRelationshipResponse)

                Dim objStatus As GetAccountRelationResponse_NACRNEWService.oneErrorReportStatus = New GetAccountRelationResponse_NACRNEWService.oneErrorReportStatus()

                If objRes.StatusReport Is Nothing Then ' when RMICW unable to call NACR Method Srver, IIS issue / URL not found.
                    objResponseLayoutRp.message.messageNumber = "1"
                    objResponseLayoutRp.message.messageText = "RMIEXPTN"
                End If


                If Not objRes.StatusReport Is Nothing Then
                    For Each objStatus In objRes.StatusReport
                        If objStatus.source = "Overall" Then
                            objResponseLayoutRp.message.messageNumber = objStatus.code
                            objResponseLayoutRp.message.messageText = objStatus.description

                            If objStatus.description = "Success" Then

                                Dim objAcctRelation As RetrievedAccountRelationShipTypeAccount = New RetrievedAccountRelationShipTypeAccount()

                                If objRes.AccountRelationship Is Nothing Then
                                    objResponseLayoutRp.message.messageNumber = "2"
                                    objResponseLayoutRp.message.messageText = "NO GAR"
                                End If


                                If (Not objRes.AccountRelationship Is Nothing And (objRes.AccountRelationship.Length > 0)) Then

                                    For Each objAcctRelation In objRes.AccountRelationship
                                        'Vision Converted accounts
                                        If (Not (String.IsNullOrWhiteSpace(objAcctRelation.visionCustomerId)) And Not (String.IsNullOrWhiteSpace(objAcctRelation.visionAccountId))) Then
                                            If Not objAcctRelation.visionCustomerId Is Nothing Then
                                                objResponseLayoutRp.results.BROADBAND.SSPBAN = objAcctRelation.visionCustomerId.Trim() + objAcctRelation.visionAccountId.Trim()
                                                objResponseLayoutRp.results.BROADBAND.LECBillingAccount = objAcctRelation.visionCustomerId.Trim() + objAcctRelation.visionAccountId.Trim()
                                                objResponseLayoutRp.results.BROADBAND.BBCAN = objAcctRelation.visionCustomerId.Trim() + objAcctRelation.visionAccountId.Trim()
                                                objResponseLayoutRp.results.voiceIdentifier.Value = objAcctRelation.visionCustomerId.Trim() + objAcctRelation.visionAccountId.Trim()
                                            End If

                                            If Not objAcctRelation.lecBillingAccount Is Nothing Then
                                                If (objAcctRelation.lecBillingAccount.Length > 0) Then
                                                    objResponseLayoutRp.results.BROADBAND.LECBillingAccount = objAcctRelation.lecBillingAccount
                                                    objResponseLayoutRp.results.voiceIdentifier.Value = objAcctRelation.lecBillingAccount
                                                End If
                                            End If

                                            If (String.IsNullOrWhiteSpace(objResponseLayoutRp.results.BROADBAND.LECBillingAccount)) Then
                                                If (objRes.VoiceCAN.Trim().Length = 12) Then 'MDVW account is prefixed with 000 + 9 digit voice can
                                                    If (objRes.VoiceCAN.Trim().Substring(0, 3) = "000") Then
                                                        objResponseLayoutRp.results.BROADBAND.LECBillingAccount = objRes.VoiceCAN.Trim().Substring(3, 9)
                                                        objResponseLayoutRp.results.voiceIdentifier.Value = objRes.VoiceCAN.Trim().Substring(3, 9)
                                                    Else
                                                        objResponseLayoutRp.results.BROADBAND.LECBillingAccount = objRes.VoiceCAN.Trim()
                                                        objResponseLayoutRp.results.voiceIdentifier.Value = objRes.VoiceCAN.Trim().Substring(3, 9)
                                                    End If

                                                Else
                                                    objResponseLayoutRp.results.BROADBAND.LECBillingAccount = objRes.VoiceCAN.Trim()
                                                    objResponseLayoutRp.results.voiceIdentifier.Value = objRes.VoiceCAN.Trim().Substring(3, 9)
                                                End If

                                            End If

                                            If Not objAcctRelation.pCAN Is Nothing Then
                                                    objResponseLayoutRp.results.profileCAN.Value = objAcctRelation.pCAN.Trim()
                                                End If
                                                If Not objAcctRelation.paymentType Is Nothing Then
                                                    objResponseLayoutRp.results.BROADBAND.BillMethod = objAcctRelation.paymentType  ' Bill method and Payment Type or Same???
                                                End If

                                                If Not objAcctRelation.hOALevel Is Nothing Then
                                                    objResponseLayoutRp.results.BROADBAND.HOA_LEVEL = objAcctRelation.hOALevel
                                                End If

                                                If Not objAcctRelation.parentVisionCustomerId Is Nothing Then
                                                    objResponseLayoutRp.results.BROADBAND.ParentCAN = objAcctRelation.parentVisionCustomerId.Trim() + objAcctRelation.parentVisionAccountId.Trim() ' Pls confirm??

                                                End If
                                                If Not objAcctRelation.relationshipCode.Trim() Is Nothing Then
                                                    objResponseLayoutRp.results.BROADBAND.RelationshipCode = objAcctRelation.relationshipCode.Trim()

                                                End If

                                                If Not objAcctRelation.sSPAcctId Is Nothing Then
                                                    objResponseLayoutRp.results.BROADBAND.SSPAcctId = objAcctRelation.sSPAcctId.Trim()
                                                End If


                                                If objAcctRelation.status = AccountStatusType.Active Then
                                                    objResponseLayoutRp.results.BROADBAND.status = "ACTIVE"
                                                ElseIf objAcctRelation.status = AccountStatusType.Deactivated Then
                                                    objResponseLayoutRp.results.BROADBAND.status = "DEACTIVATED"
                                                ElseIf objAcctRelation.status = AccountStatusType.Suspended Then
                                                    objResponseLayoutRp.results.BROADBAND.status = "SUSPENDED"
                                                ElseIf objAcctRelation.status = AccountStatusType.Inactive Then
                                                    objResponseLayoutRp.results.BROADBAND.status = "INACTIVE"
                                                ElseIf objAcctRelation.status = AccountStatusType.VacationSuspend Then
                                                    objResponseLayoutRp.results.BROADBAND.status = "VACATION SUSPENDED"
                                                Else
                                                    objResponseLayoutRp.results.BROADBAND.status = ""
                                                End If

                                                If Not objAcctRelation.companyCode Is Nothing Then
                                                    objResponseLayoutRp.results.BROADBAND.company = objAcctRelation.companyCode
                                                End If

                                                If Not objAcctRelation.typeOfAccount Is Nothing Then
                                                    objResponseLayoutRp.results.BROADBAND.TypeOfAccount = objAcctRelation.typeOfAccount
                                                End If

                                                If Not objAcctRelation.termDate Is Nothing Then
                                                    objResponseLayoutRp.results.BROADBAND.BBTermDate = objAcctRelation.termDate
                                                End If
                                                If Not objAcctRelation.sSPAcctId Is Nothing Then
                                                    objResponseLayoutRp.results.BROADBAND.SSPAcctId = objAcctRelation.sSPAcctId
                                                End If
                                                If Not objAcctRelation.hOAIdentifier Is Nothing Then
                                                    objResponseLayoutRp.results.BROADBAND.HOA_IDENTIFIER = objAcctRelation.hOAIdentifier
                                                End If

                                                If Not objAcctRelation.billCycle Is Nothing Then
                                                    objResponseLayoutRp.results.BROADBAND.BillCycle = objAcctRelation.billCycle
                                                End If

                                                objResponseLayoutRp.results.BROADBAND.state = objAcctRelation.state.ToString()

                                                objResponseLayoutRp.results.BROADBAND.effectiveDate = ""
                                                objResponseLayoutRp.results.BROADBAND.PreviousCAN = ""
                                                objResponseLayoutRp.results.BROADBAND.RelationshipInvLevel = ""
                                                objResponseLayoutRp.results.BROADBAND.WADSL = ""
                                                objResponseLayoutRp.results.BROADBAND.A2RDataDate = ""
                                                objResponseLayoutRp.results.BROADBAND.A2RConvStatus = ""
                                                objResponseLayoutRp.results.BROADBAND.ShellAccount = ""
                                                objResponseLayoutRp.results.BROADBAND.FDVPrimaryTN = ""
                                                objResponseLayoutRp.results.BROADBAND.FIOSType = ""
                                                objResponseLayoutRp.results.BROADBAND.ContBillShellDate = ""
                                                objResponseLayoutRp.results.BROADBAND.ContBiller = ""
                                                objResponseLayoutRp.results.BROADBAND.InvoiceCAN = ""

                                            Else
                                                'Non vision

                                                If Not objAcctRelation.pCAN Is Nothing Then 'BroadBand
                                                objResponseLayoutRp.results.profileCAN.Value = objAcctRelation.pCAN.ToString().Trim()
                                            End If

                                            If String.IsNullOrWhiteSpace(objResponseLayoutRp.results.profileCAN.Value) Then
                                                objResponseLayoutRp.results.profileCAN.Value = objRes.ProfileCAN
                                            End If

                                            If Not objAcctRelation.companyCode Is Nothing Then
                                                objResponseLayoutRp.results.BROADBAND.company = objAcctRelation.companyCode
                                            End If

                                            objResponseLayoutRp.results.BROADBAND.BBCAN = ""
                                            objResponseLayoutRp.results.BROADBAND.ContBiller = ""
                                            objResponseLayoutRp.results.BROADBAND.InvoiceCAN = ""
                                            objResponseLayoutRp.results.BROADBAND.ParentCAN = ""
                                            objResponseLayoutRp.results.BROADBAND.RelationshipCode = ""

                                            objResponseLayoutRp.results.BROADBAND.effectiveDate = ""
                                            objResponseLayoutRp.results.BROADBAND.PreviousCAN = ""
                                            objResponseLayoutRp.results.BROADBAND.RelationshipInvLevel = ""
                                            objResponseLayoutRp.results.BROADBAND.WADSL = ""
                                            objResponseLayoutRp.results.BROADBAND.A2RDataDate = ""
                                            objResponseLayoutRp.results.BROADBAND.A2RConvStatus = ""
                                            objResponseLayoutRp.results.BROADBAND.ShellAccount = ""
                                            objResponseLayoutRp.results.BROADBAND.FDVPrimaryTN = ""
                                            objResponseLayoutRp.results.BROADBAND.FIOSType = ""
                                            objResponseLayoutRp.results.BROADBAND.ContBillShellDate = ""

                                            If Not objAcctRelation.paymentType Is Nothing Then
                                                objResponseLayoutRp.results.BROADBAND.BillMethod = objAcctRelation.paymentType  ' Bill method and Payment Type or Same???
                                            End If

                                            If Not (String.IsNullOrWhiteSpace(objAcctRelation.hOALevel)) Then
                                                objResponseLayoutRp.results.BROADBAND.HOA_LEVEL = objAcctRelation.hOALevel
                                            End If

                                            If Not (String.IsNullOrWhiteSpace(objAcctRelation.lecBillingAccount)) Then
                                                objResponseLayoutRp.results.BROADBAND.LECBillingAccount = objAcctRelation.lecBillingAccount
                                                objResponseLayoutRp.results.voiceIdentifier.Value = objAcctRelation.lecBillingAccount

                                            ElseIf Not (String.IsNullOrWhiteSpace(objRes.VoiceCAN))

                                                If (objRes.VoiceCAN.Trim().Length = 12) Then 'MDVW account is prefixed with 000 + 9 digit voice can
                                                    If (objRes.VoiceCAN.Trim().Substring(0, 3) = "000") Then
                                                        objResponseLayoutRp.results.BROADBAND.LECBillingAccount = objRes.VoiceCAN.Trim().Substring(3, 9)
                                                        objResponseLayoutRp.results.voiceIdentifier.Value = objRes.VoiceCAN.Trim().Substring(3, 9)
                                                    Else
                                                        objResponseLayoutRp.results.BROADBAND.LECBillingAccount = objRes.VoiceCAN.Trim()
                                                        objResponseLayoutRp.results.voiceIdentifier.Value = objRes.VoiceCAN.Trim().Substring(3, 9)
                                                    End If

                                                Else
                                                    objResponseLayoutRp.results.BROADBAND.LECBillingAccount = objRes.VoiceCAN.Trim()
                                                    objResponseLayoutRp.results.voiceIdentifier.Value = objRes.VoiceCAN.Trim().Substring(3, 9)
                                                End If
                                            End If

                                            If Not (String.IsNullOrWhiteSpace(objRes.SSPBAN)) Then
                                                objResponseLayoutRp.results.BROADBAND.SSPBAN = objRes.SSPBAN
                                            End If

                                            If Not (String.IsNullOrWhiteSpace(objAcctRelation.sSPAcctId)) Then
                                                objResponseLayoutRp.results.BROADBAND.SSPAcctId = objAcctRelation.sSPAcctId
                                            End If

                                            If Not (String.IsNullOrWhiteSpace(objAcctRelation.typeOfAccount)) Then
                                                objResponseLayoutRp.results.BROADBAND.TypeOfAccount = objAcctRelation.typeOfAccount
                                            End If

                                            If Not (String.IsNullOrWhiteSpace(objAcctRelation.state)) Then
                                                objResponseLayoutRp.results.BROADBAND.state = objAcctRelation.state
                                            End If

                                            If objAcctRelation.status = AccountStatusType.Active Then
                                                objResponseLayoutRp.results.BROADBAND.status = "ACTIVE"
                                            ElseIf objAcctRelation.status = AccountStatusType.Deactivated Then
                                                objResponseLayoutRp.results.BROADBAND.status = "DEACTIVATED"
                                            ElseIf objAcctRelation.status = AccountStatusType.Suspended Then
                                                objResponseLayoutRp.results.BROADBAND.status = "SUSPENDED"
                                            ElseIf objAcctRelation.status = AccountStatusType.Inactive Then
                                                objResponseLayoutRp.results.BROADBAND.status = "INACTIVE"
                                            ElseIf objAcctRelation.status = AccountStatusType.VacationSuspend Then
                                                objResponseLayoutRp.results.BROADBAND.status = "VACATION SUSPENDED"
                                            Else
                                                objResponseLayoutRp.results.BROADBAND.status = ""
                                            End If


                                            If Not (String.IsNullOrWhiteSpace(objAcctRelation.billCycle)) Then
                                                objResponseLayoutRp.results.BROADBAND.BillCycle = objAcctRelation.billCycle
                                            End If

                                            If Not (String.IsNullOrWhiteSpace(objAcctRelation.termDate)) Then
                                                objResponseLayoutRp.results.BROADBAND.BBTermDate = objAcctRelation.termDate
                                            End If

                                            If Not (String.IsNullOrWhiteSpace(objAcctRelation.hOAIdentifier)) Then
                                                objResponseLayoutRp.results.BROADBAND.HOA_IDENTIFIER = objAcctRelation.hOAIdentifier
                                            End If

                                        End If
                                    Next

                                End If
                            End If 'Success
                            End If 'overall
                    Next
                End If
            Catch ex As Exception
                objResponseLayoutRp.message.messageText = ex.ToString()
                LogErrorFile.WriteLog("fn_getRelationShip", strInputValue + ex.ToString())
                Return objResponseLayoutRp
                'Throw (ex)
            End Try
            Return objResponseLayoutRp
        End Function
#End Region


#Region "get OrderDetails"

        <WebMethod(Description:="Get Order Details From Ext Apps -VOSE")> _
        Public Function GetOrderDetails(ByVal objOrderDetails As OrderDetails) As RMICWMessage

            Dim objOrderDetailsMessage As OrderDetailsOrder = New OrderDetailsOrder()
            Dim strRegionId As String = "WEST"
            Dim objRMICWMessage As RMICWMessage = New RMICWMessage()

            Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(strRegionId.Trim())
            Try
                ObjDataAccess.usp_InsertOrderStatus(strRegionId, objOrderDetails.Orders.MessageName, objOrderDetails.Orders.RequestId, objOrderDetails.Orders.AccountNum, objOrderDetails.Orders.MONId, objOrderDetails.Orders.OrderEvent, objOrderDetails.Orders.OrderDueDate, objOrderDetails.Orders.OrderEventDateTime)
                objRMICWMessage.messageDesc = "SUCCESS"
                objRMICWMessage.messageCode = "RMW000"
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getOrderDetails", ex.ToString())
                objRMICWMessage.messageDesc = "FAILURE"
                objRMICWMessage.messageCode = "RMW100"
            End Try

            Return objRMICWMessage
        End Function
#End Region

#Region "get Vose Order Response"

        <WebMethod(Description:="get VOSE Order Response")> _
        Public Function getVoseOrderResponse(ByVal objVOSEOrderResponse As VOSEOrderResponse) As RMICWMessage


            Dim strRegionId As String = "WEST"
            Dim sw As New StringWriter
            Dim strvoseResponseXML As String

            Dim objRMICWMessage As RMICWMessage = New RMICWMessage()


            Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(strRegionId.Trim())
            Try
                Dim ser As New XmlSerializer(objVOSEOrderResponse.GetType)
                ser.Serialize(sw, objVOSEOrderResponse)
                strvoseResponseXML = sw.ToString().Trim()
                ObjDataAccess.usp_InserttAuditLog("VOSE", "O", objVOSEOrderResponse.AcctNum, objVOSEOrderResponse.Action, "", "", "", objVOSEOrderResponse.RmicwRequestId, objVOSEOrderResponse.RmicwRequestId, strvoseResponseXML, "VOSERESP")
                ObjDataAccess.usp_UpdateVOSEServiceOrderResults(strvoseResponseXML)
                objRMICWMessage.messageDesc = "SUCCESS"
                objRMICWMessage.messageCode = "RMW000"
                objRMICWMessage.messageTrackingNumber = objVOSEOrderResponse.TrackingNo

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getOrderDetails", objVOSEOrderResponse.AcctNum + ":" + ex.ToString())
                objRMICWMessage.messageDesc = "FAILURE"
                objRMICWMessage.messageCode = "RMW100"
                objRMICWMessage.messageTrackingNumber = objVOSEOrderResponse.TrackingNo

            End Try

            Return objRMICWMessage
        End Function
#End Region

#Region "get E2EDetails"

        <WebMethod(Description:="Get E2E Details")> _
        Public Function getE2EDetails(ByVal strRegionId As String, ByVal strAcctnum As String, ByVal strOrg As String)

            'Dim objOrderDetailsMessage As OrderDetailsMessage = New OrderDetailsMessage()
            Dim dsE2E As DataSet
            Dim dtE2E As DataTable
            Dim drE2E As DataRow
            Dim objE2EList As E2EAcctList
            Dim objArrLstE2EBlock As ArrayList = New ArrayList()
            Dim objsubEvent As E2EAcctList.SubEvent = New E2EAcctList.SubEvent()





            Try

                Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(strRegionId.Trim())
                dsE2E = ObjDataAccess.usp_GetE2EDetails(strAcctnum, strOrg, strRegionId)

                For I As Integer = 0 To dsE2E.Tables.Count - 1
                    dtE2E = dsE2E.Tables(I) 'For Each dtE2E In dsE2E.Tables
                    For j As Integer = 0 To dtE2E.Rows.Count - 1
                        drE2E = dtE2E.Rows(j)
                        'For Each drE2E In dtE2E.Rows
                        objE2EList = New E2EAcctList
                        objE2EList.strAcctNum = drE2E("strAcctNum")
                        objE2EList.strEventType = drE2E("strEventType")
                        objE2EList.strUserId = drE2E("strUserId")
                        objE2EList.strUserId = drE2E("strUserId")
                        objE2EList.strReason = drE2E("strReason")
                        objE2EList.curTotalPastDue = drE2E("curTotalPastDue")
                        objE2EList.dtmPrcsdTs = drE2E("dtmPrcsdTs")
                        objE2EList.curTotalDue = drE2E("curTotalDue")
                        objE2EList.dtmSatisfyTs = drE2E("dtmSatisfyTs")
                        objE2EList.strSystemId = drE2E("strSystemId")
                        objE2EList.strSystemId = drE2E("strSystemId")
                        Select Case objE2EList.strEventType.Trim()
                            Case "ADD"
                                objsubEvent.dtmAddTs = objE2EList.dtmPrcsdTs
                            Case "EXIT"
                                objsubEvent.dtmExitTs = objE2EList.dtmSatisfyTs
                        End Select
                        objArrLstE2EBlock.Add(objsubEvent)

                        If (objsubEvent.dtmAddTs <= objE2EList.dtmPrcsdTs) And (objE2EList.dtmPrcsdTs >= objsubEvent.dtmExitTs) Then
                            If Not (objsubEvent.ht.ContainsKey(objE2EList.strEventType.Trim()) = objE2EList.strEventType.Trim()) Then
                                objsubEvent.ht.Add(objE2EList.strEventType.Trim(), objE2EList.dtmPrcsdTs)
                            End If




                        End If

                    Next j
                Next I
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getE2EDetails", ex.ToString())


            End Try

        End Function
#End Region


        '#Region "get TreatmentEvents"

        '        <WebMethod(Description:="Get TreatmentEvents")> _
        '        Public Function getTreatmentEvents(ByVal strRegionId As String, ByVal strAcctnum As String, ByVal strOrg As String, ByVal strAppId As String) As RmicwEvents

        '            'EventInfo (LTR/PTP/CLM-latest E2E) 
        '            'BalanceInfo(getTreatmentDetailsCall)  
        '            'PPXInfo (getPPXInfo) 



        '            Dim dsE2E As DataSet
        '            Dim dtE2E As DataTable
        '            Dim drE2E As DataRow

        '            Dim objArrLstE2EBlock As ArrayList = New ArrayList()
        '            Dim objsubEvent As E2EAcctList.SubEvent = New E2EAcctList.SubEvent()

        '            Dim objRmicwEvents As RmicwEvents = New RmicwEvents()




        '            Dim objTDResp As TD_Response = New TD_Response
        '            Dim objWSMain As WSMain = New WSMain()



        '            Try


        '                objTDResp = objWSMain.getTreatmentDetails(strRegionId, strOrg, "A", strAppId, strAcctnum)

        '                objRmicwEvents.TreatmentDetails = objTDResp

        '                'Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(strRegionId.Trim())
        '                'dsE2E = ObjDataAccess.usp_GetE2EDetails(strAcctnum, strOrg, strRegionId)

        '                'For Each dtE2E In dsE2E.Tables
        '                '    For Each drE2E In dtE2E.Rows

        '                '        objRmicwEvents.EventList.strAcctNum = drE2E("strAcctNum")
        '                '        objRmicwEvents.EventList.strEventType = drE2E("strEventType")
        '                '        objRmicwEvents.EventList.strUserId = drE2E("strUserId")
        '                '        objRmicwEvents.EventList.strReason = drE2E("strReason")
        '                '        objRmicwEvents.EventList.curTotalPastDue = drE2E("curTotalPastDue")
        '                '        objRmicwEvents.EventList.dtmPrcsdTs = drE2E("dtmPrcsdTs")
        '                '        objRmicwEvents.EventList.curTotalDue = drE2E("curTotalDue")
        '                '        objRmicwEvents.EventList.dtmSatisfyTs = drE2E("dtmSatisfyTs")
        '                '        objRmicwEvents.EventList.strSystemId = drE2E("strSystemId")

        '                '        Select Case objRmicwEvents.strEventInfo.strEventType.Trim()
        '                '            Case "ADD"
        '                '                objsubEvent.dtmAddTs = objRmicwEvents.EventList.dtmPrcsdTs
        '                '            Case "EXIT"
        '                '                objsubEvent.dtmExitTs = objRmicwEvents.EventList.dtmSatisfyTs
        '                '        End Select
        '                '        objArrLstE2EBlock.Add(objsubEvent)

        '                '        If (objsubEvent.dtmAddTs <= objRmicwEvents.EventList.dtmPrcsdTs) And (objRmicwEvents.EventList.dtmPrcsdTs >= objsubEvent.dtmExitTs) Then
        '                '            If Not (objsubEvent.ht.ContainsKey(objRmicwEvents.EventList.strEventType.Trim()) = objRmicwEvents.EventList.strEventType.Trim()) Then
        '                '                objsubEvent.ht.Add(objRmicwEvents.EventList.strEventType.Trim(), objRmicwEvents.EventList.dtmPrcsdTs)
        '                '            End If

        '                '        End If

        '                '    Next drE2E
        '                'Next dtE2E
        '            Catch ex As Exception
        '                LogErrorFile.WriteLog("RMICWWS-getTreatmentEvents", ex.ToString())

        '            End Try

        '            Return objRmicwEvents


        '        End Function
        '#End Region


#Region "Get Allfinancialtransactions"
        <WebMethod(Description:="Get Allfinancialtransactions Details From Ext Apps - Cofee")> _
        Public Function GetAllfinancialtransactions(ByVal strRegion As String, ByVal strAccountNum As String, ByVal strCompany As String, ByVal strState As String, ByVal strIsFios As String) As XmlDocument
            Dim objCoffeeWS As GetAllFinancialTransactionsForWest.GetAllfinancialtransactions
            objCoffeeWS = New GetAllFinancialTransactionsForWest.GetAllfinancialtransactions
            Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric()
            Dim xmlstrCofeeResponseDoc As XmlDocument = New XmlDocument

            Dim strCoffeeinput As String = ""
            Dim strCofeeResponse As String = ""
            Dim strUserID As String = "RMICW2"
            Dim strPasswd As String = "verizon123"
            Dim requestContext As SoapContext
            Dim strInputXml As String = ""
            Dim strAddingZero As String = String.Empty
            Dim xmlSer As XmlSerializer
            Dim intCount As Integer
            Dim objCoffInput As Request
            objCoffInput = New Request

            objCoffInput.strUserID = strUserID
            objCoffInput.strPasswd = strPasswd
            If (strAccountNum.Length < 10) Then
                For intCount = 1 To 10 - strAccountNum.Length
                    strAddingZero = "0"
                    strAccountNum = strAddingZero + strAccountNum
                Next
            End If
            objCoffInput.strAccountNum = strAccountNum
            objCoffInput.strCallingParty = "RMICW"
            objCoffInput.strState = strState
            objCoffInput.strCompany = strCompany
            objCoffInput.strRegion = strRegion
            objCoffInput.strJurisdiction = ""
            objCoffInput.strLobCode = ""
            objCoffInput.strRAO = ""
            objCoffInput.strLongDistanceIndicator = ""
            objCoffInput.strIsFios = strIsFios

            xmlSer = New XmlSerializer(GetType(Request))
            strCoffeeinput = CommonLibrary.GeneralRoutine.SerializeTxn(xmlSer, objCoffInput)
            strCoffeeinput = strCoffeeinput.Replace("utf-16", "utf-8")

            Dim ds As New DataSet
            Dim strReadXml As String
            Dim XmlTxtReader As XmlTextReader

            XmlTxtReader = New XmlTextReader(New StringReader(strCoffeeinput))
            XmlTxtReader.ReadOuterXml()
            ds.ReadXml(XmlTxtReader)
            strReadXml = ds.GetXml()

            Try

                requestContext = objCoffeeWS.RequestSoapContext
                objCoffeeWS.Proxy = New WebProxy
                requestContext.Security.Tokens.Clear()

                Dim unt As UsernameToken = New UsernameToken("RMW", "rmicw05", PasswordOption.SendPlainText)
                requestContext.Security.Tokens.Add(unt)
                requestContext.Security.MustUnderstand = False

                If (strRegion.Trim.ToUpper = "WEST") Or (strRegion.Trim.ToUpper <> "WEST" And strIsFios.Trim.ToUpper = "TRUE") Then
                    objCoffeeWS.Url = ObjDataAccess.usp_GetControlParmByName("ControlWEST", "COFEEADJURL")
                Else
                    objCoffeeWS.Url = ObjDataAccess.usp_GetControlParmByName("ControlEAST", "COFEEADJURL")
                End If
                objCoffeeWS.Timeout = 60000
                ObjDataAccess.usp_InserttAuditLog("VZW", "I", objCoffInput.strAccountNum.Trim(), "NA", "NA", "NA", "NA", 0, 0, strReadXml.Trim(), "WebSvc")

                strCofeeResponse = objCoffeeWS.getAllFinancialTransactions(strReadXml)

                ObjDataAccess.usp_InserttAuditLog("VZW", "O", objCoffInput.strAccountNum.Trim(), "NA", "NA", "NA", "NA", 0, 0, strCofeeResponse.Trim(), "WebSvc")

                If strCofeeResponse.Trim() <> "" Then

                    strCofeeResponse = System.Text.RegularExpressions.Regex.Replace(strCofeeResponse, "[+~!@#$%^&*()_+{}|]", "")
                    strCofeeResponse = System.Text.RegularExpressions.Regex.Replace(strCofeeResponse, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline))
                    xmlstrCofeeResponseDoc.LoadXml(strCofeeResponse)
                    xmlstrCofeeResponseDoc.LoadXml(System.Text.RegularExpressions.Regex.Replace(xmlstrCofeeResponseDoc.OuterXml, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline)))

                End If


                Return xmlstrCofeeResponseDoc
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getAllfinancialtransactions", ex.ToString())
            End Try
        End Function
#End Region

#Region "getVzOrder"
        <WebMethod(Description:="getVzOrder")> _
        Public Function getVzOrder(ByVal strRegion As String, ByVal strState As String, ByVal strAccountNum As String, ByVal strMON As String, ByVal intRequestId As Integer, ByVal strEnvironment As String) As XmlDocument
            Dim objgetVzOrder As getVzOrderRequest = New getVzOrderRequest()
            Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric()

            objgetVzOrder.HeaderInfo.requestHeaderInfo.applicationName = "RMICW"
            objgetVzOrder.HeaderInfo.requestHeaderInfo.applicationId = "RMW"
            objgetVzOrder.HeaderInfo.requestHeaderInfo.ClientMachineName = System.Environment.MachineName
            objgetVzOrder.HeaderInfo.requestHeaderInfo.RepLoginCode = "v734049"
            objgetVzOrder.HeaderInfo.requestHeaderInfo.AppServerName = System.Environment.MachineName '"11.11.1111"
            objgetVzOrder.HeaderInfo.requestHeaderInfo.AppServerTimeStamp = Now().ToString("MM/dd/yyyy hh:mm:ss EST")
            objgetVzOrder.HeaderInfo.requestHeaderInfo.TrackingNumber = intRequestId.ToString().Trim()
            objgetVzOrder.HeaderInfo.requestHeaderInfo.AdditionalInfo = strAccountNum.Trim()

            objgetVzOrder.MON = Checkdigit(strMON.Trim(), strEnvironment)
            objgetVzOrder.serviceState = strState.Trim()

            Dim xmlOrderViewDoc As XmlDocument = New XmlDocument
            Dim strgetVzOrderinput As String = ""
            Dim strgetVzOrderResponse As String = ""
            Dim requestContext As SoapContext
            Dim xmlSer As XmlSerializer

            xmlSer = New XmlSerializer(GetType(getVzOrderRequest))
            strgetVzOrderinput = CommonLibrary.GeneralRoutine.SerializeTxn(xmlSer, objgetVzOrder)
            strgetVzOrderinput = strgetVzOrderinput.Remove(0, strgetVzOrderinput.IndexOf("<getVzOrderRequest") - 1)
            strgetVzOrderinput = strgetVzOrderinput.Remove(20, strgetVzOrderinput.IndexOf("xmlns=") - 20)

            Try
                Dim objWS As NCOGWebServices.NCOGWebServices = New NCOGWebServices.NCOGWebServices()
                'requestContext = objWS.RequestSoapContext
                'objWS.Proxy = New WebProxy

                If ((strRegion = "") Or (strRegion Is Nothing)) Then
                    LogErrorFile.WriteLog("RMICWWS-getVzOrder", " Region is empty: " & strRegion)
                End If

                If (strRegion.Trim.ToUpper.Trim() = "WEST") Then
                    objWS.Url = ObjDataAccess.usp_GetControlParmByName("ControlWEST", "NCOGWSUrl")
                Else
                    objWS.Url = ObjDataAccess.usp_GetControlParmByName("ControlEAST", "NCOGWSUrl")
                End If

                objWS.Timeout = 60000
                'Logging Input Xml
                ObjDataAccess.usp_InserttAuditLog("VzOrder-NCOG", "I", strAccountNum.Trim(), "NA", "NA", "NA", "NA", 0, 0, strgetVzOrderinput.Trim(), "WebSvc")

                'Call NCOG Webmethod
                strgetVzOrderResponse = objWS.getVzOrder(strgetVzOrderinput)

                'Logging Output Xml
                ObjDataAccess.usp_InserttAuditLog("VzOrder-NCOG", "O", strAccountNum.Trim(), "NA", "NA", "NA", "NA", 0, 0, strgetVzOrderResponse.Trim(), "WebSvc")

                If strgetVzOrderResponse.Trim() <> "" Then

                    strgetVzOrderResponse = System.Text.RegularExpressions.Regex.Replace(strgetVzOrderResponse, "[+~!@#$%^&*()_+{}|]", "")
                    strgetVzOrderResponse = System.Text.RegularExpressions.Regex.Replace(strgetVzOrderResponse, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline))
                    xmlOrderViewDoc.LoadXml(strgetVzOrderResponse)
                    xmlOrderViewDoc.LoadXml(System.Text.RegularExpressions.Regex.Replace(xmlOrderViewDoc.OuterXml, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline)))

                End If

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getVzOrder", ex.ToString())
            End Try
            Return xmlOrderViewDoc
        End Function
#End Region

#Region "getVzOrderListInfo"
        <WebMethod(Description:="getVzOrderListInfo")> _
        Public Function getVzOrderListInfo(ByVal strRegion As String, ByVal strState As String, ByVal strAccountNum As String, ByVal intRequestId As Integer) As XmlDocument

            Dim objgetVzOrderListInofWS As getVzOrderListInfoRequest = New getVzOrderListInfoRequest()
            Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric()


            'requestHeaderInfo
            objgetVzOrderListInofWS.HeaderInfo.requestHeaderInfo.applicationName = "RMICW"
            objgetVzOrderListInofWS.HeaderInfo.requestHeaderInfo.applicationId = "RMW"
            objgetVzOrderListInofWS.HeaderInfo.requestHeaderInfo.ClientMachineName = System.Environment.MachineName
            objgetVzOrderListInofWS.HeaderInfo.requestHeaderInfo.RepLoginCode = "v734049"
            objgetVzOrderListInofWS.HeaderInfo.requestHeaderInfo.AppServerName = System.Environment.MachineName '"11.11.1111"
            objgetVzOrderListInofWS.HeaderInfo.requestHeaderInfo.AppServerTimeStamp = Now().ToString("MM/dd/yyyy hh:mm:ss EST")
            objgetVzOrderListInofWS.HeaderInfo.requestHeaderInfo.TrackingNumber = intRequestId.ToString().Trim()
            'serviceState
            objgetVzOrderListInofWS.serviceState = strState.Trim()
            'tn
            objgetVzOrderListInofWS.RequestInfo.tn.tnAreaCode = strAccountNum.Substring(0, 3)
            objgetVzOrderListInofWS.RequestInfo.tn.tnPrefix = strAccountNum.Substring(3, 3)
            objgetVzOrderListInofWS.RequestInfo.tn.tnBase = strAccountNum.Substring(6, 4)

            Dim xmlOrderViewDoc As XmlDocument = New XmlDocument
            Dim strgetVzOrderListInfoinput As String = ""
            Dim strgetVzOrderListInfoResponse As String = ""
            Dim requestContext As SoapContext
            Dim xmlSer As XmlSerializer



            xmlSer = New XmlSerializer(GetType(getVzOrderListInfoRequest))
            strgetVzOrderListInfoinput = CommonLibrary.GeneralRoutine.SerializeTxn(xmlSer, objgetVzOrderListInofWS)
            strgetVzOrderListInfoinput = strgetVzOrderListInfoinput.Remove(0, strgetVzOrderListInfoinput.IndexOf("<getVzOrderListInfoRequest") - 1)
            strgetVzOrderListInfoinput = strgetVzOrderListInfoinput.Remove(strgetVzOrderListInfoinput.IndexOf("<getVzOrderListInfoRequest") + 27, strgetVzOrderListInfoinput.IndexOf("xmlns=") - (strgetVzOrderListInfoinput.IndexOf("<getVzOrderListInfoRequest") + 27))


            Try
                Dim objWS As NCOGWebServices.NCOGWebServices = New NCOGWebServices.NCOGWebServices()
                requestContext = objWS.RequestSoapContext
                objWS.Proxy = New WebProxy

                If ((strRegion = "") Or (strRegion Is Nothing)) Then
                    LogErrorFile.WriteLog("RMICWWS-getVzOrderListInfo", " Region is empty: " & strRegion)
                End If

                If (strRegion.Trim.ToUpper.Trim() = "WEST") Then
                    objWS.Url = ObjDataAccess.usp_GetControlParmByName("ControlWEST", "NCOGWSUrl")
                Else
                    objWS.Url = ObjDataAccess.usp_GetControlParmByName("ControlEAST", "NCOGWSUrl")
                End If

                objWS.Timeout = 60000
                'Logging Input Xml
                ObjDataAccess.usp_InserttAuditLog("VzOrderlist-NCOG", "I", strAccountNum.Trim(), "NA", "NA", "NA", "NA", 0, 0, strgetVzOrderListInfoinput.Trim(), "WebSvc")

                'Call NCOG Webmethod
                strgetVzOrderListInfoResponse = objWS.getVzOrderListInfo(strgetVzOrderListInfoinput)

                'Logging Output Xml
                ObjDataAccess.usp_InserttAuditLog("VzOrderlist-NCOG", "O", strAccountNum.Trim(), "NA", "NA", "NA", "NA", 0, 0, strgetVzOrderListInfoResponse.Trim(), "WebSvc")
                'Return strgetVzOrderListInfoResponse

                If strgetVzOrderListInfoResponse.Trim() <> "" Then

                    strgetVzOrderListInfoResponse = System.Text.RegularExpressions.Regex.Replace(strgetVzOrderListInfoResponse, "[+~!@#$%^&*()_+{}|]", "")
                    strgetVzOrderListInfoResponse = System.Text.RegularExpressions.Regex.Replace(strgetVzOrderListInfoResponse, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline))
                    xmlOrderViewDoc.LoadXml(strgetVzOrderListInfoResponse)
                    xmlOrderViewDoc.LoadXml(System.Text.RegularExpressions.Regex.Replace(xmlOrderViewDoc.OuterXml, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline)))

                End If
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getVzOrderListInfo", ex.ToString())
            End Try
            Return xmlOrderViewDoc
        End Function
#End Region

#Region "getFiosOrderImage"
        <WebMethod(Description:="getFiosOrderImage")> _
        Public Function getFiosOrderImage(ByVal strRegionId As String, ByVal strOrderId As String, ByVal strAcctNum As String, ByVal strProfileCAN As String, ByVal intRequestId As Integer) As XmlDocument
            Dim strOrderView As String = ""

            Dim getURL As wsGETURL = New wsGETURL
            Dim posturl As String = ""
            Dim strOrderViewurl As String = ""
            Dim strOrderviewOut As String = ""
            Dim strOrderviewIn As String = ""
            Dim xmlOrderViewDoc As XmlDocument = New XmlDocument
            Dim objOrderViewService As SSPOrderViewService = New SSPOrderViewService
            Dim objSSPOrderImage As OrderViewService = New OrderViewService




            Try





                Dim objChangeAcct As MOGServiceChangeAccount = New MOGServiceChangeAccount
                Dim objAuth As AuthenticationType = New AuthenticationType


                objSSPOrderImage.GetOrderView.orderId = strOrderId.Trim()




                strOrderViewurl = getURL.getSSPURL(strRegionId.Trim(), "SSPORDERVIEW")

                If strOrderViewurl.Trim() = "" Then

                    LogErrorFile.WriteLog("RMICWWebServices-getSSPPROFILE", "Empty Profile URL:" + strOrderViewurl)

                End If


                Dim strxml As String = ""
                Dim xmlSer As XmlSerializer = New XmlSerializer(GetType(OrderViewService))
                strOrderviewIn = CommonLibrary.GeneralRoutine.SerializeTxn(xmlSer, objSSPOrderImage)
                Dim objRequestContext As SoapContext

                objRequestContext = objOrderViewService.RequestSoapContext
                objOrderViewService.Proxy = New WebProxy
                objRequestContext.Security.Tokens.Clear()
                Dim unt As Tokens.UsernameToken = New Tokens.UsernameToken("RMW", "rmicw05", Tokens.PasswordOption.SendPlainText)
                objRequestContext.Security.Tokens.Add(unt)
                objRequestContext.Security.MustUnderstand = False
                objOrderViewService.Url = strOrderViewurl.Trim()
                'objRetrievalServiceTxn.Timeout = 60000
                'Thread.Sleep(100)
                objOrderViewService.RequestSoapContext.Addressing.MustUnderstand = False
                strOrderviewOut = objOrderViewService.doRequest(strOrderviewIn.Trim())

                If strOrderviewOut.Trim() <> "" Then

                    strOrderviewOut = System.Text.RegularExpressions.Regex.Replace(strOrderviewOut, "[+~!@#$%^&*()_+{}|]", "")
                    strOrderviewOut = System.Text.RegularExpressions.Regex.Replace(strOrderviewOut, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline))
                    xmlOrderViewDoc.LoadXml(strOrderviewOut)
                    xmlOrderViewDoc.LoadXml(System.Text.RegularExpressions.Regex.Replace(xmlOrderViewDoc.OuterXml, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline)))

                End If


            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWebServices-getFiosOrderImage", ex.ToString())

            End Try
            Return xmlOrderViewDoc
        End Function
#End Region

#Region "getPPXinfo"
        <WebMethod(Description:="getPPXinfo")> _
        Public Function getPPXinfo(ByVal strRegionId As String, ByVal strAcctNum As String) As XmlDocument
            Dim strPPXUrl As String = ""
            Dim curPPXAmt As Double = 0
            Dim getURL As wsGETURL = New wsGETURL
            Dim xmlResultDoc As XmlDocument = New XmlDocument

            Try

                strPPXUrl = getURL.getSSPURL(strRegionId.Trim(), "PPXWebServices")

                Dim Objws As PPXWebServices.PPXSplitter = New PPXWebServices.PPXSplitter
                Dim strResponse As String


                Objws.Url = strPPXUrl
                strResponse = Objws.GetPPXInfo(strAcctNum, "t" + strRegionId, "RMICW")
                xmlResultDoc.LoadXml(strResponse)

            Catch ex As Exception
                LogErrorFile.WriteLog("getCBSS_CBSPCFA1_BalanceInfo West", "AcctNum: " & strAcctNum & " Erroring Out while getting PPX Info " & ex.ToString)
            End Try
            Return xmlResultDoc

        End Function
#End Region

        Public Shared Function Checkdigit(ByVal orderNum As String, ByVal strEnvironment As String) As String
            Dim ct As Integer = 0
            Dim sum As Integer = 0

            orderNum = orderNum.PadLeft(7, "0"c)

            Select Case strEnvironment
                Case "GTSW"
                    orderNum = "0" + "S" + orderNum
                Case "GTES"
                    orderNum = "0" + "M" + orderNum
                Case "GTFL"
                    orderNum = "0" + "F" + orderNum
                Case "GTCA"
                    orderNum = "0" + "C" + orderNum
            End Select
            'For ct = 0 To orderNum.Length - 1
            '    sum = sum + Integer.Parse(orderNum.Substring(ct, 1))
            'Next

            'orderNum = (10 - (sum Mod 10)).ToString() & "0" & orderNum
            'If orderNum.Length > 9 Then
            '    orderNum = orderNum.Substring(1, 9)
            'End If

            Return orderNum
        End Function


#Region "FULL Profile webmethod - NCOG "
        <WebMethod(Description:="FULL CSR Profile webmethod from NCOG")> _
        Public Function GetNCOGProfile(ByVal strRegionCd As String, ByVal strAcctNum As String, ByVal strState As String, ByVal IntRequestid As Integer) As String
            Dim posturl As String = ""
            Dim xmliFinalDoc As XmlDocument = New XmlDocument
            Dim strUrl As String
            Dim strOutput As String = ""
            Dim strInputXml As String = ""
            Dim MyEnumVal As StateType
            Dim sw As New StringWriter
            Dim strTrackId = Guid.NewGuid.ToString()

            Try

                'Pull the URL from tcontrolparm table...
                Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(strRegionCd.Trim())
                strUrl = ObjDataAccess.usp_GetControlParmByName("Control" + strRegionCd.Trim(), "NCOGURL")

                Dim objNcogWS As New NCOGAssignNumber.NCOGWebServices

                objNcogWS.Url = strUrl
                Dim RequestContext As SoapContext
                RequestContext = objNcogWS.RequestSoapContext
                objNcogWS.Proxy = New WebProxy
                RequestContext.Security.Tokens.Clear()
                Dim userToken As UsernameToken = New UsernameToken("" + "RMW" + "", "" + "rmicw05" + "", PasswordOption.SendPlainText)
                RequestContext.Security.Tokens.Add(userToken)
                RequestContext.Security.MustUnderstand = False
                objNcogWS.Timeout = 90000
                objNcogWS.RequestSoapContext.Addressing.MustUnderstand = False

                Dim Objinp As New getVZFullProfileRequest

                Objinp.HeaderInfo.requestHeaderInfo.applicationName = "RMICW"
                Objinp.HeaderInfo.requestHeaderInfo.applicationId = "RMW"
                Objinp.HeaderInfo.requestHeaderInfo.ClientMachineName = System.Environment.MachineName
                Objinp.HeaderInfo.requestHeaderInfo.RepLoginCode = "RMICW"
                Objinp.HeaderInfo.requestHeaderInfo.AppServerName = System.Environment.MachineName
                Objinp.HeaderInfo.requestHeaderInfo.AppServerTimeStamp = Now().ToString("MM/dd/yyyy hh:mm:ss EST")
                Objinp.HeaderInfo.requestHeaderInfo.TrackingNumber = strTrackId
                Objinp.RequestInfo.Profile.VoiceInfo = "Y"
                Objinp.RequestInfo.Profile.DataVideoInfo = "N"

                'Convert string to Enum type for the State Value...
                MyEnumVal = CType(System.Enum.Parse(GetType(StateType), strState.Trim()), StateType)
                Objinp.RequestInfo.serviceState = MyEnumVal

                'Set the Input value based on Region...
                Select Case strRegionCd.ToUpper().Trim()
                    Case "WEST"
                        Objinp.RequestInfo.GeneralSearch.CAN = strAcctNum
                    Case "NPD", "NY", "NE"
                        Objinp.RequestInfo.GeneralSearch.tn.tnAreaCode = strAcctNum.Substring(0, 3)
                        Objinp.RequestInfo.GeneralSearch.tn.tnPrefix = strAcctNum.Substring(3, 3)
                        Objinp.RequestInfo.GeneralSearch.tn.tnBase = strAcctNum.Substring(6, 4)
                    Case "MDVW"
                        Objinp.RequestInfo.GeneralSearch.BlactSpecified = True
                        Objinp.RequestInfo.GeneralSearch.Blact = strAcctNum.PadLeft(12, "0")
                End Select

                ' Always same params...
                Objinp.RequestInfo.AdditionalParameters.OrderFilteringCode = "00"
                Objinp.RequestInfo.AdditionalParameters.numberOfDays = "5"
                Objinp.RequestInfo.AdditionalParameters.SuppressVoiceDataPendingOrders = False 'getVZFullProfileRequest.VoiceDataProfileType.Both
                Objinp.RequestInfo.AdditionalParameters.UseExpress = "Y"

                'Serialize the xml to pass to Webmethod...
                Dim ser As New XmlSerializer(Objinp.GetType)
                ser.Serialize(sw, Objinp)
                strInputXml = sw.ToString()
                If strRegionCd = "WEST" Or strRegionCd = "MDVW" Then ' For WEST and MDVW, the TN tag is not required...
                    If (strInputXml.Contains("<tn />")) Then
                        strInputXml = strInputXml.Replace("<tn />", "")
                    End If
                End If

                'Remove the XmlNamespace/Junk data from input xml
                Dim startIndex As Integer = strInputXml.ToString().IndexOf("<HeaderInfo>")
                strInputXml = strInputXml.Remove(0, startIndex)
                strInputXml = strInputXml.Insert(0, "<getVZFullProfileRequest xmlns=""http://verizon.com/ONE/"">")
                strInputXml = strInputXml.Replace(vbCrLf, "")

                'Call the method!!
                strOutput = objNcogWS.GetVzFullProfile(strInputXml)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-GetNCOGProfile:" + strAcctNum + "/" + strRegionCd, ex.ToString())
            End Try
            Return strOutput
        End Function
#End Region

#Region "Video Profile webmethod - NCOG "
        <WebMethod(Description:="FULL CSR Profile webmethod from NCOG")> _
        Public Function GetNCOGVideoProfile(ByVal strRegionCd As String, ByVal strAcctNum As String, ByVal IntRequestid As Integer) As String
            Dim posturl As String = ""
            Dim xmliFinalDoc As XmlDocument = New XmlDocument
            Dim strUrl As String
            Dim strOutput As String = ""
            Dim strInputXml As String = ""
            Dim sw As New StringWriter
            Try


                'Pull the URL from tcontrolparm table...
                Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(strRegionCd.Trim())
                strUrl = ObjDataAccess.usp_GetControlParmByName("Control" + strRegionCd.Trim(), "NCOGURL")

                Dim objNcogWS As New NCOGAssignNumber.NCOGWebServices
                objNcogWS.Url = strUrl
                Dim RequestContext As SoapContext
                RequestContext = objNcogWS.RequestSoapContext
                objNcogWS.Proxy = New WebProxy
                RequestContext.Security.Tokens.Clear()
                Dim userToken As UsernameToken = New UsernameToken("" + "RMW" + "", "" + "rmicw05" + "", PasswordOption.SendPlainText)
                RequestContext.Security.Tokens.Add(userToken)
                RequestContext.Security.MustUnderstand = False
                objNcogWS.Timeout = 90000
                objNcogWS.RequestSoapContext.Addressing.MustUnderstand = False


                Dim Objinp As New getVideoProfileWithBalancesRequest


                Objinp.HeaderInfo.requestHeaderInfo.applicationName = "RMICW"
                Objinp.HeaderInfo.requestHeaderInfo.applicationId = "RMW"
                Objinp.HeaderInfo.requestHeaderInfo.ClientMachineName = System.Environment.MachineName
                Objinp.HeaderInfo.requestHeaderInfo.RepLoginCode = "RMICW"
                Objinp.HeaderInfo.requestHeaderInfo.AppServerName = System.Environment.MachineName
                Objinp.HeaderInfo.requestHeaderInfo.AppServerTimeStamp = Now().ToString("MM/dd/yyyy hh:mm:ss EST")
                Objinp.HeaderInfo.requestHeaderInfo.TrackingNumber = IntRequestid
                Objinp.inputValue = strAcctNum
                Objinp.region = strRegionCd
                Objinp.inputTypeIndicator = inputTypeIndicatorType.BROADBAND

                'Serialize the xml to pass to Webmethod...
                Dim ser As New XmlSerializer(Objinp.GetType)
                ser.Serialize(sw, Objinp)
                strInputXml = sw.ToString()

                'Remove the XmlNamespace/Junk data from input xml
                Dim startIndex As Integer = strInputXml.ToString().IndexOf("<HeaderInfo>")
                strInputXml = strInputXml.Remove(0, startIndex)
                strInputXml = strInputXml.Insert(0, "<getVideoProfileWithBalancesRequest xmlns=""http://verizon.com/ONE/"">")
                strInputXml = strInputXml.Replace(vbCrLf, "")

                'Call the method!!
                strOutput = objNcogWS.getVideoProfileWithBalances(strInputXml)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-GetNCOGVideoProfile:" + strAcctNum + "/" + strRegionCd, ex.ToString())
            End Try
            Return strOutput
        End Function
#End Region
#Region "PPV [Pay Per View webmethod - NCOG "
        <WebMethod(Description:="PPV webmethod from NCOG")> _
        Public Function GetPPVInfoService(ByVal strRegionCd As String, ByVal strAcctNum As String, ByVal intRequestid As Integer, ByVal strPPVServiceType As String) As XmlDataDocument
            Dim posturl As String = ""
            Dim xmliFinalDoc As XmlDocument = New XmlDocument
            Dim strUrl As String
            Dim strOutput As String = ""
            Dim strInputXml As String = ""
            'Dim MyEnumVal As getVZFullProfileRequest.stateTypeNcog
            Dim sw As New StringWriter

            Dim xmlDoc As XmlDataDocument
            xmlDoc = New XmlDataDocument
            Dim objVisionSSPPA As VisionSSPPA = New VisionSSPPA()
            Try

                'If strRegionCd.ToUpper.Trim() = "WEST" Then
                '    strUrl = "HTTP://SACS1LRCW01.ITUTL1.ITCENT.EBIZ.VERIZON.COM/MARJUNSEPDEC/NCOGWEBSERVICES.ASMX"
                'Else
                '    strUrl = "HTTP://SACU1LRFCW01.ITUTL1.ITCENT.EBIZ.VERIZON.COM/MARJUNSEPDEC/NCOGWEBSERVICES.ASMX"
                'End If
                Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(strRegionCd.Trim())
                If strRegionCd = "VISION" Then

                    xmlDoc = objVisionSSPPA.getPPVInfo(strAcctNum, intRequestid, strPPVServiceType)

                    Return xmlDoc


                Else
                    strUrl = ObjDataAccess.usp_GetControlParmByName("Control" + strRegionCd.Trim(), "NCOGURL")
                End If

                'strUrl = "http://SACD1LRONA02.ITUTL1.ITCENT.EBIZ.VERIZON.COM/MarJunSepDec/NCOGWebServices.asmx"

                Dim objNcogWS As New NCOGAssignNumber.NCOGWebServices
                objNcogWS.Url = strUrl
                Dim RequestContext As SoapContext
                RequestContext = objNcogWS.RequestSoapContext
                objNcogWS.Proxy = New WebProxy
                RequestContext.Security.Tokens.Clear()

                Dim userToken As UsernameToken = New UsernameToken("" + "RMW" + "", "" + "rmicw05" + "", PasswordOption.SendPlainText)
                RequestContext.Security.Tokens.Add(userToken)
                RequestContext.Security.MustUnderstand = False

                objNcogWS.Timeout = 90000
                objNcogWS.RequestSoapContext.Addressing.MustUnderstand = False
                Dim Objinp

                If (strPPVServiceType.ToUpper.ToString().Trim = "PPVEVENTS") Then
                    Objinp = New getPPVInfoRequest
                ElseIf (strPPVServiceType.ToUpper.ToString().Trim = "RBALEVENTS") Then
                    Objinp = New getRemainingBalanceInfoRequest
                ElseIf (strPPVServiceType.ToUpper.ToString().Trim = "UNBILLEVENTS") Then
                    Objinp = New getUnBilledInfoRequest
                End If

                Objinp.HeaderInfo.requestHeaderInfo.applicationName = "RMICW"
                Objinp.HeaderInfo.requestHeaderInfo.applicationId = "RMW"
                Objinp.HeaderInfo.requestHeaderInfo.ClientMachineName = System.Environment.MachineName
                Objinp.HeaderInfo.requestHeaderInfo.RepLoginCode = "RMICW"
                Objinp.HeaderInfo.requestHeaderInfo.AppServerName = System.Environment.MachineName
                Objinp.HeaderInfo.requestHeaderInfo.AppServerTimeStamp = Now().ToString("MM/dd/yyyy hh:mm:ss EST")
                Objinp.HeaderInfo.requestHeaderInfo.TrackingNumber = intRequestid

                If (strPPVServiceType.ToUpper.ToString().Trim = "PPVEVENTS") Then

                    Objinp.PPVService.PPVEvents.inputValue = strAcctNum
                    Objinp.PPVService.PPVEvents.region = strRegionCd
                    Objinp.PPVService.PPVEvents.inputTypeIndicator = inputTypeIndicatorType.BROADBAND
                    Objinp.PPVService.PPVEvents.requestType = "BILLED"

                ElseIf (strPPVServiceType.ToUpper.ToString().Trim = "RBALEVENTS") Then

                    Objinp.PPVService.RemainingBalanceInfo.inputValue = strAcctNum
                    Objinp.PPVService.RemainingBalanceInfo.region = strRegionCd
                    Objinp.PPVService.RemainingBalanceInfo.inputTypeIndicator = inputTypeIndicatorType.BROADBAND

                ElseIf (strPPVServiceType.ToUpper.ToString().Trim = "UNBILLEVENTS") Then

                    Objinp.PPVService.UnbilledVideoEvents.inputValue = strAcctNum
                    Objinp.PPVService.UnbilledVideoEvents.region = strRegionCd
                    Objinp.PPVService.UnbilledVideoEvents.inputTypeIndicator = inputTypeIndicatorType.BROADBAND
                End If

                Dim ser As New XmlSerializer(Objinp.GetType)
                ser.Serialize(sw, Objinp)
                strInputXml = sw.ToString()

                Dim startIndex As Integer = strInputXml.ToString().IndexOf("<HeaderInfo>")
                strInputXml = strInputXml.Remove(0, startIndex)
                strInputXml = strInputXml.Insert(0, "<getPPVInfoRequest xmlns=""http://verizon.com/ONE/"">")
                strInputXml = strInputXml.Replace("getRemainingBalanceInfoRequest", "getPPVInfoRequest")
                strInputXml = strInputXml.Replace("getUnBilledInfoRequest", "getPPVInfoRequest")
                strInputXml = strInputXml.Replace(vbCrLf, "")
                strOutput = objNcogWS.getPPVInfo(strInputXml)
                xmlDoc.LoadXml(System.Text.RegularExpressions.Regex.Replace(strOutput, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline)))
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-GetPPVInfoService:" + strAcctNum + "/" + strRegionCd, ex.ToString())
                strOutput = "<getPPVInfo>" + ex.ToString() + "<getPPVInfo/>"
                xmlDoc.LoadXml(System.Text.RegularExpressions.Regex.Replace(strOutput, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline)))
            End Try
            Return xmlDoc

        End Function
#End Region

#Region "PPV [Pay Per View webmethod - NCOG "
        <WebMethod(Description:="PPSH Confirmation webmethod")> _
        Public Function RMICWNotification(ByVal strAppId As String, ByVal strRegionCd As String, ByVal strInputXml As String) As TS_ResponseForSBM
            'Dim strMessageid As String = "RMICW001"
            'Dim strMessagedesc As String = "SUCCESS"
            Dim strResponseXml As String = String.Empty
            Dim objTS_ResponseSBM As TS_ResponseForSBM = New TS_ResponseForSBM
            Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(strRegionCd.Trim())
            Try
                ObjDataAccess.usp_InsertPPSHACK(strAppId, strRegionCd, strInputXml)
            Catch ex As Exception
                objTS_ResponseSBM.RequestStatus.strMessageId = "RMCIWEXP"
                objTS_ResponseSBM.RequestStatus.strMessageDescription = "FAILURE"
                Return objTS_ResponseSBM
            End Try
            objTS_ResponseSBM.RequestStatus.strMessageId = "RMCIW001"
            objTS_ResponseSBM.RequestStatus.strMessageDescription = "SUCCESS"
            Return objTS_ResponseSBM
        End Function
#End Region

#Region "get BKCY SearchByAccountBTN"

        <WebMethod(Description:="get DataShare BKCY SearchByAccountBTN")> _
        Public Function GET_BKSearchByAccountBTN(ByVal strAcctnum As String, ByVal strBTN As String, ByVal strAppId As String, ByVal strRegionId As String) As XmlNode

            Dim strDSUrl As String = ""
            Dim getURL As wsGETURL = New wsGETURL
            Dim doc As New XmlDocument()
            Dim root As XmlNode = doc.DocumentElement
            Try

                strDSUrl = getURL.getSSPURL(strRegionId.Trim(), "DSBKCY")
                Dim Objws As DataShare.DS_BKRPT_Search = New DataShare.DS_BKRPT_Search
                Objws.Url = strDSUrl
                root = Objws.GET_BKSearchByAccountBTN(strAcctnum, strBTN)

            Catch ex As Exception
                LogErrorFile.WriteLog("GET_BKSearchByAccountBTN ", "AcctNum: " & strAcctnum & " Erroring Out while getting GET_BKSearchByAccountBTN Info " & ex.ToString)
            End Try
            Return root

        End Function
#End Region

#Region "get BKCY GET_BKSearch"

        <WebMethod(Description:="get DataShare BKCY GET_BKSearch")> _
        Public Function GET_BKSearch(ByVal strSSN As String, ByVal strBusinessTAXID As String, ByVal strBusinessName As String, ByVal strLastName As String, ByVal FullAddress As String, ByVal strRegionId As String) As XmlNode





            Dim strDSUrl As String = ""
            Dim getURL As wsGETURL = New wsGETURL
            Dim doc As New XmlDocument()
            Dim root As XmlNode = doc.DocumentElement
            Dim strPrimary As String = ""
            Dim strSecondary As String = ""
            Try
                If strRegionId.Trim() = "" Then
                    strRegionId = "PORTAL"
                End If
                strDSUrl = getURL.getSSPURL(strRegionId.Trim(), "DSBKCY")

                'SSN = '-56789',@lastname ='Kirli', @addressfull ='1055 E. Fondale St Azusa CA 91702-4816' 
                Dim Objws As DataShare.DS_BKRPT_Search = New DataShare.DS_BKRPT_Search
                Objws.Url = strDSUrl
                root = Objws.GET_BKSearch(strSSN, strBusinessTAXID, strBusinessName, strLastName, FullAddress)


                'Dim objSC As New DSBKSearch.Search()
                'Dim objD1 As New DSBKSearch.BKSearchDelegate(AddressOf objSC.BKSearchPrimaryDebtor)
                'Dim objD2 As New DSBKSearch.BKSearchDelegate(AddressOf DSBKSearch.Search.BKSearchSecoundaryDebtor)
                'strPrimary = objD1("Kirli", "1055 E. Fondale St Azusa CA 91702-4816", Objws.Url)
                'strSecondary = objD2("Kirli", "1055 E. Fondale St Azusa CA 91702-4816", Objws.Url)




            Catch ex As Exception
                LogErrorFile.WriteLog("GET_BKSearchByAccountBTN ", "LastName and Address : " & strLastName & FullAddress & "  Erroring Out while getting GET_BKSearch Info " & ex.ToString)
            End Try
            Return root

        End Function


        Public Class DSBKSearch

            ' Declares a delegate for a method that takes in an int and returns a String.
            Delegate Function BKSearchDelegate(ByVal strLastName As String, ByVal FullAddress As String, ByVal strUrl As String) As [String]


            Public Class Search

                Public Function BKSearchPrimaryDebtor(ByVal strLastName As String, ByVal FullAddress As String, ByVal strUrl As String) As [String]
                    Dim doc As New XmlDocument()
                    Dim root As XmlNode = doc.DocumentElement
                    Dim Objws As DataShare.DS_BKRPT_Search = New DataShare.DS_BKRPT_Search
                    Objws.Url = strUrl
                    root = Objws.GET_BKSearch("", "", "", strLastName, FullAddress)
                    Return root.OuterXml
                End Function

                Public Shared Function BKSearchSecoundaryDebtor(ByVal strLastName As String, ByVal FullAddress As String, ByVal strUrl As String) As [String]
                    Dim doc As New XmlDocument()
                    Dim root As XmlNode = doc.DocumentElement
                    Dim Objws As DataShare.DS_BKRPT_Search = New DataShare.DS_BKRPT_Search
                    Objws.Url = strUrl
                    root = Objws.GET_BKSearch("", "", "", strLastName, FullAddress)
                    Return root.OuterXml
                End Function
            End Class

        End Class



#End Region


#Region "issuePPVBlockUnBlock"
        <WebMethod(Description:="issue Collection Block UnBlock thru SDMP ")> _
        Public Function issuePPVBlockUnBlock(ByVal intRequestid As String, ByVal strProfileCAN As String, ByVal strActn As String, ByVal strAcctNum As String) As XmlDocument


            Dim getURL As wsGETURL = New wsGETURL
            Dim posturl As String = ""
            Dim ObjSDMPws As SDMP.FTTPVideoPPVManager = New SDMP.FTTPVideoPPVManager()
            Dim doc As New XmlDocument()
            Dim objSDMPRespDoc As XmlNode = doc.DocumentElement
            Dim strClientIdentification As String = ""

            Dim xdoc As New XmlDocument()



            Try
                posturl = getURL.getSSPURL("WEST", "SDMPURL")

                If posturl.Trim() = "" Then

                    LogErrorFile.WriteLog("RMICWWebServices-issuePPVBlockUnBlock", "Empty Profile URL:" + posturl)

                End If


                'Dim strxml As String = ""
                'Dim xmlSer As XmlSerializer = New XmlSerializer(GetType(OrderViewService))

                Dim objRequestContext As SoapContext

                objRequestContext = ObjSDMPws.RequestSoapContext
                ObjSDMPws.Proxy = New WebProxy
                objRequestContext.Security.Tokens.Clear()
                Dim unt As Tokens.UsernameToken = New Tokens.UsernameToken("RMW", "rmicw05", Tokens.PasswordOption.SendPlainText)
                objRequestContext.Security.Tokens.Add(unt)
                objRequestContext.Security.MustUnderstand = False

                'posturl = "http://113.130.73.240/rbg/BGWWebServices/FTTPVideoPPVManager/FTTPVideoPPVManager.asmx"

                ObjSDMPws.Url = posturl.Trim()


                'objRetrievalServiceTxn.Timeout = 60000
                'Thread.Sleep(100)
                ObjSDMPws.RequestSoapContext.Addressing.MustUnderstand = False

                Dim objTest As Object
                strClientIdentification = "<client_transaction_no>" + intRequestid.ToString() + "</client_transaction_no><client_other_data></client_other_data>"

                If strActn.StartsWith("S") Then
                    objSDMPRespDoc = ObjSDMPws.CollectionBlock(strClientIdentification.Trim(), strProfileCAN, "", "")
                ElseIf strActn.StartsWith("R") Then
                    objSDMPRespDoc = ObjSDMPws.CollectionRestore(strClientIdentification, strProfileCAN, "", "")
                End If


                doc.XmlResolver = Nothing
                doc.LoadXml(objSDMPRespDoc.OuterXml)
                xdoc.XmlResolver = Nothing
                xdoc.LoadXml(System.Text.RegularExpressions.Regex.Replace(doc.OuterXml, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline)))
                doc.XmlResolver = Nothing
                doc.LoadXml(xdoc.OuterXml)

                Dim objDA As WSDataAccessGeneric = New WSDataAccessGeneric("WEST")

                If objSDMPRespDoc.OuterXml.Trim() <> "" Then
                    objDA.usp_InserttAuditLog("SDMPRQST", "O", strAcctNum, "PPV", strProfileCAN, "", "", intRequestid, 0, objSDMPRespDoc.OuterXml.Trim(), "")
                End If



            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWebServices-issuePPVBlockUnBlock", ex.ToString())
                Throw ex

            End Try
            Return doc
        End Function
#End Region

#Region "get DS Finance Profile"
        <WebMethod(Description:="Get SSP Profile Test")> _
        Public Function GetDSFinanceProfile(ByVal strVisionCustID As String, ByVal strVisionAccountID As String, ByVal strCallType As String, ByVal strAppID As String) As FinanceProfile

            Dim objFinanceProfile As FinanceProfile = New FinanceProfile()
            Dim posturl As String = ""
            Dim xmliFinalDoc As XmlDocument = New XmlDocument
            Dim strUrl As String
            Dim strOutput As String = ""
            Dim strInputXml As String = ""
            Dim sw As New StringWriter
            Dim strXmlNode As XmlNode
            Dim strDSxml As String = ""
            Dim strRegionId As String = "VISION"
            Dim strAcctnum As String = strVisionCustID + strVisionAccountID

            Try



                Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(strRegionId.Trim())
                strUrl = ObjDataAccess.usp_GetControlParmByName("Control" + strRegionId.Trim(), "DSFinance")
                Dim objDSFinance As DSFinanceProfile.DS_FinanceProfile_Service = New DSFinanceProfile.DS_FinanceProfile_Service()
                objDSFinance.Url = strUrl
                Dim RequestContext As SoapContext
                RequestContext = objDSFinance.RequestSoapContext
                objDSFinance.Proxy = New WebProxy
                RequestContext.Security.Tokens.Clear()
                Dim userToken As UsernameToken = New UsernameToken("" + "RMW" + "", "" + "rmicw05" + "", PasswordOption.SendPlainText)
                RequestContext.Security.Tokens.Add(userToken)
                RequestContext.Security.MustUnderstand = False
                objDSFinance.Timeout = 90000
                objDSFinance.RequestSoapContext.Addressing.MustUnderstand = False
                'strXmlNode = objDSFinance.DS_RetrieveFinanceProfile("350139592", "0001", "E", "RMICW", "00")
                If strCallType.Trim() = "" Then
                    strCallType = "G"
                End If
                strXmlNode = objDSFinance.DS_RetrieveFinanceProfile(strVisionCustID, strVisionAccountID, strCallType, "RMICW", "")
                strDSxml = strXmlNode.InnerXml.Trim()

                'Using sr As StreamReader = New StreamReader("C:\Users\v412440\Documents\Rmicw 2015\dsfinanace.txt")
                '    strDSxml = sr.ReadToEnd()
                'End Using

                If strDSxml <> "" Then
                    strXmlNode.InnerXml = System.Text.RegularExpressions.Regex.Replace(strDSxml, "[+~!@#$%^&*()_+{}|]", "")
                    strDSxml = System.Text.RegularExpressions.Regex.Replace(strDSxml, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline))
                    strDSxml = "<FinanceProfile>" + strDSxml + "</FinanceProfile>"
                End If
                Dim xmlSer As XmlSerializer = New XmlSerializer(GetType(FinanceProfile))

                objFinanceProfile = xmlSer.Deserialize(New XmlTextReader(New StringReader(strDSxml.Trim())))


            Catch ex As Exception
                LogErrorFile.WriteLog("Request Manager :GetDSFinanceProfile:" + strAcctnum + "/" + strRegionId, ex.ToString())
            End Try
            Return objFinanceProfile
        End Function
#End Region


#Region "SSP NACR  webmethod - SSPPA"
        <WebMethod(Description:="getRelationship from SSP PA")>
        Public Function getAccountRelationShip(ByVal strAcctNum As String, strAcctType As String, ByVal strRegioncd As String, ByVal IntRequestid As String) As XmlDocument
            Dim posturl As String = ""
            Dim strUrl As String
            Dim strOutput As String = ""
            Dim strInputXml As String = ""
            Dim MyEnumVal As StateType
            Dim sw As New StringWriter
            Dim xmlDoc As XmlDocument
            xmlDoc = New XmlDocument
            Dim strParmName As String = "SSPPA"

            Try

                Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(strRegioncd.Trim())

                strUrl = ObjDataAccess.usp_GetControlParmByName("Control" + strRegioncd.Trim(), strParmName)

                Dim objSSPPA As NCOG_BY_SSPPA.getAccountRelationshipRequest = New NCOG_BY_SSPPA.getAccountRelationshipRequest()

                Dim objHeaderInfo As NCOG_BY_SSPPA.HeaderInfoType = New NCOG_BY_SSPPA.HeaderInfoType()

                Dim objReqHeaderInfo As NCOG_BY_SSPPA.RequestHeaderInfoType = New NCOG_BY_SSPPA.RequestHeaderInfoType()

                Dim objAcctInfo As NCOG_BY_SSPPA.GARAccountNumberType = New NCOG_BY_SSPPA.GARAccountNumberType()


                objReqHeaderInfo.applicationName = "RMICW"
                objReqHeaderInfo.applicationId = "RMW"
                objReqHeaderInfo.ClientMachineName = System.Environment.MachineName
                objReqHeaderInfo.RepLoginCode = "RMICW"
                objReqHeaderInfo.AppServerName = System.Environment.MachineName
                objReqHeaderInfo.AppServerTimeStamp = Now().ToString("MM/dd/yyyy hh:mm:ss EST")


                'objSSPPA.HeaderInfo.requestHeaderInfo.applicationName = "RMICW"
                'objSSPPA.HeaderInfo.requestHeaderInfo.applicationId
                'objSSPPA.HeaderInfo.requestHeaderInfo.ClientMachineName = System.Environment.MachineName
                'objSSPPA.HeaderInfo.requestHeaderInfo.RepLoginCode = "RMICW"
                'objSSPPA.HeaderInfo.requestHeaderInfo.AppServerName = System.Environment.MachineName
                'objSSPPA.HeaderInfo.requestHeaderInfo.AppServerTimeStamp = Now().ToString("MM/dd/yyyy hh:mm:ss EST")

                If IntRequestid.Trim() = "" Then
                    IntRequestid = "0"
                End If
                'objSSPPA.HeaderInfo.requestHeaderInfo.TrackingNumber = IntRequestid
                'objReqHeaderInfo.TrackingNumber = IntRequestid
                objReqHeaderInfo.TrackingNumber = Guid.NewGuid.ToString().Substring(0, 15)
                'objSSPPA.AccountNumber.Item = strAcctNum.Trim()
                'objSSPPA.includeAccountRelationshipDetails = "Y"

                'objSSPPA.Request.Identifier = strAcctNum.Trim()
                'objSSPPA.Request.includeFinalAccountsOnly = "N"
                'objSSPPA.Request.isSubAccountsRequired = "Y"

                objHeaderInfo.requestHeaderInfo = objReqHeaderInfo
                objSSPPA.HeaderInfo = objHeaderInfo

                Select Case strAcctType.Trim()
                    Case "BROADBAND"
                        'objSSPPA.Request.IdentifierType = "BBCAN"
                        objAcctInfo.ItemElementName = NCOG_BY_SSPPA.ItemChoiceType.AccountId 'Confirm with Mahesh Bandi once. 
                    Case "VOICE"
                        'objSSPPA.Request.IdentifierType = "VoiceCAN"
                        objAcctInfo.ItemElementName = NCOG_BY_SSPPA.ItemChoiceType.AccountId 'CAN type ncog changes to 10 digit validation so cAN 13 digit pass it under AccountID
                    Case "SSPBAN"
                        'objSSPPA.Request.IdentifierType = "SSPBAN"
                        objAcctInfo.ItemElementName = NCOG_BY_SSPPA.ItemChoiceType.BAN
                    Case "PROFILE"
                        'objSSPPA.Request.IdentifierType = "PCAN"
                        objAcctInfo.ItemElementName = NCOG_BY_SSPPA.ItemChoiceType.ProfileCAN
                    Case "VOLUserid"
                        'objSSPPA.Request.IdentifierType = "VOLUserid"
                        objAcctInfo.ItemElementName = NCOG_BY_SSPPA.ItemChoiceType.vzUserId
                    Case "TN"
                        'objSSPPA.Request.IdentifierType = "TN"
                        objAcctInfo.ItemElementName = NCOG_BY_SSPPA.ItemChoiceType.BTN
                    Case Else
                        If strRegioncd.ToUpper() = "VISION" Then
                            'objSSPPA.Request.IdentifierType = "VisionId"
                            objAcctInfo.ItemElementName = NCOG_BY_SSPPA.ItemChoiceType.AccountId
                        Else
                            objAcctInfo.ItemElementName = NCOG_BY_SSPPA.ItemChoiceType.AccountId
                        End If

                End Select



                If (strAcctNum.EndsWith("0001")) Then
                    'objSSPPA.Request.IdentifierType = "VisionId"
                    objAcctInfo.ItemElementName = NCOG_BY_SSPPA.ItemChoiceType.AccountId
                End If

                If (strAcctNum.EndsWith("0001")) And strRegioncd.ToUpper() <> "VISION" Then
                    ' objSSPPA.Request.IdentifierType = "VoiceCAN"
                    objAcctInfo.ItemElementName = NCOG_BY_SSPPA.ItemChoiceType.AccountId
                End If

                objAcctInfo.Item = strAcctNum.Trim()

                objSSPPA.IsFinalAccount = "N"
                objSSPPA.includeAccountRelationshipDetails = "Y"
                objSSPPA.AccountNumber = objAcctInfo

                Dim objNACR_SSPPA As New SSPPA.NCOGWebServices()

                objNACR_SSPPA.Url = strUrl
                Dim RequestContext As SoapContext
                RequestContext = objNACR_SSPPA.RequestSoapContext
                objNACR_SSPPA.Proxy = New WebProxy
                RequestContext.Security.Tokens.Clear()
                Dim userToken As UsernameToken = New UsernameToken("" + "RMW" + "", "" + "rmicw05" + "", PasswordOption.SendPlainText)
                RequestContext.Security.Tokens.Add(userToken)
                RequestContext.Security.MustUnderstand = False
                objNACR_SSPPA.Timeout = 90000
                objNACR_SSPPA.RequestSoapContext.Addressing.MustUnderstand = False

                'Serialize the xml to pass to Webmethod...
                Dim ser As New XmlSerializer(objSSPPA.GetType())
                ser.Serialize(sw, objSSPPA)
                strInputXml = sw.ToString()

                ''Remove TN Tag
                'If (strInputXml.Contains("<tn />")) Then
                '    strInputXml = strInputXml.Replace("<tn />", "")
                'End If



                'Remove the XmlNamespace/Junk data from input xml
                Dim startIndex As Integer = strInputXml.ToString().IndexOf("<HeaderInfo>")
                strInputXml = strInputXml.Remove(0, startIndex)
                strInputXml = strInputXml.Insert(0, "<getAccountRelationshipRequest xmlns=""http://verizon.com/ONE/"">")

                strInputXml = strInputXml.Replace(vbCrLf, "")

                'Call the method!!
                'strOutput = objSSPPA.GetVzFullProfile(strInputXml)
                'strOutput = objNACR_SSPPA.getRelationship(strInputXml)
                strOutput = objNACR_SSPPA.getAccountRelationship(strInputXml)

                xmlDoc.LoadXml(System.Text.RegularExpressions.Regex.Replace(strOutput, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline)))

                'Dim objDAT As WSDataAccessGeneric = New WSDataAccessGeneric(strRegioncd.Trim())
                'objDAT.usp_InserttAuditLog("PCAN1", "E", strAcctNum, strAcctType, strAcctType, strAcctType, "", 0, 0, strInputXml, System.Environment.MachineName)
                'objDAT.usp_InserttAuditLog("PCAN_O", "E", strAcctNum, strAcctType, strAcctType, strAcctType, "", 0, 0, strOutput.ToString(), System.Environment.MachineName)
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-SSPPA:" + strAcctNum + "/" + strRegioncd, ex.ToString())
                strOutput = "<getAccountRelationship>" + ex.Message.Trim().ToString() + "</getAccountRelationship>"
                xmlDoc.LoadXml(System.Text.RegularExpressions.Regex.Replace(strOutput, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline)))
            End Try
            Return xmlDoc
        End Function
#End Region


#Region "FULL Profile webmethod - SSPPA"
        <WebMethod(Description:="FULL CSR Profile webmethod from SSPPA")> _
        Public Function getVZFullProfile(ByVal strAcctNum As String, ByVal strState As String, ByVal IntRequestid As Integer) As XmlDataDocument
            Dim posturl As String = ""
            Dim strUrl As String
            Dim strOutput As String = ""
            Dim strInputXml As String = ""
            Dim MyEnumVal As StateType
            Dim sw As New StringWriter
            Dim xmlDoc As XmlDataDocument
            xmlDoc = New XmlDataDocument
            Dim strParmName As String = "SSPPA"
            Dim strRegionCd As String = "VISION"
            Dim strTrackId = Guid.NewGuid.ToString()
            Try


                Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(strRegionCd.Trim())
                'Select Case strState.Trim().ToUpper()
                '    Case "MA", "RI", "NY", "CT", "NJ", "PA", "DE", "MD", "DC", "VA", "WV", "VC", "VG", "PG", "PQ", "PC", "PD", "VT", "NH", "ME", "EAST"
                '        strParmName = "SSPPAEAST"
                '    Case Else
                '        strParmName = "SSPPA"
                'End Select
                strState = "NY"  'untill copper goes in we will default the state to WEST ...copper revisit ablve case logic ...

                strUrl = ObjDataAccess.usp_GetControlParmByName("Control" + strRegionCd.Trim(), strParmName)

                Dim objSSPPA As New SSPPA.NCOGWebServices

                objSSPPA.Url = strUrl
                Dim RequestContext As SoapContext
                RequestContext = objSSPPA.RequestSoapContext
                objSSPPA.Proxy = New WebProxy
                RequestContext.Security.Tokens.Clear()
                Dim userToken As UsernameToken = New UsernameToken("" + "RMW" + "", "" + "rmicw05" + "", PasswordOption.SendPlainText)
                RequestContext.Security.Tokens.Add(userToken)
                RequestContext.Security.MustUnderstand = False
                objSSPPA.Timeout = 90000
                objSSPPA.RequestSoapContext.Addressing.MustUnderstand = False

                'Dim Objinp As New getVZFullProfileRequest("FULL")

                Dim Objinp As getVZFullProfileRequest = New getVZFullProfileRequest("FULL")


                Objinp.HeaderInfo.requestHeaderInfo.applicationName = "RMICW"
                Objinp.HeaderInfo.requestHeaderInfo.applicationId = "RMW"
                Objinp.HeaderInfo.requestHeaderInfo.ClientMachineName = System.Environment.MachineName
                Objinp.HeaderInfo.requestHeaderInfo.RepLoginCode = "RMICW"
                Objinp.HeaderInfo.requestHeaderInfo.AppServerName = System.Environment.MachineName
                Objinp.HeaderInfo.requestHeaderInfo.AppServerTimeStamp = Now().ToString("MM/dd/yyyy hh:mm:ss EST")
                Objinp.HeaderInfo.requestHeaderInfo.TrackingNumber = strTrackId
                Objinp.RequestInfo.Profile.VoiceInfo = "Y"
                Objinp.RequestInfo.Profile.DataVideoInfo = "Y"

                'Convert string to Enum type for the State Value...
                MyEnumVal = CType(System.Enum.Parse(GetType(StateType), strState.Trim()), StateType)
                Objinp.RequestInfo.serviceState = MyEnumVal
                'Objinp.RequestInfo.GeneralSearch.AccountId = strAcctNum

                Objinp.RequestInfo.UniqueCustomerSearch.VisionId.VisionCustomerId = strAcctNum.Substring(0, 9)
                Objinp.RequestInfo.UniqueCustomerSearch.VisionId.VisionAccountId = strAcctNum.Substring(9, 4)


                ' Always same params...
                'Objinp.RequestInfo.AdditionalParameters.OrderFilteringCode = "00"
                'Objinp.RequestInfo.AdditionalParameters.numberOfDays = "5"

                'Set SuppressVoiceDataPendingOrdersSpecified = False and no value for SuppressVoiceDataPendingOrders
                Objinp.RequestInfo.AdditionalParameters.SuppressVoiceDataPendingOrdersSpecified = False
                'Objinp.RequestInfo.AdditionalParameters.SuppressVoiceDataPendingOrdersSpecified = True
                'Objinp.RequestInfo.AdditionalParameters.SuppressVoiceDataPendingOrders = getVZFullProfileRequest.VoiceDataProfileType.Both

                'Objinp.RequestInfo.AdditionalParameters.UseExpress = "Y"
                'Objinp.RequestInfo.AdditionalParameters.isRetainOffer = "Y"
                Objinp.RequestInfo.AdditionalParameters.includeFinanceProfile = "Y"



                'Serialize the xml to pass to Webmethod...
                Dim ser As New XmlSerializer(Objinp.GetType())
                ser.Serialize(sw, Objinp)
                strInputXml = sw.ToString()
                'Remove TN Tag
                If (strInputXml.Contains("<tn />")) Then
                    strInputXml = strInputXml.Replace("<tn />", "")
                End If

                'Remove GeneralSearch
                strInputXml = System.Text.RegularExpressions.Regex.Replace(strInputXml, "<GeneralSearch>[\s\S]*?<\/GeneralSearch>", "")

                'Remove the XmlNamespace/Junk data from input xml
                Dim startIndex As Integer = strInputXml.ToString().IndexOf("<HeaderInfo>")
                strInputXml = strInputXml.Remove(0, startIndex)
                strInputXml = strInputXml.Insert(0, "<getVZFullProfileRequest xmlns=""http://verizon.com/ONE/"">")
                strInputXml = strInputXml.Replace(vbCrLf, "")

                'Call the method!!
                strOutput = objSSPPA.GetVzFullProfile(strInputXml)
                xmlDoc.XmlResolver = Nothing
                ' xmlDoc.LoadXml(System.Text.RegularExpressions.Regex.Replace(strOutput, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline)))
                If xmlDoc IsNot Nothing Then
                    xmlDoc.LoadXml(System.Text.RegularExpressions.Regex.Replace(strOutput, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline)))
                End If
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-SSPPA:" + strAcctNum + "/" + strRegionCd, ex.ToString())
                strOutput = "<getVZFullProfileRequest>" + ex.ToString() + "<getVZFullProfileRequest/>"
                xmlDoc.XmlResolver = Nothing
                ' xmlDoc.LoadXml(System.Text.RegularExpressions.Regex.Replace(strOutput, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline)))
                If xmlDoc IsNot Nothing Then
                    xmlDoc.LoadXml(System.Text.RegularExpressions.Regex.Replace(strOutput, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline)))
                End If
            End Try
            Return xmlDoc
        End Function
#End Region

#Region "Billing Profile V5 - Bad Debt"
        <WebMethod(Description:="Billing Profile V5 Bad Debt")>
        Public Function getV5BillingProfile(ByVal strRegion As String, ByVal strAcctNum As String) As XmlElement
            Dim posturl As String = ""
            Dim strUrl As String
            Dim strOutput As String = ""
            Dim strInputXml As String = ""
            Dim MyEnumVal As StateType
            Dim sw As New StringWriter
            Dim xmlDoc As XmlDocument
            xmlDoc = New XmlDocument
            Dim strParmName As String = "SSPVS"
            Dim strRegionCd As String = "VISION"
            Dim strTrackId As String = ""
            Dim strVisionAcctId As String = ""
            Dim strVisionCustId As String = ""

            Try

                If Not (String.IsNullOrWhiteSpace(strRegion)) Then
                    strRegionCd = strRegion
                End If

                Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(strRegionCd.Trim())


                strUrl = ObjDataAccess.usp_GetControlParmByName("Control" + strRegionCd.Trim(), strParmName)

                Dim objSSPVS As New SSPV5billingProfile.SSPVisionLookupService()


                objSSPVS.Url = strUrl
                Dim RequestContext As SoapContext
                RequestContext = objSSPVS.RequestSoapContext
                objSSPVS.Proxy = New WebProxy
                RequestContext.Security.Tokens.Clear()
                Dim userToken As UsernameToken = New UsernameToken("" + "rmicw" + "", "" + "rmicw01" + "", PasswordOption.SendPlainText)
                RequestContext.Security.Tokens.Add(userToken)
                RequestContext.Security.MustUnderstand = False
                objSSPVS.Timeout = 90000
                objSSPVS.RequestSoapContext.Addressing.MustUnderstand = False

                strTrackId = Guid.NewGuid.ToString()

                If (Not String.IsNullOrWhiteSpace(strAcctNum)) Then
                    If (strAcctNum.Trim().EndsWith("0001")) Then
                        strVisionCustId = strAcctNum.Trim().Substring(0, 9)
                        strVisionAcctId = strAcctNum.Trim().Substring(9, 4)
                    End If
                End If


                strInputXml = "<Request><HeaderInfo><ClientDetails><AppName>RMICW</AppName><AppId>RMICW</AppId><TrackingNumber>" + strTrackId + "</TrackingNumber><AppServerName>" + System.Environment.MachineName + "</AppServerName><ManagedServerName>" + System.Environment.MachineName + "</ManagedServerName><RequestTimeStamp>" + Now().ToString("MM/dd/yyyy hh:mm:ss EST") + "</RequestTimeStamp><AdditionalInfo>Vision Service Pre-order lookup from SSP Vision Adapter</AdditionalInfo></ClientDetails></HeaderInfo><COMMAREA><ClientInfo><SERVICE>S</SERVICE><SUBSERVICE>T</SUBSERVICE><CLIENT-ID>SSPVS</CLIENT-ID><USERID>RMICW</USERID><SECURITY-CLASS-IND>A</SECURITY-CLASS-IND><SECURITY-CLASS></SECURITY-CLASS><DVS-CORRELATION-ID>Correlation</DVS-CORRELATION-ID><ORIG-CLIENT-ID></ORIG-CLIENT-ID><FILLER></FILLER></ClientInfo><INPUT><CUSTOMER-ID>" + strVisionCustId + "</CUSTOMER-ID><ACCOUNT-ID>" + strVisionAcctId + "</ACCOUNT-ID><TN-REQ></TN-REQ><BDV-REQ-IND></BDV-REQ-IND><SVC-ELEMENT-ID-REQ></SVC-ELEMENT-ID-REQ><TAX-GEO-CODE></TAX-GEO-CODE><TAX-EXEMPT-REQ-IND>N</TAX-EXEMPT-REQ-IND><ACCOUNT-INC-FLAG>Y</ACCOUNT-INC-FLAG><LNE-OF-SVC-INC-FLAG>Y</LNE-OF-SVC-INC-FLAG><PRODUCT-INC-FLAG>Y</PRODUCT-INC-FLAG><FILLER/></INPUT></COMMAREA></Request>"

                'Call the method!!
                strOutput = objSSPVS.doRequest(strInputXml)
                strOutput = strOutput.Replace("LN-OF-SVC-STAT-CD", "SvcStatus") 'To know Rmicw terminology 
                strOutput = strOutput.Replace("LN-SVC-TYPE", "SvcName") 'To know Rmicw terminology
                strOutput = strOutput.Replace("BL-ACCT-STA-CD", "AcctStatus") 'To know Rmicw terminology
                strOutput = strOutput.Replace("encoding=" + """" + "utf-8" + """", "")
                strOutput = strOutput.Replace("encoding=" + """" + "utf-16" + """", "")
                xmlDoc.LoadXml(strOutput)
                'xmlDoc.LoadXml(System.Text.RegularExpressions.Regex.Replace(xmlDoc.OuterXml, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline)))
                'xmlDoc.LoadXml(System.Text.RegularExpressions.Regex.Replace(strOutput, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline)))
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-SSPV5:" + strAcctNum + "/" + strRegionCd, ex.ToString())
                strOutput = "<Response>" + ex.ToString() + "</Response>"
                xmlDoc.LoadXml(System.Text.RegularExpressions.Regex.Replace(strOutput, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline)))
            End Try
            Return xmlDoc.DocumentElement
        End Function
#End Region

#Region "NSOP Order Status - Bad Debt"
        <WebMethod(Description:="Billing Profile V5 Bad Debt")>
        Public Function getNSOPOrderStatusByBTN(ByVal strRegion As String, ByVal strAcctNum As String) As XmlElement
            Dim posturl As String = ""
            Dim strUrl As String
            Dim strOutput As String = ""
            Dim strInputXml As String = ""
            Dim MyEnumVal As StateType
            Dim sw As New StringWriter
            Dim xmlDoc As XmlDocument
            xmlDoc = New XmlDocument
            Dim strParmName As String = "NSOPWS"
            Dim strRegionCd As String = "NY"
            Dim strTrackId As String = ""
            Dim strVisionAcctId As String = ""
            Dim strVisionCustId As String = ""
            Dim boolResult As Boolean = True
            Dim strBTN As String = String.Empty
            Dim strState As String = String.Empty
            Dim objEnvDS As DataSet
            Dim strDateTime As String
            Dim strDate As String
            Dim strTime As String
            Try

                If Not (String.IsNullOrWhiteSpace(strRegion)) Then
                    strRegionCd = strRegion
                End If

                Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(strRegionCd.Trim())


                strUrl = ObjDataAccess.usp_GetControlParmByName("Control" + strRegionCd.Trim(), strParmName)

                Dim objNSOPWS As New NSOPOrderStatus.NSOPWebService()


                objNSOPWS.Url = strUrl
                Dim RequestContext As SoapContext
                RequestContext = objNSOPWS.RequestSoapContext
                objNSOPWS.Proxy = New WebProxy
                RequestContext.Security.Tokens.Clear()
                Dim userToken As UsernameToken = New UsernameToken("" + "rmw" + "", "" + "rmicw05" + "", PasswordOption.SendPlainText)
                RequestContext.Security.Tokens.Add(userToken)
                RequestContext.Security.MustUnderstand = False
                objNSOPWS.Timeout = 90000
                objNSOPWS.RequestSoapContext.Addressing.MustUnderstand = False

                strDateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss").Trim()
                strDate = strDateTime.Substring(0, 10)
                strTime = strDateTime.Substring(11, 8).Replace(":", "")


                'If (Not String.IsNullOrWhiteSpace(strAcctNum)) Then
                '    If (strAcctNum.Trim().EndsWith("0001")) Then
                '        strVisionCustId = strAcctNum.Trim().Substring(0, 9)
                '        strVisionAcctId = strAcctNum.Trim().Substring(9, 4)
                '    End If
                'End If

                objEnvDS = ObjDataAccess.usp_GetCustomerAddressInfo(strRegion, strAcctNum)

                If Not (ObjDataAccess.IsEmptyRecordSet(objEnvDS)) Then
                    If Not (String.IsNullOrWhiteSpace(objEnvDS.Tables(0).Rows(0)("strTelephoneNum"))) Then
                        strBTN = objEnvDS.Tables(0).Rows(0)("strTelephoneNum")
                    Else
                        strBTN = "9999999999"
                    End If
                    strState = objEnvDS.Tables(0).Rows(0)("strState")
                    End If

                strInputXml = "<TRANSACTION><SENDINFO><SENDDATA Sendtyp=""SENDAPP"">RMICW</SENDDATA></SENDINFO><TRANINFO><TRANDATA Trantyp=""TRANID"">TnSearch</TRANDATA><TRANDATA Trantyp=""USERID"">RMICW</TRANDATA><TRANDATA Trantyp=""PASSWORD"">RMICW</TRANDATA><TRANDATA Trantyp=""TOKENID"">" +
                            "</TRANDATA><TRANDATA Trantyp=""SCHEMAINVERSION"">1.0</TRANDATA></TRANINFO><REPLYINFO><REPLYDATA Replytyp=""REPLYAPP"">WFMNT</REPLYDATA></REPLYINFO><REQUESTTRANS Datesent=""" + strDate + """ Timesent=""" + strTime + """ Jurisdiction=""" + strState + """ Identifier="""">" +
                            "<REQUEST><TNSearchRequest><TN>" + strBTN + "</TN><AdditionalCheck>C</AdditionalCheck></TNSearchRequest></REQUEST></REQUESTTRANS></TRANSACTION>"
                'Call the method!!
                strOutput = objNSOPWS.GetOrdersByTN(strInputXml, boolResult)


                strOutput = strOutput.Replace("encoding=" + """" + "utf-8" + """", "")
                strOutput = strOutput.Replace("encoding=" + """" + "utf-16" + """", "")
                xmlDoc.LoadXml(strOutput)
                'xmlDoc.LoadXml(System.Text.RegularExpressions.Regex.Replace(xmlDoc.OuterXml, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline)))
                'xmlDoc.LoadXml(System.Text.RegularExpressions.Regex.Replace(strOutput, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline)))
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-NSOPWS:" + strAcctNum + "/" + strRegionCd, ex.ToString())
                strOutput = "<Response>" + ex.ToString() + "</Response>"
                xmlDoc.LoadXml(System.Text.RegularExpressions.Regex.Replace(strOutput, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline)))
            End Try
            Return xmlDoc.DocumentElement
        End Function
#End Region
#Region "getVisionBillingInfo - SSPPA"
        <WebMethod(Description:="Vision Billing Information from SSPPA")> _
        Public Function getVisionBillingInfo(ByVal strAcctNum As String, ByVal strRequestType As String, ByVal strBalanceType As String, ByVal IntRequestid As Integer) As XmlDataDocument
            Dim posturl As String = ""
            Dim strUrl As String
            Dim strOutput As String = ""
            Dim strInputXml As String = ""
            Dim sw As New StringWriter
            Dim xmlDoc As XmlDataDocument
            xmlDoc = New XmlDataDocument
            Try

                'Pull the URL from tcontrolparm table...
                Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(strRegionCd.Trim())
                strUrl = ObjDataAccess.usp_GetControlParmByName("Control" + strRegionCd.Trim(), "SSPPA")

                Dim objSSPPA As New SSPPA.NCOGWebServices

                objSSPPA.Url = strUrl
                Dim RequestContext As SoapContext
                RequestContext = objSSPPA.RequestSoapContext
                objSSPPA.Proxy = New WebProxy
                RequestContext.Security.Tokens.Clear()
                Dim userToken As UsernameToken = New UsernameToken("" + "RMW" + "", "" + "rmicw05" + "", PasswordOption.SendPlainText)
                RequestContext.Security.Tokens.Add(userToken)
                RequestContext.Security.MustUnderstand = False
                objSSPPA.Timeout = 90000
                objSSPPA.RequestSoapContext.Addressing.MustUnderstand = False

                Dim Objinp As New getVZFullProfileRequest("BILLING")


                Dim objInpRequestinfo As New getVZFullProfileRequest.RequestType


                Objinp.HeaderInfo.requestHeaderInfo.applicationName = "RMICW"
                Objinp.HeaderInfo.requestHeaderInfo.applicationId = "RMW"
                Objinp.HeaderInfo.requestHeaderInfo.ClientMachineName = System.Environment.MachineName
                Objinp.HeaderInfo.requestHeaderInfo.RepLoginCode = "RMICW"
                Objinp.HeaderInfo.requestHeaderInfo.AppServerName = System.Environment.MachineName
                Objinp.HeaderInfo.requestHeaderInfo.AppServerTimeStamp = Now().ToString("MM/dd/yyyy hh:mm:ss EST")
                Objinp.HeaderInfo.requestHeaderInfo.TrackingNumber = IntRequestid

                Objinp.Request.VisionCustomerId = strAcctNum.Substring(0, 9)
                Objinp.Request.VisionAccountId = strAcctNum.Substring(9, 4)

                Select Case strRequestType.ToUpper().Trim()
                    Case "ALL"
                        Objinp.Request.AdditionalParameters.requestType = getVZFullProfileRequest.VISIONBillingRequestType.ALL
                    Case "BALANCE"
                        Objinp.Request.AdditionalParameters.requestType = getVZFullProfileRequest.VISIONBillingRequestType.BALANCE
                    Case "PAYMENT"
                        Objinp.Request.AdditionalParameters.requestType = getVZFullProfileRequest.VISIONBillingRequestType.PAYMENT
                    Case "ADJUSTMENT"
                        Objinp.Request.AdditionalParameters.requestType = getVZFullProfileRequest.VISIONBillingRequestType.ADJUSTMENT
                    Case Else
                        Objinp.Request.AdditionalParameters.requestType = getVZFullProfileRequest.VISIONBillingRequestType.ALL
                End Select

                Select Case strBalanceType.ToUpper().Trim()
                    Case "A"
                        Objinp.Request.AdditionalParameters.balanceTypeIndicator = getVZFullProfileRequest.BalanceTypeIndicator.A
                    Case "B"
                        Objinp.Request.AdditionalParameters.balanceTypeIndicator = getVZFullProfileRequest.BalanceTypeIndicator.B
                    Case "C"
                        Objinp.Request.AdditionalParameters.balanceTypeIndicator = getVZFullProfileRequest.BalanceTypeIndicator.C
                    Case Else
                        Objinp.Request.AdditionalParameters.balanceTypeIndicator = getVZFullProfileRequest.BalanceTypeIndicator.B
                End Select

                Objinp.Request.AdditionalParameters.includeHistory = "Y"
                Objinp.Request.AdditionalParameters.includeAdjustmentSummary = "N"
                Objinp.Request.AdditionalParameters.includeAllAdjustmentTypes = "Y"
                Objinp.Request.AdditionalParameters.outputSequence = getVZFullProfileRequest.OutputSequenceType.A

                'Serialize the xml to pass to Webmethod...
                Dim ser As New XmlSerializer(Objinp.GetType)
                ser.Serialize(sw, Objinp)
                strInputXml = sw.ToString()
                'Remove the XmlNamespace/Junk data from input xml
                Dim startIndex As Integer = strInputXml.ToString().IndexOf("<HeaderInfo>")
                strInputXml = strInputXml.Remove(0, startIndex)
                strInputXml = strInputXml.Insert(0, "<getVZFullProfileRequest xmlns=""http://verizon.com/ONE/"">")
                strInputXml = strInputXml.Replace(vbCrLf, "")
                strInputXml = strInputXml.Replace("getVZFullProfileRequest", "getVisionBillingInfoRequest")
                strInputXml = System.Text.RegularExpressions.Regex.Replace(strInputXml, "<RequestInfo>[\s\S]*?<\/RequestInfo>", "")
                'Call the method!!
                strOutput = objSSPPA.getVisionBillingInfo(strInputXml)
                xmlDoc.LoadXml(System.Text.RegularExpressions.Regex.Replace(strOutput, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline)))
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-SSPPA:getVisionBillingInfo" + strAcctNum + "/" + strRegionCd, ex.ToString())
                strOutput = "<getVisionBillingInfo>" + ex.ToString() + "<getVisionBillingInfo/>"
                xmlDoc.LoadXml(System.Text.RegularExpressions.Regex.Replace(strOutput, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline)))
            End Try
            Return xmlDoc
        End Function

#End Region


#Region "Video Profile webmethod - SSPPA "
        <WebMethod(Description:="FULL CSR Profile webmethod from SSPPA")> _
        Public Function getVideoProfileWithBalances(ByVal strAcctNum As String, ByVal IntRequestid As Integer) As String


            Dim posturl As String = ""
            Dim xmliFinalDoc As XmlDocument = New XmlDocument
            Dim strUrl As String
            Dim strOutput As String = ""
            Dim strInputXml As String = ""
            Dim sw As New StringWriter
            Try


                'Pull the URL from tcontrolparm table...
                Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(strRegionCd.Trim())
                strUrl = ObjDataAccess.usp_GetControlParmByName("Control" + strRegionCd.Trim(), "SSPPA")

                Dim objNcogWS As New NCOGAssignNumber.NCOGWebServices
                objNcogWS.Url = strUrl
                Dim RequestContext As SoapContext
                RequestContext = objNcogWS.RequestSoapContext
                objNcogWS.Proxy = New WebProxy
                RequestContext.Security.Tokens.Clear()
                Dim userToken As UsernameToken = New UsernameToken("" + "RMW" + "", "" + "rmicw05" + "", PasswordOption.SendPlainText)
                RequestContext.Security.Tokens.Add(userToken)
                RequestContext.Security.MustUnderstand = False
                objNcogWS.Timeout = 90000
                objNcogWS.RequestSoapContext.Addressing.MustUnderstand = False


                Dim Objinp As New getVideoProfileWithBalancesRequest


                Objinp.HeaderInfo.requestHeaderInfo.applicationName = "RMICW"
                Objinp.HeaderInfo.requestHeaderInfo.applicationId = "RMW"
                Objinp.HeaderInfo.requestHeaderInfo.ClientMachineName = System.Environment.MachineName
                Objinp.HeaderInfo.requestHeaderInfo.RepLoginCode = "RMICW"
                Objinp.HeaderInfo.requestHeaderInfo.AppServerName = System.Environment.MachineName
                Objinp.HeaderInfo.requestHeaderInfo.AppServerTimeStamp = Now().ToString("MM/dd/yyyy hh:mm:ss EST")
                Objinp.HeaderInfo.requestHeaderInfo.TrackingNumber = IntRequestid
                Objinp.inputValue = strAcctNum
                Objinp.region = strRegionCd
                Objinp.inputTypeIndicator = inputTypeIndicatorType.BROADBAND

                'Serialize the xml to pass to Webmethod...
                Dim ser As New XmlSerializer(Objinp.GetType)
                ser.Serialize(sw, Objinp)
                strInputXml = sw.ToString()

                'Remove the XmlNamespace/Junk data from input xml
                Dim startIndex As Integer = strInputXml.ToString().IndexOf("<HeaderInfo>")
                strInputXml = strInputXml.Remove(0, startIndex)
                strInputXml = strInputXml.Insert(0, "<getVideoProfileWithBalancesRequest xmlns=""http://verizon.com/ONE/"">")
                strInputXml = strInputXml.Replace(vbCrLf, "")

                'Call the method!!
                strOutput = objNcogWS.getVideoProfileWithBalances(strInputXml)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-GetNCOGVideoProfile:" + strAcctNum + "/" + strRegionCd, ex.ToString())
            End Try
            Return strOutput
        End Function
#End Region



#Region "Get Payment Details from Payment Hub"

        <WebMethod(Description:="Payment Details from Payment Hub")> _
        <OperationContract()> _
        Public Function GetPaymentDetails(ByVal strAccountID As String, _
                                           ByVal strCallingApp As String, _
                                           ByVal strCustInterfaceApp As String, _
                                           ByVal strFromDate As String, _
                                           ByVal strRepUserId As String, _
                                           ByVal strSessionId As String, _
                                           ByVal strToDate As String) As PaymentCloudService.GetAllPaymentsResponse

            Dim blnSucess As Boolean = False
            Dim strIvappInputXml As String = ""
            Dim stroutput As String = ""

            'Dim xmlDoc As XmlDocument
            Dim objPaymentRequest As PaymentCloudService.GetAllPaymentRequest = New PaymentCloudService.GetAllPaymentRequest
            'Dim objRequest As ProductStatus_Request = New ProductStatus_Request
            'Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric

            'strvalue = ObjDataAccess.usp_GetControlParmByName(strRegion, "MQiGOEnable")

            objPaymentRequest.AccountID = strAccountID.Trim()
            objPaymentRequest.CallingApp = strCallingApp.Trim()
            objPaymentRequest.CustInterfaceApp = strCustInterfaceApp.Trim()
            objPaymentRequest.FromDate = strFromDate.Trim()
            objPaymentRequest.RepUserId = strRepUserId.Trim()
            objPaymentRequest.SessionId = strSessionId.Trim()
            objPaymentRequest.ToDate = strToDate.Trim()

            'objRequest.strAcctNum = strAcctnum.Trim()
            'objRequest.strRegionId = strRegionCd.ToUpper().Trim()
            'objRequest.strFIOSInd = strFIOSInd.ToUpper().Trim()


            'Dim objProductStatus As ProductStatus = New ProductStatus(strRegionCd)
            'System.Net.ServicePointManager.ServerCertificateValidationCallback = (senderX, certificate, chain, sslPolicyErrors)
            '        System.Net.ServicePointManager.ServerCertificateValidationCallback = ()
            Dim objPaymentStatus As PHPaymentServiceClient = New PHPaymentServiceClient


            Try
                'objWireless1Bill.getWireless1BillStatus(objBqtrequest)

                'Return objProductStatus.GetRMICWProductStatus(objRequest)
                'Return stroutput

                Return objPaymentStatus.GetAllPayments(objPaymentRequest)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS- PaymentDetails", ex.ToString())
                strIvappInputXml = ex.ToString
            End Try

        End Function
#End Region


#Region "Payment History from Payment Hub"
        '<WebMethod(Description:="Payment History from Payment Hub")> _
        '<OperationContract()> _
        '    Public Function GetPaymentInfo(ByVal strVisionID As String, ByVal strUserID As String)
        '    Dim objPayment As PostPaymentDetails[] = New PostPaymentDetails(1)


        '    Try
        '        Dim strAppID As String = "RMICW"

        '        Dim strMonthCheck As String = ConfigurationSettings.AppSettings("PaymentHistory").ToString()
        '        Dim intMonthcheck as Integer = Convert.ToInt32(ConfigurationSettings.AppSettings("PaymentHistory")

        '        Dim strToDate As String = System.DateTime.Now.ToString("MM/dd/yyyy")
        '        Dim strFromDate As String = System.DateTime.Now.AddMonths(-intMonthcheck).ToString("MM/dd/yyyy")

        '        Dim objPaymentService As PHPaymentServiceClient = New PHPaymentServiceClient
        '        Dim objPaymentRequest As PaymentCloudService.GetPaymentInfoRequest = New PaymentCloudService.GetPaymentInfoRequest
        '        Dim objPaymentResponse As PaymentCloudService.GetPaymentInfoResponse = New PaymentCloudService.GetPaymentInfoResponse

        '        objPaymentRequest.AccountID = strVisionID.Trim()
        '        objPaymentRequest.CallingEntity = strAppID
        '        objPaymentRequest.RepUserId = strUserID.Trim()
        '        objPaymentRequest.ToDate = strToDate
        '        objPaymentRequest.FromDate = strFromDate

        '        objPaymentResponse = objPaymentService.GetPaymentInfo(objPaymentRequest)


        '        If (objPaymentResponse = "") Then
        '            If (objPaymentResponse.ResponseCode <> "" And objPaymentResponse.ResponseStatus <> "") Then
        '                If (objPaymentResponse.ResponseCode.Trim() = "9950" And objPaymentResponse.ResponseStatus.ToUpper().Trim() = "SUCCESS") Then
        '                    If (objPaymentResponse.GetPaymentInfoResultData <> "") Then
        '                        If (objPaymentResponse.GetPaymentInfoResultData.Count > 0) Then
        '                                objPayment = new PostPaymentDetails[objPaymentResponse.GetPaymentInfoResultData.Count ];

        '                        End If
        '                    End If
        '                End If
        '            End If

        '            For count = 0 To objGetAcctRelationship_Response.arrLstAcctRelationship.Count - 1
        '                objPayment[count] = new PostPaymentDetails();
        '                objPayment[count].strBilldate = (objPaymentResponse.GetPaymentInfoResultData(count).BillDate == null) ? "--" : (objPaymentResponse.GetPaymentInfoResultData[count].BillDate != string.Empty) ? Convert.ToString(objPaymentResponse.GetPaymentInfoResultData[count].BillDate.Substring(0,9)) : "--";
        '                objPayment[count].strPaymentID = (objPaymentResponse.GetPaymentInfoResultData[count].PaymentID == null) ? "--" : (objPaymentResponse.GetPaymentInfoResultData[count].PaymentID != string.Empty) ? Convert.ToString(objPaymentResponse.GetPaymentInfoResultData[count].PaymentID) : "--";
        '                objPayment[count].strReceivedDate = (objPaymentResponse.GetPaymentInfoResultData[count].ReceivedDate == null) ? "--" : (objPaymentResponse.GetPaymentInfoResultData[count].ReceivedDate != string.Empty) ? Convert.ToString(objPaymentResponse.GetPaymentInfoResultData[count].ReceivedDate) : "--";
        '                objPayment[count].strTransactionType = (objPaymentResponse.GetPaymentInfoResultData[count].TypeofTransaction == null) ? "--" : (objPaymentResponse.GetPaymentInfoResultData[count].TypeofTransaction != string.Empty) ? Convert.ToString(objPaymentResponse.GetPaymentInfoResultData[count].TypeofTransaction) : "--";
        '                objPayment[count].strVendor = (objPaymentResponse.GetPaymentInfoResultData[count].Vendor == null) ? "--" : (objPaymentResponse.GetPaymentInfoResultData[count].Vendor != string.Empty) ? Convert.ToString(objPaymentResponse.GetPaymentInfoResultData[count].Vendor) : "--";
        '                objPayment[count].strStatus = (objPaymentResponse.GetPaymentInfoResultData[count].Status == null) ? "--" : (objPaymentResponse.GetPaymentInfoResultData[count].Status != string.Empty) ? Convert.ToString(objPaymentResponse.GetPaymentInfoResultData[count].Status) : "--";
        '                objPayment[count].dblPaymentAmount = Convert.ToDouble(objPaymentResponse.GetPaymentInfoResultData[count].PaymentAmount);
        '                objPayment[count].strdateTimesenttoBilling = (objPaymentResponse.GetPaymentInfoResultData[count].DateTimesenttoBilling == null) ? "--" : (objPaymentResponse.GetPaymentInfoResultData[count].DateTimesenttoBilling != string.Empty) ? Convert.ToString(objPaymentResponse.GetPaymentInfoResultData[count].DateTimesenttoBilling) : "--";
        '                objPayment[count].strPostedDateandTimeInBilling = (objPaymentResponse.GetPaymentInfoResultData[count].PostedDateandTimeinBilling == null) ? "--" : (objPaymentResponse.GetPaymentInfoResultData[count].PostedDateandTimeinBilling != string.Empty) ? Convert.ToString(objPaymentResponse.GetPaymentInfoResultData[count].PostedDateandTimeinBilling) : "--";
        '                //objPayment[count].isPaymentAmountField = true;
        '                objPayment[count].strPaymentSource = (objPaymentResponse.GetPaymentInfoResultData[count].PaymentOrigin == null) ? "--" : (objPaymentResponse.GetPaymentInfoResultData[count].PaymentOrigin != string.Empty) ? Convert.ToString(objPaymentResponse.GetPaymentInfoResultData[count].PaymentOrigin) : "--";
        '                objPayment[count].strPaymentType = (objPaymentResponse.GetPaymentInfoResultData[count].PaymentType == null) ? "--" : (objPaymentResponse.GetPaymentInfoResultData[count].PaymentType != string.Empty )? Convert .ToString (objPaymentResponse.GetPaymentInfoResultData[count].PaymentType ):"--";
        '            Next

        '                                }

        '                            }
        '        Else
        '                            {
        '                                objPayment = null;
        '                            }
        '                        }
        '                        else
        '                        {
        '                            objPayment = null;
        '                        }


        '                    }
        '                    else
        '                    {
        '                        objPayment = null;
        '                    }
        '                }
        '                else
        '                {
        '                    objPayment = null;
        '                }

        '            }
        '            else
        '            {
        '                objPayment = null;
        '            }

        '        }
        '        Catch(Exception ex)
        '        objPayment = null
        '           LogErrorFile.WriteLog(strVisionID, "", ex.Message.ToString(), "", ErrorType.Error, Severity.High, ApplicationID.iCollect);

        '        Return objPayment

        'End Function
#End Region

#Region "RetrieveMultiBroadbandOneLEC - uses SSP_PA Info"
        <WebMethod(Description:="Get RetrieveMultiBroadbandOneLEC info from SSPPA ")> _
        Public Function RetrieveMultiBroadbandOneLEC_SSPPA(ByVal strAcctnum As String, ByVal strRegionid As String, ByVal intRequestid As String) As XmlDocument

            Dim objRetrieveRes As RetrievalServiceResponse = New RetrievalServiceResponse
            Dim objRequestContext As SoapContext
            Dim getURL As wsGETURL = New wsGETURL
            Dim objSSPNACRReq As RetriveService_SSPPA.RetrievalService = New RetriveService_SSPPA.RetrievalService
            Dim objRetrievalServiceTxn As RetrievalServiceTxn = New RetrievalServiceTxn
            Dim strSSPNACRReqxml As String = ""
            Dim strName As String = "xmlns=" & """http://www.verizon.com/RetrievalService"""

            strSSPNACRReqxml = "<RetrievalService " + strName + "><Comment>RetrievalAccount Request</Comment><Authentication><Id>RMW</Id><Password>rmicw05</Password></Authentication><ClientSystemId>COG</ClientSystemId><ClientRequestId>" + intRequestid + "</ClientRequestId><RetrieveMultiBroadbandBillingOneLEC><VoiceCAN>" + strAcctnum + "</VoiceCAN></RetrieveMultiBroadbandBillingOneLEC></RetrievalService>"
            Dim objRS As RetriveService_SSPPA.RetrievalServiceRetrieveMultiBroadbandBillingOneLEC = New RetriveService_SSPPA.RetrievalServiceRetrieveMultiBroadbandBillingOneLEC()

            Dim objResponse As Response = New Response
            Dim strXML As String = ""
            Dim strUrl = ""
            Dim strParmName As String = "SSPProfile"
            Dim sspRetrievalServiceXML As String = ""
            Dim xmldoc As New XmlDocument


            Try

                Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(strRegionid.Trim())

                strUrl = ObjDataAccess.usp_GetControlParmByName("Control" + strRegionid.Trim(), strParmName)

                objRequestContext = objRetrievalServiceTxn.RequestSoapContext
                objRetrievalServiceTxn.Proxy = New WebProxy
                objRequestContext.Security.Tokens.Clear()
                Dim unt As Tokens.UsernameToken = New Tokens.UsernameToken("RMW", "rmicw05", Tokens.PasswordOption.SendPlainText)
                objRequestContext.Security.Tokens.Add(unt)
                objRequestContext.Security.MustUnderstand = False

                If (strUrl = "") Then
                    strUrl = "https://sspprofile-nte3.ebiz.verizon.com/RetrievalWebService-COG_itw/RetrievalService"
                End If

                objRetrievalServiceTxn.Url = strUrl.Trim()
                objRetrievalServiceTxn.RequestSoapContext.Addressing.MustUnderstand = False
                sspRetrievalServiceXML = objRetrievalServiceTxn.doRequest(strSSPNACRReqxml.Trim())

            Catch ex As Exception
                LogErrorFile.WriteLog("RetrieveMultiBroadbandOneLEC_SSPPA", ex.Message.ToString())
                sspRetrievalServiceXML = "<RetrievalServiceResponse>" + ex.Message.ToString() + "</RetrievalServiceResponse>"
            End Try
            xmldoc.LoadXml(sspRetrievalServiceXML)
            Return xmldoc
        End Function
#End Region

#Region "RetrieveChildAccountforParent  - uses SSP_PA Info"
        <WebMethod(Description:="Get RetrieveChildAccountforParent  info from SSPPA ")> _
        Public Function RetrieveChildAccountforParent_SSPPA(ByVal strAcctnum As String, ByVal strRegionid As String, ByVal intRequestid As String) As XmlDocument

            Dim objRequestContext As SoapContext
            Dim objRetrievalServiceTxn As RetrievalServiceTxn = New RetrievalServiceTxn
            Dim strSSPNACRReqxml As String = ""
            Dim strName As String = "xmlns=" & """http://www.verizon.com/RetrievalService"""
            Dim strAcctID As String = "'" + strAcctnum.Trim().Substring(strAcctnum.Length - 4) + "'"
            Dim strAcctCID As String = "'" + strAcctnum.Trim().Substring(0, 9) + "'"
            Dim strUrl = ""
            Dim strParmName As String = "SSPProfile"
            Dim xmldoc As New XmlDocument
            Dim sspRetrievalServiceXML As String

            Try
                Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(strRegionid.Trim())
                strUrl = ObjDataAccess.usp_GetControlParmByName("Control" + strRegionid.Trim(), strParmName)

                strSSPNACRReqxml = "<RetrievalService " + strName + "><Comment>RetrievalAccount Request</Comment><Authentication><Id>RMW</Id><Password>rmicw05</Password></Authentication><ClientSystemId>COG</ClientSystemId><ClientRequestId>" + intRequestid + "</ClientRequestId><RetrieveChildAccountByParentId><VisionId visionCustomerId=" + strAcctCID + " visionAccountId=" + strAcctID + " /></RetrieveChildAccountByParentId></RetrievalService>"
                Dim strXML As String = ""
                Dim strSSPNACRUrl = ""
                objRequestContext = objRetrievalServiceTxn.RequestSoapContext
                objRetrievalServiceTxn.Proxy = New WebProxy
                objRequestContext.Security.Tokens.Clear()
                Dim unt As Tokens.UsernameToken = New Tokens.UsernameToken("RMW", "rmicw05", Tokens.PasswordOption.SendPlainText)
                objRequestContext.Security.Tokens.Add(unt)
                objRequestContext.Security.MustUnderstand = False

                If (strUrl = "") Then
                    strUrl = "https://sspprofile-nte3.ebiz.verizon.com/RetrievalWebService-COG_itw/RetrievalService"
                End If

                objRetrievalServiceTxn.Url = strUrl.Trim()
                objRetrievalServiceTxn.RequestSoapContext.Addressing.MustUnderstand = False

                sspRetrievalServiceXML = objRetrievalServiceTxn.doRequest(strSSPNACRReqxml.Trim())

            Catch ex As Exception
                LogErrorFile.WriteLog("RetrieveChildAccountforParent_SSPPA", ex.Message.ToString())
                sspRetrievalServiceXML = "<RetrievalServiceResponse>" + ex.Message.ToString() + "</RetrievalServiceResponse>"
            End Try
            xmldoc.LoadXml(sspRetrievalServiceXML)
            Return xmldoc
        End Function
#End Region

#Region "RMICW -Account Status"

        <WebMethod(Description:="RMICW Account Status ")> _
        Public Function RMICWAccountStatus(ByVal strVisionCustomerId As String, ByVal strVisionAccountId As String, ByVal strAcctnum As String, ByVal strAppId As String, ByVal strBTN As String, ByVal strRegionId As String, ByVal intInrequestid As String) As String
            Dim strResponse As String

            If strRegionId.ToUpper.Trim() = "NE" Or strRegionId.ToUpper.Trim() = "NY" Or strRegionId.ToUpper.Trim() = "NPD" Or strRegionId.ToUpper.Trim() = "MDVW" Or strRegionId.ToUpper.Trim() = "VISION" Or strRegionId.ToUpper.Trim() = "WEST" Then

                Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(strRegionId.Trim())
                Dim ds As DataSet = New DataSet()

                If (strVisionCustomerId <> "" And strVisionAccountId <> "") Then
                    strAcctnum = strVisionCustomerId.Trim() + strVisionAccountId.Trim()
                End If

                Try
                    ds = ObjDataAccess.usp_GetAccountStatus(strAcctnum, strAppId, intInrequestid)

                    strResponse = ds.GetXml.ToString()

                    strResponse = strResponse.Replace("<NewDataSet>", "<RMICWRequestWS_Output>")
                    strResponse = strResponse.Replace("</NewDataSet>", "</RMICWRequestWS_Output >")
                    strResponse = strResponse.Replace("<Table>", "")
                    strResponse = strResponse.Replace("</Table>", "")

                Catch ex As Exception
                    LogErrorFile.WriteLog("RMICWWS : RMICWAccountStatus", ex.Message.ToString() + "-" + strAcctnum + "-" + strRegionId)
                    strResponse = ""
                    strResponse = "<RMICWRequestWS_Output><strAcctNum>" + strAcctnum + "</<strAcctNum> <strMessageId>RMWEXPTN</strMessageId><strMessageDescription>RMICW Internal Error</strMessageDescription></RMICWRequestWS_Output>"
                End Try
            Else
                strResponse = ""
                strResponse = "<RMICWRequestWS_Output><strAcctNum>" + strAcctnum + "</<strAcctNum> <strMessageId>RMWINVLD</strMessageId><strMessageDescription>Invalid Region Passed</strMessageDescription></RMICWRequestWS_Output>"
            End If
            Return strResponse
        End Function
#End Region
    End Class
End Namespace
