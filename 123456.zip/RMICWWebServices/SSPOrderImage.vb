﻿Option Strict Off
Option Explicit On

Imports System
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Web.Services2
Imports System.Web.Services2.Protocols
Imports System.Xml.Serialization



Namespace Verizon.RMICW.WebServices
    '''<remarks/>
    <System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "2.0.50727.3038"), _
     System.SerializableAttribute(), _
     System.Diagnostics.DebuggerStepThroughAttribute(), _
     System.ComponentModel.DesignerCategoryAttribute("code"), _
     System.Xml.Serialization.XmlTypeAttribute(AnonymousType:=True, [Namespace]:="http://www.verizon.com/OrderViewService"), _
     System.Xml.Serialization.XmlRootAttribute([Namespace]:="http://www.verizon.com/OrderViewService", IsNullable:=False)> _
    Public Class OrderViewService

        Private commentField As String

        Private authenticationField As OrderViewServiceAuthentication


        Private clientSystemIdField As String

        Private clientRequestIdField As String

        Private getOrderViewField As OrderViewServiceGetOrderView

        '''<remarks/>
        Public Property Comment() As String
            Get
                Return Me.commentField
            End Get
            Set(ByVal value As String)
                Me.commentField = value
            End Set
        End Property

   

        '''<remarks/>
        <System.Xml.Serialization.XmlElementAttribute("Authentication")> _
        Public Property Authentication() As OrderViewServiceAuthentication
            Get
                Return Me.authenticationField
            End Get
            Set(ByVal value As OrderViewServiceAuthentication)
                Me.authenticationField = value
            End Set
        End Property

        '''<remarks/>
        Public Property ClientSystemId() As String
            Get
                Return Me.clientSystemIdField
            End Get
            Set(ByVal value As String)
                Me.clientSystemIdField = value
            End Set
        End Property

        '''<remarks/>
        Public Property ClientRequestId() As String
            Get
                Return Me.clientRequestIdField
            End Get
            Set(ByVal value As String)
                Me.clientRequestIdField = value
            End Set
        End Property

        '''<remarks/>
        <System.Xml.Serialization.XmlElementAttribute("GetOrderView")> _
        Public Property GetOrderView() As OrderViewServiceGetOrderView
            Get
                Return Me.getOrderViewField
            End Get
            Set(ByVal value As OrderViewServiceGetOrderView)
                Me.getOrderViewField = value
            End Set
        End Property

        Public Sub New()

            Comment = "OrderView Request"
            Authentication = New OrderViewServiceAuthentication
            GetOrderView = New OrderViewServiceGetOrderView
            ClientRequestId = "ICN1234"
            ClientSystemId = "ICN"

        End Sub


    End Class

    '''<remarks/>
    <System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "2.0.50727.3038"), _
     System.SerializableAttribute(), _
     System.Diagnostics.DebuggerStepThroughAttribute(), _
     System.ComponentModel.DesignerCategoryAttribute("code"), _
     System.Xml.Serialization.XmlTypeAttribute(AnonymousType:=True, [Namespace]:="http://www.verizon.com/OrderViewService")> _
    Partial Public Class OrderViewServiceAuthentication

        Private idField As String

        Private passwordField As String

        '''<remarks/>
        Public Property Id() As String
            Get
                Return Me.idField
            End Get
            Set(ByVal value As String)
                Me.idField = value
            End Set
        End Property

        '''<remarks/>
        Public Property Password() As String
            Get
                Return Me.passwordField
            End Get
            Set(ByVal value As String)
                Me.passwordField = value
            End Set
        End Property

        Public Sub New()
            Id = "RMICW"
            Password = "RMICW"
        End Sub
    End Class

    '''<remarks/>
    <System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "2.0.50727.3038"), _
     System.SerializableAttribute(), _
     System.Diagnostics.DebuggerStepThroughAttribute(), _
     System.ComponentModel.DesignerCategoryAttribute("code"), _
     System.Xml.Serialization.XmlTypeAttribute(AnonymousType:=True, [Namespace]:="http://www.verizon.com/OrderViewService")> _
    Partial Public Class OrderViewServiceGetOrderView

        Private orderIdField As String

        Private isCancelledOrderRequiredField As String

        '''<remarks/>
        <System.Xml.Serialization.XmlAttributeAttribute()> _
        Public Property orderId() As String
            Get
                Return Me.orderIdField
            End Get
            Set(ByVal value As String)
                Me.orderIdField = value
            End Set
        End Property

        '''<remarks/>
        <System.Xml.Serialization.XmlAttributeAttribute()> _
        Public Property isCancelledOrderRequired() As String
            Get
                Return Me.isCancelledOrderRequiredField
            End Get
            Set(ByVal value As String)
                Me.isCancelledOrderRequiredField = value
            End Set
        End Property
        Public Sub New()
            orderId = ""
            isCancelledOrderRequired = "N"

        End Sub
    End Class

    '''<remarks/>
    '<System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "2.0.50727.3038"), _
    ' System.SerializableAttribute(), _
    ' System.Diagnostics.DebuggerStepThroughAttribute(), _
    ' System.ComponentModel.DesignerCategoryAttribute("code"), _
    ' System.Xml.Serialization.XmlTypeAttribute(AnonymousType:=True, [Namespace]:="http://www.verizon.com/OrderViewService"), _
    ' System.Xml.Serialization.XmlRootAttribute([Namespace]:="http://www.verizon.com/OrderViewService", IsNullable:=False)> _
    'Partial Public Class NewDataSet
    '    Private itemField As String
    '    '''<remarks/>
    '    <System.Xml.Serialization.XmlElementAttribute("OrderViewService")> _
    '    Public Property item() As String
    '        'Public Property Items() As OrderViewService()
    '        Get
    '            Return Me.itemField
    '        End Get
    '        Set(ByVal value As String)
    '            Me.itemField = value
    '        End Set
    '    End Property



    'End Class
End Namespace


