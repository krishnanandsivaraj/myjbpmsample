﻿Option Strict Off
Option Explicit On

Imports System.Xml.Serialization
Imports CommonLibrary
Imports System.Xml
Imports Verizon.RMICW.DataAccess
Imports Verizon.RMICW.WebServices
Imports IBM.WMQ
Imports IBM

Imports Microsoft.Web.Services2.Security
Imports Microsoft.Web.Services2
Imports Microsoft.Web.Services2.Dime
Imports System.Web.Services.Protocols
Imports System.Diagnostics
Imports System.Web.Services
Imports System.Net
Imports System.IO
Imports System.Text




Namespace Verizon.RMICW.WebServices
    Public Class VisionSSP
#Region "getSSPProdProfile"


        Public Function getSSPProdProfile(ByVal objSSPRqst As SSPRequestDetails) As SSPRequestDetails



            Dim objclsSSPTxn As clsSSPTxn = New clsSSPTxn

            Dim getURL As wsGETURL = New wsGETURL
            Dim posturl As String = ""
            Dim postProfileurl As String = ""
            Dim strProfileXml As String = ""
            Dim objService As WSMain = New WSMain()
            Dim objFullProfileResp As SSPPAFullProfile.getVZFullProfileResponse = New SSPPAFullProfile.getVZFullProfileResponse()

            Dim xmlDoc As XmlDocument = New XmlDocument
            Dim xmlProfileDoc As XmlDocument = New XmlDocument
            Dim strServiceID As String = ""

            Dim intLoop As Integer = 6
            Dim blnSuccess As Boolean = False
            Dim objSubType As SSPRequestDetails.SSPRequestDetailsSubType = New SSPRequestDetails.SSPRequestDetailsSubType
            Dim strSubType As String
            Dim objarrLst As ArrayList = New ArrayList



            Try
                postProfileurl = getURL.getSSPURL(objSSPRqst.strRegionId.Trim(), "SSPPROFILE")

                If postProfileurl.Trim() = "" Then
                    postProfileurl = "https://sspsac.verizon.com/RetrievalWebService-COG_itw/RetrievalService"
                End If

                'RETRY
                If objSSPRqst.intRequestId = "" Then
                    objSSPRqst.intRequestId = 1
                End If
                'objFullProfileResp = objService.getFullProfile(objSSPRqst.strAcctNum, "WEST", objSSPRqst.intRequestId)

                If objFullProfileResp Is Nothing Then

                    While intLoop > 3
                        'objFullProfileResp = objService.getFullProfile(objSSPRqst.strAcctNum, "WEST", objSSPRqst.intRequestId)
                        If objFullProfileResp Is Nothing Then
                            intLoop = intLoop - 1
                        Else
                            intLoop = 0
                        End If

                    End While


                End If

                If Not objFullProfileResp Is Nothing Then
                    Dim objStatus As SSPPAFullProfile.oneErrorReportStatus
                    For Each objStatus In objFullProfileResp.StatusReport
                        If objStatus.description.ToUpper() = "SUCCESS" Then
                            blnSuccess = True
                        Else

                            If objStatus.source = "SSP" Then
                                objSSPRqst.strReturnCd = objStatus.category + objStatus.code
                                objSSPRqst.strRemarks = objStatus.description
                            End If
                        End If

                    Next
                End If

                If blnSuccess = True Then

                    Dim objaccInfoType As SSPPAFullProfile.accInfoType = New SSPPAFullProfile.accInfoType

                    Dim objserviceInfo As SSPPAFullProfile.getProfileServiceLocationTypeServiceLocation

                    objSSPRqst.AccountDetails.strAcctStatus = objFullProfileResp.accountInformation.dataAccount.getProfileAccountProfile.accountStatus
                    objSSPRqst.strSSPAccountID = objFullProfileResp.accountInformation.dataAccount.getProfileAccountProfile.sspAccountId
                    objSSPRqst.AccountDetails.VisionAccountType = objFullProfileResp.accountInformation.common.Customer.VisionAccountType

                    objSSPRqst.copyRightInfringementLevel = objFullProfileResp.accountInformation.dataAccount.getProfileAccountProfile.copyRightInfringementLevel
                    objSSPRqst.isPortOutTreatment = objFullProfileResp.accountInformation.dataAccount.getProfileAccountProfile.isPortOutTreatment
                    objSSPRqst.accountStatus = objFullProfileResp.accountInformation.dataAccount.getProfileAccountProfile.accountStatus
                    objSSPRqst.AccountDetails.strFirstName = objFullProfileResp.accountInformation.dataAccount.getProfileAccountProfile.AccountContact.name.firstName
                    objSSPRqst.AccountDetails.strLastName = objFullProfileResp.accountInformation.dataAccount.getProfileAccountProfile.AccountContact.name.lastName
                    'objSSPRqst.AccountDetails.Email = objFullProfileResp.accountInformation.dataAccount.getProfileAccountProfile.AccountContact.email
                    'objSSPRqst.AccountDetails.Email = objFullProfileResp.accountInformation.common.CustomerContact.Email
                    'objSSPRqst.AccountDetails.EmailValidated = objFullProfileResp.accountInformation.common.CustomerContact.EmailValidated
                    'objSSPRqst.AccountDetails.EmailVerified = objFullProfileResp.accountInformation.common.CustomerContact.EmailVerified
                    'objSSPRqst.AccountDetails.MTN = objFullProfileResp.accountInformation.common.CustomerContact.MTN
                    'objSSPRqst.AccountDetails.MTNConsent = objFullProfileResp.accountInformation.common.CustomerContact.MTNConsent
                    'objSSPRqst.AccountDetails.MTNValidated = objFullProfileResp.accountInformation.common.CustomerContact.MTNValidated
                    'objSSPRqst.AccountDetails.MTNVerified = objFullProfileResp.accountInformation.common.CustomerContact.MTNVerified

                    objSSPRqst.nWGStatus = objFullProfileResp.accountInformation.dataAccount.getProfileAccountProfile.nWGStatus
                    objSSPRqst.nWGType = objFullProfileResp.accountInformation.dataAccount.getProfileAccountProfile.nWGType
                    objSSPRqst.nWGSecurityLevel = objFullProfileResp.accountInformation.dataAccount.getProfileAccountProfile.nWGSecurityLevel
                    'objSSPRqst.nWGDateActionTaken = objFullProfileResp.accountInformation.dataAccount.getProfileAccountProfile.nWGDateActionTaken.monthPart + objFullProfileResp.accountInformation.dataAccount.getProfileAccountProfile.nWGDateActionTaken.dayPart + objFullProfileResp.accountInformation.dataAccount.getProfileAccountProfile.nWGDateActionTaken.yearPart

                    objSSPRqst.AccountDetails.strAddStreet = objFullProfileResp.accountInformation.dataAccount.getProfileAccountProfile.BillingAddress.StreetName
                    objSSPRqst.AccountDetails.strAddHouseNo = objFullProfileResp.accountInformation.dataAccount.getProfileAccountProfile.BillingAddress.StreetNumber
                    objSSPRqst.AccountDetails.strAddCity = objFullProfileResp.accountInformation.dataAccount.getProfileAccountProfile.BillingAddress.City
                    objSSPRqst.AccountDetails.strAddState = objFullProfileResp.accountInformation.dataAccount.getProfileAccountProfile.BillingAddress.State
                    objSSPRqst.AccountDetails.strAddZip = objFullProfileResp.accountInformation.dataAccount.getProfileAccountProfile.BillingAddress.zipCode.zipCodeBase






                    objSubType.strServiceId = ""
                    objSubType.strCircuitId = ""



                    For Each objserviceInfo In objFullProfileResp.accountInformation.dataAccount.getProfileAccountProfile.serviceInfo

                        If Not objserviceInfo.Data Is Nothing Then
                            Dim objProducts As SSPPAFullProfile.getProfileDataInfoServices
                            For Each objProducts In objserviceInfo.Data

                                If Not objProducts.BBEService Is Nothing Then
                                    objSSPRqst.blnBBEON = True
                                    objSSPRqst.strCircuitId = objProducts.BBEService.bbeServiceId
                                    objSubType.strServiceName = "BBEService"
                                    objSubType.strServiceId = objProducts.BBEService.bbeServiceId
                                    objSubType.strServiceStatus = objProducts.serviceStatus
                                    objSubType.strProdType = "BBE"

                                ElseIf Not objProducts.CAOfferService Is Nothing Then
                                    objSSPRqst.blnBBEON = True
                                    objSSPRqst.strCircuitId = objProducts.CAOfferService.caofferServiceId
                                    objSubType.strServiceName = "CAOfferService"
                                    objSubType.strServiceId = objProducts.CAOfferService.caofferServiceId
                                    objSubType.strServiceStatus = objProducts.serviceStatus
                                    objSubType.strProdType = "CAOffer"



                                ElseIf Not objProducts.CDSEndUser Is Nothing Then
                                    objSSPRqst.blnCDSEndUser = True
                                    objSSPRqst.strCircuitId = objProducts.CDSEndUser.ISPCircuitId
                                    objSubType.strServiceName = "FiberEndUser"
                                    objSubType.strServiceId = objProducts.CDSEndUser.VADICircuitId
                                    objSubType.strServiceStatus = objProducts.serviceStatus
                                    objSubType.strProdType = "CDSEndUser"

                                ElseIf Not objProducts.CVSEndUser Is Nothing Then
                                    objSSPRqst.blnCVSTYPEON = True
                                    objSSPRqst.strCircuitId = objProducts.CVSEndUser.FiberTN.tnAreaCode + objProducts.CVSEndUser.FiberTN.tnBase + objProducts.CVSEndUser.FiberTN.tnPrefix
                                    objSubType.strServiceName = "CVSEndUser"
                                    objSubType.strServiceId = objProducts.serviceId
                                    objSubType.strServiceStatus = objProducts.serviceStatus
                                    objSubType.strProdType = "CVSEndUser"

                                ElseIf Not objProducts.DIAService Is Nothing Then
                                    objSSPRqst.blnDIAON = True
                                    objSSPRqst.strCircuitId = objProducts.DIAService.vzUserId
                                    objSubType.strServiceName = "DIAService"
                                    objSubType.strServiceId = objProducts.serviceId
                                    objSubType.strServiceStatus = objProducts.serviceStatus
                                    objSubType.strProdType = "DIA"

                                ElseIf Not objProducts.DNEService Is Nothing Then
                                    objSSPRqst.blnDNEON = True
                                    objSSPRqst.strCircuitId = objProducts.DNEService.WTN.tnAreaCode + objProducts.DNEService.WTN.tnBase + objProducts.DNEService.WTN.tnPrefix
                                    objSubType.strServiceName = "DNEService"
                                    objSubType.strServiceId = objProducts.DNEService.DNRService.dnrServiceId
                                    objSubType.strServiceStatus = objProducts.DNEService.DNRService.serviceStatus
                                    objSubType.strProdType = "DNE"

                                ElseIf Not objProducts.DNRService Is Nothing Then
                                    objSSPRqst.blnDNRON = True
                                    objSSPRqst.strCircuitId = ""
                                    objSubType.strServiceName = "DNRService"
                                    objSubType.strServiceId = objProducts.DNRService.dnrServiceId
                                    objSubType.strServiceStatus = objProducts.DNRService.serviceStatus
                                    objSubType.strProdType = "DNR"

                                ElseIf Not objProducts.DeskTopSecurityService Is Nothing Then
                                    objSSPRqst.blnWEBSECURITYON = True
                                    objSSPRqst.strCircuitId = ""
                                    objSubType.strServiceName = "DeskTopSecurityService"
                                    objSubType.strServiceId = objProducts.DeskTopSecurityService.DesktopSecurityelements.emailAddress
                                    objSubType.strServiceStatus = objProducts.serviceStatus
                                    objSubType.strProdType = "DeskTopSecurityService"

                                ElseIf Not objProducts.FiosVoice Is Nothing Then
                                    objSSPRqst.blnFVoiceON = True
                                    objSSPRqst.strCircuitId = objProducts.FiosVoice.ISPCircuitId
                                    objSubType.strServiceName = "FiosVoice"
                                    objSubType.strServiceId = objProducts.serviceId
                                    objSubType.strServiceStatus = objProducts.serviceStatus
                                    objSubType.strProdType = "FIOS_VOICE"

                                ElseIf Not objProducts.PremiumSecurityService Is Nothing Then
                                ElseIf Not objProducts.Thunder Is Nothing Then
                                    objSSPRqst.blnFVoiceON = True
                                    objSSPRqst.strCircuitId = objProducts.FiosVoice.ISPCircuitId
                                    objSubType.strServiceName = "Thunder"
                                    objSubType.strServiceId = objProducts.serviceId
                                    objSubType.strServiceStatus = objProducts.serviceStatus
                                    objSubType.strProdType = "THUNDER"
                                ElseIf Not objProducts.VASIPService Is Nothing Then
                                    objSSPRqst.blnVASIPON = True
                                    objSSPRqst.strCircuitId = objProducts.VASIPService.vzUserId
                                    objSubType.strServiceName = "VASIPService"
                                    objSubType.strServiceId = objProducts.serviceId
                                    objSubType.strServiceStatus = objProducts.serviceStatus
                                    objSubType.strProdType = "VASIP"

                                ElseIf Not objProducts.VZWirelessService Is Nothing Then
                                ElseIf Not objProducts.VideoEndUser Is Nothing Then
                                    objSSPRqst.blnCDSEndUser = True
                                    objSSPRqst.strCircuitId = objProducts.videoService.circuitId
                                    objSubType.strServiceName = "VideoEndUser"
                                    objSubType.strServiceId = objProducts.serviceId
                                    objSubType.strServiceStatus = objProducts.serviceStatus
                                    objSubType.strProdType = "FIOS_VIDEO_END_USER"

                                ElseIf Not objProducts.WebDevelopmentService Is Nothing Then
                                ElseIf Not objProducts.WebHostingService Is Nothing Then
                                ElseIf Not objProducts.dialService Is Nothing Then
                                    objSSPRqst.blnDIALUPON = True
                                    objSubType.strServiceName = "dialService"
                                    objSubType.strServiceId = objProducts.serviceId
                                    objSubType.strServiceStatus = objProducts.serviceStatus
                                    objSSPRqst.strCircuitId = objProducts.dialService.vzUserId
                                    objSSPRqst.internetTOSAccepted = objProducts.dialService.internetTOSAccepted
                                    objSSPRqst.internetTOSAcceptedVersion = objProducts.dialService.internetTOSAcceptedVersion
                                    objSSPRqst.internetTOSAcceptedDate = objProducts.dialService.internetTOSAcceptedDate.monthPart + objProducts.dialService.internetTOSAcceptedDate.dayPart + objProducts.dialService.internetTOSAcceptedDate.yearPart
                                    objSubType.strProdType = "DialUp"

                                ElseIf Not objProducts.dslService Is Nothing Then
                                    objSSPRqst.blnDSLON = True
                                    objSubType.strServiceName = "dslService"
                                    objSubType.strServiceId = objProducts.serviceId
                                    objSubType.strServiceStatus = objProducts.serviceStatus
                                    objSSPRqst.strCircuitId = objProducts.dslService.vadiCircuitId
                                    objSubType.strProdType = "DSL"

                                ElseIf Not objProducts.fttpService Is Nothing Then
                                    objSSPRqst.blnFDataON = True
                                    objSSPRqst.ispId = objProducts.fttpService.isChangeISP
                                    objSSPRqst.strCircuitId = objProducts.fttpService.VADICircuitId
                                    objSSPRqst.internetTOSAccepted = objProducts.fttpService.internetTOSAccepted
                                    objSSPRqst.internetTOSAcceptedVersion = objProducts.fttpService.internetTOSAcceptedVersion
                                    objSSPRqst.internetTOSAcceptedDate = objProducts.fttpService.internetTOSAcceptedDate.monthPart + objProducts.fttpService.internetTOSAcceptedDate.dayPart + objProducts.fttpService.internetTOSAcceptedDate.yearPart

                                    objSubType.strServiceName = "fttpService"
                                    objSubType.strServiceId = objProducts.serviceId
                                    objSubType.strCircuitId = objProducts.fttpService.VADICircuitId
                                    objSubType.strSuspendReasonCode = objProducts.fttpService.suspendReasonCode
                                    objSubType.strServiceStatus = objProducts.serviceStatus
                                    objSubType.strProdType = "FIOS_DATA"

                                    objSSPRqst.nWGStatus = objFullProfileResp.accountInformation.dataAccount.getProfileAccountProfile.nWGStatus
                                    objSSPRqst.nWGType = objFullProfileResp.accountInformation.dataAccount.getProfileAccountProfile.nWGType
                                    objSSPRqst.nWGSecurityLevel = objFullProfileResp.accountInformation.dataAccount.getProfileAccountProfile.nWGSecurityLevel





                                ElseIf Not objProducts.videoService Is Nothing Then

                                    objSSPRqst.blnFVideoON = True
                                    objSSPRqst.strCircuitId = objProducts.videoService.circuitId
                                    objSubType.strServiceName = "videoService"
                                    objSubType.strServiceId = objProducts.serviceId
                                    objSubType.strServiceStatus = objProducts.serviceStatus
                                    objSubType.strProdType = "FIOS_VIDEO"
                                End If




                                objarrLst.Add(objSubType)
                                objSubType = New SSPRequestDetails.SSPRequestDetailsSubType
                                objSSPRqst.subType = objarrLst.ToArray(GetType(SSPRequestDetails.SSPRequestDetailsSubType))
                                objSSPRqst.blnProducts = True



                            Next
                        End If




                    Next




                End If


            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-RetrievalServiceTxn:intRequestid/strActn/strOrg/intLoop/ExceptionMsg:", objSSPRqst.intRequestId + "/" + objSSPRqst.strOrg + "/" + intLoop.ToString() + "/" + ex.ToString())
                If (getURL.getSSPURL(objSSPRqst.strRegionId.Trim(), "LOGGINGPROFILE").Trim() = "TRUE") Then
                    Try
                        Dim objDA As WSDataAccessGeneric = New WSDataAccessGeneric(objSSPRqst.strRegionId.Trim())
                        objDA.usp_InserttAuditLog("PROFILE", "X", objSSPRqst.strAcctNum, objSSPRqst.strActn, objSSPRqst.strProfileCAN, objSSPRqst.strSSPAccountID, "", objSSPRqst.intRequestId, 0, strProfileXml.Trim(), objSSPRqst.strAcctLvlOrder.Trim())
                    Catch exProfileAudit As Exception
                        LogErrorFile.WriteLog("RMICWWS-getSSPPROFILE:LOGGING", exProfileAudit.ToString())
                    End Try
                End If
                Throw (ex)



            End Try



        End Function






#End Region

    End Class

End Namespace


