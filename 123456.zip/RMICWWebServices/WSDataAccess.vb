Imports Verizon.RMICW.DataAccess
Imports CommonLibrary
Imports System
Imports System.Xml
Imports System.Drawing.Text
Imports System.Xml.Serialization
Imports System.IO
Imports System.Text.RegularExpressions
Imports CommonLibrary.SSPPAFullProfile



Namespace Verizon.RMICW.WebServices



    Public Enum RegionType
        NE
        NY
        MDVW
        NPD
        WEST
        VISION
    End Enum

    Public Class retSOPClass
        Public intSOPRequestId As Long
        Public intAAISSyncStatus As Integer
        Public intAAISAsyncStatus As Integer
        Public intSkipRequest As Integer
    End Class


    Public Class WSDataAccessGeneric

        Private strRegionId As String
        Private dbEnv As String
        Private dbtype As dbType = dbtype.SQLServer
        Private dataAccess As DataAccessComponent = Nothing
        'This DataSet is used as a memory data
        'Private Shared dsParm As DataSet
        Public Shared dsDAParm As DataSet = Nothing
        Private Shared dsOrgActn As DataSet = Nothing
        Private Shared dsREFParm As DataSet = Nothing


        Public ReadOnly Property RegionId() As String
            Get
                Return strRegionId
            End Get

        End Property

        Public Property PDBEnv() As Object
            Get
                Return dbEnv
            End Get
            Set(ByVal Value As Object)
                dbEnv = Value
            End Set
        End Property

        Public Sub resetDBObj()
            dataAccess = Nothing
            dataAccess = New DataAccessComponent(dbtype, dbEnv)
        End Sub

        Public Sub resetDBObj(ByVal dbEnv As String)
            dataAccess = Nothing
            PDBEnv = dbEnv
            dataAccess = New DataAccessComponent(dbtype, PDBEnv)

        End Sub

        Public ReadOnly Property DataAccessObj() As DataAccessComponent
            Get
                If (dataAccess Is Nothing) Then
                    Try
                        dataAccess = New DataAccessComponent(dbtype, PDBEnv)
                    Catch ex As Exception
                        Throw ex
                    End Try
                End If
                Return dataAccess

            End Get

        End Property


        Public Sub New()
            strRegionId = "NE"
            PDBEnv = "ProdNE"
        End Sub

        Public Sub New(ByVal regionId As String)
            strRegionId = regionId
            PDBEnv = "Prod" + regionId.Trim()
            resetDBObj(PDBEnv)
        End Sub

        Public Sub New(ByVal regionId As String, ByVal strType As String)
            strRegionId = regionId
            PDBEnv = "Prod" + regionId.Trim()
            resetDBObj(PDBEnv)
            dsParmValue = usp_GetControlparmALLByRegion()
        End Sub


        Public Property dsParmValue() As Object
            Get

                If dsDAParm Is Nothing Then
                    dsDAParm = usp_GetControlparmALLByRegion()

                End If
                Return dsDAParm
            End Get
            Set(ByVal Value As Object)
                dsDAParm = Value
            End Set
        End Property


        Public Property dsRefActnValue() As Object
            Get

                If dsREFParm Is Nothing Then
                    dsREFParm = usp_GetRefActionALL()

                End If
                Return dsREFParm
            End Get
            Set(ByVal Value As Object)
                dsREFParm = Value
            End Set
        End Property



        'get tRefAction 
        Public Sub New(ByVal regionId As String, ByVal strType As String, ByVal strOrg As String)
            strRegionId = regionId
            PDBEnv = "Prod" + regionId.Trim()
            resetDBObj(PDBEnv)
            dsRefActnValue = usp_GetRefActionALL()
        End Sub



#Region "usp_GetTreatmentData"
        Public Function usp_GetTreatmentData(ByVal strAcctNum As String, ByVal strOrg As String, ByVal strAppid As String, ByVal strRegionCd As String) As DataSet
            Dim ds As DataSet
            Try
                ds = DataAccessObj().execStoreProcedure(strAcctNum, strOrg, strAppid, strRegionCd)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return ds
        End Function
#End Region

#Region "usp_GetControlParmByName"
        Public Function usp_GetControlParmByName(ByVal strRegionId As String, ByVal strParmName As String) As String

            Dim strvalue As String = " "
            Try
                strvalue = GetParmSelect(strParmName, strRegionId)


            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return strvalue
        End Function
#End Region

#Region "usp_GetRefAction"
        Public Function usp_GetRefAction(ByVal strRegionId As String, ByVal strType As String) As String

            Dim strvalue As String = " "
            Try

                strvalue = GetRefActnSelect("ALL", strType, strRegionId)

            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return strvalue
        End Function
#End Region

#Region "usp_insertPPSHACK : Confirmation"
        Public Function usp_InsertPPSHACK(ByVal strAppId As String, ByVal strRegionCd As String, ByVal strInputXml As String)
            Try
                DataAccessObj().execStoreProcedure(strAppId, strRegionCd, strInputXml)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
        End Function
#End Region

#Region "usp_GetCustomerAddressInfo"
        Public Function usp_GetCustomerAddressInfo(ByVal strRegionId As String, ByVal strAcctNum As String) As DataSet

            Dim ds As DataSet
            Dim strvalue As String = " "
            Try
                ds = DataAccessObj().execStoreProcedure(strRegionId, strAcctNum)


            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            Finally

            End Try
            Return ds
        End Function
#End Region
#Region "usp_GetCustomerAddressInfo"
        Public Function USP_GetClassOfService(ByVal strXMLData As String) As DataSet

            Dim ds As DataSet
            Dim strvalue As String = " "
            Try
                ds = DataAccessObj().execStoreProcedure(strXMLData)

            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            Finally

            End Try
            Return ds
        End Function
#End Region


#Region "usp_getClaims"

        Public Function usp_getClaims(ByVal strRegionId As String, ByVal strAcctNum As String) As DataSet

            Dim ds As DataSet
            Try
                ds = DataAccessObj().execStoreProcedure(strRegionId, strAcctNum)

            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            Finally

            End Try
            Return ds
        End Function
#End Region

#Region "usp_GetEnvironment"
        Public Function usp_GetEnvironment(ByVal strRegionId As String, ByVal strAcctNum As String, ByVal strEnvironment As String) As String

            Dim strvalue As String = " "
            Try
                Dim ds As DataSet
                Dim dt As DataTable
                Dim dr As DataRow
                ds = DataAccessObj().execStoreProcedure(strRegionId, strAcctNum, strEnvironment)
                For i As Integer = 0 To ds.Tables.Count - 1
                    dt = ds.Tables(i)
                    'For Each dt In ds.Tables
                    For j As Integer = 0 To dt.Rows.Count - 1
                        dr = dt.Rows(j)
                        'For Each dr In dt.Rows
                        strvalue = dr("strParmValue")
                    Next
                Next

            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return strvalue
        End Function
#End Region

#Region "usp_insertAuditTrail"
        Public Function usp_InsertAuditTrail(ByVal strSource As String, ByVal strDestination As String, ByVal strOrg As String, ByVal strActn As String, ByVal strType As String, ByVal strAcctNum As String, ByVal strDescription As String) As Integer
            Dim i As Integer
            Try
                i = DataAccessObj().execStoreProcedureNonQuery(strSource, strDestination, strOrg, strActn, strType, strAcctNum, strDescription)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return i
        End Function
#End Region

#Region "usp_getTreatmentStatus"
        Public Function usp_GetTreatmentStatus(ByVal strRegionCd As String, ByVal strInpType As String, ByVal strAcctNum As String, ByVal strOrg As String, ByVal strApplicationId As String) As DataSet
            Dim ds As DataSet
            Try
                ds = DataAccessObj().execStoreProcedure(strRegionCd, strInpType, strAcctNum, strOrg, strApplicationId)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return ds
        End Function
#End Region

#Region "usp_getTreatmentStatusFIOS"
        Public Function usp_GetTreatmentStatusFIOS(ByVal strRegionCd As String, ByVal strWTN As String) As DataSet
            Dim ds As DataSet
            Try
                ds = DataAccessObj().execStoreProcedure(strRegionCd, strWTN)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return ds
        End Function
#End Region


#Region "usp_GetRMICWProductStatus"
        Public Function usp_GetProductStatus(ByVal strRegionCd As String, ByVal strAcctnum As String, ByVal strFIOSInd As String) As DataSet
            Dim ds As DataSet
            Try
                ds = DataAccessObj().execStoreProcedure(strRegionCd, strAcctnum, strFIOSInd)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return ds
        End Function
#End Region

#Region "usp_GetSBMProductStatus"
        Public Function usp_GetSBMProductStatus(ByVal strRegionId As String, ByVal strChildListXML As String, ByVal strRshipCode As String) As DataSet
            Dim ds As DataSet
            Try
                ds = DataAccessObj().execStoreProcedure(strRegionId, strChildListXML, strRshipCode)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return ds
        End Function
#End Region

#Region "usp_InsertBalanceResponse"
        Public Function usp_InsertBalanceResponse(ByVal strAcctNum As String, ByVal strRegionId As String, ByVal strAppId As String, ByVal strXML As String) As DataSet
            Dim ds As DataSet
            Try
                ds = DataAccessObj().execStoreProcedure(strAcctNum, strRegionId, strAppId, strXML)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return ds
        End Function
#End Region


#Region "usp_InsertERAResponse" 'WR68132
        Public Function usp_InsertERAResponse(ByVal strAcctNum As String, ByVal strRegionId As String, ByVal strAppId As String, ByVal strXML As String) As DataSet
            Dim ds As DataSet
            Try
                ds = DataAccessObj().execStoreProcedure(strAcctNum, strRegionId, strAppId, strXML)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return ds
        End Function
#End Region


#Region "usp_UpdateSTRATARealTimeNotification"
        Public Function usp_UpdateSTRATARealTimeNotification(ByVal strAcctNum As String, ByVal strStrataOutcome As String, ByVal strRegionId As String) As DataSet
            Dim ds As DataSet
            Try
                ds = DataAccessObj().execStoreProcedure(strAcctNum, strStrataOutcome, strRegionId)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return ds
        End Function
#End Region



#Region "usp_GetRMVPBalanceDetails"
        Public Function usp_GetRMVPBalanceDetails(ByVal strRegionCd As String, ByVal strAcctNum As String, ByVal strOrg As String) As DataSet
            Dim ds As DataSet
            Try
                ds = DataAccessObj().execStoreProcedure(strRegionCd, strAcctNum, strOrg)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return ds
        End Function
#End Region

#Region "usp_getTriadUpdateValue"
        Public Function usp_getTriadUpdateValue(ByVal strAcctNum As String, ByVal strActn As String, _
        ByVal strTranType As String, ByVal strRegionCd As String) As DataSet
            Dim ds As DataSet
            Try
                ds = DataAccessObj().execStoreProcedure(strAcctNum, strActn, strTranType, strRegionCd)

            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return ds
        End Function
#End Region

#Region "usp_GetResponseForRequest"
        Public Function usp_GetResponseForRequest(ByVal strRegionId As String, ByVal intRequestId As Long) As DataSet
            Dim ds As DataSet
            Try
                ds = DataAccessObj().execStoreProcedure(strRegionId, intRequestId)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return ds
        End Function
#End Region

#Region "usp_InsertRISORequest"
        Public Function usp_InsertRISORequest(ByVal strRegionid As String, ByVal strAcctNum As String, ByVal strOrg As String, ByVal strEchosClass As String, ByVal strEchosActn As String, ByVal strEchosNotes As String, ByVal strEchosUserId As String, ByVal dtmRequeueDate As DateTime, ByVal strBTNNum As String, ByVal strMasterAcctNum As String, ByVal strRemarks As String, ByVal strOriginationId As String, ByVal strRequestActnType As String, ByVal OUTstrResultRequestId As Long, ByVal strConditionCd As String, ByVal strEnvironment As String, ByVal strApplicationId As String, Optional ByVal strReturnCd As String = "") As Integer

            Dim intResultRequestId As Long
            'Dim strResultRequestId As String
            Dim retObj As ArrayList
            Try
                retObj = DataAccessObj().execStoreProcedureWithOutPutParam(strRegionid, strAcctNum, strOrg, strEchosClass, strEchosActn, strEchosNotes, strEchosUserId, dtmRequeueDate, strBTNNum, strMasterAcctNum, strRemarks, strOriginationId, strRequestActnType, OUTstrResultRequestId, strConditionCd, strEnvironment, strApplicationId, strReturnCd)
                intResultRequestId = (CType(retObj(0), Long))

                Try

                    'LogErrorFile.WriteLog("RMICWWS", "Result Request Id:" & intResultRequestId.ToString)
                    'intResultRequestId = Integer.Parse(strResultRequestId)
                Catch ex As Exception
                    LogErrorFile.WriteLog("RMICWWS", "Result RequestId is Invalid. Defaulting to Zeroes. Acct: " & strAcctNum)
                    intResultRequestId = 0

                End Try
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return intResultRequestId
        End Function
#End Region

#Region "usp_GetRMICWInfo"
        Public Function usp_GetRMICWInfo(ByVal strRegioncd As String, ByVal strInpType As String, ByVal strAcctNum As String, ByVal strOrg As String) As DataSet
            Dim ds As DataSet
            Try
                ds = DataAccessObj().execStoreProcedure(strRegioncd, strInpType, strAcctNum, strOrg)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return ds
        End Function
#End Region

#Region "IsEmptyRecordSet"
        Public Function IsEmptyRecordSet(ByVal ds As DataSet) As Boolean
            Dim dt As DataTable
            For i As Integer = 0 To ds.Tables.Count - 1
                dt = ds.Tables(i)
                'For Each dt In ds.Tables
                If dt.Rows.Count > 0 Then
                    Return False
                End If
            Next i
            Return True
        End Function
#End Region

#Region "usp_CheckSOPRequest : CheckSOPRequest"
        Public Function usp_CheckSOPRequest(ByVal strRegionCd As String, ByVal intRequestId As Long, ByVal strAcctNum As String, ByVal strBTNNum As String, ByVal strActn As String, ByVal strDestSystem As String, ByVal strSyncFlag As String, ByVal strNotationCd As String, ByVal strRemarks As String, ByVal strAppId As String, ByVal strOverRideRequest As String, ByVal OUTintSOPRequestId As Long, ByVal OUTintAAISSyncStatus As Integer, ByVal OUTintAAISAsyncStatus As Integer, ByVal OUTintSkipRequest As Integer, ByVal strOrg As String, ByVal strEnvironment As String) As retSOPClass
            Dim strvalue As String = " "
            'Dim intSOPRequestId As Long
            Dim retObj As ArrayList
            Dim retObjSOP As retSOPClass = New retSOPClass


            Try
                retObj = DataAccessObj().execStoreProcedureWithOutPutParam(strRegionId, intRequestId, strAcctNum, strBTNNum, strActn, strDestSystem, strSyncFlag, strNotationCd, strRemarks, strAppId, strOverRideRequest, OUTintSOPRequestId, OUTintAAISSyncStatus, OUTintAAISAsyncStatus, OUTintSkipRequest, strOrg, strEnvironment)
                retObjSOP.intSOPRequestId = (CType(retObj(0), Long))
                retObjSOP.intAAISSyncStatus = (CType(retObj(1), Integer))
                retObjSOP.intAAISAsyncStatus = (CType(retObj(2), Integer))
                retObjSOP.intSkipRequest = (CType(retObj(3), Integer))

            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return retObjSOP
        End Function
#End Region

#Region "usp_InsertSOPChildRequest : InsertSOPChildRequest"
        Public Function usp_InsertSOPChildRequest(ByVal intSOPRequestId As Long, ByVal strAcctNum As String, ByVal strWTN As String, ByVal strActn As String, ByVal strStatusCd As String, ByVal strReturnCd As String, ByVal strNotationCd As String, ByVal strResultId As String, ByVal strResultDesc As String, ByVal OUTintChildSOPRequest As Long) As Long
            Dim intSOPChildRequest As Long
            Dim retObj As ArrayList

            Try
                retObj = DataAccessObj().execStoreProcedureWithOutPutParam(intSOPRequestId, strAcctNum, strWTN, strActn, strStatusCd, strReturnCd, strNotationCd, strResultId, strResultDesc, OUTintChildSOPRequest)
                intSOPChildRequest = (CType(retObj(0), Long))
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return intSOPChildRequest
        End Function
#End Region

#Region "usp_InsertAffiliateRequests"

        Public Function usp_InsertAffiliateRequests(ByVal strRegionCd As String, ByVal strXML As String, ByVal strExtendedParm As String, ByVal strVZWXML As String) As Integer

            'Dim ds As DataSet
            Dim i As Integer
            Try

                i = DataAccessObj().execStoreProcedureNonQuery(strRegionCd, strXML, strExtendedParm, strVZWXML)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try

            Return i
        End Function
#End Region

#Region "usp_InserttAuditLog"

        Public Function usp_InserttAuditLog(ByVal strDestSystem As String, ByVal strIOType As String, ByVal strAcctNum As String, ByVal strActn As String, ByVal strProfileCAN As String, ByVal strSSPAcctId As String, ByVal strDAN As String, ByVal intRequestId As Integer, ByVal intRefRequestId As Integer, ByVal strText As String, ByVal strUpdtId As String) As Integer

            'Dim ds As DataSet
            Dim i As Integer
            Try

                i = DataAccessObj().execStoreProcedureNonQuery(strDestSystem, strIOType, strAcctNum, strActn, strProfileCAN, strSSPAcctId, strDAN, intRequestId, intRefRequestId, strText, strUpdtId)

            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try

            Return i
        End Function
#End Region

#Region "usp_UpdateSOPRequest : usp_UpdateSOPRequest"
        Public Function usp_UpdateSOPRequest(ByVal strUpdtType As String, ByVal intSOPRequestId As Long, ByVal strStatusCd As String, ByVal strReturnCd As String, ByVal strRemarks As String, ByVal strUpdtId As String) As Integer

            Dim i As Integer
            Try
                i = DataAccessObj().execStoreProcedureNonQuery(strUpdtType, intSOPRequestId, strStatusCd, strReturnCd, strRemarks, strUpdtId)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return i
        End Function
#End Region

        'used for AAISClient Method
#Region "usp_InsertSOPAndSOPChildRequest : usp_InsertSOPAndSOPChildRequest"
        Public Function usp_InsertSOPAndSOPChildRequest(ByVal strRegionCd As String, ByVal strAcctNum As String, ByVal strWTN As String, ByVal intRequestId As Long, ByVal strActn As String, ByVal strSyncFlag As String, ByVal strNotationCd As String, ByVal strRemarks As String) As Integer

            Dim i As Integer
            Try
                i = DataAccessObj().execStoreProcedureNonQuery(strRegionCd, strAcctNum, strWTN, intRequestId, strActn, strSyncFlag, strNotationCd, strRemarks)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return i
        End Function
#End Region

#Region "usp_UpdateChildRequest : usp_UpdateChildRequest"
        Public Function usp_UpdateChildRequest(ByVal strUpdtType As String, ByVal intSOPChildRequestId As Long, ByVal strStatusCd As String, ByVal strReturnCd As String, ByVal strResultId As String, ByVal strType As String, ByVal strLineInfo As String, ByVal strResultDesc As String, ByVal strUpdtId As String) As Integer

            Dim i As Integer
            Try
                i = DataAccessObj().execStoreProcedureNonQuery(strUpdtType, intSOPChildRequestId, strStatusCd, strReturnCd, strResultId, strType, strLineInfo, strResultDesc, strUpdtId)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return i
        End Function
#End Region

#Region "usp_GetMessageResponse : usp_GetMessageResponse"
        Public Function usp_GetMessageResponse(ByVal strInpType As String, ByVal intRequestId As Long) As DataSet

            Dim ds As DataSet
            Try
                ds = DataAccessObj().execStoreProcedure(strInpType, intRequestId)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return ds
        End Function
#End Region

#Region "usp_InsertUpdateuCSRData : usp_InsertUpdateuCSRData"

        'Public Function usp_InsertUpdateuCSRData(ByVal strCANNum As String, ByVal strAcctNum As String, ByVal strActn As String, ByVal strServiceType As String, ByVal strCompanyCode As String, ByVal strServiceOrderNum As String, ByVal strLECBilledStatus As String) As DataSet
        Public Function usp_InsertUpdateuCSRData(ByVal strCANNum As String, ByVal strAcctNum As String, ByVal strActn As String, ByVal strServiceType As String, ByVal strCompanyCode As String, ByVal strServiceOrderNum As String, ByVal strLECBilledStatus As String, ByVal strRAO As String, ByVal strPCAN As String, ByVal strDCR As String, ByVal strAccountId As String, ByVal strServiceId As String) As Integer

            'Dim ds As DataSet
            Dim i As Integer
            Try
                'ds = DataAccessObj().execStoreProcedure(strCANNum, strAcctNum, strActn, strServiceType, strCompanyCode, strServiceOrderNum, strLECBilledStatus)
                i = DataAccessObj().execStoreProcedureNonQuery(strCANNum, strAcctNum, strActn, strServiceType, strCompanyCode, strServiceOrderNum, strLECBilledStatus, strRAO, strPCAN, strDCR, strAccountId, strServiceId)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            'Return ds
            Return i
        End Function
#End Region

#Region "usp_InsertSSPMasterAndChild : usp_InsertSSPMasterAndChild"


        Public Function usp_InsertSSPMasterAndChild(ByVal strRegionCd As String, ByVal strXML As String, ByVal strExtendedParm As String, ByVal strEnvironment As String) As Integer

            'Dim ds As DataSet
            Dim i As Integer
            Try

                i = DataAccessObj().execStoreProcedureNonQuery(strRegionCd, strXML, strExtendedParm, strEnvironment)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try

            Return i
        End Function
#End Region

#Region "usp_UpdateSSPResponse : usp_UpdateSSPResponse"


        Public Function usp_UpdateSSPResponse(ByVal strRegionCd As String, ByVal strXML As String, ByVal strExtendedParm As String) As Integer


            Dim i As Integer
            Try

                i = DataAccessObj().execStoreProcedureNonQuery(strRegionCd, strXML, strExtendedParm)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try

            Return i
        End Function
#End Region

#Region "usp_GetControlparmALLByRegion : usp_GetControlparmALLByRegion"
        Public Function usp_GetControlparmALLByRegion() As DataSet
            'Dim ds As DataSet
            dsDAParm = New DataSet
            Try
                'ds = DataAccessObj().execStoreProcedure(strRegionCd)
                dsDAParm = DataAccessObj().execStoreProcedure()


            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            'Return ds
            Return dsDAParm
        End Function
#End Region


#Region "usp_GetRefActionALL : usp_GetRefActionALL"
        Public Function usp_GetRefActionALL() As DataSet
            'Dim ds As DataSet
            dsREFParm = New DataSet
            Try
                'ds = DataAccessObj().execStoreProcedure(strRegionCd)
                dsREFParm = DataAccessObj().execStoreProcedure()


            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            'Return ds
            Return dsREFParm
        End Function
#End Region

#Region "GetParmSelect : GetParmSelect"
        Public Function GetParmSelect(ByVal strParmName As String, ByVal strRegion As String) As Object
            Dim strSrchCrt As String
            Dim strValue As String
            Dim arrDRow() As DataRow = Nothing
            Dim dtDAParm As DataTable

            strSrchCrt = "strParmName =" + "'" + strParmName + "'" + "  AND strRegionId = " + "'" + strRegion + "'"

            If dsParmValue.Tables Is Nothing Then
                LogErrorFile.WriteLog("GetParmSelect", "dsParmValue.Tables is nothing")

            End If

            For i As Integer = 0 To dsParmValue.Tables.Count - 1
                dtDAParm = dsParmValue.Tables(i)
                'For Each dtDAParm In dsParmValue.Tables
                arrDRow = dtDAParm.Select(strSrchCrt)
            Next

            Try
                If Not arrDRow Is Nothing Then
                    If (arrDRow.Length > 0) Then
                        strValue = arrDRow(0).Item("strParmValue")
                    Else
                        strValue = ""
                    End If
                End If

            Catch ex As Exception
                LogErrorFile.WriteLog("GetParmSelect", "strSrchCrt:" + strSrchCrt + ex.ToString())
            End Try
            Return strValue.Trim()
        End Function
#End Region


#Region "GetRefActnSelect : GetRefActnSelect"
        Public Function GetRefActnSelect(ByVal strOrg As String, ByVal strType As String, ByVal strRegion As String) As Object
            Dim strSrchCrt As String
            Dim strValue As String
            Dim arrDRow() As DataRow = Nothing
            Dim dtREFActn As DataTable

            strSrchCrt = "strOrg =" + "'" + strOrg + "'" + "  AND strType = " + "'" + strType + "'"

            If dsRefActnValue.Tables Is Nothing Then
                LogErrorFile.WriteLog("GetRefActnSelect", "dsRefActnValue.Tables is nothing")

            End If

            For i As Integer = 0 To dsRefActnValue.Tables.Count - 1
                dtREFActn = dsRefActnValue.Tables(i)
                'For Each dtREFActn In dsRefActnValue.Tables
                arrDRow = dtREFActn.Select(strSrchCrt)
            Next

            Try
                If Not arrDRow Is Nothing Then
                    If (arrDRow.Length > 0) Then
                        strValue = arrDRow(0).Item("strRefActn")
                    Else
                        strValue = ""
                    End If
                End If

            Catch ex As Exception
                LogErrorFile.WriteLog("GetRefActnSelect", "strSrchCrt:" + strSrchCrt + ex.ToString())
            End Try
            Return strValue.Trim()
        End Function
#End Region

#Region "usp_GetProdSpnsnLvl"
        Public Function usp_GetProdSpnsnLvl(ByVal strRegionCd As String, ByVal strSSPAcctId As String, ByVal strAcctNum As String, ByVal strSSPBAN As String) As DataSet
            Dim ds As DataSet
            Try
                ds = DataAccessObj().execStoreProcedure(strRegionCd, strSSPAcctId, strAcctNum, strSSPBAN)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return ds
        End Function
#End Region

#Region "usp_InsertSSPMasterAndChildForIVAPP : usp_InsertSSPMasterAndChildForIVAPP"


        Public Function usp_InsertSSPMasterAndChildForIVAPP(ByVal strRegionCd As String, ByVal strXML As String, ByVal strErrXML As String, ByVal strExtendedParm As String, ByVal strEnvironment As String) As Integer

            'Dim ds As DataSet
            Dim i As Integer
            Try
                If strRegionCd.Trim() <> "VISION" Then
                    If (strXML <> "") Then
                        strXML = strXML.Remove(0, 40)
                    End If
                End If
                i = DataAccessObj().execStoreProcedureNonQuery(strRegionCd, strXML, strErrXML, strExtendedParm, strEnvironment)
            Catch e As Exception
                LogErrorFile.WriteLog("usp_InsertSSPMasterAndChildForIVAPP", e.ToString() + strXML.ToString())
                Throw (e)
            End Try

            Return i
        End Function
#End Region

#Region "usp_GetRMICWProfile : usp_GetRMICWProfile"


        Public Function usp_GetRMICWProfile(ByVal strRegionCd As String, ByVal strAcctNum As String, ByVal strInpType As String, ByVal strOrg As String, ByVal strEnvironment As String) As String

            Dim ds As DataSet
            Dim strResult As String = Nothing
            Try


                ds = DataAccessObj().execStoreProcedure(strRegionCd, strAcctNum, strInpType, strOrg, strEnvironment)

                Dim dtPS As DataTable
                Dim drPS As DataRow

                Dim dtmActnBeginDate As DateTime = Nothing
                For i As Integer = 0 To ds.Tables.Count - 1
                    dtPS = ds.Tables(i)
                    'For Each dtPS In ds.Tables
                    For j As Integer = 0 To dtPS.Rows.Count - 1
                        drPS = dtPS.Rows(j)
                        'For Each drPS In dtPS.Rows
                        strResult = drPS.Item(0)
                    Next
                Next
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try

            Return strResult
        End Function
#End Region

#Region "usp_GetSBMRelationShip : getSBM Relationship accounts"

        Public Function usp_GetSBMRelationShip(ByVal strRegionId As String, ByVal strType As String, ByVal strAcctNum As String, ByVal strBTNNum As String, ByVal strOrg As String) As DataSet
            Dim ds As DataSet
            Try

                ds = DataAccessObj().execStoreProcedure(strRegionId, strType, strAcctNum, strBTNNum, strOrg)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return ds
        End Function
#End Region

#Region "usp_GetVZRestoreOrderStatus : Get Restore Order Status"

        Public Function usp_GetVZRestoreOrderStatus(ByVal strRegionCd As String, ByVal strAcctNum As String, ByVal strOrg As String) As String

            Dim ds As DataSet
            Dim strResult As String = Nothing

            Try

                ds = DataAccessObj().execStoreProcedure(strRegionCd, strAcctNum, strOrg)
                If ds.Tables.Count > 0 Then
                    If (ds.Tables(0).Rows(0)(0) > 0) Then
                        strResult = "Y"
                    Else
                        strResult = "N"
                    End If
                Else
                    strResult = "N"
                End If



            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try

            Return strResult
        End Function
#End Region

#Region "Driver Logic E2E"

        Public Function usp_GetRequestMainDriverByRequestId(ByVal TBLRMICWMainDriverDetails As String, ByVal strRegionId As String, ByVal intRequestId As Long, ByVal strServerName As String, ByVal intStatus As Integer) As RMICWMainDriverLayout
            Dim ds As RMICWMainDriverLayout
            Try
                ds = CType(DataAccessObj().execStoreProcedureWithTypedDataSet(TBLRMICWMainDriverDetails, strRegionId, intRequestId, strServerName, intStatus), RMICWMainDriverLayout)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return ds
        End Function

        Public Function usp_CheckPrecedenceLevel(ByVal intRequestId As Long, ByVal strAcctNum As String, ByVal strStatusCd As String, ByVal strUpdtId As String, ByVal OUTintContinue As Integer) As Boolean

            Dim ds As DataSet
            Dim dt As DataTable
            Dim dr As DataRow
            Dim retObj As ArrayList
            Dim blnContinue As Boolean = True
            Dim intContinue As Integer


            Try
                retObj = DataAccessObj().execStoreProcedureWithOutPutParam(intRequestId, strAcctNum, strStatusCd, strUpdtId, OUTintContinue)
                intContinue = Integer.Parse(CType(retObj(0), String))
                If intContinue = 1 Then
                    blnContinue = False
                End If

            Catch e As Exception
                LogErrorFile.WriteLog(e)
            End Try
            Return blnContinue
        End Function

#Region "usp_GetAccountStatus"
        Public Function usp_GetAccountStatus(ByVal strAcctnum As String, ByVal strAppid As String, ByVal intInrequestid As String) As DataSet

            Dim ds As DataSet
            Try
                ds = DataAccessObj().execStoreProcedure(strAcctnum, strAppid, intInrequestid)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return ds
        End Function
#End Region

        Public Function usp_UpdateCombinedRequest(ByVal intRequestId As Long, ByVal strActnParm As String, ByVal strUpdtIdParm As String, ByVal strReturnCdParm As String, ByVal OUTintStatus As Integer) As Integer
            Dim i As Integer
            Try
                i = DataAccessObj().execStoreProcedureNonQuery(intRequestId, strActnParm, strUpdtIdParm, strReturnCdParm, OUTintStatus)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return i

        End Function

        Public Function usp_UpdateStatusDLRorOtherRequest(ByVal strDestSystem As String, ByVal intRequestId As Long, ByVal strReturnCd As String, ByVal strUpdtId As String) As Integer
            Dim i As Integer
            Try
                i = DataAccessObj().execStoreProcedureNonQuery(strDestSystem, intRequestId, strReturnCd, strUpdtId)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return i

        End Function

        Public Function SelectOrgActionFromDS(ByVal strOrg As String, ByVal strActn As String) As OrgActn

            Dim strSrch As String = " strOrg = '" & strOrg.Trim() & "' and strActn = '" & strActn.Trim() & "'"
            Dim drows As DataRow()
            Dim objOrgActn As OrgActn = New OrgActn()

            If (dsOrgActn Is Nothing) Then
                dsOrgActn = usp_GetOrgActn()
            End If

            Try

                If (Not IsEmptyRecordSet(dsOrgActn)) Then
                    drows = dsOrgActn.Tables(0).Select(strSrch)
                    If (Not drows Is Nothing) And _
                       (drows.Length > 0) Then
                        objOrgActn.PStrOrg = drows(0)("strOrg")
                        objOrgActn.PStrActn = drows(0)("strActn")
                        objOrgActn.PStrResultAction = drows(0)("strResultAction")
                        objOrgActn.PcurRstFee = drows(0)("curRstFee")
                        objOrgActn.PStrTrtmntHistCd = drows(0)("strTrtmntHistCd")
                    End If
                End If
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                objOrgActn = New OrgActn()
            End Try

            Return objOrgActn

        End Function

        Public Function usp_GetOrgActn() As DataSet
            Dim ds As DataSet
            Dim dt As DataTable
            Dim dr As DataRow

            Try
                ds = DataAccessObj().execStoreProcedure()
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return ds
        End Function

#Region "usp_CheckAffRequestByRequestId : usp_CheckAffRequestByRequestId"


        Public Function usp_CheckAffRequestByRequestId(ByVal strRegionId As String, ByVal strAcctNum As String, ByVal intRequestId As Integer, ByVal strDestSystem As String, ByVal strAffActn As String, ByVal intStatus As Integer) As Integer

            'Dim ds As DataSet
            Dim i As Integer
            Try

                i = DataAccessObj().execStoreProcedureNonQuery(strRegionId, strAcctNum, intRequestId, strDestSystem, strAffActn, intStatus)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try

            Return i
        End Function
#End Region


#End Region

#Region " COFFE Adjustment"
        Public Function usp_GetReconnectFee(ByVal strRegionId As String, ByVal strOrg As String, ByVal strActn As String, ByVal strCompanyCd As String, ByVal strLocationCd As String, ByVal strClassOfService As String, ByVal strlinetype As String) As DataSet
            Dim ds As DataSet
            Try
                ds = DataAccessObj().execStoreProcedure(strRegionId, strOrg, strActn, strCompanyCd, strLocationCd, strClassOfService, strlinetype)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return ds
        End Function



        Public Function usp_InsRecourseCarrierInfocofee(ByVal strVoucherNum As String, ByVal curVoucherAmt As Double, ByVal strAccountNum As String, ByVal intRequestId As String, ByVal strTypeId As String, ByVal strTypevalue As String) As Integer

            Dim i As Integer
            Try
                i = DataAccessObj().execStoreProcedureNonQuery(strVoucherNum, curVoucherAmt, strAccountNum, intRequestId, strTypeId, strTypevalue)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return i
        End Function

        Public Function usp_InsertRequestFeed1(ByVal strRequestType As String, ByVal intRequestId As Long, ByVal strAcctNum As String, ByVal strRequestedBy As String, ByVal strActn As String, ByVal strDestSystem As String, ByVal strStatusCd As String, ByVal strResultType As String, ByVal strResultId As String, ByVal strReturnCd As String, ByVal strArchiveInd As String, ByVal strNotationCd As String, ByVal strUpdtId As String, ByVal dtmechosbackts As String) As Integer
            Dim i As Integer
            Try
                i = DataAccessObj().execStoreProcedureNonQuery(strRequestType, intRequestId, strAcctNum, strRequestedBy, strActn, strDestSystem, strStatusCd, strResultType, strResultId, strReturnCd, strArchiveInd, strNotationCd, strUpdtId, dtmechosbackts)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return i
        End Function

        Public Function usp_updateRequestFeedcf(ByVal strRequestType As String, ByVal intRequestId As Long, ByVal strAcctNum As String, ByVal strRequestedBy As String, ByVal strActn As String, ByVal strDestSystem As String, ByVal strStatusCd As String, ByVal strResultType As String, ByVal strResultId As String, ByVal strReturnCd As String, ByVal strArchiveInd As String, ByVal strNotationCd As String, ByVal strUpdtId As String, ByVal dtmechosbackts As String) As Integer
            Dim i As Integer
            Try
                i = DataAccessObj().execStoreProcedureNonQuery(strRequestType, intRequestId, strAcctNum, strRequestedBy, strActn, strDestSystem, strStatusCd, strResultType, strResultId, strReturnCd, strArchiveInd, strNotationCd, strUpdtId, dtmechosbackts)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return i
        End Function

        Public Function usp_InsertRequest1(ByVal strAcctNum As String, ByVal strOrg As String, ByVal strClass As String, ByVal strActn As String, ByVal strStatusCd As String, ByVal strNotationCd As String, ByVal intInstalBlngCd As Long, ByVal strLogonId As String, ByVal strRstFeeInd As String, ByVal strOriginationId As String, ByVal strReturnCd As String, ByVal strResultType As String, ByVal strResultId As String, ByVal strUpdtId As String, ByVal strConditionCd As String, ByVal strBTNNum As String, ByVal strRemarks As String, ByVal dtmPrcsdTs As String, ByVal strEnvironment As String) As Integer

            Dim i As Integer
            Try
                i = DataAccessObj().execStoreProcedureNonQuery(strAcctNum, strOrg, strClass, strActn, strStatusCd, strNotationCd, intInstalBlngCd, strLogonId, strRstFeeInd, strOriginationId, strReturnCd, strResultType, strResultId, strUpdtId, strConditionCd, strBTNNum, strRemarks, dtmPrcsdTs, strEnvironment)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return i
        End Function

        Public Function usp_InsertRequestSBM(ByVal strAcctNum As String, ByVal strOrg As String, ByVal strClass As String, ByVal strActn As String, ByVal strStatusCd As String, ByVal strNotationCd As String, ByVal intInstalBlngCd As Integer, ByVal strLogonId As String, ByVal strRstFeeInd As String, ByVal strOriginationId As String, ByVal dtmRequeueDt As String, ByVal strReturnCd As String, ByVal dtmPymntRcvdDt As String, ByVal strResultType As String, ByVal strResultId As String, ByVal strUpdtId As String, ByVal strBTNNum As String, ByVal strMasterAcctNum As String, ByVal strRemarks As String, ByVal strConditionCd As String, ByVal intParentRqstId As Integer, ByVal strEnvironment As String, ByVal strArchiveInd As String) As Integer

            Dim i As Integer
            Try
                i = DataAccessObj().execStoreProcedureNonQuery(strAcctNum, strOrg, strClass, strActn, strStatusCd, strNotationCd, intInstalBlngCd, strLogonId, strRstFeeInd, strOriginationId, dtmRequeueDt, strReturnCd, dtmPymntRcvdDt, strResultType, strResultId, strUpdtId, strBTNNum, strMasterAcctNum, strRemarks, strConditionCd, intParentRqstId, strEnvironment, strArchiveInd)

            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return i
        End Function


#End Region


#Region "usp_RMI_getOrgByOrg" 'WR57588
        Public Function usp_RMI_getOrgByOrg(ByVal strOrgParm As String) As DataSet
            Dim ds As DataSet
            Try
                ds = DataAccessObj().execStoreProcedure(strOrgParm)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return ds
        End Function
#End Region



#Region "usp_InsertOrderStatus : Insert Order Details"

        Public Function usp_InsertOrderStatus(ByVal strRegionCd As String, ByVal MessageName As String, ByVal RequestId As Long, ByVal AccountNum As String, ByVal MONId As String, ByVal OrderEvent As String, ByVal OrderDueDate As DateTime, ByVal OrderEventDateTime As DateTime) As DataSet
            Dim ds As DataSet
            Try
                ds = DataAccessObj().execStoreProcedure(strRegionCd, MessageName, RequestId, AccountNum, MONId, OrderEvent, OrderDueDate, OrderEventDateTime)

            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return ds
        End Function
#End Region


#Region "usp_GetE2EDetails : get E2E Details"

        Public Function usp_GetE2EDetails(ByVal strAcctNum As String, ByVal strOrg As String, ByVal strRegionCd As String) As DataSet
            Dim ds As DataSet
            Try
                ds = DataAccessObj().execStoreProcedure(strAcctNum, strOrg, strRegionCd)

            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return ds
        End Function
#End Region

#Region "[usp_UpdateVOSEServiceOrderResults] : Insert VOSE Order Details"

        Public Function usp_UpdateVOSEServiceOrderResults(ByVal strVOSEXml As String) As DataSet
            Dim ds As DataSet
            Try
                ds = DataAccessObj().execStoreProcedure(strVOSEXml)

            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return ds
        End Function
#End Region

#Region "usp_Get Bundle Info"
        Public Function usp_GetBundleInfo(ByVal strRegionId As String, ByVal strAcctNum As String) As DataSet

            Dim ds As DataSet
            Dim strvalue As String = " "
            Try
                ds = DataAccessObj().execStoreProcedure(strRegionId, strAcctNum)

            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            Finally

            End Try
            Return ds
        End Function
#End Region
#Region "usp_GetReconnectFeeData"
        Public Function usp_GetReconnectFeeData(ByVal strRegionId As String, ByVal strActn As String, ByVal strOrg As String, ByVal strCompanyCd As String) As DataSet
            Dim dsReconnectFee As DataSet

            Try
                dsReconnectFee = DataAccessObj().execStoreProcedure(strRegionId, DBNull.Value, strOrg, "TaxFee")
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            Finally

            End Try
            Return dsReconnectFee
        End Function
#End Region
#Region "usp_GetAccountEnvironment"
        Public Function usp_GetAccountEnvironment(ByVal strAcctNum As String, ByVal strRegioncd As String) As DataSet
            Dim dsAcctEnv As DataSet

            Try
                dsAcctEnv = DataAccessObj().execStoreProcedure(strAcctNum, strRegioncd)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            Finally

            End Try
            Return dsAcctEnv
        End Function
#End Region

#Region "usp_GetNWGStatus"
        Public Function usp_GetNWGStatus(ByVal strAcctNum As String, ByVal strProfileCAN As String, ByVal strDataCircuitId As String) As DataSet

            Dim ds As DataSet
            Dim strvalue As String = " "
            Try
                ds = DataAccessObj().execStoreProcedure(strAcctNum, strProfileCAN, strDataCircuitId)


            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            Finally

            End Try
            Return ds
        End Function
#End Region

#Region "getSSPFullResponseObject"
        Public Function getSSPFullResponseObject(ByVal strAcctNum As String, ByVal strRegioncd As String, ByVal strType As String) As SSPPAFullProfile.getVZFullProfileResponse
            Dim dsAcctEnv As DataSet
            Dim strOutXml As String = ""
            Dim startIndex As Integer
            Dim objSSPProfileResp As SSPPAFullProfile.getVZFullProfileResponse = New SSPPAFullProfile.getVZFullProfileResponse()
            Dim objwsMain As WSMain = New WSMain()
            Dim objSSPRespxmlDoc As XmlDataDocument = New XmlDataDocument()
            'Dim strInputXml As String
            Dim xmlSSPProfileResponseDeSer As XmlSerializer = New XmlSerializer(GetType(SSPPAFullProfile.getVZFullProfileResponse))

            'Dim sw As New StringWriter
            'Dim ser As New XmlSerializer(objSSPProfileResp.GetType())
            'ser.Serialize(sw, objSSPProfileResp)
            'strInputXml = sw.ToString()

            If strType = "" Then
                Try

                    Dim strState As String
                    Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(strRegioncd)
                    Try
                        dsAcctEnv = ObjDataAccess.usp_GetAccountEnvironment(strAcctNum, strRegioncd)
                        If ((Not dsAcctEnv Is Nothing) And (dsAcctEnv.Tables.Count > 0)) Then
                            If (Not ObjDataAccess.IsEmptyRecordSet(dsAcctEnv)) Then
                                strState = dsAcctEnv.Tables(0).Rows(0).Item("strState").ToString().Trim()
                            Else
                                strState = ""
                            End If
                        Else
                            strState = ""
                        End If
                    Catch ex As Exception
                        LogErrorFile.WriteLog("usp_GetAccountEnvironment" + strAcctNum, "GetStateCode Error")
                    End Try

                Catch e As Exception
                    LogErrorFile.WriteLog(e)
                    Throw (e)
                Finally
                End Try

            End If

            Try
                objSSPRespxmlDoc = objwsMain.getVZFullProfile(strAcctNum, "VISION", 0)
                strOutXml = objSSPRespxmlDoc.InnerXml.ToString()
                startIndex = strOutXml.ToString().IndexOf("<getVZFullProfileResponse>")
                strOutXml = strOutXml.Remove(0, startIndex)
                strOutXml = strOutXml.Replace("<getVZFullProfileResponse>", "")
                strOutXml = strOutXml.Insert(0, "<getVZFullProfileResponse xmlns=""http://verizon.com/ONE/"">")
                strOutXml = strOutXml.Replace(vbCrLf, "")
                objSSPProfileResp = xmlSSPProfileResponseDeSer.Deserialize(New XmlTextReader(New StringReader(strOutXml)))

            Catch ex1 As Exception
                LogErrorFile.WriteLog(ex1)
                Throw (ex1)
            End Try

            Return objSSPProfileResp
        End Function
#End Region
    End Class


    Public Class WSDummyDataAccess

        Private Shared objDataAccess As DataAccessComponent = Nothing

        Public Shared ReadOnly Property DataAccessObj() As DataAccessComponent
            Get
                If objDataAccess Is Nothing Then
                    Try
                        objDataAccess = New DataAccessComponent(dbType.SQLServer, "DUMMYINTERFACES")
                    Catch e As Exception
                        Throw (e)
                    End Try
                End If
                Return objDataAccess
            End Get

        End Property

        Public Sub WSDummyDataAccess()
        End Sub

        Private Shared Function IsEmptyRecordSet(ByVal ds As DataSet) As Boolean
            Dim dt As DataTable
            For i As Integer = 0 To ds.Tables.Count - 1
                dt = ds.Tables(i)
                'For Each dt In ds.Tables
                If dt.Rows.Count > 0 Then
                    Return False
                End If
            Next i
            Return True
        End Function

#Region "usp_getSBMRelation : getSBM Relationship accounts"

        Public Shared Function usp_GetSBMRelation(ByVal strRegionId As String, ByVal strMasterAcctNum As String) As DataSet
            Dim ds As DataSet
            Try
                ds = DataAccessObj().execStoreProcedure(strRegionId, strMasterAcctNum)
            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return ds
        End Function
#End Region





#Region "Global use of usp_GetControlParmByName"
        Public Function usp_GetControlParmByName(ByVal strRegionId As String, ByVal strParmName As String) As String
            Static ds As DataSet

            Dim strvalue As String = " "
            Try
                'Dim ds As DataSet
                Dim dt As DataTable
                Dim dr As DataRow
                ds = DataAccessObj().execStoreProcedure(strRegionId, strParmName)
                For i As Integer = 0 To ds.Tables.Count - 1
                    dt = ds.Tables(i)
                    'For Each dt In ds.Tables
                    For j As Integer = 0 To dt.Rows.Count - 1
                        dr = dt.Rows(j) 'For Each dr In dt.Rows
                        strvalue = dr("strParmValue")
                    Next
                Next

            Catch e As Exception
                LogErrorFile.WriteLog(e)
                Throw (e)
            End Try
            Return strvalue
        End Function


#End Region



    End Class
End Namespace

