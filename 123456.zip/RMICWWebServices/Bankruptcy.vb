﻿Option Strict Off
Option Explicit On
Imports System
Imports System.Net
Imports System.Collections
Imports System.Text
Imports System.Security
Imports System.IO
Imports CommonLibrary
Imports System.Xml.Serialization
Imports System.Xml
Imports DTVService1
Imports Verizon.RMICW.DataAccess
Imports System.Data
Imports System.DateTime
Imports System.Text.RegularExpressions



Namespace Verizon.RMICW.WebServices
    Public Class Bankruptcy

        Inherits RMICWWSBase
        Public Sub New(ByVal strRegionId As String)
            MyBase.New(strRegionId)
        End Sub

        Public strResponse As String = ""



        Private Function getDataShare(ByVal strDTVAcctnum As String) As String

            Dim strRequestXml As String

            strRequestXml = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:SOAP-ENC=""http://schemas.xmlsoap.org/soap/encoding/"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" xmlns:m0=""http://ei.directv.com/schemas/entities/v3_1""><SOAP-ENV:Header><m:ei xmlns:m=""http://ei.directv.com/schemas/envelope/v3_0""><m:type>request</m:type><m:service><m:name>getTelcoAccountProfile</m:name><m:version>3.0</m:version></m:service><m:originator>FrontierNCA</m:originator><m:businessProcessName>PARTNER_RTM_GetTelcoProfile</m:businessProcessName><m:requestDateTime>" & DateTime.Now().ToString("yyyy-MM-ddThh:mm:ss.fff") & "</m:requestDateTime><m:sourceSystemTransactionId>PPP123</m:sourceSystemTransactionId><m:sequenceNumber>001</m:sequenceNumber><m:user><m:id>user</m:id><m:group>group</m:group></m:user></m:ei></SOAP-ENV:Header><SOAP-ENV:Body><m:request xmlns:m=""http://ei.directv.com/schemas/wsdl/telcoServices/v3_0/getTelcoAccountProfile""><m0:accountId>" & strDTVAcctnum & "</m0:accountId></m:request></SOAP-ENV:Body></SOAP-ENV:Envelope>"
            Return strRequestXml

        End Function


    End Class


End Namespace
