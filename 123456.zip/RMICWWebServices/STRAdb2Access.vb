Imports CommonLibrary
Imports IBM.Data.DB2

'Public Class 

'End Class


Namespace Verizon.RMICW.WebServices

    Public Enum STRAOrderStatus
        NA
        Order_New
        Order_Completed 'CP
        Order_OnHold 'HD,HI,HN,HS,HT,HW
        Order_Cancelled 'CA
        Order_Released
        Order_Pending 'PN
        Order_inTranslate 'TR
        Order_WorkInProgress 'WP
        Order_Error 'ER
        Order_Resubmit 'QR,QS,RS

    End Enum

    Public Enum STRAOrderType
        NA
        C_Change_Order
        E_Intercept_Order
        I_Install_Order
        L_FinLOB_Order
        M_Move_Order
        O_Out_Order
        P_PCut_Order
        S_Supercedure_Order
        Z_Order
    End Enum

    Public Class STRA_Order_Output

        Public strAccountNo As String
        Public strOrderNum As String
        Public strGWYOrderNum As String
        Public strOrderStatus As String
        Public strOrderType As String
        Public dtmCompletionDate As DateTime
        'Public strOrderBlgPosNo As String
        'Public strOrderBlgTypeCd As String
        'Public dtmOrderCreationDate As DateTime
        'Public dtmOrderDueDate As DateTime

    End Class

    Public Class XBCLSP05

        Public strAcctNum As String
        <System.Xml.Serialization.XmlElement(ElementName:="OrderDetails", Type:=GetType(STRAOrderDetails))> _
        Public arrLstOrderDetails As ArrayList
        Public RequestStatus As StatusOfRequest

        Public Sub New()

            arrLstOrderDetails = New ArrayList
            RequestStatus = New StatusOfRequest
        End Sub
    End Class

    Public Class STRAOrderDetails
   
        Public strAccountNo As String
        Public strOrderNum As String
        Public strGWYOrderNum As String
        Public enOrderStatus As STRAOrderStatus
        Public strOrderType As String
        Public dtmCompletionDate As DateTime
        Public dtmOrderDueDate As DateTime




        Public Sub New()
            strAccountNo = " "
            enOrderStatus = STRAOrderStatus.NA
            strOrderNum = " "
            strGWYOrderNum = " "
            strOrderType = " "
            dtmCompletionDate = "1900-01-01"
            dtmOrderDueDate = "1900-01-01"

            
        End Sub
    End Class

    Public Class STRAdb2Access
        Inherits RMICWWSBase

        Public Sub New(ByVal strRegionId As String)
            MyBase.New(strRegionId)
        End Sub


        Public Function get_XBCLSP05(ByVal strRegionId As String, ByVal strAcctNum As String, ByVal strEnv As String, ByVal strSVRQ As String, ByVal intReadKey As Integer) As XBCLSP05

            Dim objXBCLSP05 As XBCLSP05 = New XBCLSP05

            Try
                Dim reqObj As STRARequest = New STRARequest
                Dim resObj As STRAResponse
                Dim DB2DT As DataTable
                Dim DB2DR As DataRow
                Dim strInpValue As String = Nothing

                Select Case True

                    Case strRegionId Is Nothing Or strRegionId.Trim = ""
                        objXBCLSP05.RequestStatus.strMessageId = "INVRGNID"
                        objXBCLSP05.RequestStatus.strMessageDescription = "Invalid Region Id passed."
                        Return objXBCLSP05
                    Case strAcctNum Is Nothing Or strAcctNum.Trim = ""
                        objXBCLSP05.RequestStatus.strMessageId = "INVACNBR"
                        objXBCLSP05.RequestStatus.strMessageDescription = "Invalid Account Number passed as Input."
                        Return objXBCLSP05
                End Select


                reqObj.In_REQ_BLACT_F = strAcctNum.Trim()
                reqObj.In_REQ_SVRQ = strSVRQ.Trim()
                reqObj.In_REQ_Read_Ind = intReadKey
                reqObj.strERAName = "XBCLSP00.XCO_XBCLSP05"
                reqObj.strRegionId = strRegionId.Trim()

                'objXBCLSP05.strAcctNum = strAcctNum
                Dim obj As BrokerSTRADB2Data = New BrokerSTRADB2Data(reqObj)
                resObj = obj.STRADB2Connect(strEnv.Trim())


                Select Case True

                    Case Not resObj.Out_RES_SQLCode = 0
                        objXBCLSP05.RequestStatus.strMessageId = resObj.Out_RES_SQLCode.ToString
                        objXBCLSP05.RequestStatus.strMessageDescription = resObj.Out_RES_Error_Msg
                        Return objXBCLSP05
                    Case resObj.Out_RES_SQLCode = 100
                        objXBCLSP05.RequestStatus.strMessageId = "100"
                        objXBCLSP05.RequestStatus.strMessageDescription = "No Matching Record Found in STRA"
                        Return objXBCLSP05
                    Case MyBase.WSDataAccessObj.IsEmptyRecordSet(resObj.DB2DS)
                        objXBCLSP05.RequestStatus.strMessageId = "100"
                        objXBCLSP05.RequestStatus.strMessageDescription = "No Matching Record Found in STRA"
                        Return objXBCLSP05
                End Select

                Dim arrLst As ArrayList = New ArrayList
                Dim objCommon As CommonFunctions = New CommonFunctions
                Dim objSTRAOrder As STRA_Order_Output = New STRA_Order_Output
                Dim objSTRAOrderDetails As STRAOrderDetails


                'For Each DB2DT In resObj.DB2DS.Tables
                '    For Each DB2DR In DB2DT.Rows
                For i As Integer = 0 To resObj.DB2DS.Tables.Count - 1
                    DB2DT = resObj.DB2DS.Tables(i)
                    For j As Integer = 0 To DB2DT.Rows.Count - 1
                        DB2DR = DB2DT.Rows(j)

                        objSTRAOrder = New STRA_Order_Output
                        objSTRAOrderDetails = New STRAOrderDetails

                        objSTRAOrderDetails.strAccountNo = DB2DR("BLACT_F")
                        objSTRAOrderDetails.strOrderNum = DB2DR("SVRQ_F")
                        objSTRAOrderDetails.strGWYOrderNum = DB2DR("SVORD_B")
                        objSTRAOrder.strOrderStatus = DB2DR("STT_YC")

                        If (intReadKey = "2") Then
                            objSTRAOrderDetails.dtmOrderDueDate = DB2DR("SVRQ_DUE_D")
                        End If


                        Select Case objSTRAOrder.strOrderStatus.Trim
                            Case "CP"
                                objSTRAOrderDetails.enOrderStatus = STRAOrderStatus.Order_Completed
                            Case "CA"
                                objSTRAOrderDetails.enOrderStatus = STRAOrderStatus.Order_Cancelled
                            Case "ER"
                                objSTRAOrderDetails.enOrderStatus = STRAOrderStatus.Order_Error
                            Case "WP"
                                objSTRAOrderDetails.enOrderStatus = STRAOrderStatus.Order_WorkInProgress
                                'pending orders
                            Case "TR"
                                objSTRAOrderDetails.enOrderStatus = STRAOrderStatus.Order_inTranslate
                            Case "PN"
                                objSTRAOrderDetails.enOrderStatus = STRAOrderStatus.Order_Pending
                            Case "PB"
                                objSTRAOrderDetails.enOrderStatus = STRAOrderStatus.Order_Pending
                            Case "PD"
                                objSTRAOrderDetails.enOrderStatus = STRAOrderStatus.Order_Pending
                            Case "PJ"
                                objSTRAOrderDetails.enOrderStatus = STRAOrderStatus.Order_Pending
                            Case "PO"
                                objSTRAOrderDetails.enOrderStatus = STRAOrderStatus.Order_Pending
                                'hold 
                            Case "HD"
                                objSTRAOrderDetails.enOrderStatus = STRAOrderStatus.Order_OnHold
                            Case "HI"
                                objSTRAOrderDetails.enOrderStatus = STRAOrderStatus.Order_OnHold
                            Case "HN"
                                objSTRAOrderDetails.enOrderStatus = STRAOrderStatus.Order_OnHold
                            Case "HS"
                                objSTRAOrderDetails.enOrderStatus = STRAOrderStatus.Order_OnHold
                            Case "HT"
                                objSTRAOrderDetails.enOrderStatus = STRAOrderStatus.Order_OnHold
                            Case "HW"
                                objSTRAOrderDetails.enOrderStatus = STRAOrderStatus.Order_OnHold
                            Case "SH"
                                objSTRAOrderDetails.enOrderStatus = STRAOrderStatus.Order_OnHold
                                'resubmit
                            Case "QR"
                                objSTRAOrderDetails.enOrderStatus = STRAOrderStatus.Order_Resubmit
                            Case "QS"
                                objSTRAOrderDetails.enOrderStatus = STRAOrderStatus.Order_Resubmit
                            Case "RS"
                                objSTRAOrderDetails.enOrderStatus = STRAOrderStatus.Order_Resubmit
                            Case Else
                                objSTRAOrderDetails.enOrderStatus = STRAOrderStatus.NA
                        End Select

                        objSTRAOrderDetails.strOrderType = DB2DR("SVORD_YC")
                        objSTRAOrderDetails.dtmCompletionDate = DB2DR("UPD_S")

                        objXBCLSP05.arrLstOrderDetails.Add(objSTRAOrderDetails)
                    Next j
                Next i



            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-XBCLSP05", "AcctNum: " & strAcctNum & " Erroring Out " & ex.ToString)
                objXBCLSP05.RequestStatus.strMessageId = "RMIEXPTN"
                objXBCLSP05.RequestStatus.strMessageDescription = ex.ToString

            End Try
            Return objXBCLSP05

        End Function
    End Class
End Namespace


