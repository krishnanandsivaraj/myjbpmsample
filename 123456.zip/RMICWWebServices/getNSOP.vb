Imports CommonLibrary
Imports System.Xml
Imports System.Xml.Serialization
Imports System.IO
'Imports RMICWSOPInterface.NSOPInterface.PendingOrder
'Imports RMICWSOPInterface.NSOPInquiry
Imports System.Web.Services.Protocols
Imports Microsoft.Web.Services2
Imports Microsoft.Web.Services2.Security
Imports Microsoft.Web.Services2.Security.Tokens
Imports System.Diagnostics
'Imports RMICWSOPInterface.NSOPInquiry.NSOPWebService
Imports System.Collections
Imports System
Imports System.Text
Imports System.Web.Services
Imports System.Net
Imports System.Globalization
Imports System.Text.RegularExpressions
Imports Microsoft.Web.Services2.Dime
Imports Verizon.RMICW.WebServices.wsGETURL




Namespace Verizon.RMICW.WebServices

    Public Class getNSOP


        Public Function CallgetOrderImage(ByVal strOrdernum As String, ByVal strJuristication As String, ByVal strBTN As String) As String
            Dim strRequestXml As String = String.Empty
            Dim strResponseXml As String = String.Empty
            strRequestXml = "<NSOPWEBSERVICES><NSOPWEBSVCSREQUEST><ACCESSINFO><METHODNAME>GetOrderImageEx</METHODNAME><APPID>NSOP</APPID><USERID>rmw</USERID><PASSWORD>rmicw05</PASSWORD><APPID>NSOP</APPID><USERID>rmw</USERID><PASSWORD>rmicw05</PASSWORD><TOKENID>000</TOKENID><TRANSACTIONID>06a1cf38-b5c9-4ff8-b1cb-a5090739f226</TRANSACTIONID><SCHEMAINVERSION>1.0</SCHEMAINVERSION></ACCESSINFO><METHODINPUTS><CSWSB>Y</CSWSB>"
            strRequestXml = strRequestXml & "<ORDER><ORDERNUMBER>" + strOrdernum.Trim() + "</ORDERNUMBER><BTN>" + strBTN + "</BTN><JURISDICTION>" + strJuristication.Trim() + "</JURISDICTION></ORDER>"
            strRequestXml = strRequestXml & "</METHODINPUTS></NSOPWEBSVCSREQUEST></NSOPWEBSERVICES>"
            strResponseXml = getOrderImageResponse(strRequestXml, strJuristication)
            Return strResponseXml
        End Function


        Private Function getOrderImageResponse(ByVal strInputXML As String, ByVal strJuristication As String) As String
            Dim bSuccess As Boolean
            Dim StrResult As String = String.Empty
            Dim posturl As String = ""
            Dim getURL As wsGETURL = New wsGETURL
            Dim strRegion As String
            'Set ITW credentials

            Dim objref As New NsopWebService.NSOPWebService
            Dim RequestContext As SoapContext
            RequestContext = objRef.RequestSoapContext
            objRef.Proxy = New WebProxy
            RequestContext.Security.Tokens.Clear()
            Dim unt As Tokens.UsernameToken = New Tokens.UsernameToken("RMW", "rmicw05", Tokens.PasswordOption.SendPlainText)
            RequestContext.Security.Tokens.Add(unt)
            RequestContext.Security.MustUnderstand = False
            StrResult = String.Empty

            Select Case strJuristication.Trim()
                Case "MD", "DC", "VA"
                    strRegion = "MDVW"
                Case "NJ", "PA", "DE"
                    strRegion = "NPD"
                Case "MA", "RI"
                    strRegion = "NE"
                Case "NY"
                    strRegion = "NY"
                Case Else
                    strRegion = "WEST"
            End Select

            posturl = getURL.getNSOPURL(strRegion, "NSOPINQUIRYURL")
            objref.Url = posturl.Trim
            StrResult = objref.GetOrderImageEx(strInputXML, bSuccess)
            Return StrResult

        End Function
#Region "Input XML for getting Pending Orders"
        Public Function fn_loadInputxml(ByVal strAcctnum As String) As String
            Dim strRequestXml As String
            Dim _sentdate As String
            Dim _TimeSent As String

            _sentdate = DateTime.Now.ToString("MM/dd/yyyy")
            _TimeSent = DateTime.Now.ToString("hh:mm")

            'AdditionalCheck(values)
            '00 = will return just Pending Orders + 5 days worth of completed orders (this value would likely not be used CIS gateway).
            '03 = Just pending Orders.
            '04 = Pending and Completed orders for 30 days.
            '05 = Completed orders only.


            strRequestXml = "<TRANSACTION><SENDINFO><SENDDATA Sendtyp=""SENDAPP"">NSOP</SENDDATA></SENDINFO>"
            strRequestXml = strRequestXml & "<TRANINFO><TRANDATA Trantyp=""TRANID"">TNSearch</TRANDATA><TRANDATA Trantyp=""USERID"">rmw</TRANDATA><TRANDATA Trantyp=""PASSWORD"">rmicw05</TRANDATA><TRANDATA Trantyp=""TOKENID"" /><TRANDATA Trantyp=""SCHEMAINVERSION"">1.0</TRANDATA></TRANINFO>"
            strRequestXml = strRequestXml & "<REPLYINFO><REPLYDATA Replytyp=""REPLYAPP"">NSOP</REPLYDATA></REPLYINFO>"
            strRequestXml = strRequestXml & "<REQUESTTRANS Datesent=""" + _sentdate + """ Timesent=""" + _TimeSent + """ Jurisdiction="""" Identifier=""FHDP1LRCDGW05d1a159e8-2130-441c-bbab-ae396f8ab96a"">"
            strRequestXml = strRequestXml & "<REQUEST><TNSearchRequest><TN>" & strAcctnum & " </TN><AdditionalCheck>03</AdditionalCheck></TNSearchRequest></REQUEST></REQUESTTRANS></TRANSACTION>"

            Return strRequestXml
        End Function

#End Region
    End Class
End Namespace
