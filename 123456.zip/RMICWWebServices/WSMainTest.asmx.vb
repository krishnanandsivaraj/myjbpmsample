Imports System.Web.Services
Imports CommonLibrary
Imports System.Xml
Imports System.Xml.Serialization
Imports System.IO
Imports Verizon.RMICW.WebServices.Profile
Imports DTVService1
Imports System.Xml.Xsl
Imports System.Xml.XPath
Imports System.Collections
Imports System.Security.Cryptography.X509Certificates
Imports Microsoft.Web.Services2
Imports Microsoft.Web.Services2.Security
Imports Microsoft.Web.Services2.Dime
Imports System.Net
Imports NsopWebService
Imports Microsoft.Web.Services2.Security.Tokens
Imports System.Linq
Imports System.Xml.Linq

Namespace Verizon.RMICW.WebServices

    'Public Interface ICertificatePolicy
    'End Interface

    Public Class VZWPolicy
        Implements ICertificatePolicy
        Public Shared Function ValidateServerCertificate(ByVal sender As Object, ByVal certificate As X509Certificate, ByVal chain As X509Chain, ByVal sslPolicyErrors As Net.Security.SslPolicyErrors) As Boolean
            Return True
        End Function
    End Class
    <System.Web.Services.WebService(Namespace:="http://tempuri.org//WSMainTest")>
    Public Class WSMainTest
        Inherits System.Web.Services.WebService

#Region " Web Services Designer Generated Code "

        Public Sub New()
            MyBase.New()

            'This call is required by the Web Services Designer.
            InitializeComponent()

            'Add your own initialization code after the InitializeComponent() call

        End Sub

        'Required by the Web Services Designer
        Private components As System.ComponentModel.IContainer

        'NOTE: The following procedure is required by the Web Services Designer
        'It can be modified using the Web Services Designer.
        'Do not modify it using the code editor.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
            components = New System.ComponentModel.Container
        End Sub

        Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
            'CODEGEN: This procedure is required by the Web Services Designer
            'Do not modify it using the code editor.
            If disposing Then
                If Not (components Is Nothing) Then
                    components.Dispose()
                End If
            End If
            MyBase.Dispose(disposing)
        End Sub

#End Region

#Region "Treatment Status Test Webmethod"
        <WebMethod(Description:="Get Treatment Status")>
        Public Function getTreatmentStatusTest(ByVal strRegionId As String, ByVal strOrg As String, ByVal InpRequestType As String, ByVal strAppId As String, ByVal strAcctNum As String) As TS_Response

            Try
                Dim obj As TreatmentStatus = New TreatmentStatus(strRegionId.Trim)
                Dim objRequest As TS_Request = New TS_Request
                objRequest.strAcctNum = strAcctNum
                objRequest.strApplicationId = strAppId
                objRequest.strInputRequestType = InpRequestType
                objRequest.strOrg = strOrg
                objRequest.strRegionId = strRegionId
                Return obj.getTreatmentStatus(objRequest)
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWebServices", ex.ToString())
            End Try
        End Function
#End Region

#Region "RMICWRequestIssueTest Webmethod"
        <WebMethod(Description:="Issue Requests to RMiCW")>
        Public Function RMICWRequestIssueTest(ByVal strVisionCustomerId As String, ByVal strVisionAccountId As String, ByVal strAcctNum As String, ByVal strAppId As String, ByVal strBTN As String, ByVal strClass As String, ByVal strConditionCd As String, ByVal strLogonId As String, ByVal strNotationCd As String, ByVal strOrg As String, ByVal strOriginationId As String, ByVal strRegionId As String, ByVal strActn As String, ByVal strRequestType As String, ByVal strSBM As String, ByVal strEnvironment As String, ByVal strRemarks As String, ByVal strReturncd As String) As RMICWRequestWS_Output
            Dim obj As RMICWRequestIssue = New RMICWRequestIssue(strRegionId.Trim)
            Return obj.RMICWRequestIssueTest(strVisionCustomerId, strVisionAccountId, strAcctNum, strAppId, strBTN, strClass, strConditionCd, strLogonId, strNotationCd, strOrg, strOriginationId, strRegionId, strActn, strRequestType, strSBM, strEnvironment, strRemarks, strReturncd)
        End Function
#End Region

#Region "getResponseForRequestTest Webmethod"

        <WebMethod(Description:="Get Response for the Request Issued")>
        Public Function getResponseForRequestTest(ByVal strRegionId As String, ByVal strAppId As String, ByVal strAcctNum As String, ByVal intRequestId As String) As ResultResponseWS_Output
            Dim obj As RMICWRequestIssue = New RMICWRequestIssue(strRegionId)
            Return obj.getResponseForRequestTest(strRegionId, strAppId, strAcctNum, intRequestId)
        End Function

#End Region

#Region "getCBSS_CBSPERA1 Webmethod Test"

        <WebMethod(Description:="Get Account Profile from CBSPERA1")>
        Public Function getCBSS_CBSPERA1Test(ByVal strRegionId As String, ByVal strAcctNum As String) As CBSPERA1

            Dim objCBSPERA1 As CBSPERA1 = New CBSPERA1
            Try
                Dim objERAAccess As CBSSERAAccess = New CBSSERAAccess(strRegionId)
                objCBSPERA1 = objERAAccess.getCBSS_CBSPERA1(strRegionId, strAcctNum)
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getCBSS_CBSPERA1", ex.ToString())
                objCBSPERA1.RequestStatus.strMessageId = "RMIEXPTN"
                objCBSPERA1.RequestStatus.strMessageDescription = ex.ToString
            End Try
            Return objCBSPERA1
        End Function
#End Region

#Region "getCBSS_CBSPERA2 Webmethod Test"

        '<WebMethod()> _
        'Public Function getCBSS_CBSPERA2Test(ByVal strRegionId As String, ByVal strAcctNum As String) As CBSPERA2

        '    Dim objCBSPERA2 As CBSPERA2 = New CBSPERA2
        '    Try
        '        Dim objERAAccess As CBSSERAAccess = New CBSSERAAccess(strRegionId)
        '        objCBSPERA2 = objERAAccess.getCBSS_CBSPERA2(strRegionId, strAcctNum)
        '    Catch ex As Exception
        '        LogErrorFile.WriteLog("RMICWWS-getCBSS_CBSPERA2", ex.ToString())
        '        objCBSPERA2.RequestStatus.strMessageId = "RMIEXPTN"
        '        objCBSPERA2.RequestStatus.strMessageDescription = ex.ToString
        '    End Try
        '    Return objCBSPERA2
        'End Function
#End Region

#Region "getCBSS_CBSEZRA9 Webmethod Test"

        '<WebMethod()> _
        'Public Function getCBSS_CBSEZRA9Test(ByVal strRegionId As String, ByVal strAcctNum As String) As CBSEZRA9

        '    Dim objCBSEZRA9 As CBSEZRA9 = New CBSEZRA9
        '    Try
        '        Dim objERAAccess As CBSSERAAccess = New CBSSERAAccess(strRegionId)
        '        objCBSEZRA9 = objERAAccess.getCBSS_CBSEZRA9(strRegionId, strAcctNum)
        '    Catch ex As Exception
        '        LogErrorFile.WriteLog("RMICWWS-getCBSS_CBSEZRA9", ex.ToString())
        '        objCBSEZRA9.RequestStatus.strMessageId = "RMIEXPTN"
        '        objCBSEZRA9.RequestStatus.strMessageDescription = ex.ToString
        '    End Try
        '    Return objCBSEZRA9
        'End Function
#End Region

#Region "getCBSS_CBSPTRA9_CreditInfo Webmethod Test"
        <WebMethod(Description:="Get Credit Information from CBSPTRA9")>
        Public Function getCBSS_CBSPTRA9_CreditInfoTest(ByVal strRegionId As String, ByVal strAcctNum As String) As CBSPTRA9_CreditInfo

            Dim objCreditInfo As CBSPTRA9_CreditInfo = New CBSPTRA9_CreditInfo
            Try
                Dim objERAAccess As CBSSERAAccess = New CBSSERAAccess(strRegionId)
                objCreditInfo = objERAAccess.getCBSS_CBSPTRA9_CreditInfo(strRegionId, strAcctNum)
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getCBSS_CBSPTRA9_CreditInfo", ex.ToString())
                objCreditInfo.RequestStatus.strMessageId = "RMIEXPTN"
                objCreditInfo.RequestStatus.strMessageDescription = ex.ToString
            End Try
            Return objCreditInfo
        End Function
#End Region

#Region "getCBSS_CBSPCFA1_BalanceInfo Webmethod Test"
        'CBSPCFA1 - Calculate Customer Balances

        <WebMethod(Description:="Get Customer Balance Information from CBSPCFA1")>
        Public Function getCBSS_CBSPCFA1_BalanceInfoTest(ByVal strRegionId As String, ByVal strAcctNum As String) As CFIBalanceInfo

            'Dim objCreditInfo As CBSPTRA9_CreditInfo = New CBSPTRA9_CreditInfo
            Dim objBalanceInfo As CFIBalanceInfo = New CFIBalanceInfo
            'CBSPCFA1
            Try
                Dim objERAAccess As CBSSERAAccess = New CBSSERAAccess(strRegionId)
                objBalanceInfo = objERAAccess.getCBSS_CBSPCFA1_BalanceInfo(strRegionId, strAcctNum)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getCBSS_CBSPCFA1_BalanceInfo", ex.ToString())
                objBalanceInfo.RequestStatus.strMessageId = "RMIEXPTN"
                objBalanceInfo.RequestStatus.strMessageDescription = ex.ToString
            End Try
            Return objBalanceInfo
        End Function
#End Region

#Region "getCBSS_CBSPCFA3  Webmethod Test"
        'CBSPCFA3 - Calculate Customer Balances

        <WebMethod(Description:="Get Customer Balance Information from CBSPCFA3")>
        Public Function getCBSS_CBSPCFA3(ByVal strRegionId As String, ByVal strAcctnum As String, ByVal strXMLLog As String) As XmlDocument

            'Dim objCreditInfo As CBSPTRA9_CreditInfo = New CBSPTRA9_CreditInfo
            Dim objBalanceInfo As CFIBalanceInfo = New CFIBalanceInfo
            Dim xmlCFA3 As XmlDocument = New XmlDocument()
            'CBSPCFA3
            Try
                Dim objERAAccess As CBSSERAAccess = New CBSSERAAccess(strRegionId)
                xmlCFA3 = objERAAccess.getCBSS_CBSPCFA3(strRegionId, strAcctnum, strXMLLog)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getCBSS_CBSPCFA3_BalanceInfo", ex.ToString())
                objBalanceInfo.RequestStatus.strMessageId = "RMIEXPTN"
                objBalanceInfo.RequestStatus.strMessageDescription = ex.ToString
            End Try
            Return xmlCFA3
        End Function
#End Region

#Region "getEOI_EOIFS010 Webmethod Test"

        <WebMethod(Description:="Get List of Pending Orders")>
        Public Function getEOI_EOIFS010Test(ByVal strRegionId As String, ByVal strAcctNum As String) As EOIFS010

            Dim objEOIFS010 As EOIFS010 = New EOIFS010
            Try
                Dim objEOIAccess As EOIERAAccess = New EOIERAAccess(strRegionId)
                objEOIFS010 = objEOIAccess.getEOI_EOIFS010(strRegionId, strAcctNum)
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getEOI_EOIFS010", ex.ToString())
                objEOIFS010.RequestStatus.strMessageId = "RMIEXPTN"
                objEOIFS010.RequestStatus.strMessageDescription = ex.ToString
            End Try
            Return objEOIFS010
        End Function
#End Region

#Region "getAcctsForSBM Webmethod Test"

        <WebMethod(Description:="Get List of Account Numbers and BTN for an SBM")>
        Public Function getAcctsForSBMTest(ByVal strRegionId As String, ByVal strAcctNum As String, ByVal strRshipCode As String) As SummaryBillDetails

            Dim objSBMList As SummaryBillDetails = New SummaryBillDetails
            Try
                Dim objERAAccess As CBSSERAAccess = New CBSSERAAccess(strRegionId)
                objSBMList = objERAAccess.getAcctsForSBM(strRegionId, strAcctNum, strRshipCode)
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getAcctsForSBM", ex.ToString())
                objSBMList.RequestStatus.strMessageId = "RMIEXPTN"
                objSBMList.RequestStatus.strMessageDescription = ex.ToString
            End Try
            Return objSBMList
        End Function
#End Region

#Region "AAIS Starts"

#Region "AAISClient Test"

        <WebMethod(Description:="AAIS Client Test ")>
        Public Function AAISClientTest(ByVal strRegionId As String, ByVal strAcctNum As String, ByVal strAAISActn As String, ByVal strAAISIP As String, ByVal strAAISPort As String, ByVal RMICWServer As String, ByVal RMICWPort As String, ByVal strSyncFlag As String, ByVal strWTN As String, ByVal intRequestId As Long) As String
            Dim strMsg As String = " "

            Try
                Dim objAAISAccess As AAISClient = New AAISClient(strRegionId)
                Dim Request As AAISRequest = New AAISRequest
                Request.strAcctNum = strAcctNum
                Request.strAAISActn = strAAISActn
                Request.strAAISServerIP = strAAISIP
                Request.strAAISPort = strAAISPort
                Request.strRequestId = intRequestId.ToString()
                Request.strRMiCWServerIP = RMICWServer
                Request.strRMICWServerPort = RMICWPort
                Request.strSyncFlag = strSyncFlag
                Request.strWTN = strWTN

                strMsg = objAAISAccess.StartClientTest(Request)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getAcctsForSBM", ex.ToString())
                strMsg = ex.ToString
            End Try
            Return strMsg
        End Function
#End Region

#Region "SubmitMessageRequest Test"

        <WebMethod(Description:="SubmitMessageRequest ")>
        Public Function SubmitMessageRequestTest(ByVal strRegionId As String, ByVal intRequestId As String, ByVal strAcctNum As String, ByVal strAAISActn As String, ByVal strAAISIP As String, ByVal strAppId As String, ByVal strBTNNum As String, ByVal strDestSystem As String, ByVal strNotationCd As String, ByVal strOrg As String, ByVal strOverrideFlag As String, ByVal strSyncFlag As String, ByVal strRemarks As String, ByVal strEnvironment As String) As MessageRequestOut
            Dim RequestOut As MessageRequestOut = New MessageRequestOut

            Try
                Dim objAAISAccess As AAISAccess = New AAISAccess(strRegionId)
                Dim Request As MessageRequestInp = New MessageRequestInp
                Request.strAcctNum = strAcctNum
                Request.intRequestId = intRequestId.ToString()
                Request.strActn = strAAISActn
                Request.strAppId = strAppId
                Request.strBTNNum = strBTNNum
                Request.strDestSystem = strDestSystem
                Request.strNotationCd = strNotationCd
                Request.strOrg = strOrg
                Request.strOverrideFlag = strOverrideFlag
                Request.strRegionId = strRegionId
                Request.strRemarks = strRemarks
                Request.strSyncFlag = strSyncFlag
                Request.strEnvironment = strEnvironment

                RequestOut = objAAISAccess.submitMessageRequest(Request)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-SubMitMessageRequest", ex.ToString())
                RequestOut.RequestStatus.strMessageId = "RMIEXPTN"
                RequestOut.RequestStatus.strMessageDescription = ex.ToString
            End Try
            Return RequestOut
        End Function
#End Region

#Region "SubmitAAISBatch Test"
        'RMICW to AAIS thru Tunnelling
        '<WebMethod(Description:="SubmitAAISBatch ")> _
        'Public Function SubmitAAISBatchTest(ByVal strRegionId As String, ByVal strAcctNum As String, ByVal strAAISActn As String) As MessageRequestOut
        '    Dim RequestOut As MessageRequestOut = New MessageRequestOut

        '    Try
        '        Dim objAAISAccess As AAISAccess = New AAISAccess(strRegionId)
        '        Dim Request As MessageRequestInp = New MessageRequestInp
        '        Request.strAcctNum = strAcctNum
        '        'Request.intRequestId = intRequestId.ToString()
        '        Request.strActn = strAAISActn
        '        'Request.strAppId = strAppId
        '        'Request.strBTNNum = strBTNNum
        '        'Request.strDestSystem = strDestSystem
        '        'Request.strNotationCd = strNotationCd
        '        'Request.strOrg = strOrg
        '        'Request.strOverrideFlag = strOverrideFlag
        '        'Request.strRegionId = strRegionId
        '        'Request.strRemarks = strRemarks
        '        'Request.strSyncFlag = strSyncFlag

        '        'RequestOut = objAAISAccess.submitMessageRequest(Request)
        '        'RequestOut = objAAISAccess.SubmitChildRequestForAAISSyncBatch
        '        'Dim arrReq() As AAISRequest
        '        Dim arrLst As ArrayList = New ArrayList
        '        Dim AAISReq As AAISRequest = New AAISRequest

        '        '608-253-5190
        '        '608-253-5407
        '        '608-253-5544
        '        '1st array
        '        AAISReq.strAcctNum = "1000578429"
        '        AAISReq.strRequestId = "991015"
        '        AAISReq.strAAISActn = "S"
        '        'AAISReq.strSyncFlag = MsgInp.Request.strSyncFlag
        '        AAISReq.strWTN = "6082544765"
        '        AAISReq.strAAISServerIP = "192.76.102.71"
        '        AAISReq.strAAISPort = "6507"
        '        AAISReq.strRMiCWServerIP = "113.130.193.23"
        '        AAISReq.strRMICWServerPort = "11000"
        '        arrLst.Add(AAISReq)

        '        '2nd array
        '        AAISReq.strAcctNum = "1000578429"
        '        AAISReq.strRequestId = "991016"
        '        AAISReq.strAAISActn = "S"
        '        'AAISReq.strSyncFlag = MsgInp.Request.strSyncFlag
        '        AAISReq.strWTN = "6082544769"
        '        AAISReq.strAAISServerIP = "192.76.102.71"
        '        AAISReq.strAAISPort = "6507"
        '        AAISReq.strRMiCWServerIP = "113.130.193.23"
        '        AAISReq.strRMICWServerPort = "11000"
        '        arrLst.Add(AAISReq)

        '        ''3rd array
        '        'AAISReq.strAcctNum = "1000578429"
        '        'AAISReq.strRequestId = "991007"
        '        'AAISReq.strAAISActn = "S"
        '        ''AAISReq.strSyncFlag = MsgInp.Request.strSyncFlag
        '        'AAISReq.strWTN = "6082544771"
        '        'AAISReq.strAAISServerIP = "192.76.102.71"
        '        'AAISReq.strAAISPort = "6507"
        '        'AAISReq.strRMiCWServerIP = "113.130.193.23"
        '        'AAISReq.strRMICWServerPort = "11000"
        '        'arrLst.Add(AAISReq)

        '        For Each AAISReq In arrLst
        '            Dim strwtn As String = ""
        '            strwtn = AAISReq.strWTN
        '            strwtn += strwtn
        '        Next

        '        'objAAISAccess.SubmitChildRequestForAAISSyncBatch(arrLst, AAISReq)

        '        'objAAISAccess.SubmitChildRequestForAAIS(arrLst, AAISReq)

        '    Catch ex As Exception
        '        LogErrorFile.WriteLog("RMICWWS-SubMitMessageRequest", ex.ToString())
        '        RequestOut.RequestStatus.strMessageId = "RMIEXPTN"
        '        RequestOut.RequestStatus.strMessageDescription = ex.ToString
        '    End Try
        '    Return RequestOut
        'End Function

        'RMICW to AAIS thru Webservice

        <WebMethod(Description:="SubmitAAISBatch ")>
        Public Function SubmitAAISBatchTest(ByVal strRegionId As String, ByVal strAcctNum As String, ByVal strAAISActn As String) As MessageRequestOut
            Dim RequestOut As MessageRequestOut = New MessageRequestOut

            Try
                Dim objAAISAccess As AAISAccess = New AAISAccess(strRegionId)
                Dim Request As MessageRequestInp = New MessageRequestInp
                Request.strAcctNum = strAcctNum
                Request.strActn = strAAISActn

                Dim arrLst As ArrayList = New ArrayList
                Dim AAISReq As AAISRequest = New AAISRequest

                '1st array
                AAISReq.strAcctNum = "2800141396"
                AAISReq.strAAISActn = "S"
                AAISReq.strRequestId = "11191644"
                AAISReq.strSyncFlag = "F"
                AAISReq.strWTN = "3256418624"
                arrLst.Add(AAISReq)

                '2nd array
                AAISReq.strAcctNum = "2828174719"
                AAISReq.strAAISActn = "S"
                AAISReq.strRequestId = "11191645"
                AAISReq.strSyncFlag = "F"
                AAISReq.strWTN = "3256418972"
                arrLst.Add(AAISReq)

                '3rd array
                AAISReq.strAcctNum = "2811203649"
                AAISReq.strAAISActn = "S"
                AAISReq.strRequestId = "11191646"
                AAISReq.strSyncFlag = "F"
                AAISReq.strWTN = "3256419035"
                arrLst.Add(AAISReq)

                AAISReq.strAcctNum = "2800222433"
                AAISReq.strAAISActn = "S"
                AAISReq.strRequestId = "11191647"
                AAISReq.strSyncFlag = "F"
                AAISReq.strWTN = "3256419281"
                arrLst.Add(AAISReq)

                AAISReq.strAcctNum = "2811376070"
                AAISReq.strAAISActn = "S"
                AAISReq.strRequestId = "11191648"
                AAISReq.strSyncFlag = "F"
                AAISReq.strWTN = "3256419313"
                arrLst.Add(AAISReq)

                ''3rd array
                'AAISReq.strAcctNum = "1000578429"
                'AAISReq.strRequestId = "991007"
                'AAISReq.strAAISActn = "S"
                ''AAISReq.strSyncFlag = MsgInp.Request.strSyncFlag
                'AAISReq.strWTN = "6082544771"
                'AAISReq.strAAISServerIP = "192.76.102.71"
                'AAISReq.strAAISPort = "6507"
                'AAISReq.strRMiCWServerIP = "113.130.193.23"
                'AAISReq.strRMICWServerPort = "11000"
                'arrLst.Add(AAISReq)

                'For Each AAISReq In arrLst
                For i As Integer = 0 To arrLst.Count - 1
                    AAISReq = arrLst(i)
                    Dim strwtn As String = ""
                    strwtn = AAISReq.strWTN
                    strwtn += strwtn
                Next

                'objAAISAccess.fnSendMultipleRequest(arrLst, AAISReq)
                ' objAAISAccess.SubmitChildRequestForAAIS(arrLst, AAISReq)

                'objAAISAccess.SubmitChildRequestForAAISSyncBatch(arrLst, AAISReq)

                objAAISAccess.SubmitChildRequestForAAIS(arrLst, AAISReq)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-SubMitMessageRequest", ex.ToString())
                RequestOut.RequestStatus.strMessageId = "RMIEXPTN"
                RequestOut.RequestStatus.strMessageDescription = ex.ToString
            End Try
            Return RequestOut
        End Function

#End Region

#End Region

#Region "get uCSR Details"

        <WebMethod(Description:="Get uCSR Data ")>
        Public Function getuCSRData(ByVal strCANNum As String, ByVal strAcctNum As String, ByVal stractn As String, ByVal strServiceType As String, ByVal strCompanyCode As String, ByVal strServiceOrderNum As String, ByVal strLECBilledStatus As String, ByVal strRAO As String, ByVal strPCAN As String, ByVal strDCR As String, ByVal strAccountId As String, ByVal strServiceId As String) As uCSR_DetailsOut

            Dim uCSRDetailOut As uCSR_DetailsOut = New uCSR_DetailsOut

            Try

                Dim objuCSRRequest As uCSR_DetailsInp = New uCSR_DetailsInp
                Dim objuCSRData As TreatmentStatus = New TreatmentStatus("WEST")

                objuCSRRequest.strCANNum = strCANNum
                objuCSRRequest.strAcctNum = strAcctNum
                objuCSRRequest.strActn = stractn
                objuCSRRequest.strServiceType = strServiceType
                objuCSRRequest.strCompanyCode = strCompanyCode
                objuCSRRequest.strServiceOrderNum = strServiceOrderNum
                objuCSRRequest.strLECBilledStatus = strLECBilledStatus
                objuCSRRequest.strRAO = strRAO

                'Added for Enhance SSP collection processing  - Additional fields -Begin
                objuCSRRequest.strPCAN = strPCAN
                objuCSRRequest.strDCR = strDCR
                objuCSRRequest.strAccountId = strAccountId
                objuCSRRequest.strServiceId = strServiceId
                'Added for Enhance SSP collection processing  - Additional fields -End

                uCSRDetailOut = objuCSRData.getuCSRData(objuCSRRequest)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-uCSR", ex.ToString())
                uCSRDetailOut.strStatus = "RMICWEXPTN"
            End Try
            Return uCSRDetailOut
        End Function
#End Region

#Region "get Account Relationship - uses uCSR GetAccountRelationships"

        <WebMethod(Description:="Get info from uCSR/NACR ")>
        Public Function getAccountRelationships(ByVal strEastWestInd As String, ByVal strInputValue As String, ByVal strInputType As String, ByVal strBaseRegion As String) As GetAcctRelationship_Response

            Dim objGetAcctRelationship_Response As GetAcctRelationship_Response = New GetAcctRelationship_Response

            Try

                Dim objUCSRAccess As UCSRAccess = New UCSRAccess(strBaseRegion.Trim)
                objGetAcctRelationship_Response = objUCSRAccess.getAccountRelationships(strEastWestInd, strInputValue, strInputType)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getAccountRelationships", ex.ToString())

            End Try
            Return objGetAcctRelationship_Response
        End Function
#End Region

#Region "get Account RelationshipCOG - uses uCSR GetAccountRelationshipsCOGTest"

        <WebMethod(Description:="Get info from uCSR/NACR ")>
        Public Function getAccountRelationshipsCOGTest(ByVal strRegionId As String, ByVal strEastWestInd As String, ByVal strInputValue As String, ByVal strInputType As String, ByVal intRequestid As String) As GetAcctRelationship_Response

            Dim objGetAcctRelationship_Response As GetAcctRelationship_Response = New GetAcctRelationship_Response

            Try

                Dim objUCSRAccess As UCSRAccess = New UCSRAccess(strRegionId.Trim)
                objGetAcctRelationship_Response = objUCSRAccess.getAccountRelationshipsCOG(strRegionId, strEastWestInd, strInputValue, strInputType, intRequestid)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getAccountRelationshipsCOGTest", ex.ToString())

            End Try
            Return objGetAcctRelationship_Response
        End Function
#End Region

#Region "get STRA XBCLSP05 sproc details Webmethod TEST"

        <WebMethod(Description:="Get List of Pending Orders in STRA")>
        Public Function get_XBCLSP05Test(ByVal strRegionId As String, ByVal strAcctNum As String, ByVal strEnv As String, ByVal strSVRQ As String, ByVal intReadkey As Integer) As XBCLSP05

            Dim objXBCLSP05 As XBCLSP05 = New XBCLSP05
            Try
                Dim objSTRAAccess As STRAdb2Access = New STRAdb2Access(strRegionId)

                objXBCLSP05 = objSTRAAccess.get_XBCLSP05(strRegionId, strAcctNum, strEnv, strSVRQ, intReadkey)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getEOI_EOIFS010", ex.ToString())
                objXBCLSP05.RequestStatus.strMessageId = "RMIEXPTN"
                objXBCLSP05.RequestStatus.strMessageDescription = ex.ToString
            End Try
            Return objXBCLSP05
        End Function
#End Region

#Region "get XBCLSPA5 sproc details Webmethod for RMVP-MDVW data"

        <WebMethod(Description:="Get Balances from XBCLSPA5 for RMVP_MDVW")>
        Public Function get_XBCLSPA5(ByVal strRegionId As String, ByVal strAcctountNum As String, ByVal strEnv As String, ByVal intReadkey As Integer) As XBCLSPA5

            Dim objXBCLSPA5 As XBCLSPA5 = New XBCLSPA5
            Try
                Dim objDB2Access As MDVW_RMVP_Data = New MDVW_RMVP_Data(strRegionId)
                'Dim RMVPdb2Access As New MDVW_RMVPdb2Access
                objXBCLSPA5 = objDB2Access.get_XBCLSPA5(strRegionId, strAcctountNum, strEnv, intReadkey)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getEOI_EOIFS010", ex.ToString())
                objXBCLSPA5.RequestStatus.strMessageId = "RMIEXPTN"
                objXBCLSPA5.RequestStatus.strMessageDescription = ex.ToString
            End Try
            Return objXBCLSPA5
        End Function
#End Region

#Region "get XBCLSPA3 details from ICollect Webmethod for RMVP-MDVW and WEbPortal"

        <WebMethod(Description:="Get Balances from iCollect WebService for RMVP_MDVW")>
        Public Function get_XBCLSPA3_ICollect(ByVal strRegionId As String, ByVal strAcctountNum As String) As XBCLSPA5

            Dim objXBCLSPA3 As XBCLSPA5 = New XBCLSPA5
            Try

                Dim objDB2Access As MDVW_RMVP_Strata = New MDVW_RMVP_Strata(strRegionId)
                objXBCLSPA3 = objDB2Access.get_XBCLSPA3_Icollect(strRegionId, strAcctountNum)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-ICollect[SPA3-MDVW]", ex.ToString())
                objXBCLSPA3.RequestStatus.strMessageId = "RMIEXPTN"
                objXBCLSPA3.RequestStatus.strMessageDescription = ex.ToString
            End Try
            Return objXBCLSPA3

        End Function
#End Region

        '#Region "get XBCLSPA5 sproc details Webmethod for RMVP-MDVW data"

        '        <WebMethod(Description:="Get Balances from iCollect WebService for RMVP_MDVW")> _
        '        Public Function get_XBCLSPA5(ByVal strRegionId As String, ByVal strAcctountNum As String, ByVal strEnv As String, ByVal intReadkey As Integer) As XBCLSPA3

        '            Dim objXBCLSPA3 As XBCLSPA3 = New XBCLSPA3
        '            Try

        '                Dim objDB2Access As MDVW_RMVP_Strata = New MDVW_RMVP_Strata(strRegionId)
        '                objXBCLSPA3 = objDB2Access.get_XBCLSPA3(strRegionId, strAcctountNum, strEnv, intReadkey)

        '            Catch ex As Exception
        '                LogErrorFile.WriteLog("RMICWWS-ICollect[SPA5]", ex.ToString())
        '                objXBCLSPA3.RequestStatus.strMessageId = "RMIEXPTN"
        '                objXBCLSPA3.RequestStatus.strMessageDescription = ex.ToString
        '            End Try
        '            Return objXBCLSPA3
        '        End Function
        '#End Region

#Region "Treatment Details Test Webmethod for RMVP"
        <WebMethod(Description:="Get Treatment Status")>
        Public Function getTreatmentDetailsTest(ByVal strRegionId As String, ByVal strOrg As String, ByVal InpRequestType As String, ByVal strAppId As String, ByVal strAcctNum As String) As TD_Response

            Try

                Dim obj As TreatmentStatus = New TreatmentStatus(strRegionId.Trim)
                Dim objRequest As TD_Request = New TD_Request
                objRequest.strAcctNum = strAcctNum
                objRequest.strApplicationId = strAppId
                objRequest.strInputRequestType = InpRequestType
                objRequest.strOrg = strOrg
                objRequest.strRegionId = strRegionId
                'Return obj.getTreatmentStatus(objRequest)
                Return obj.getTreatmentDetails(objRequest)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWebServices", ex.ToString())
            End Try
        End Function
#End Region
#Region "get FIOS Info - uses FIOS Info"
        <WebMethod(Description:="Get info from uCSR For FIOS Test")>
        Public Function getFIOSDataTest(ByVal intRequestId As String, ByVal strAcctnum As String, ByVal strActn As String, ByVal strSSPActn As String, ByVal strDest As String, ByVal strEnv As String, ByVal strOrg As String, ByVal strOriginationId As String, ByVal strRegionId As String, ByVal strVideoCAN As String, ByVal strBBACN As String, ByVal strPROFILECAN As String, ByVal strExtendedParm As String, ByVal strWTN As String, ByVal strNotationCd As String, ByVal strSSPAccountId As String, ByVal strClass As String, ByVal strRemarks As String, ByVal strRETRY As String, ByVal isRestoreFee As String) As sspResponseDetails

            Dim objSSPRp As sspResponseDetails = New sspResponseDetails

            Try
                Dim wsM As WSMain = New WSMain
                Dim getFIOSRequest As getFIOSDataInputDetails = New getFIOSDataInputDetails
                'TEST PARM SETUP
                getFIOSRequest.intRequestId = intRequestId
                getFIOSRequest.strAcctNum = strAcctnum
                getFIOSRequest.strRegionId = strRegionId
                getFIOSRequest.strActn = strActn
                getFIOSRequest.strSSPActn = strSSPActn
                getFIOSRequest.strOrg = strOrg
                getFIOSRequest.strClass = strClass.Trim()  'Added StrClass for Thunder - IVAPP Requests.
                getFIOSRequest.strRemarks = strRemarks.Trim() 'Added StrClass for Thunder - IVAPP Requests.
                If strNotationCd.Trim() = "ACCTLVL" Then
                    getFIOSRequest.strNotationCd = strNotationCd
                ElseIf strNotationCd.Trim() = "MIGRATION" Then
                    getFIOSRequest.strNotationCd = strNotationCd
                ElseIf IsNumeric(getFIOSRequest.strNotationCd.Trim()) Then
                    getFIOSRequest.strSSPAccountID = strNotationCd
                Else
                    getFIOSRequest.strNotationCd = strNotationCd
                End If

                getFIOSRequest.strSSPAccountID = strSSPAccountId.Trim()
                getFIOSRequest.strExtendedParm = strRETRY
                getFIOSRequest.strEnvironment = strEnv
                If isRestoreFee.Trim().ToUpper() = "Y" Then
                    getFIOSRequest.isFVRestoralFee = "Y"
                Else
                    getFIOSRequest.isFVRestoralFee = "N"
                End If

                objSSPRp = wsM.getFIOSData(getFIOSRequest)

                'TEST PARM SETUP

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWebServices", ex.ToString())
            End Try
            Return objSSPRp
        End Function
#End Region
#Region "get SSP ID - To Get SSP Account ID Test"
        <WebMethod(Description:="Get SSP Account ID from CSR")>
        Public Function GetGenIndexByAcctNum(ByVal strBBNum As String, ByVal strRegionId As String) As String
            Dim strSSPIDXML As String = ""
            Dim strSSPID As String = ""
            Dim objSSPRqst As New SSPRequestDetails
            Dim wsM As New WSMain
            objSSPRqst.strRegionId = strRegionId
            Try

                strSSPIDXML = wsM.GetGenIndexByAcctNum(strBBNum.Trim(), objSSPRqst)
                If (strSSPIDXML.IndexOf("Generic Index Not Found in NACR for Account Number") >= 0) Then
                    strSSPID = ""
                Else
                    strSSPID = strSSPIDXML.Trim()
                End If
                '*****************************************************************
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-GetGenIndexByAcctNum:strBBNum" + strBBNum, ex.ToString())
                strSSPID = ""
            End Try
            Return strSSPID.Trim()

        End Function
#End Region

#Region "issue IVAPP Request - Test"

        <WebMethod(Description:="Issue Request to IVAPP")>
        Public Function RequestIssueToIVAPP(ByVal intrequestid As String, ByVal strAcctnum As String, ByVal strRegionId As String, ByVal strActn As String, ByVal strOrg As String, ByVal strWTN As String, ByVal strRETRY As String, ByVal strClass As String) As sspResponseDetails
            Dim blnSucess As Boolean = False
            Dim strIvappInputXml As String = ""
            Dim objAcctLineInfo As AcctLineLevelInfo = New AcctLineLevelInfo
            Dim objAddBlockVoiceOrder As AddBlockVoiceOrder = New AddBlockVoiceOrder()
            ' Dim xmlDoc As XmlDocument
            Dim objSSPResp As sspResponseDetails = New sspResponseDetails
            Dim objSSPRqst As SSPRequestDetails = New SSPRequestDetails
            Dim getFIOSRequest As getFIOSDataInputDetails = New getFIOSDataInputDetails

            Dim wsM As WSMain = New WSMain
            Dim objRMWIVAPP As clsIvappMain = New clsIvappMain
            Dim objUSCRGetAccount As CSRGetAccount.Account = New CSRGetAccount.Account
            If strRETRY <> "Y" Then
                Try
                    'TEST PARM SETUP
                    getFIOSRequest.intRequestId = intrequestid
                    getFIOSRequest.strAcctNum = strAcctnum
                    getFIOSRequest.strRegionId = strRegionId
                    getFIOSRequest.strActn = strActn
                    getFIOSRequest.strOrg = strOrg
                    getFIOSRequest.strExtendedParm = strRETRY
                    getFIOSRequest.strWTN = strWTN
                    getFIOSRequest.strClass = strClass 'Added for project thunder.
                    objSSPResp = wsM.RequestIssueToIVAPP(getFIOSRequest)
                    'TEST PARM SETUP
                Catch ex As Exception
                    LogErrorFile.WriteLog("RMICWWS-RequestIssueToIVAPP", strAcctnum + ex.ToString())
                    strIvappInputXml = ex.ToString
                End Try
                Return objSSPResp

            End If

        End Function
#End Region

#Region "GetAccount - uses uCSR GetcustomGAR"
        <WebMethod(Description:="GetcustomGAR Details from ikeynacr")>
        Public Function GetcustomGAR(ByVal strEastWestInd As String, ByVal strInputValue As String, ByVal strInputType As String, ByVal strBaseRegion As String) As GetCustomGAR

            Dim objGetAcctRelationship_Response As GetAcctRelationship_Response = New GetAcctRelationship_Response
            Dim objGAR As GetCustomGAR = New GetCustomGAR

            Try
                strBaseRegion = "WEST"
                Dim objUCSRAccess As UCSRAccess = New UCSRAccess(strBaseRegion.Trim)
                'objGetAcctRelationship_Response = objUCSRAccess.GetcustomGAR(strEastWestInd, strInputValue, strInputType)
                objGAR = objUCSRAccess.GetcustomGAR(strEastWestInd, strInputValue, strInputType)
                'objGAR = objUCSRAccess.GetcustomGAR("E", "A000075724", "PROFILE")

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-GetcustomGAR", ex.ToString())

            End Try
            'Return objGetAcctRelationship_Response
            Return objGAR
            '
        End Function
#End Region

#Region "get uCSR Account - uses uCSR GetAccount"

        <WebMethod(Description:="Get ACCOUNT INFO from uCSR Test ")>
        Public Function getCSRAccountData(ByVal strAcctnum As String, ByVal strRegionId As String) As CSRGetAccount.Account

            Dim objWsMain As WSMain = New WSMain
            Dim objUSCRGetAccount As CSRGetAccount.Account = New CSRGetAccount.Account
            Dim objSSPRqst As SSPRequestDetails = New SSPRequestDetails

            Try

                'ITW Enable - SS 100907
                objSSPRqst.strRegionId = strRegionId
                objUSCRGetAccount = objWsMain.getCSRAccountData(strAcctnum, objSSPRqst)

                'ITW Enable

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getCSRAccountData", ex.ToString())
                objUSCRGetAccount = Nothing
            End Try
            Return objUSCRGetAccount
        End Function
#End Region

#Region "putgetMQ Test"
        <WebMethod(Description:="MQ Get and Put Messages")>
        Public Function MQTest(ByVal strMsg As String, ByVal strRegionId As String, ByVal strTYpe As String, ByVal strGetPut As String) As String
            Dim objMQGeneric As clsMQGeneric = New clsMQGeneric
            Try
                Select Case strGetPut.ToUpper.Trim()
                    Case "GET"
                        strTYpe = strGetPut + ": successful : " + strTYpe

                    Case "PUT"
                        Dim cls As clsIvappMain = New clsIvappMain
                        Dim objsspRqst As SSPRequestDetails = New SSPRequestDetails
                        cls.putTheMessageIntoQueue(strMsg, strRegionId, strTYpe, objsspRqst)
                        objMQGeneric.fnMQPutMsg(strMsg, strRegionId, strTYpe)

                End Select

                strTYpe = strGetPut + ": successful : " + strTYpe

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-putgetMQ:" + strGetPut + strTYpe, ex.ToString())

            End Try
            Return strTYpe.Trim()

        End Function
#End Region

#Region "STRATA RESPONSE"

        <WebMethod(Description:="GET STRATA RESPONSE")>
        Public Function GetStrataResponse(ByVal strAccoutNumber As String, ByVal strEventType As String, ByVal strAppID As String) As IcollectSTRATAService.StrataResponse

            Dim objresp As New IcollectSTRATAService.StrataResponse
            Dim strataclient As New IcollectSTRATAService.SDEServiceClient()
            If strAppID.Trim() = "" Then
                strAppID = "RMICW"
            End If
            objresp = strataclient.PA_STRATA_Communicator(strAccoutNumber, strEventType, strAppID)
            Return objresp

        End Function
#End Region

#Region "iGO Success Request"

        <WebMethod(Description:="Issue Success Request to iGO")>
        Public Function SRequestIssueToiGO(ByVal strActn As String, ByVal strOrg As String, ByVal strRegion As String, ByVal strMasterOrderNumber As String, ByVal strOrderNumber As String, ByVal strOrderType As String, ByVal strBillingTelephoneNumber As String, ByVal strBAN As String, ByVal strCAN As String, ByVal strSuspendRestoreDisconnectflag As String, ByVal blnData As Boolean, ByVal blnVideo As Boolean, ByVal blnVoice As Boolean, ByVal strLOB As String, ByVal strFirstName As String, ByVal strLastName As String, ByVal strStreetNumber As String, ByVal strStreetName As String, ByVal strUnitType As String, ByVal strUnitVal As String, ByVal strCity As String, ByVal strState As String, ByVal strZip As String, ByVal strProfileCan As String) As iGO_SuccessLayout

            'Public Function RequestIssueToiGO(ByVal strMasterOrderNumber As String, ByVal strOrderNumber As String, ByVal strOrderType As String, ByVal strBAN As String, ByVal strCAN As String, ByVal strSuspendRestoreDisconnectflag As String, ByVal Data As String, ByVal Video As String, ByVal Voice As String, ByVal strLOB As String, ByVal strFirstName As String, ByVal strLastName As String, ByVal strStreetNumber As String, ByVal strStreetName As String, ByVal strUnitType As String, ByVal strUnitVal As String, ByVal strCity As String, ByVal strState As String, ByVal strZip As String) As String
            Dim blnSucess As Boolean = False
            Dim strIvappInputXml As String = ""
            Dim strvalue As String = ""
            'Dim xmlDoc As XmlDocument
            Dim objiGORqst As iGO_SuccessLayout = New iGO_SuccessLayout
            Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric

            strvalue = ObjDataAccess.usp_GetControlParmByName(strRegion, "MQiGOEnable")

            If strvalue.ToUpper().Trim() = "TRUE" Then

                objiGORqst.strMasterOrderNumber = strMasterOrderNumber
                objiGORqst.strOrderNumber = strOrderNumber
                objiGORqst.strOrderType = strOrderType
                Try
                    Select Case strRegion.ToUpper.Trim()
                        Case "NE", "NY", "NPD", "MDVW"
                            strBillingTelephoneNumber = strBillingTelephoneNumber.Substring(0, 10)

                    End Select

                Catch ex As Exception
                    strBillingTelephoneNumber = strBillingTelephoneNumber
                End Try

                objiGORqst.strBillingTelephoneNumber = strBillingTelephoneNumber
                objiGORqst.strBAN = strBAN
                objiGORqst.strAcctNum = strCAN
                objiGORqst.strPCAN = strProfileCan
                objiGORqst.strSuspendRestoreDisconnectflag = strSuspendRestoreDisconnectflag
                objiGORqst.strServiceTypes.Data = blnData
                objiGORqst.strServiceTypes.Video = blnVideo
                objiGORqst.strServiceTypes.Voice = blnVoice
                objiGORqst.strLOB = strLOB
                objiGORqst.SERVICEADDRESSFIELDS.strFirstName = strFirstName
                objiGORqst.SERVICEADDRESSFIELDS.strLastName = strLastName
                objiGORqst.SERVICEADDRESSFIELDS.strStreetNumber = strStreetNumber
                objiGORqst.SERVICEADDRESSFIELDS.strStreetName = strStreetName
                objiGORqst.SERVICEADDRESSFIELDS.strUnitType = strUnitType
                objiGORqst.SERVICEADDRESSFIELDS.strUnitVal = strUnitVal
                objiGORqst.SERVICEADDRESSFIELDS.strCity = strCity
                objiGORqst.SERVICEADDRESSFIELDS.strState = strState
                objiGORqst.SERVICEADDRESSFIELDS.strZip = strZip

                Dim objRmicwiGo As RMICWiGO = New RMICWiGO

                Try
                    objRmicwiGo.SendiGoSuccessMsg(strActn, strOrg, strRegion, objiGORqst)

                Catch ex As Exception
                    LogErrorFile.WriteLog("RMICWWS- iGOSInterface", ex.ToString())
                    strIvappInputXml = ex.ToString
                End Try

                Return objiGORqst

            Else
                LogErrorFile.WriteLog("RMICWWS- iGOSInterface", "Not Calling Igo - Chk Controlparm")
            End If

        End Function
#End Region

#Region "iGO Failure Request"

        <WebMethod(Description:="Issue Success Request to iGO")>
        Public Function FRequestIssueToiGO(ByVal strActn As String, ByVal strOrg As String, ByVal strAcctnum As String, ByVal strMasterOrderNumber As String, ByVal strSuspendRestoreDisconnectflag As String, ByVal blnData As Boolean, ByVal blnVideo As Boolean, ByVal blnVoice As Boolean, ByVal strRegioncd As String) As iGO_FailureLayout

            'Public Function RequestIssueToiGO(ByVal strMasterOrderNumber As String, ByVal strOrderNumber As String, ByVal strOrderType As String, ByVal strBAN As String, ByVal strCAN As String, ByVal strSuspendRestoreDisconnectflag As String, ByVal Data As String, ByVal Video As String, ByVal Voice As String, ByVal strLOB As String, ByVal strFirstName As String, ByVal strLastName As String, ByVal strStreetNumber As String, ByVal strStreetName As String, ByVal strUnitType As String, ByVal strUnitVal As String, ByVal strCity As String, ByVal strState As String, ByVal strZip As String) As String
            Dim blnSucess As Boolean = False
            Dim strIvappInputXml As String = ""
            Dim strvalue As String = ""
            'Dim xmlDoc As XmlDocument
            Dim objiGOFRqst As iGO_FailureLayout = New iGO_FailureLayout
            Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric

            strvalue = ObjDataAccess.usp_GetControlParmByName(strRegioncd, "MQiGOEnable")

            If strvalue.ToUpper().Trim() = "TRUE" Then
                objiGOFRqst.strMasterOrderNumber = strMasterOrderNumber
                objiGOFRqst.strSuspendRestoreDisconnectflag = strSuspendRestoreDisconnectflag
                objiGOFRqst.strServiceTypes.Data = blnData
                objiGOFRqst.strServiceTypes.Video = blnVideo
                objiGOFRqst.strServiceTypes.Voice = blnVoice

                Dim objRmicwiGo As RMICWiGO = New RMICWiGO
                Try
                    objRmicwiGo.SendiGoFailureMsg(objiGOFRqst, strRegioncd, strActn, strOrg, strAcctnum)

                Catch ex As Exception
                    LogErrorFile.WriteLog("RMICWWS- iGOFInterface", ex.ToString())
                    strIvappInputXml = ex.ToString
                End Try
            Else
                LogErrorFile.WriteLog("RMICWWS- iGOSInterface", "Not Calling Igo - Chk Controlparm")
            End If

        End Function

#End Region

        '#Region "Wireless1Bill Status"

        '        <WebMethod(Description:="Wireless1Bill Status")> _
        '         Public Function GetWireless1BillStatus(ByVal strregioncd As String, ByVal strAcctnum As String) As String 'BQTResponse 'As W1B_Response

        '            Dim blnSucess As Boolean = False
        '            Dim strIvappInputXml As String = ""
        '            Dim stroutput As String = ""

        '            'Dim xmlDoc As XmlDocument

        '            Dim objBqtrequest As W1B_Request = New W1B_Request
        '            Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric

        '            'strvalue = ObjDataAccess.usp_GetControlParmByName(strRegion, "MQiGOEnable")

        '            objBqtrequest.strAcctNum = strAcctnum.Trim()
        '            objBqtrequest.strRegionId = strregioncd.ToUpper().Trim()

        '            Dim objWireless1Bill As Wireless1BillStatus = New Wireless1BillStatus(strregioncd)

        '            Try
        '                'objWireless1Bill.getWireless1BillStatus(objBqtrequest)

        '                Return objWireless1Bill.getWireless1BillStatus(objBqtrequest)
        '                'Return stroutput

        '            Catch ex As Exception
        '                LogErrorFile.WriteLog("RMICWWS- BQTInterface", ex.ToString())
        '                strIvappInputXml = ex.ToString
        '            End Try

        '        End Function
        '#End Region

#Region "getCBSS_CBSPCFA1_BalanceInfoEast Webmethod Test"

        <WebMethod(Description:="Get Customer Balance Information from East CFI - CBSPCFA1")>
        Public Function getCBSS_CBSPCFA1_BalanceInfoEast(ByVal strRegionCd As String, ByVal strAcctNum As String, ByVal strGetPPX As String, ByVal strGetClaim As String, ByVal curPPXAmt As Double, ByVal curBasicClaimAmt As Double, ByVal curNBClaimAmt As Double, ByVal curTollClaimAmt As Double, ByVal curOCARClaimAmt As Double, ByVal dtmbilldate As DateTime, ByVal dtmBilldueDate As DateTime, ByVal strOrg As String, ByVal strGetOption As String) As CFIBalanceInfoAccum

            Dim objBalanceInfo As CFIBalanceInfoAccum = New CFIBalanceInfoAccum

            Dim objInp As CFIBalanceInput = New CFIBalanceInput
            objInp.strRegioncd = strRegionCd
            objInp.strGetPPX = strGetPPX
            objInp.strGetClaim = strGetClaim
            objInp.strAcctNum = strAcctNum
            objInp.curPPXAmt = curPPXAmt
            objInp.curBasicClaimAmt = curBasicClaimAmt
            objInp.curNonBasicClaimAmt = curNBClaimAmt
            objInp.curTollClaimAmt = curTollClaimAmt
            objInp.curOCARClaimAmt = curOCARClaimAmt
            objInp.dtmBillDate = dtmbilldate
            objInp.dtmBillDueDate = dtmBilldueDate
            objInp.strOrg = strOrg
            If strGetOption = "" Then
                strGetOption = "0"
            End If
            objInp.strGetOption = strGetOption.Trim()

            'CBSPCFA1
            Try
                Dim objERAAccess As CBSSERAAccess = New CBSSERAAccess(objInp.strRegioncd)
                objBalanceInfo = objERAAccess.getCBSS_CBSPCFA1_BalanceInfoEast(objInp)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getCBSS_CBSPCFA1_BalanceInfo", ex.ToString())
                objBalanceInfo.RequestStatus.strMessageId = "RMIEXPTN"
                objBalanceInfo.RequestStatus.strMessageDescription = ex.ToString
            End Try
            Return objBalanceInfo
        End Function
#End Region

#Region "getRMICWProfile"

        <WebMethod(Description:="Get RMICW Profile")>
        Public Function getRMICWProfileTest(ByVal strRegionId As String, ByVal strAcctNum As String, ByVal strInpType As String, ByVal strOrg As String, ByVal strEnvironment As String) As XmlDocument

            Dim strResult As String = ""
            Dim objDA As WSDataAccessGeneric
            objDA = New WSDataAccessGeneric(strRegionId)
            Dim xmlDoc As XmlDocument
            Try

                strResult = objDA.usp_GetRMICWProfile(strRegionId, strAcctNum, strInpType, strOrg, strEnvironment)
                xmlDoc = New XmlDocument
                xmlDoc.LoadXml(strResult)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getRMICWProfile", ex.ToString())

            End Try
            Return xmlDoc

        End Function
#End Region

#Region "get SSP PROFILE  - uses SSP Info"
        <WebMethod(Description:="Get SSP Profile Test")>
        Public Function getSSPPROFILETest(ByVal strAcctnum As String, ByVal strRegionId As String, ByVal strProfileCAN As String) As XmlDocument

            Dim xmlProfileDoc As XmlDocument = New XmlDocument

            Try
                Dim wsM As WSMain = New WSMain
                xmlProfileDoc = wsM.getSSPPROFILE(strAcctnum, strRegionId, strProfileCAN)

            Catch exprofile As Exception
                LogErrorFile.WriteLog("RMICWWebServices-getSSPPROFILETest", exprofile.ToString())

            End Try

            Return xmlProfileDoc
        End Function
#End Region

#Region "DTV Request"

        <WebMethod(Description:="Affliate Notification Request")>
        Public Function AffliateNotification(ByVal strAcctnum As String, ByVal strDAN As String, ByVal strActn As String, ByVal strRegionId As String) As AffiliateResponse
            'Public Function IssueDTVRequest(ByVal strRegionId As String, ByVal intRequestId As String, ByVal strAcctNum As String, ByVal strOrg As String, ByVal strActn As String, ByVal strDestSystem As String, ByVal strStatusCd As String, ByVal strOriginationId As String, ByVal strReturnCd As String, ByVal strNotationCd As String, ByVal strEnvironment As String, ByVal strUpdtId As String, ByVal strResultId As String, ByVal strResultDesc As String) As DTVResponse
            'test
            Dim blnSucess As Boolean = False
            Dim strvalue As String = ""
            Dim xmlDoc As XmlDocument
            'Dim strXmlDoc As String

            Dim objDTVResponse As AffiliateResponse = New AffiliateResponse
            Dim objDataLay As AffiliateNotification = New AffiliateNotification

            'Dim sReader As StringReader
            'Dim tReader As TextReader

            'sReader = New StringReader(strXmlDoc)
            'Dim xmlDTVResponseDeSer As XmlSerializer = New XmlSerializer(GetType(AffiliateNotification))
            'objDataLay = CType(xmlDTVResponseDeSer.Deserialize(sReader), AffiliateNotification)

            objDataLay.strRegionId = strRegionId
            objDataLay.strAcctNum = strAcctnum
            objDataLay.strDTVAcctNum = strDAN
            objDataLay.strDTVActn = strActn

            Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(objDataLay.strRegionId)

            strvalue = ObjDataAccess.usp_GetControlParmByName(objDataLay.strRegionId, "DTVEnable")

            If strvalue.ToUpper().Trim() = "TRUE" Then

                Dim ObjReq As DTVWebservices = New DTVWebservices(objDataLay.strRegionId.Trim)

                Try
                    'objReqDTVSuspend.SendDTVRequest(strRegionId, intRequestId, strAcctNum, strOrg, strActn, strDestSystem, strStatusCd, strOriginationId, strReturnCd, strNotationCd, strEnvironment, strUpdtId, strResultId, strResultDesc)
                    ObjReq.SendAffiliateNotification(objDataLay)

                Catch ex As Exception
                    LogErrorFile.WriteLog("RMICWWS- DTVInterface", ex.ToString())
                End Try

                Return objDTVResponse
            Else
                LogErrorFile.WriteLog("RMICWWS- DTVInterface", "Not Calling DTV - Chk Controlparm")
            End If

        End Function
#End Region

#Region "Webservice to call Arbor webservice"
        <WebMethod(Description:="Get Balance Information from Arbor")>
        Public Function Get_Arbor_BalanceInfo(ByVal strAcctnum As String) As ARBOR_TRX_RESPONSE
            Dim objGetBal As New ArborWebservices
            Dim objResponse As ARBOR_TRX_RESPONSE
            objResponse = objGetBal.PostArborValues(strAcctnum)
            Return objResponse
        End Function
#End Region

#Region "Webservice to call iFinals webservice"
        <WebMethod(Description:="Get BTNFTIN Information from iFinals Test Method")>
        Public Function GetFinalAccountsForBTNTest(ByVal strBTNNum As String, ByVal strRegionCd As String) As XmlDocument

            Dim wsM As WSMain = New WSMain
            Dim iFinalsResponseXml As XmlDocument = New XmlDocument
            Try
                iFinalsResponseXml = wsM.GetFinalAccountsForBTN(strBTNNum, strRegionCd)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-GetFinalAccountsForBTNTest:strBTNNum/strRegionCd:" + strBTNNum + "/" + strRegionCd, ex.ToString())

            End Try

            Return iFinalsResponseXml

        End Function
#End Region

        <WebMethod(Description:="Affliate Notification Request to Wireless")>
        Public Function NotifyWirelessTest(ByVal strXmlDoc As String) As String
            'input xml
            'http://gsb6.north.vzwcorp.com/globalRouter/GlobalRouterCommonGateway?xmlreqdoc=<service><serviceHeader><billingSys></billingSys><clientId>VSO-RECVABLMGMT</clientId><userId>VSORMICW</userId><password>June2009</password><serviceName>hotlineMaintenance</serviceName></serviceHeader><serviceBody><serviceRequest><subServiceName>addHotline</subServiceName><accountNo>302269322-1</accountNo><landlineTelephoneNumber>2156389277581</landlineTelephoneNumber></serviceRequest></serviceBody></service>

            'Dim objXML As XmlDocument = New XmlDocument
            'objXML.LoadXml(strXmlDoc)

            Dim HRequest As HttpWebRequest = Nothing
            Dim strResponse As String = ""
            Dim strUserid As String = "VSORMICW"
            Dim strpwd As String = "June2009"
            Dim strRequestUri As String = "http://gsb6.north.vzwcorp.com/globalRouter/GlobalRouterCommonGateway?"
            'Dim strRequestUri As String = "http://gsb2.north.vzwcorp.com/globalRouter/GlobalRouterCommonGateway?"
            Try
                Dim authBytes As Byte() = System.Text.Encoding.UTF8.GetBytes(strUserid + ":" + strpwd.ToCharArray())
                'Dim inputbyte As Byte() = System.Text.Encoding.UTF8.GetBytes(strXmlDoc)
                'Dim inputbyte As Byte() = System.Text.Encoding.ASCII.GetBytes(objXML.InnerXml.ToString())
                Dim inputbyte As Byte() = System.Text.Encoding.ASCII.GetBytes(HttpUtility.HtmlEncode(strXmlDoc))

                ' set a default CertificatePolicy that accepts ALL Server certificates
                ServicePointManager.ServerCertificateValidationCallback = New Net.Security.RemoteCertificateValidationCallback(AddressOf VZWPolicy.ValidateServerCertificate)

                HRequest = CType(WebRequest.Create(strRequestUri), HttpWebRequest)
                'HRequest.Headers.Set("Pragma", "no-cache")
                'HRequest.Headers("Authorization") = "Basic " + Convert.ToBase64String(authBytes)

                HRequest.Headers.Add(HttpRequestHeader.Authorization, "Basic " + Convert.ToBase64String(authBytes))
                'HRequest.Headers("Authorization") = "Basic " + Convert.ToBase64String(authBytes)

                HRequest.KeepAlive = False
                HRequest.Method = "POST"
                HRequest.Accept = "application/soap+xml, application/dime, multipart/related, text/*"
                HRequest.ContentType = "text/xml;charset=\""ISO-8859-1\"""
                HRequest.ContentLength = strXmlDoc.Length
                HRequest.Timeout = 90000
                HRequest.ConnectionGroupName = Guid.NewGuid.ToString()

                Dim Swriter As System.IO.Stream
                Swriter = HRequest.GetRequestStream()
                HtmlEncodeSwriter(strXmlDoc, inputbyte, Swriter)
                Dim Wresponse As WebResponse = Nothing
                Wresponse = HRequest.GetResponse()
                With (Wresponse)
                    Dim Sreader As New StreamReader(Wresponse.GetResponseStream())
                    With (Sreader)
                        strResponse = Sreader.ReadToEnd()
                        Sreader.Close()
                    End With
                End With
                Swriter.Flush()
                Swriter.Close()
            Catch ex As Exception
                If (Not IsNothing(HRequest)) Then
                    HRequest = Nothing
                    Throw ex
                End If
            Finally
            End Try
            Return strResponse
        End Function

        Private Shared Sub HtmlEncodeSwriter(strXmlDoc As String, inputbyte() As Byte, Swriter As Stream)
            Swriter.Write(Text.Encoding.ASCII.GetBytes(HttpUtility.JavaScriptStringEncode(strXmlDoc)), 0, inputbyte.Length)
        End Sub

        Private Shared Function GetInputbyte(inputbyte() As Byte) As Byte()
            Return inputbyte
        End Function

#Region "Webservice to call NSOP webservice to pull the Pending order by Acct"
        <WebMethod(Description:="To Pull the Pending Order Status From Nsop - NPD")>
        Public Function CallGetOrderListByTN(ByVal strAcctnum As String) As String
            Dim bSuccess As Boolean
            Dim StrResult As String
            Dim strInputXML As String
            Dim objgetNsop As New Verizon.RMICW.WebServices.getNSOP
            strInputXML = objgetNsop.fn_loadInputxml(strAcctnum)

            'Set ITW credentials
            Dim objRef As NsopWebService.NSOPWebService = New NsopWebService.NSOPWebService
            Dim RequestContext As SoapContext
            RequestContext = objRef.RequestSoapContext
            objRef.Proxy = New WebProxy
            RequestContext.Security.Tokens.Clear()
            Dim unt As Tokens.UsernameToken = New Tokens.UsernameToken("RMW", "rmicw05", Tokens.PasswordOption.SendPlainText)
            RequestContext.Security.Tokens.Add(unt)
            RequestContext.Security.MustUnderstand = False
            StrResult = objRef.GetOrderListByTN(strInputXML, bSuccess)
            Return StrResult

        End Function
#End Region

#Region "Get Child account by Parent CAN - uses uCSR GetChildAccountByParentCANTest"

        <WebMethod(Description:="Get info from uCSR/GetChildAccountByParentCANTest")>
        Public Function GetChildAccountByParentCANTest(ByVal strInputValue As String, ByVal strInputType As String, ByVal strRegionId As String) As UCSRNACR.GetChildAccountByParentCANResponse


            Dim objResponse As Response = New Response
            Dim strXML As String = ""
            Dim xmlSer As XmlSerializer = New XmlSerializer(GetType(Response))
            strXML = CommonLibrary.GeneralRoutine.SerializeTxn(xmlSer, objResponse)
            Dim xmlDeSer As XmlSerializer = New XmlSerializer(GetType(UCSRNACR.GetChildAccountByParentCANResponse))
            'Dim xmlR As New StreamReader("C:\Test1.xml")
            Dim objGetChildAccountByParentCANResponse As UCSRNACR.GetChildAccountByParentCANResponse = New UCSRNACR.GetChildAccountByParentCANResponse()
            Dim objUCSRNACR As UCSRNACR.NACRGAR = New UCSRNACR.NACRGAR
            Dim objMessage As UCSRNACR.GetChildAccountByParentCANMessage = New UCSRNACR.GetChildAccountByParentCANMessage
            Dim objBROADBAND As UCSRNACR.GetChildAccountByParentCANResponse = New UCSRNACR.GetChildAccountByParentCANResponse

            Try

                Dim objUCSRAccess As UCSRAccess = New UCSRAccess(strRegionId)
                Dim objGetChildAccountByParentCANRequest As UCSRNACR.GetChildAccountByParentCANRequest = New UCSRNACR.GetChildAccountByParentCANRequest
                objGetChildAccountByParentCANResponse = objUCSRAccess.GetChildAccountByParentCAN(strInputValue, strInputType, strRegionId)
                'objGetChildAccountByParentCANResponse = CType(xmlDeSer.Deserialize(xmlR), UCSRNACR.GetChildAccountByParentCANResponse)
                Dim objBroadbandCAN As UCSRNACR.ResultsBroadbandCAN = New UCSRNACR.ResultsBroadbandCAN

                'Dim str As String = ""
                'If Not objBroadbandCAN.Value Is Nothing Then
                '    For Each objBroadbandCAN In objGetChildAccountByParentCANResponse.Results.ParentCAN.BroadbandCAN
                '        str = objBroadbandCAN.Value
                '    Next
                'End If
                'xmlR.Close()

                'Dim xmlDeSer As XmlSerializer = New XmlSerializer(GetType(UCSRNACR.GetChildAccountByParentCANResponse))
                'objGetChildAccountByParentCANResponse = xmlDeSer.Deserialize(New StringReader(xmlR.Read().ToString()))
                'xmlR.Close()

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-GetChildAccountByParentCAN", ex.ToString())
                'xmlR.Close()

            End Try
            Return objGetChildAccountByParentCANResponse
        End Function
#End Region

#Region "Get Multi Broadband Billing one LEC account - uses uCSR GetMultiBroadbandBillingOneLEC"

        <WebMethod(Description:="Get info from uCSR/GetMultiBroadbandBillingOneLECTest")>
        Public Function GetMultiBroadbandBillingOneLECTest(ByVal strInputValue As String, ByVal strEastWestInd As String, ByVal strSystemId As String, ByVal strRegionId As String) As UCSRNACR.GetMultiBroadbandBillingOneLECResponse

            Dim objResponse As Response = New Response
            Dim strXML As String = ""
            Dim xmlSer As XmlSerializer = New XmlSerializer(GetType(Response))
            strXML = CommonLibrary.GeneralRoutine.SerializeTxn(xmlSer, objResponse)
            Dim xmlDeSer As XmlSerializer = New XmlSerializer(GetType(UCSRNACR.GetMultiBroadbandBillingOneLECResponse))
            'Dim xmlR As New StreamReader("C:\Test1.xml")

            Dim objGetMultiBroadbandBillingOneLECResponse As UCSRNACR.GetMultiBroadbandBillingOneLECResponse = New UCSRNACR.GetMultiBroadbandBillingOneLECResponse()
            Dim objUCSRNACR As UCSRNACR.NACRGAR = New UCSRNACR.NACRGAR
            Dim objMessage As UCSRNACR.GetMultiBroadbandBillingOneLECMessage = New UCSRNACR.GetMultiBroadbandBillingOneLECMessage
            Dim objBROADBAND As UCSRNACR.GetMultiBroadbandBillingOneLECResponse = New UCSRNACR.GetMultiBroadbandBillingOneLECResponse

            Try

                Dim objUCSRAccess As UCSRAccess = New UCSRAccess(strRegionId)
                Dim objGetMultiBroadbandBillingOneLECRequest As UCSRNACR.GetMultiBroadbandBillingOneLECRequest = New UCSRNACR.GetMultiBroadbandBillingOneLECRequest
                objGetMultiBroadbandBillingOneLECResponse = objUCSRAccess.GetMultiBroadbandBillingOneLEC(strInputValue, strEastWestInd, strSystemId, strRegionId)
                'objGetChildAccountByParentCANResponse = CType(xmlDeSer.Deserialize(xmlR), UCSRNACR.GetChildAccountByParentCANResponse)
                Dim objBroadbandCAN As UCSRNACR.ResultsBroadbandCAN = New UCSRNACR.ResultsBroadbandCAN

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-GetMultiBroadbandBillingOneLEC", ex.ToString())
                'xmlR.Close()

            End Try
            Return objGetMultiBroadbandBillingOneLECResponse
        End Function
#End Region

#Region "Treatment Status SBM Test Webmethod"

        <WebMethod(Description:="Get Treatment Status For SBM")>
        Public Function getTreatmentStatusForSBMTest(ByVal strRegionId As String, ByVal strAcctNum As String, ByVal strOrg As String, ByVal strRshipCode As String) As TS_ResponseForSBM
            Dim obj As TreatmentStatus = New TreatmentStatus(strRegionId.Trim)
            Return obj.getTreatmentStatusForSBM(strRegionId, strAcctNum, strOrg, strRshipCode)
        End Function

#End Region

#Region "get Vose Order Response"

        <WebMethod(Description:="get VOSE Order Response")>
        Public Function getVoseOrderResponsetest(ByVal AppId As String, ByVal Track As String, ByVal RequestId As Long, ByVal AcctNum As String, ByVal BTN As String, ByVal NewAcctNum As String, ByVal Action As String, ByVal InputOrderNum As String, ByVal curTotAmtDue As Double, ByVal OrderNum As String, ByVal OrderType As String, ByVal LastActionDate As Date, ByVal Region As String, ByVal NotationCode As String, ByVal NumLines As Integer, ByVal MessageID As String, ByVal MessageDesc As String, ByVal PendingOrderDueDate As String, ByVal StatusCd As String, ByVal OrderSubmitTs As String) As RMICWMessage

            Dim strRegionId As String = "WEST"
            Dim sw As New StringWriter
            'Dim strvoseResponseXML As String

            Dim objRMICWMessage As RMICWMessage = New RMICWMessage()

            Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(strRegionId.Trim())
            Dim objwsMain As WSMain = New WSMain()
            Dim objVOSEOrderResponse As VOSEOrderResponse = New VOSEOrderResponse()
            objVOSEOrderResponse.AppID = AppId
            objVOSEOrderResponse.TrackingNo = Track
            objVOSEOrderResponse.RmicwRequestId = RequestId
            objVOSEOrderResponse.AcctNum = AcctNum
            objVOSEOrderResponse.BTN = BTN
            objVOSEOrderResponse.NewAcctNum = NewAcctNum
            objVOSEOrderResponse.Action = Action
            objVOSEOrderResponse.InputOrderNum = InputOrderNum
            objVOSEOrderResponse.CurTotalAmountDue = curTotAmtDue
            objVOSEOrderResponse.OrderNumber = OrderNum
            objVOSEOrderResponse.OrderType = OrderType
            objVOSEOrderResponse.LastActionDate = LastActionDate
            objVOSEOrderResponse.Region = VZWestOrderRegionsType.S
            objVOSEOrderResponse.NotationCode = NotationCode
            objVOSEOrderResponse.NumLines = NumLines
            objVOSEOrderResponse.MessageID = MessageDesc
            objVOSEOrderResponse.MessageID = MessageID
            objVOSEOrderResponse.PendingOrderDueDate = PendingOrderDueDate
            objVOSEOrderResponse.StatusCd = StatusCd
            objVOSEOrderResponse.OrderSubmitTs = OrderSubmitTs

            Try
                '   Dim ser As New XmlSerializer(objVOSEOrderResponse.GetType)
                '  ser.Serialize(sw, objVOSEOrderResponse)
                ' strvoseResponseXML = sw.ToString().Trim()

                objwsMain.getVoseOrderResponse(objVOSEOrderResponse)
                'ObjDataAccess.usp_UpdateVOSEServiceOrderResults(strvoseResponseXML)
                objRMICWMessage.messageDesc = "SUCCESS"
                objRMICWMessage.messageCode = "RMW000"
                ' objRMICWMessage.messageTrackingNumber = objVOSEOrderResponse.TrackingNo

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getOrderDetails", ex.ToString())
                objRMICWMessage.messageDesc = "FAILURE"
                objRMICWMessage.messageCode = "RMW100"
                'objRMICWMessage.messageTrackingNumber = objVOSEOrderResponse.TrackingNo

            End Try

            Return objRMICWMessage
        End Function
#End Region

#Region "STRATA REAL TIME NOTIFICATION TEST"
        <WebMethod(Description:="GET STRATA REAL TIME NOTIFICATION TEST")>
        Public Function GetStrataRealTimeNotificationTest(ByVal strAcctNum As String, ByVal StrataRealTimeNotification As StrataRealTimeNotification, ByVal strRegionId As String) As XmlDocument

            Dim objRMICWMessage As RMICWMessage = New RMICWMessage()
            Dim objStrataRealTimeNotification As StrataRealTimeNotification = New StrataRealTimeNotification()

            Dim xmlSer As XmlSerializer = New XmlSerializer(GetType(StrataRealTimeNotification))
            Dim xmlDoc As XmlDocument = New XmlDocument
            Try
                Dim strStrataOutcome As String = ""

                strStrataOutcome = CommonLibrary.GeneralRoutine.SerializeTxn(xmlSer, StrataRealTimeNotification)

                xmlDoc.LoadXml(strStrataOutcome)

                xmlDoc.LoadXml(System.Text.RegularExpressions.Regex.Replace(xmlDoc.OuterXml, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline)))

            Catch ex As Exception
                LogErrorFile.WriteLog("STRATAREALTIMENOTIFICATION", strAcctNum + ex.ToString())

            End Try

            Return xmlDoc

        End Function
#End Region
#Region "get OrderDetailsTest"

        <WebMethod(Description:="Get Order Details Test From Ext Apps -VOSE")>
        Public Function GetOrderDetailsTest(ByVal strRegionCd As String, ByVal strMsgName As String, ByVal intRequestId As Long, ByVal strAcctnum As String, ByVal strMon As String, ByVal strEvent As String, ByVal dtmOrderDueDate As String, ByVal dtmEventDate As String) As RMICWMessage

            Dim objOrderDetails As OrderDetailsOrder = New OrderDetailsOrder()
            Dim objOrderDetailsMessage As OrderDetailsOrder = New OrderDetailsOrder()
            Dim strRegionId As String = "WEST"
            Dim objRMICWMessage As RMICWMessage = New RMICWMessage()

            Dim objwsMain As WSMain = New WSMain()

            Try

                objOrderDetails.AccountNum = strAcctnum
                objOrderDetails.MessageName = strMsgName
                objOrderDetails.RequestId = intRequestId
                objOrderDetails.MONId = strMon
                objOrderDetails.OrderEvent = strEvent
                objOrderDetails.OrderDueDate = dtmOrderDueDate
                objOrderDetails.OrderEventDateTime = dtmEventDate
                Dim objOrders As OrderDetails = New OrderDetails()
                objOrders.Orders = objOrderDetails

                objwsMain.GetOrderDetails(objOrders)
                objRMICWMessage.messageDesc = "SUCCESS"
                objRMICWMessage.messageCode = "RMW000"
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getOrderDetails", ex.ToString())
                objRMICWMessage.messageDesc = "FAILURE"
                objRMICWMessage.messageCode = "RMW100"
            End Try

            Return objRMICWMessage
        End Function
#End Region

#Region "get FIOS Info - uses FIOS Info"
        <WebMethod(Description:="Get info from uCSR For FIOS Test")>
        Public Function getMONTest(ByVal intRequestId As String, ByVal strAcctnum As String, ByVal strRegionId As String, ByVal strOrg As String, ByVal strState As String, ByVal strCity As String) As String

            Dim objSSPRp As sspResponseDetails = New sspResponseDetails
            Dim objclsCOGsvcs As clsCOGsvcs = New clsCOGsvcs()
            Dim strMon As String = ""

            Try
                Dim wsM As WSMain = New WSMain
                Dim objSSPRqst As SSPRequestDetails = New SSPRequestDetails()

                objSSPRqst.intRequestId = intRequestId
                objSSPRqst.strAcctNum = strAcctnum
                objSSPRqst.strRegionId = strRegionId
                objSSPRqst.strOrg = strOrg
                objSSPRqst.AccountDetails.strAddState = strState
                objSSPRqst.AccountDetails.strAddCity = strCity

                strMon = objclsCOGsvcs.fnInvokeCOGWest(objSSPRqst)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWebServices", ex.ToString())
                strMon = ""
            End Try
            Return strMon
        End Function
#End Region

#Region "get FIOS Info - uses FIOS Info"
        <WebMethod(Description:="Get Account Relationship info from SSPNACR For FIOS Test")>
        Public Function GetAcctRelation_SSPNACR(ByVal strAccountnum As String, ByVal strRegionid As String, ByVal strIdentifier As String, ByVal strIntRequestid As String) As XmlDocument
            Dim objUCSRAccess As UCSRAccess = New UCSRAccess(strRegionid)
            Dim objRetrieveRes As RetrievalServiceResponse = New RetrievalServiceResponse
            objRetrieveRes = objUCSRAccess.fnGetAccountRelation_SSPNACR(strAccountnum, strRegionid, strIdentifier, strIntRequestid)

            'Serialize and return in the form of XML as it is TEST method - for Testing/Validation purpose.
            Dim xmlSer As XmlSerializer = New XmlSerializer(GetType(RetrievalServiceResponse))
            Dim strSSPNACRResxml As String = CommonLibrary.GeneralRoutine.SerializeTxn(xmlSer, objRetrieveRes)
            Dim xmldoc As New XmlDocument

            xmldoc.LoadXml(strSSPNACRResxml)

            Return xmldoc
        End Function
#End Region

#Region "get SSP PROFILE LINQ"
        <WebMethod(Description:="Get SSP Profile LINQ")>
        Public Function getSSPPROFILE_LINQ(ByVal strAcctnum As String, ByVal strRegionId As String, ByVal strProfileCAN As String) As XmlDocument

            Dim xmlProfileDoc As XmlDocument = New XmlDocument

            Dim objRes As SSPProfile.RetrievalServiceResponse = New SSPProfile.RetrievalServiceResponse()

            Dim xdoc As XDocument
            Dim xmldoc As XmlDocument = New XmlDocument
            Dim xRoot As XmlRootAttribute = New XmlRootAttribute()
            xRoot.ElementName = "RetrievalServiceResponse"
            xRoot.IsNullable = True

            Try
                Dim wsM As WSMain = New WSMain
                xmlProfileDoc = wsM.getSSPPROFILE(strAcctnum, strRegionId, strProfileCAN)

                Dim xmlSSPResponseDeSer As XmlSerializer = New XmlSerializer(GetType(SSPProfile.RetrievalServiceResponse), xRoot)
                objRes = CType(xmlSSPResponseDeSer.Deserialize(New StringReader(xmlProfileDoc.OuterXml)), SSPProfile.RetrievalServiceResponse)

                Dim objStatus As GetAccountRelationResponse_NACRNEWService.oneErrorReportStatus = New GetAccountRelationResponse_NACRNEWService.oneErrorReportStatus()
                'Dim objRetrievalAccepted As SSPProfile_RetrievalServiceResponse.RetrievalServiceResponseRetrievalAcceptedService

                'Dim objXdoc = XDocument.Parse(xmlProfileDoc.InnerXml)
                'Dim objEle = From

                Dim objSSPRqst As New SSPRequestDetails
                Dim objSubType As New SSPRequestDetails.SSPRequestDetailsSubType
                Dim query As Object
                Dim objResponseInfo As SSPProfile.RetrievalServiceResponseResponseInfo = New SSPProfile.RetrievalServiceResponseResponseInfo
                Dim objAccepted As SSPProfile.RetrievalServiceResponseRetrievalAccepted = New SSPProfile.RetrievalServiceResponseRetrievalAccepted()
                ' Dim objService As SSPProfile.RetrievalServiceResponseRetrievalAcceptedService = New SSPProfile.RetrievalServiceResponseRetrievalAcceptedService()
                query = From objRetrievalAccepted As SSPProfile.RetrievalServiceResponseRetrievalAccepted In objRes.RetrievalAccepted Select objRetrievalAccepted
                For Each objAccepted In query
                    If objAccepted.Service.Length > 0 Then
                        For Each objService As SSPProfile.RetrievalServiceResponseRetrievalAcceptedService In objAccepted.Service

                            If Not objService.BBEService Is Nothing Then
                                objSubType.strServiceName = "BBE"
                                objSubType.strServiceId = objService.serviceId
                                objSubType.strCircuitId = "" 'No Circuit id for BBE Service
                                objSubType.strServiceStatus = ""
                            End If

                            If Not objService.FiosVoice Is Nothing Then
                                objSubType.strServiceName = "VOICE"
                                objSubType.strServiceId = objService.serviceId
                                objSubType.strCircuitId = ""
                            End If

                            If Not objService.FiberService Is Nothing Then
                                objSubType.strServiceName = "DATA"
                                objSubType.strServiceId = objService.serviceId
                                objSubType.strCircuitId = ""
                            End If

                            If Not objService.FiberService Is Nothing Then
                                objSubType.strServiceName = "FIBER"
                                objSubType.strServiceId = objService.serviceId
                                objSubType.strCircuitId = ""
                            End If

                            If Not objService.VideoService Is Nothing Then
                                objSubType.strServiceName = "VIDEO"
                                objSubType.strServiceId = objService.serviceId
                                objSubType.strCircuitId = ""
                            End If

                            If Not objService.serviceName Is Nothing Then
                                Select Case objService.serviceName.ToUpper()
                                    Case "VIDEO"
                                        '                                        objSubType.strServiceName = Not objService.serviceName is  Nothing ? objService.serviceName : "Video"
                                    Case "VOICE"
                                    Case "FIBER"
                                    Case "DATA"
                                    Case "DIALUP"
                                    Case "DSL"
                                    Case "BDV"
                                    Case "THUNDER"
                                    Case "VASIP"
                                    Case "CAOFFER"
                                    Case "RETAIN"
                                    Case "DNR"
                                    Case "DNE"
                                    Case "FVIDEOENDUSER"
                                    Case "FVIDEOCDSENDUSER"
                                End Select
                            End If

                        Next

                    End If

                Next

            Catch exprofile As Exception
                LogErrorFile.WriteLog("RMICWWebServices-getSSPPROFILETest", exprofile.ToString())

            End Try

            Return xmlProfileDoc
        End Function
#End Region

    End Class

End Namespace