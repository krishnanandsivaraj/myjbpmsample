Option Strict Off
Option Explicit On
Imports System
Imports System.Net
Imports System.Collections
Imports System.Text
Imports System.Security
Imports System.IO
Imports CommonLibrary
Imports System.Xml.Serialization
Imports System.Xml
Imports DTVService1
Imports Verizon.RMICW.DataAccess
Imports System.Data
Imports System.DateTime
Imports System.Security.Cryptography.X509Certificates
Imports System.Text.RegularExpressions

Namespace Verizon.RMICW.WebServices
    Public Class VZWWebservices
        Inherits RMICWWSBase
        Public Sub New(ByVal strRegionId As String)
            MyBase.New(strRegionId)
        End Sub
        Public Interface ICertificatePolicy
        End Interface
        Public Class VZWPolicy
            Implements ICertificatePolicy
            Public Shared Function ValidateServerCertificate(ByVal sender As Object, ByVal certificate As X509Certificate, ByVal chain As X509Chain, ByVal sslPolicyErrors As Net.Security.SslPolicyErrors) As Boolean
                Return True
            End Function
        End Class
        Public Function SendAffiliateNotification(ByVal objVZWRqst As AffiliateNotification) As VZWResponse
            LogErrorFile.WriteLog("RMICWWS-VZW", "SendAffiliateNotification called")
            Dim objVZWResponse As New VZWResponse
            Dim strBillingSystem As String = "" ' To Be confirmed that would it be changed based on Region?
            Dim strsubServiceName As String = ""
            Dim strAcctnum As String = ""
            Dim strLandlineTNNbr As String = ""
            Dim strRequestxml As String = ""
            Dim strParmValue As String = ""
            Dim arrValArr As Array
            Dim strRequestUri As String = ""
            Dim struserid As String = ""
            Dim strpwd As String = ""
            Dim strResponseXml As String = ""
            Dim xmlDoc As XmlDocument
            Dim xmlEle As XmlElement
            Dim strStatusCd As String = ""
            Dim strErrorCd As String = ""
            Dim strErrorMsg As String = ""

            Dim objDA As WSDataAccessGeneric = New WSDataAccessGeneric(objVZWRqst.strRegionId)
            Try

                If objVZWRqst.strVZWAcctNum = "" Then
                    objVZWRqst.strResultDesc = "NO VZWActno Found"
                    objVZWRqst.strErrorCd = "NO-WAN"
                    objVZWRqst.strStatusCd = "VD"

                    objVZWResponse.serviceHeader.errorCode = objVZWRqst.strErrorCd.Trim()
                    objVZWResponse.serviceHeader.statusCode = objVZWRqst.strStatusCd.Trim()
                    objVZWResponse.serviceBody.serviceRequest.accountNo = objVZWRqst.strAcctNum.Trim()
                    objVZWResponse.serviceHeader.errorMsg = "NO VZWActno Found"

                    LogErrorFile.WriteLog("RMICWWS-VZW", "NO VZWActno Found - exiting")

                    UpdateVZWResponse(objVZWRqst, "")
                    Return objVZWResponse

                End If

                If (objVZWRqst.strOrg.StartsWith("WV")) Then   'SSR 01OCT09
                    Select Case objVZWRqst.strActn.Trim()
                        Case "RN", "SN", "RTN", "MRN", "MRTN", "DN", "DTN", "MDN", "MDTN", "STN"
                            objVZWRqst.strResultDesc = "INVALID ORG ACTN"
                            objVZWRqst.strErrorCd = "INV-ACTN"
                            objVZWRqst.strStatusCd = "VD"

                            objVZWResponse.serviceHeader.errorCode = objVZWRqst.strErrorCd.Trim()
                            objVZWResponse.serviceHeader.statusCode = objVZWRqst.strStatusCd.Trim()
                            objVZWResponse.serviceBody.serviceRequest.accountNo = objVZWRqst.strAcctNum.Trim()
                            objVZWResponse.serviceHeader.errorMsg = "Invalid Org Action Combination"

                            LogErrorFile.WriteLog("RMICWWS-VZW", "Invalid Org Action Combination")

                            UpdateVZWResponse(objVZWRqst, "")
                            Return objVZWResponse
                    End Select
                End If


                Select Case objVZWRqst.strVZWActn.ToUpper().Trim() ' we would be getting Wirelessaction here.
                    Case "SVZW"
                        strsubServiceName = "addHotline"
                    Case "RVZW"
                        strsubServiceName = "removeHotline"
                End Select

                'Get the uri,userid,pwd from the tControlparm
                strParmValue = GetParmValues(objVZWRqst.strRegionId.Trim(), "VZWURL")
                LogErrorFile.WriteLog("RMICWWS-VZW", "tControlparm is True")
                arrValArr = Split(strParmValue, ";")
                strRequestUri = arrValArr(0)
                struserid = arrValArr(1)
                strpwd = arrValArr(2)
                strAcctnum = objVZWRqst.strVZWAcctNum.Trim.ToString()
                strLandlineTNNbr = objVZWRqst.strBTNNum.Trim.ToString()
                strRequestxml = "xmlreqdoc=<service><serviceHeader><billingSys>" + strBillingSystem + "</billingSys><clientId>VSO-RECVABLMGMT</clientId><userId>" + struserid + "</userId><password>" + strpwd + "</password><serviceName>hotlineMaintenance</serviceName></serviceHeader><serviceBody><serviceRequest><subServiceName>" + strsubServiceName + "</subServiceName><accountNo>" + strAcctnum + "</accountNo><landlineTelephoneNumber>" + strLandlineTNNbr + "</landlineTelephoneNumber></serviceRequest></serviceBody></service>"

                If strRequestxml Is Nothing Then
                    objVZWRqst.strErrorCd = "INVLDXML"
                    objVZWRqst.strStatusCd = "VD"

                    objVZWResponse.serviceHeader.errorCode = objVZWRqst.strErrorCd.Trim()
                    objVZWResponse.serviceHeader.statusCode = objVZWRqst.strStatusCd.Trim()
                    objVZWResponse.serviceBody.serviceRequest.accountNo = objVZWRqst.strAcctNum.Trim()
                    objVZWResponse.serviceHeader.errorMsg = "Invalid Input Xml"

                    LogErrorFile.WriteLog("RMICWWS-VZW Invalid XML", "Invalid")
                    Return objVZWResponse
                End If
                'HTTP POST call
                LogErrorFile.WriteLog("RMICWWS-VZW  ", "Calling Getresponse")
                strResponseXml = GetResponse(strRequestUri, strRequestxml, struserid, strpwd)

                'Parse the response
                Try
                    xmlDoc = New XmlDocument
                    xmlDoc.LoadXml(strResponseXml)
                    xmlEle = xmlDoc.DocumentElement

                    strStatusCd = xmlEle.GetElementsByTagName("statusCode", "*").Item(0).InnerXml()
                    strErrorCd = xmlEle.GetElementsByTagName("errorCode", "*").Item(0).InnerXml()
                    strErrorMsg = xmlEle.GetElementsByTagName("errorMsg", "*").Item(0).InnerXml()

                    'Handled in the usp '[usp_InsertAffiliateRequests]
                    'Select Case strErrorCd.Trim()
                    '    Case "00", "402", "887", "3815", "3808", "3809", "3813", "3810"
                    '        strStatusCd = "CP"

                    '    Case "3041", "1001", "8086", "8028", "4000", "3807", "3805"
                    '        strStatusCd = "VC"

                    '    Case "3806", "3804", "8008", "8212", "3811", "3812", "821", "3814", "329"
                    '        strStatusCd = "SE"
                    '    Case Else
                    '        strStatusCd = "SE" ' Can we make VC as default - confirm
                    'End Select

                    objVZWRqst.strStatusCd = strStatusCd.Trim()
                    objVZWRqst.strErrorCd = strErrorCd.Trim()
                    objVZWRqst.strResultDesc = strErrorMsg.Trim()

                Catch ex As Exception
                    LogErrorFile.WriteLog("RMICWWS - Wireless output parsing ", ex.ToString())
                    objVZWResponse.serviceHeader.errorMsg = ex.ToString()
                    objVZWResponse.serviceHeader.statusCode = "ER" ' ER refers Exception
                    objVZWResponse.serviceBody.serviceRequest.accountNo = objVZWRqst.strAcctNum.Trim()
                End Try

                'updating tAffiliatenotification table with Response
                UpdateVZWResponse(objVZWRqst, strResponseXml)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS - Wireless  Request", ex.ToString())
                objVZWResponse.serviceHeader.errorMsg = ex.ToString()
                objVZWResponse.serviceHeader.statusCode = "VC"
                objVZWResponse.serviceBody.serviceRequest.accountNo = objVZWRqst.strAcctNum.Trim()
                objVZWRqst.strExtendedParm = "true"
                objVZWRqst.strReturnCd = objVZWRqst.strExtendedParm.Trim()
                UpdateVZWResponse(objVZWRqst, strResponseXml)
            End Try

            'Logging input/output xml
            Try
                objDA.usp_InserttAuditLog("VZW", "I", objVZWRqst.strAcctNum.Trim(), objVZWRqst.strActn.Trim(), "NA", "NA", objVZWRqst.strVZWAcctNum, objVZWRqst.intRequestId, 0, strRequestxml.Trim(), "WebSvc")
                objDA.usp_InserttAuditLog("VZW", "O", objVZWRqst.strAcctNum.Trim(), objVZWRqst.strActn.Trim(), "NA", "NA", objVZWRqst.strVZWAcctNum, objVZWRqst.intRequestId, 1, strResponseXml.Trim(), "WebSvc")
            Catch exAudit As Exception
                LogErrorFile.WriteLog("RMICWWS-VZW", exAudit.ToString())
                objVZWResponse.serviceHeader.errorMsg = exAudit.ToString()
            End Try

                Return objVZWResponse
        End Function
        Public Function GetParmValues(ByVal strRegionID As String, ByVal strParmname As String) As String
            Dim strURL As String = ""
            Dim strCntl As String = "Control" + strRegionID.Trim()

            Dim WSDataAccessObj As WSDataAccessGeneric = New WSDataAccessGeneric(strRegionID.Trim())
            Try
                strURL = WSDataAccessObj.usp_GetControlParmByName(strCntl, strParmname.Trim())
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-VZW", "Unable to pull Wireless URL from tControlparm")
            End Try
            Return strURL
        End Function
        Public Function GetResponse(ByVal strRequestUri As String, ByVal strRequestXml As String, ByVal struserid As String, ByVal strpwd As String) As String
            Dim HRequest As HttpWebRequest = Nothing
            Dim strResponse As String = ""
            Try
                strRequestXml = strRequestXml.Replace(vbCrLf, "")
                Dim authBytes As Byte() = System.Text.Encoding.Unicode.GetBytes(struserid + ":" + strpwd.ToCharArray())
                Dim inputbyte As Byte() = System.Text.Encoding.UTF8.GetBytes(strRequestXml)

                ' set a default CertificatePolicy that accepts ALL Server certificates 
                ServicePointManager.ServerCertificateValidationCallback = New Net.Security.RemoteCertificateValidationCallback(AddressOf VZWPolicy.ValidateServerCertificate)

                HRequest = CType(WebRequest.Create(strRequestUri), HttpWebRequest)
                HRequest.Headers.Add("HTTP_Referer", "www.Verizon.com")
                HRequest.Headers.Set("Pragma", "no-cache")
                HRequest.Headers("Authorization") = "Basic " + Convert.ToBase64String(authBytes)
                HRequest.KeepAlive = False
                HRequest.Method = "POST"
                HRequest.Accept = "application/soap+xml, application/dime, multipart/related, text/*"
                HRequest.ContentType = "application/x-www-form-urlencoded"
                HRequest.ContentLength = strRequestXml.Length
                HRequest.Timeout = 90000
                HRequest.ConnectionGroupName = Guid.NewGuid.ToString()


                Dim Swriter As System.IO.Stream
                Swriter = HRequest.GetRequestStream()
                Swriter.Write(inputbyte, 0, inputbyte.Length)

                Dim Wresponse As WebResponse = Nothing
                Wresponse = HRequest.GetResponse()
                With (Wresponse)
                    Dim Sreader As New StreamReader(Wresponse.GetResponseStream())
                    With (Sreader)
                        strResponse = Sreader.ReadToEnd()
                        Sreader.Close()
                    End With
                End With
                Swriter.Flush()
                Swriter.Close()
            Catch ex As Exception
                If (Not IsNothing(HRequest)) Then
                    HRequest = Nothing
                    Throw ex
                End If
            Finally
            End Try
            Return strResponse
        End Function
        Public Function UpdateVZWResponse(ByVal objVZWRqst As AffiliateNotification, ByVal strResponseXML As String) As String
            ''update back to the tAffliateNotification Table
            strResponseXML = strResponseXML.Replace("UTF-8", "utf-16")

            Dim strMsgBody As String
            Dim objXmlSer As XmlSerializer
            objXmlSer = New XmlSerializer(GetType(CommonLibrary.AffiliateNotification))
            Dim strResponse As String
            Dim objAff As AffiliateNotification = New AffiliateNotification()
            Dim objDA As WSDataAccessGeneric = New WSDataAccessGeneric(objVZWRqst.strRegionId)

            '  Variable populated for update
            objAff.intRequestId = objVZWRqst.intRequestId
            objAff.intRetryCnt = objVZWRqst.intRetryCnt
            objAff.strAcctNum = objVZWRqst.strAcctNum.Trim()
            objAff.strActn = objVZWRqst.strActn.Trim()
            objAff.strBQTActn = objVZWRqst.strBQTActn.Trim()
            objAff.strBTNNum = objVZWRqst.strBTNNum.Trim()
            objAff.strDestSystem = "VZW" 'objDTVRqst.strDestSystem 'if Destination comes from sporc, then remove hardcoded.
            objAff.strVZWAcctNum = objVZWRqst.strVZWAcctNum.Trim()
            objAff.strVZWActn = objVZWRqst.strVZWActn.Trim()
            objAff.strEnvironment = objVZWRqst.strEnvironment.Trim()
            objAff.strErrorCd = objVZWRqst.strErrorCd.Trim()
            objAff.strExtendedParm = objVZWRqst.strExtendedParm.Trim()
            objAff.strLogonId = objVZWRqst.strLogonId.Trim()
            objAff.strNotationCd = objVZWRqst.strNotationCd.Trim()
            objAff.strOrg = objVZWRqst.strOrg.Trim()
            objAff.strOriginationId = objVZWRqst.strOriginationId.Trim()
            objAff.strRegionId = objVZWRqst.strRegionId.Trim()
            objAff.strResultDesc = objVZWRqst.strResultDesc.Trim()
            objAff.strStatusCd = objVZWRqst.strStatusCd.Trim()

            strMsgBody = CommonLibrary.GeneralRoutine.SerializeTxn(objXmlSer, objAff)
            Try
                objDA.usp_InsertAffiliateRequests(objVZWRqst.strRegionId, strMsgBody, objVZWRqst.strExtendedParm, strResponseXML)
                strResponse = ""
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-VZW-Update", ex.ToString())
                strResponse = ex.ToString()
            End Try

            LogErrorFile.WriteLog("RMICWWS-VZW Update", "updating aff notify")

            Return strResponse

        End Function
    End Class
End Namespace