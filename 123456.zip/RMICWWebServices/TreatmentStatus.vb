Imports CommonLibrary
Imports System.Xml
Imports System.Xml.Serialization
Imports System.IO
Imports CommonLibrary.SSPPAFullProfile
Imports System.Linq
Imports System.Xml.Linq
Imports System.Collections.Generic


Namespace Verizon.RMICW.WebServices





    Public Class AccountInfo

        Public strAcctNum As String
        Public strFTNNum As String
        Public strFTNStatus As String
        Public blnDenyStatusChangePending As Boolean
        Public strPendingRequest As String

        <System.Xml.Serialization.XmlElement(ElementName:="RequestList", Type:=GetType(RequestDetails))> _
        Public arrLstRequest As ArrayList
        Public TrtStatus As TS_Response



        Public RequestStatus As StatusOfRequest

        Public Sub New()
            strAcctNum = " "
            strFTNNum = " "
            strFTNStatus = " "
            arrLstRequest = New ArrayList
            RequestStatus = New StatusOfRequest

            blnDenyStatusChangePending = False
            strPendingRequest = " "

            TrtStatus = New TS_Response
            Dim objTSRespStatus As TS_Response.TS_Response_Status = New TS_Response.TS_Response_Status
            TrtStatus.ResponseStatus = objTSRespStatus

        End Sub

    End Class

    Public Class RequestDetails
        Public intRequestId As Long
        Public strAcctNum As String
        Public dtmRequestTs As DateTime
        Public strOrg As String
        Public strClass As String
        Public strActn As String
        Public strStatusCd As String
        Public strLogonId As String
        Public strOriginationId As String
        Public dtmRequestDueDt As DateTime
        Public strReturnCd As String
        Public strLongDesc As String
        Public strArchiveInd As String
        Public dtmPrcsdTs As DateTime
        Public strActnClsCd As String
        Public strDestSystem As String
        Public strActnDescription As String

    End Class
    Public Enum EnBucketName
        enBucketBasic
        enBucketNonBasic
        enBucketToll
        enBucketDA
        enBucketNonTelcom
        enBucketOCAR
        enBucketWRLS
        enBucketIP ' invoice points / internet provider charges /
        enBucketCPE  ' customer premesis equipment
        enBucketCurrentDue  '
    End Enum




    Public Class TreatmentStatus
        Inherits RMICWWSBase
        Public arrBucket() As String = {"Basic", "Non-Basic", "Toll", "OCAR", "NonTelecom", "DA"}
        Public Sub New(ByVal strRegionId As String)
            MyBase.New(strRegionId)
        End Sub
        Public Function getLiveFinalValueForAccNum(ByVal strAcctNum As String, ByVal strRegionID As String) As String

            Dim strActn As String = "ALL"
            Dim strTranType As String = "LF"
            Dim dsLF As DataSet
            'Dim dtLF As DataTable
            'Dim drLF As DataRow
            Dim strLFValue As String = Nothing
            Try
                dsLF = MyBase.WSDataAccessObj.usp_getTriadUpdateValue(strAcctNum, strActn, strTranType, strRegionID)

                If Not dsLF Is Nothing And dsLF.Tables(0).DefaultView.Count > 0 Then
                    strLFValue = dsLF.Tables(0).Rows(0)("TriadUpdateValue")
                    If UCase(strLFValue) = "NA" Then strLFValue = "00"
                End If

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS - getLiveFinalValueForAccNum", ex.ToString())
            End Try

            Return strLFValue

        End Function
#Region "getTreatmentStatus"
        Public Function getTreatmentStatus(ByVal Request As TS_Request) As TS_Response

            Dim objTSResp As TS_Response = New TS_Response
            Dim objTSStatusDesc As TS_Response.TS_Status_Description = New TS_Response.TS_Status_Description
            Dim objTSRespStatus As TS_Response.TS_Response_Status = New TS_Response.TS_Response_Status
            objTSResp.ResponseStatus = objTSRespStatus
            Dim objWSCommon As WSCommonClasses = New WSCommonClasses
            Dim arrLstStatus As ArrayList = New ArrayList
            Dim dsCA As DataSet
            Dim strLFvalue As String
            Dim strVacationInd As String = ""
            Dim objTSDesc As TS_Response.TS_Status_Description
            Dim blnSkip As Boolean = True

            Try
                objTSResp.strRegionId = Request.strRegionId
                objTSResp.strAcctNum = Request.strAcctNum
                objTSResp.strOCARBucketStatusInd = BucketStatus.NA
                objTSResp.strNonTelecomStatusInd = BucketStatus.NA
                objTSResp.strDAStatusInd = BucketStatus.NA



                'objTSResp.strCashOnlyInd = "Y"


                If (Not WSCommonClasses.CheckRegionType(Request.strRegionId.Trim)) Then
                    objTSRespStatus.strMessageId = "RMWTS001"
                    objTSRespStatus.strMessageDescription = "Invalid RegionId Specified"
                    Return objTSResp
                End If

                If (Request.strInputRequestType = "A" Or Request.strInputRequestType = "B") Then
                Else
                    objTSRespStatus.strMessageId = "RMWTS002"
                    objTSRespStatus.strMessageDescription = "Invalid Request Type."
                    Return objTSResp
                End If

                Dim dsTS As DataSet = MyBase.WSDataAccessObj.usp_GetTreatmentStatus(Request.strRegionId, Request.strInputRequestType, Request.strAcctNum, Request.strOrg, Request.strApplicationId)
                Dim dtTS As DataTable
                Dim drTS As DataRow
                Dim strValue As String

                If (MyBase.WSDataAccessObj.IsEmptyRecordSet(dsTS)) Then
                    objTSResp.Initialize(Request.strRegionId)
                    Return objTSResp
                End If

                'For Each dtTS In dsTS.Tables
                For i As Integer = 0 To dsTS.Tables.Count - 1
                    dtTS = dsTS.Tables(i)
                    For j As Integer = 0 To dtTS.Rows.Count - 1
                        'For Each drTS In dtTS.Rows
                        drTS = dtTS.Rows(j)
                        strValue = drTS("strCategoryCd")
                        Select Case strValue.Trim()
                            Case "B"
                                objTSResp.strBasicBucketStatusInd = objWSCommon.getBucketStatus(drTS("strTrtStatusDesc"), drTS("strActn"))

                            Case "T"
                                objTSResp.strTollBucketStatusInd = objWSCommon.getBucketStatus(drTS("strTrtStatusDesc"), drTS("strActn"))
                            Case "N"
                                objTSResp.strNonBasicBucketStatusInd = objWSCommon.getBucketStatus(drTS("strTrtStatusDesc"), drTS("strActn"))
                            Case "O"
                                'objTSResp.strOCARBucketStatusInd = objWSCommon.getBucketStatus(drTS("strTrtStatusDesc"), drTS("strActn"))
                                If Request.strRegionId = "MDVW" Then
                                    objTSResp.strNonTelecomStatusInd = objWSCommon.getBucketStatus(drTS("strTrtStatusDesc"), drTS("strActn"))
                                Else
                                    objTSResp.strOCARBucketStatusInd = objWSCommon.getBucketStatus(drTS("strTrtStatusDesc"), drTS("strActn"))
                                End If
                            Case "D"
                                objTSResp.strDAStatusInd = objWSCommon.getBucketStatus(drTS("strTrtStatusDesc"), drTS("strActn"))

                            Case "P"
                                objTSResp.strPPVStatusInd = objWSCommon.getBucketStatus(drTS("strTrtStatusDesc"), drTS("strActn"))
                        End Select

                        'Dim objTSDesc As TS_Response.TS_Status_Description = New TS_Response.TS_Status_Description
                        objTSDesc = New TS_Response.TS_Status_Description

                        objTSDesc.strBucketName = drTS("strCategoryDescription")
                        objTSDesc.strBucketStatusInd = objWSCommon.getBucketStatus(drTS("strTrtStatusDesc"), drTS("strActn"))
                        'Copper Migration VRU Changes override 'Denied-Migration' with 'LIVE' when Appid is VRU 

                        'If Request.strApplicationId.Trim().ToUpper() = "VRU" And (drTS("strTrtStatusDesc").ToString() = "Denied-Migration" Or drTS("strTrtStatusDesc").ToString().ToUpper() = "NT SUSPENSION") Then
                        If (drTS("strTrtStatusDesc").ToString().ToUpper().Trim() = "DENIED-MIGRATION" Or drTS("strTrtStatusDesc").ToString().ToUpper().Trim() = "NT SUSPENSION") Then 'SB-MS then basic status should be Live.
                            objTSDesc.strBucketStatusInd = BucketStatus.Live
                            objTSResp.strBasicBucketStatusInd = BucketStatus.Live
                        End If

                        If objTSDesc.strBucketStatusInd = BucketStatus.Denied Then

                            If (Request.strOrg.Trim() = "DC1" Or Request.strOrg.Trim() = "VA1" Or Request.strOrg.Trim() = "DE1" Or Request.strOrg.Trim() = "DE5") And strValue.Trim() = "B" Then
                                Dim dsBundleInfo As New DataSet()
                                Dim dtBundleInfo As DataTable
                                Dim drBundleInfo As DataRow
                                Dim strSPHandlingCd As String = ""
                                Dim strSPHandlingCdDesc As String = ""

                                objTSDesc.strBucketStatusDesc = drTS("strTrtStatusDesc")
                                dsBundleInfo = WSDataAccessObj.usp_GetBundleInfo(Request.strRegionId, Request.strAcctNum)
                                If MyBase.WSDataAccessObj.IsEmptyRecordSet(dsBundleInfo) Then
                                Else
                                    'If dsBundleInfo.Tables(0).Rows(0).Item(3).ToString().Trim() = "30" And dsBundleInfo.Tables(0).Rows(0).Item(4).ToString().ToUpper().Trim = "FREEDOM-FOUND" Then
                                    '    objTSDesc.strBucketStatusDesc = drTS("strTrtStatusDesc") + "(BUNDLE)"

                                    'Else
                                    '    objTSDesc.strBucketStatusDesc = drTS("strTrtStatusDesc")
                                    'End If

                                    For l As Integer = 0 To dsBundleInfo.Tables.Count - 1
                                        dtBundleInfo = dsBundleInfo.Tables(l)
                                        'For Each dtBundleInfo In dsBundleInfo.Tables
                                        For k As Integer = 0 To dtBundleInfo.Rows.Count - 1
                                            drBundleInfo = dtBundleInfo.Rows(k)
                                            'For Each drBundleInfo In dtBundleInfo.Rows
                                            strSPHandlingCd = drBundleInfo("strSPHandlingCd")
                                            strSPHandlingCdDesc = drBundleInfo("strSPHandlingCdDesc")
                                        Next
                                    Next

                                    If strSPHandlingCd.Trim() = "30" And dsBundleInfo.Tables(0).Rows(0)("strSPHandlingCdDesc").ToUpper().Trim = "FREEDOM-FOUND" Then
                                        objTSDesc.strBucketStatusDesc = drTS("strTrtStatusDesc") + "(BUNDLE)"
                                    ElseIf strSPHandlingCdDesc = "Y" Then
                                        objTSDesc.strBasicBundleInd = "Y"
                                        objTSDesc.strBucketStatusDesc = drTS("strTrtStatusDesc") + "(BUNDLE)"
                                    Else
                                        objTSDesc.strBucketStatusDesc = drTS("strTrtStatusDesc")
                                    End If

                                End If
                                ' Else
                                ' objTSDesc.strBucketStatusDesc = drTS("strTrtStatusDesc")
                                'End If
                                'ElseIf Request.strRegionId.Trim() = "NPD" And (Request.strOrg.Trim() = "DE1" Or Request.strOrg.Trim() = "DE5") And strValue.Trim() = "B" Then
                                '    Dim strFreedomInd As String
                                '    Dim dsGetFreedomInd As New DataSet()
                                '    objTSDesc.strBucketStatusDesc = drTS("strTrtStatusDesc")
                                '    dsGetFreedomInd = WSDataAccessObj.usp_GetTreatmentData(Request.strAcctNum, Request.strOrg, Request.strApplicationId, Request.strRegionId)
                                '    If MyBase.WSDataAccessObj.IsEmptyRecordSet(dsGetFreedomInd) Then
                                '    Else
                                '        If dsGetFreedomInd.Tables(0).Rows(0)("strFreedomPackageInd") = "Y" Then
                                '            objTSDesc.strBucketStatusDesc = drTS("strTrtStatusDesc") + "(BUNDLE)"
                                '            objTSDesc.strBasicBundleInd = "Y"

                                '        Else
                                '            objTSDesc.strBucketStatusDesc = drTS("strTrtStatusDesc")
                                '        End If
                                '    End If
                            Else
                                objTSDesc.strBucketStatusDesc = drTS("strTrtStatusDesc")
                            End If

                        Else
                            objTSDesc.strBucketStatusDesc = drTS("strTrtStatusDesc")
                        End If



                        '68132/68041 STRATA NY - To chk the bucket status - only for LIVE status we need VS ind - Bala
                        If (Request.strRegionId.ToUpper().Trim() = "NPD" Or Request.strRegionId.ToUpper().Trim() = "NY" Or Request.strRegionId.ToUpper().Trim() = "NE" Or Request.strRegionId.ToUpper().Trim() = "WEST") And objTSResp.strBasicBucketStatusInd = BucketStatus.Live Then

                            dsCA = MyBase.WSDataAccessObj.usp_GetCustomerAddressInfo(Request.strRegionId, Request.strAcctNum)
                            If Not (MyBase.WSDataAccessObj.IsEmptyRecordSet(dsCA)) Then
                                If (Not dsCA.Tables(0).Rows(0)("strBlockSnpInd") Is Nothing And Not dsCA.Tables(0).Rows(0)("strBlockSnpInd").Equals(DBNull.Value)) Then
                                    strVacationInd = dsCA.Tables(0).Rows(0)("strBlockSnpInd")
                                    'If strVacationInd.Trim() = "V" Then
                                    '    objTSResp.strBasicBucketStatusInd = BucketStatus.Denied
                                    'End If
                                End If
                            End If
                        End If

                        'objTSDesc.strBucketStatusInd = objWSCommon.getBucketStatus(drTS("strTrtStatusDesc"), drTS("strActn"))
                        'objTSDesc.strBucketStatusDesc = drTS("strTrtStatusDesc")
                        objTSDesc.strCategoryCd = drTS("strCategoryCd")
                        objTSDesc.dtmBeginDate = drTS("dtmBeginDate")


                        If (Not Request.strOrg Is Nothing) Then
                            If (Request.strOrg.Trim = "SC1") Then
                                If (objTSResp.strTollBucketStatusInd = BucketStatus.Denied) Then
                                    objTSDesc.strBucketStatusDesc = "Denied Lifeline/PostBill"
                                End If
                            End If
                        End If

                        '76588
                        If objTSDesc.strCategoryCd.ToUpper().Trim() = "P" Then
                            If objTSDesc.strBucketStatusDesc.ToUpper().Trim() = "COLLECTION DENIED" Then
                                objTSResp.strPPVStatusInd = objTSDesc.strBucketStatusDesc
                                blnSkip = True
                            Else
                                objTSResp.strPPVStatusInd = "NA" 'Changed as per siva . other than Denied status could be LIVE
                                'blnSkip = True  'Changed to add even status is other than Denied
                                blnSkip = False
                            End If
                            'If objTSResp.strPPVStatusInd = 0 Then 'Safer logic to set Ind to LIVE when it is not collection denied.
                            '    objTSResp.strPPVStatusInd = objTSDesc.strBucketStatusDesc
                            'End If
                        End If


                        'added referred/written off (ref/wo) logic
                        'if actn is BB2/BB4 and beginDate more than 60 days from today, overwrite status Terminated
                        'business rule: if acct is sitting in BB2/BB4 for longer than 60 days, it gets ref/wo.
                        'Dim strActnValue As String
                        'Dim dtmBeginDateValue As DateTime

                        'strActnValue = drTS("strActn")
                        'dtmBeginDateValue = drTS("dtmBeginDate")

                        'If strActnValue.Trim = "BB2" And DateDiff("d", dtmBeginDateValue, Today) > 60 Then
                        '    objTSResp.strTollBucketStatusInd = BucketStatus.Terminated
                        '    objTSDesc.strBucketStatusDesc = "Terminated"
                        '    objTSDesc.strBucketStatusInd = BucketStatus.Terminated
                        'End If

                        'If strActnValue.Trim = "BB4" And DateDiff("d", dtmBeginDateValue, Today) > 60 Then
                        '    objTSResp.strOCARBucketStatusInd = BucketStatus.Terminated
                        '    objTSDesc.strBucketStatusDesc = "Terminated"
                        '    objTSDesc.strBucketStatusInd = BucketStatus.Terminated
                        'End If

                        If (blnSkip) Then
                            arrLstStatus.Add(objTSDesc)
                        End If
                        blnSkip = True

                    Next j
                Next i
                objTSResp.arrStatusDesc = CType(arrLstStatus.ToArray(GetType(TS_Response.TS_Status_Description)), TS_Response.TS_Status_Description())

                If strVacationInd.Trim().ToUpper() = "V" Then

                    'For Each objTSDesc In arrLstStatus
                    For i As Integer = 0 To arrLstStatus.Count - 1
                        objTSDesc = arrLstStatus(i)
                        If objTSDesc.strBucketName.Trim().ToUpper() = "BASIC" Or objTSDesc.strBucketName.Trim().ToUpper() = "REGULATED" Then
                            'objTSResp.strBasicBucketStatusInd = BucketStatus.Denied
                            'objTSDesc.strBucketStatusInd = BucketStatus.Denied
                            objTSDesc.strBucketStatusDesc = "Vacation Suspended"
                        End If
                    Next



                End If
                '3/17/09 - MDVW - If L/F value is F - Status Shld be just as Terminated - Bala

                If (Not String.IsNullOrWhiteSpace(Request.strRegionId)) Then
                    If Request.strRegionId.ToUpper().Trim() = "MDVW" Or Request.strRegionId.ToUpper().Trim() = "NE" Or Request.strRegionId.ToUpper().Trim() = "NY" Or Request.strRegionId.ToUpper().Trim() = "NPD" Or Request.strRegionId.ToUpper().Trim() = "WEST" Or Request.strRegionId.ToUpper().Trim() = "VISION" Then
                        dsCA = MyBase.WSDataAccessObj.usp_GetCustomerAddressInfo(Request.strRegionId, Request.strAcctNum)
                        If Not (MyBase.WSDataAccessObj.IsEmptyRecordSet(dsCA)) Then
                            strLFvalue = dsCA.Tables(0).Rows(0)("strLiveFinalInd")
                            If Not String.IsNullOrWhiteSpace(strLFvalue) Then
                                If strLFvalue.Trim().ToUpper() = "F" Or strLFvalue.Trim().ToUpper() = "U" Or strLFvalue.Trim().ToUpper() = "D" Or strLFvalue.Trim().ToUpper() = "S" Then
                                    'objTSResp.InitializeMDVW(Request.strRegionId)
                                    objTSResp.strBasicBucketStatusInd = BucketStatus.Terminated
                                    'Return objTSResp
                                    'For Each objTSDesc In arrLstStatus
                                    For i As Integer = 0 To arrLstStatus.Count - 1
                                        objTSDesc = arrLstStatus(i)
                                        'If objTSDesc.strBucketName.Trim().ToUpper() = "BASIC" Or objTSDesc.strBucketName.Trim().ToUpper() = "REGULATED" Then
                                        objTSDesc.strBucketStatusInd = BucketStatus.Terminated
                                        objTSDesc.strBucketStatusDesc = "Terminated"
                                        'End If
                                    Next
                                End If
                            End If
                        End If
                    End If
                End If

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS - getTreatmentStatusstrRegionId/ strInputRequestType / strAcctNum / strOrg / strApplicationId: ", Request.strRegionId + "/" + Request.strInputRequestType + "/" + Request.strAcctNum + "/" + Request.strOrg + "/" + Request.strApplicationId + ex.ToString())
            End Try

            Return objTSResp

        End Function
#End Region
        Private Function MyXmlString(ByVal strString As String) As String
            Return strString
        End Function
#Region "Treatment status for FIOS"
        Public Function getTreatmentStatusFIOS(ByVal Request As TS_Request) As TSFIOS_Response

            Dim objTSFIOSResp As TSFIOS_Response = New TSFIOS_Response
            Dim objTSFIOSStatusDesc As TSFIOS_Response.TSFIOS_Status_Description = New TSFIOS_Response.TSFIOS_Status_Description
            'Dim objTSFIOSRespStatus As TSFIOS_Response.TS_Response_Status = New TSFIOS_Response.TS_Response_Status
            Dim objTSFIOSRespStatus As StatusOfRequest = New StatusOfRequest
            'objTSFIOSResp.ResponseStatus = objTSFIOSRespStatus

            Dim objWSCommon As WSCommonClasses = New WSCommonClasses
            Dim arrLstStatus As ArrayList = New ArrayList
            Dim dtmDefaultEndDate As DateTime = New DateTime(9998, 12, 31)

            Try
                objTSFIOSResp.strRegionId = Request.strRegionId
                objTSFIOSResp.strAcctNum = Request.strAcctNum

                Select Case True
                    Case Request.strAcctNum Is Nothing Or Request.strAcctNum.Trim = ""
                        objTSFIOSRespStatus.strMessageId = "INVACNBR"
                        objTSFIOSRespStatus.strMessageDescription = "Invalid Account Number passed as Input."
                        Return objTSFIOSResp
                    Case (Request.strRegionId Is Nothing Or Request.strRegionId.Trim = "")
                        objTSFIOSRespStatus.strMessageId = "INVENV"
                        objTSFIOSRespStatus.strMessageDescription = "Invalid region passed as Input."
                        Return objTSFIOSResp
                End Select

                Dim objTSFIOSDesc As TSFIOS_Response.TSFIOS_Status_Description = New TSFIOS_Response.TSFIOS_Status_Description
                Dim AcctInfo As AcctLineLevelInfo
                Dim LineInfo As LineLevelInfo
                Dim objERAAccess As CBSSERAAccess = New CBSSERAAccess(Request.strRegionId)


                '*******call fgetProfileValues to get WTN info from SSPPA*******

                If Request.strRegionId.Trim().ToUpper() = "VISION" Then
                    Dim objLineInfo As AcctLineLevelInfo = New AcctLineLevelInfo
                    Dim objLineLevel As LineLevelInfo
                    Dim xdoc As XDocument
                    Dim xmldoc As XmlDocument = New XmlDocument
                    Dim strWTN As String = ""
                    Dim objWsMain As WSMain = New WSMain()
                    Try
                        xmldoc.XmlResolver = Nothing
                        xmldoc = objWsMain.getVZFullProfile(Request.strAcctNum, "WEST", 0)
                        ' xdoc = XDocument.Parse(xmldoc.OuterXml)
                        If xmldoc IsNot Nothing Then
                            xdoc = XDocument.Parse(HttpUtility.HtmlEncode(MyXmlString(xmldoc.OuterXml)))
                        End If

                        Dim objxelement As XElement = XElement.Parse(xdoc.ToString())
                        Dim objServices As IEnumerable(Of XElement) = _
                                            From el In objxelement...<Data>.<Services>.<FiosVoice>.<PrimaryLineInfo>.<TN> _
                                            Select el

                        For Each el As XElement In objServices
                            If el.Name = "TN" Then
                                objLineLevel = New LineLevelInfo
                                objLineLevel.strTelephoneNo = el.Value
                                objLineLevel.strSubAcctServiceType = ""
                                objLineLevel.dtmSubAccountTermDate = "1900/01/01"
                                objLineInfo.arrLstLineDetails.Add(objLineLevel)
                            End If
                        Next

                        AcctInfo = objLineInfo


                    Catch ex As Exception
                        LogErrorFile.WriteLog("RMICWWS - getTreatmentStatusFIOS VISION", ex.ToString() + Request.strAcctNum)
                    End Try






                End If



                '*******call getCBSS_AcctLineInfo to get WTN info*******




                'AcctInfo = objERAAccess.getCBSS_AcctLineInfo(Request.strRegionId, Request.strAcctNum)
                If Request.strRegionId.Trim() <> "VISION" Then
                    AcctInfo = objERAAccess.getCBSS_AcctLineInfo("FRAUDWEST", Request.strAcctNum)
                End If


                If (AcctInfo.RequestStatus.strMessageId.Trim = "") Or (Request.strRegionId.Trim() = "VISION") Then

                    'For Each LineInfo In AcctInfo.arrLstLineDetails
                    For k As Integer = 0 To AcctInfo.arrLstLineDetails.Count - 1
                        LineInfo = AcctInfo.arrLstLineDetails(k)

                        If ((LineInfo.strSubAcctServiceType.Trim = "A" Or LineInfo.strSubAcctServiceType.Trim = "B" Or LineInfo.strSubAcctServiceType.Trim = "E") And LineInfo.dtmSubAccountTermDate > dtmDefaultEndDate) Or (Request.strRegionId.Trim() = "VISION") Then

                            Dim strCBSSWTN As String = " "
                            strCBSSWTN = LineInfo.strTelephoneNo

                            '*******call usp_GetTreatmentStatusFIOS to get status info*******
                            Dim dsTS As DataSet = MyBase.WSDataAccessObj.usp_GetTreatmentStatusFIOS(Request.strRegionId, strCBSSWTN)
                            Dim dtTS As DataTable
                            Dim drTS As DataRow
                            Dim strValue As String
                            Dim strValue2 As String

                            'For Each dtTS In dsTS.Tables
                            For i As Integer = 0 To dsTS.Tables.Count - 1
                                dtTS = dsTS.Tables(i)
                                'For Each drTS In dtTS.Rows
                                For j As Integer = 0 To dtTS.Rows.Count - 1
                                    drTS = dtTS.Rows(j)

                                    Dim objmyTSFIOSDesc As TSFIOS_Response.TSFIOS_Status_Description = New TSFIOS_Response.TSFIOS_Status_Description
                                    objmyTSFIOSDesc.strWTN = strCBSSWTN
                                    objmyTSFIOSDesc.strLineType = "WTN"

                                    strValue = drTS("strtActionActn")
                                    Select Case strValue.Trim()
                                        Case "B-ALL"
                                            objmyTSFIOSDesc.strBlockType = FIOSBlockType.BlockAll
                                        Case "B-INTL"
                                            objmyTSFIOSDesc.strBlockType = FIOSBlockType.BlockIntl
                                    End Select

                                    '*******status can be Live or Blocked*******
                                    strValue2 = drTS("strtSLLActn")
                                    If strValue2 Is Nothing Or strValue2.Trim = "" Then
                                        objmyTSFIOSDesc.strStatus = BucketStatusFIOS.Live
                                    Else
                                        objmyTSFIOSDesc.strStatus = BucketStatusFIOS.Blocked
                                    End If

                                    objmyTSFIOSDesc.strPendingStatus = "N"
                                    objmyTSFIOSDesc.strPendingDesc = " "
                                    '*******=> objmyTSFIOSDesc.dtmBeginDate=drTS("dtmBeginDate") '????
                                    arrLstStatus.Add(objmyTSFIOSDesc)
                                Next
                            Next

                        End If 'end of LineInfo.strSubAcctServiceType filter

                    Next k

                Else
                    If (AcctInfo.RequestStatus.strMessageId.Trim = "100") Then
                        'MyBase.WSDataAccessObj.usp_UpdateSOPRequest("STATUS", MsgInp.intSOPRequestId, "SE", "NFNDECPS", " ", "RMICWWS")
                    End If
                End If

                'objTSFIOSDesc.strWTN = "8131111234"
                'objTSFIOSDesc.strLineType = "WTN"
                'objTSFIOSDesc.strBlockType = FIOSBlockType.BlockAll
                'objTSFIOSDesc.strStatus = BucketStatusFIOS.Live
                'objTSFIOSDesc.strPendingStatus = "N"
                'objTSFIOSDesc.strPendingDesc = " "
                'arrLstStatus.Add(objTSFIOSDesc)

                'Dim objTSFIOSDesc2 As TSFIOS_Response.TSFIOS_Status_Description = New TSFIOS_Response.TSFIOS_Status_Description
                'objTSFIOSDesc2.strWTN = "8131111235"
                'objTSFIOSDesc2.strLineType = "WTN"
                'objTSFIOSDesc.strBlockType = FIOSBlockType.BlockIntl
                'objTSFIOSDesc2.strStatus = BucketStatusFIOS.Live
                'objTSFIOSDesc2.strPendingStatus = "N"
                'objTSFIOSDesc2.strPendingDesc = " "
                'arrLstStatus.Add(objTSFIOSDesc2)

                'Dim objTSFIOSDesc3 As TSFIOS_Response.TSFIOS_Status_Description = New TSFIOS_Response.TSFIOS_Status_Description
                'objTSFIOSDesc3.strWTN = "8131111236"
                'objTSFIOSDesc3.strLineType = "WTN"
                'objTSFIOSDesc.strBlockType = FIOSBlockType.BlockIntl
                'objTSFIOSDesc3.strStatus = BucketStatusFIOS.Blocked
                'objTSFIOSDesc3.strPendingStatus = "Y"
                'objTSFIOSDesc3.strPendingDesc = " "
                'arrLstStatus.Add(objTSFIOSDesc3)

                objTSFIOSResp.arrStatusDesc = CType(arrLstStatus.ToArray(GetType(TSFIOS_Response.TSFIOS_Status_Description)), TSFIOS_Response.TSFIOS_Status_Description())

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS - getTreatmentStatusFIOS", ex.ToString())
            End Try

            Return objTSFIOSResp

        End Function

#End Region
#Region "Treatment Details for RMVP"

        Public Function getTreatmentDetails_old1(ByVal Request As TD_Request) As TD_Response

            Dim ObjTDRequest As New TD_Request
            Dim objTDResp As TD_Response = New TD_Response
            Dim objTDDesc As TD_Response.TD_Status_Description = New TD_Response.TD_Status_Description

            Dim objRequest As New TS_Request
            Dim objTSResp As TS_Response = New TS_Response
            Dim objTSDesc As TS_Response.TS_Status_Description = New TS_Response.TS_Status_Description


            Dim objTDRespStatus As TD_Response.TD_Response_Status = New TD_Response.TD_Response_Status
            objTDResp.ResponseStatus = objTDRespStatus

            Dim objWSCommon As WSCommonClasses = New WSCommonClasses
            Dim arrLstStatus As ArrayList = New ArrayList

            'to get info from CFI webmethod
            Dim objBalanceInfo As CFIBalanceInfo = New CFIBalanceInfo

            Try
                objTDResp.strRegionId = Request.strRegionId
                objTDResp.strAcctNum = Request.strAcctNum
                'objTDResp.strOCARBucketStatusInd = BucketStatus.NA
                'objTDResp.strNonTelecomStatusInd = BucketStatus.NA
                'objTDResp.strDAStatusInd = BucketStatus.NA

                If (Not WSCommonClasses.CheckRegionType(Request.strRegionId.Trim)) Then
                    objTDRespStatus.strMessageId = "RMWTS001"
                    objTDRespStatus.strMessageDescription = "Invalid RegionId Specified"
                    Return objTDResp
                End If

                If (Request.strInputRequestType.ToUpper() = "A" Or Request.strInputRequestType.ToUpper() = "B") Then
                Else
                    objTDRespStatus.strMessageId = "RMWTS002"
                    objTDRespStatus.strMessageDescription = "Invalid Request Type."
                    Return objTDResp
                End If

                ' Call Treatment status method to populate status of the account
                objRequest.strAcctNum = Request.strAcctNum.Trim()
                objRequest.strApplicationId = Request.strApplicationId.Trim()
                objRequest.strInputRequestType = Request.strInputRequestType.Trim()
                objRequest.strOrg = Request.strOrg.Trim()
                objRequest.strRegionId = Request.strRegionId.Trim()

                objTSResp = (getTreatmentStatus(objRequest))


                'Get Balance details only if any one of the bucket is denied else send zeros
                If (objTSResp.strBasicBucketStatusInd = BucketStatus.Denied Or objTSResp.strNonBasicBucketStatusInd = BucketStatus.Denied Or _
                    objTSResp.strTollBucketStatusInd = BucketStatus.Denied Or objTSResp.strNonTelecomStatusInd = BucketStatus.Denied Or objTSResp.strOCARBucketStatusInd = BucketStatus.Denied) Then

                    ' Call Sproc to get the balances
                    Dim dsTD As DataSet = MyBase.WSDataAccessObj.usp_GetRMVPBalanceDetails(Request.strRegionId, Request.strAcctNum, Request.strOrg)
                    'Dim dtTD As DataTable
                    'Dim drTS As DataRow
                    'Dim strValue As String

                    If (MyBase.WSDataAccessObj.IsEmptyRecordSet(dsTD)) Then
                        objTDResp.Initialize(Request.strRegionId)
                        Return objTDResp
                    End If

                    If Request.strRegionId = "WEST" Then

                        'Dim objBalanceInfo As CFIBalanceInfo = New CFIBalanceInfo

                        Try
                            Dim objERAAccess As CBSSERAAccess = New CBSSERAAccess(Request.strRegionId)
                            objBalanceInfo = objERAAccess.getCBSS_CBSPCFA1_BalanceInfo(Request.strRegionId, Request.strAcctNum)

                            'Dim dblpastdue As Double
                            'dblpastdue = objBalanceInfo.curPastDueBasic

                        Catch ex As Exception
                            LogErrorFile.WriteLog("RMICWWS-getCBSS_CBSPCFA1_BalanceInfo", ex.ToString())
                            objBalanceInfo.RequestStatus.strMessageId = "RMIEXPTN"
                            objBalanceInfo.RequestStatus.strMessageDescription = ex.ToString
                        End Try
                    End If

                    ' should change to get the btnnum .. tsuspnllvl table
                    objTDResp.strBTNNum = objTDResp.strAcctNum

                    objTDResp.strPendingRestoral = dsTD.Tables(0).Rows(0).Item(2)
                    objTDResp.strBasicBucketStatusInd = objTSResp.strBasicBucketStatusInd
                    objTDResp.strNonBasicBucketStatusInd = objTSResp.strNonBasicBucketStatusInd
                    objTDResp.strTollBucketStatusInd = objTSResp.strTollBucketStatusInd
                    objTDResp.strOCARBucketStatusInd = objTSResp.strOCARBucketStatusInd
                    objTDResp.strNonTelecomStatusInd = objTSResp.strNonTelecomStatusInd
                    objTDResp.strDAStatusInd = objTSResp.strDAStatusInd
                    'objTDDesc.dtmBeginDate = objTSDesc.dtmBeginDate.Date


                    Dim strStatus As String = Nothing

                    'For Each objRow As DataRow In dsTD.Tables(0).Rows
                    For i As Integer = 0 To dsTD.Tables(0).Rows.Count - 1
                        Dim objRow As DataRow = dsTD.Tables(0).Rows(i)
                        objTDDesc = New TD_Response.TD_Status_Description
                        'Dim objBalanceInfo As CFIBalanceInfo = New CFIBalanceInfo

                        objTDDesc.strBucketName = objRow("strBucketName")
                        'Select Case objRow("strBucketName")
                        Select Case objTDDesc.strBucketName
                            Case "Basic"
                                strStatus = objTSResp.strBasicBucketStatusInd.ToString()
                            Case "Non-Basic"
                                strStatus = objTSResp.strNonBasicBucketStatusInd.ToString()
                            Case "Toll"
                                strStatus = objTSResp.strTollBucketStatusInd.ToString()
                            Case "OCAR"
                                strStatus = objTSResp.strOCARBucketStatusInd.ToString()
                            Case "NonTelecom"
                                strStatus = objTSResp.strNonTelecomStatusInd.ToString()
                            Case "DA"
                                strStatus = objTSResp.strDAStatusInd.ToString()
                        End Select

                        objTDDesc.strBucketStatusInd = strStatus
                        If Not strStatus Is Nothing Then
                            Select Case strStatus.ToUpper()
                                Case "DENIED"
                                    objTDDesc.dtmTerminationDate = objRow("TermDate")
                                    objTDDesc.dtmBeginDate = objTSDesc.dtmBeginDate
                                Case Else
                                    objTDDesc.dtmTerminationDate = New DateTime(1900, 1, 1)
                                    objTDDesc.dtmBeginDate = New DateTime(1900, 1, 1)

                            End Select
                        End If
                        'objTDDesc.dtmTerminationDate = objRow("TermDate")
                        If Request.strRegionId.ToUpper().Trim() = "WEST" Then
                            'Select Case objRow("strBucketName")
                            Select Case objTDDesc.strBucketName
                                Case "Basic"
                                    objTDDesc.curPastDueAmount = objBalanceInfo.curPastDueBasic
                                    objTDDesc.curTreatableAmount = objBalanceInfo.curTreatableDueBasic
                                Case "Non-Basic"
                                    objTDDesc.curPastDueAmount = objBalanceInfo.curPastDueNonBasic
                                    objTDDesc.curTreatableAmount = objBalanceInfo.curTreatableDueNonBasic
                                Case "Toll"
                                    objTDDesc.curPastDueAmount = objBalanceInfo.curPastDueToll
                                    objTDDesc.curTreatableAmount = objBalanceInfo.curTreatableDueToll
                                Case "OCAR"
                                    objTDDesc.curPastDueAmount = 0
                                    objTDDesc.curTreatableAmount = 0
                                Case "NonTelecom"
                                    objTDDesc.curPastDueAmount = 0
                                    objTDDesc.curTreatableAmount = 0
                                Case "DA"
                                    objTDDesc.curPastDueAmount = 0
                                    objTDDesc.curTreatableAmount = 0
                            End Select
                        Else
                            objTDDesc.curPastDueAmount = objRow("CurPastdueamount")
                            objTDDesc.curTreatableAmount = objRow("curTreatableAmount")
                        End If
                        objTDDesc.curNoticeAmount = objRow("curNoticeAmount")
                        objTDDesc.curSnpAmount = objRow("curSnpAmount")
                        arrLstStatus.Add(objTDDesc)
                        objTDDesc = Nothing

                    Next
                Else

                    'intialize all values to zeros
                    objTDResp.Initialize(Request.strRegionId)
                    Return objTDResp

                End If

                objTDResp.arrStatusDesc = CType(arrLstStatus.ToArray(GetType(TD_Response.TD_Status_Description)), TD_Response.TD_Status_Description())

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS - getTreatmentDetails", ex.ToString())
            End Try

            Return objTDResp

        End Function



        Public Function GetDueOnSpecificDateMDVW(ByVal InputData As XBCLSPA5, ByVal curBucketAmt As Double, ByVal dtmRequestDt As DateTime, ByVal enBucketInfo As EnBucketName) As Double


            Dim curDueAmt As Double = curBucketAmt
            Dim objInp As New XBCLSPA5
            Dim objBill As BillDetails
            objInp = InputData

            'For Each objBill In objInp.arrLstBalanceInfoDetails
            For i As Integer = 0 To objInp.arrLstBalanceInfoDetails.Count - 1
                objBill = objInp.arrLstBalanceInfoDetails(i)
                If (objBill.intMonthPastInd > 2) Then

                    If (objBill.dtmBillDt.CompareTo(dtmRequestDt) > 0) Then

                        Select Case (enBucketInfo)
                            Case EnBucketName.enBucketCurrentDue
                                curDueAmt -= (objBill.curTotBilled - objBill.curBalDueAmt)
                            Case EnBucketName.enBucketBasic
                                If objBill.curBasicAmt < 0 Then objBill.curBasicAmt = 0.0
                                curDueAmt -= (objBill.curBasicAmt)

                            Case EnBucketName.enBucketNonBasic
                                If (objBill.curNonBasicAmt < 0) Then objBill.curNonBasicAmt = 0.0
                                curDueAmt -= (objBill.curNonBasicAmt)
                            Case EnBucketName.enBucketToll
                                If (objBill.curTollAmt < 0.0) Then objBill.curTollAmt = 0.0
                                curDueAmt -= (objBill.curTollAmt)

                            Case EnBucketName.enBucketWRLS
                                If (objBill.curWrlsAmt < 0.0) Then objBill.curWrlsAmt = 0.0
                                curDueAmt -= (objBill.curWrlsAmt)

                            Case EnBucketName.enBucketOCAR
                                If (objBill.curOcarAmt < 0.0) Then objBill.curOcarAmt = 0.0
                                curDueAmt -= (objBill.curOcarAmt)

                            Case EnBucketName.enBucketDA
                                If (objBill.curDAAmt < 0.0) Then objBill.curDAAmt = 0.0
                                curDueAmt -= (objBill.curDAAmt)

                            Case EnBucketName.enBucketIP
                                If (objBill.curIPAmt < 0.0) Then objBill.curIPAmt = 0.0
                                curDueAmt -= (objBill.curIPAmt)

                            Case EnBucketName.enBucketCPE
                                If (objBill.curCPEAmt < 0.0) Then objBill.curCPEAmt = 0.0
                                curDueAmt -= (objBill.curCPEAmt)
                        End Select

                    End If
                End If

            Next



            Return curDueAmt

        End Function
        Public Function getTreatmentDetails_OLD(ByVal Request As TD_Request) As TD_Response

            Dim ObjTDRequest As New TD_Request
            Dim objTDResp As TD_Response = New TD_Response
            Dim objTDDesc As TD_Response.TD_Status_Description = New TD_Response.TD_Status_Description

            Dim objRequest As New TS_Request
            Dim objTSResp As TS_Response = New TS_Response
            Dim objTSDesc As TS_Response.TS_Status_Description = New TS_Response.TS_Status_Description


            Dim objTDRespStatus As TD_Response.TD_Response_Status = New TD_Response.TD_Response_Status
            objTDResp.ResponseStatus = objTDRespStatus

            Dim objWSCommon As WSCommonClasses = New WSCommonClasses
            Dim arrLstStatus As ArrayList = New ArrayList

            'to get info from CFI webmethod
            Dim objBalanceInfo As CFIBalanceInfo = New CFIBalanceInfo

            Dim blPassZero As Boolean = False
            Dim strStatus As BucketStatus
            Dim dsTD As DataSet = Nothing
            'Dim dtTD As DataTable
            'Dim drTS As DataRow
            'Dim strValue As String

            ' for MDVW
            Dim objMDVW_RMVP_Data As MDVW_RMVP_Data
            Dim objMDVW_RMVP_Strata As MDVW_RMVP_Strata
            Dim objResSPA5 As XBCLSPA5
            Dim strEnv As String = Nothing
            Dim objEnvDS As DataSet
            Dim MDVWcurTotalTotalDueAmt As Double
            Dim MDVWcurBasicTotalDueAmt As Double
            Dim MDVWcurNonBasicTotalDueAmt As Double
            Dim MDVWcurTollTotalDueAmt As Double
            Dim MDVWcurOcarTotalDueAmt As Double
            Dim MDVWcurNonTelecomeDueAmt As Double

            Dim MDVWcurTotalPastDueAmt As Double
            Dim MDVWcurBasicPastDueAmt As Double
            Dim MDVWcurNonBasicPastDueAmt As Double
            Dim MDVWcurTollPastDueAmt As Double
            Dim MDVWcurOcarPastDueAmt As Double
            Dim MDVWcurNonTelecomePastDueAmt As Double



            Dim MDVWcurTotalTrtbleAmt As Double
            Dim MDVWcurBasicTrtbleAmt As Double
            Dim MDVWcurNonBasicTrtbleAmt As Double
            Dim MDVWcurTollTrtbleAmt As Double
            Dim MDVWcurOcarTrtbleAmt As Double
            Dim MDVWcurNonTelecomeTrtbleAmt As Double


            Dim objBill As BillDetails
            Dim strtmpOrg As String = Nothing

            Try
                objTDResp.strRegionId = Request.strRegionId
                objTDResp.strAcctNum = Request.strAcctNum

                If (Not WSCommonClasses.CheckRegionType(Request.strRegionId.Trim)) Then
                    objTDRespStatus.strMessageId = "RMWTS001"
                    objTDRespStatus.strMessageDescription = "Invalid RegionId Specified"
                    Return objTDResp
                End If

                If (Request.strInputRequestType.ToUpper() = "A" Or Request.strInputRequestType.ToUpper() = "B") Then
                Else
                    objTDRespStatus.strMessageId = "RMWTS002"
                    objTDRespStatus.strMessageDescription = "Invalid Request Type."
                    Return objTDResp
                End If

                ' Call Treatment status method to populate status of the account
                objRequest.strAcctNum = Request.strAcctNum.Trim()
                objRequest.strApplicationId = Request.strApplicationId.Trim()
                objRequest.strInputRequestType = Request.strInputRequestType.Trim()
                objRequest.strOrg = Request.strOrg.Trim()
                objRequest.strRegionId = Request.strRegionId.Trim()

                objTSResp = (getTreatmentStatus(objRequest))

                'Get Balance details only if any one of the bucket is denied else send zeros
                If (objTSResp.strBasicBucketStatusInd = BucketStatus.Denied Or objTSResp.strNonBasicBucketStatusInd = BucketStatus.Denied Or _
                    objTSResp.strTollBucketStatusInd = BucketStatus.Denied Or objTSResp.strNonTelecomStatusInd = BucketStatus.Denied Or objTSResp.strOCARBucketStatusInd = BucketStatus.Denied) Then

                    blPassZero = False
                Else
                    blPassZero = True
                End If

                If blPassZero = False Then

                    ' Call Sproc to get the balances
                    dsTD = MyBase.WSDataAccessObj.usp_GetRMVPBalanceDetails(Request.strRegionId, Request.strAcctNum, Request.strOrg)

                    If (MyBase.WSDataAccessObj.IsEmptyRecordSet(dsTD)) Then

                        fn_initialize(objTSResp, objTDResp)
                        Return objTDResp
                    End If

                    If Request.strRegionId = "WEST" Then

                        Try
                            Dim objERAAccess As CBSSERAAccess = New CBSSERAAccess(Request.strRegionId)
                            objBalanceInfo = objERAAccess.getCBSS_CBSPCFA1_BalanceInfo(Request.strRegionId, Request.strAcctNum)
                        Catch ex As Exception
                            LogErrorFile.WriteLog("RMICWWS-getCBSS_CBSPCFA1_BalanceInfo", ex.ToString())
                            objBalanceInfo.RequestStatus.strMessageId = "RMIEXPTN"
                            objBalanceInfo.RequestStatus.strMessageDescription = ex.ToString
                        End Try
                    End If

                    If Request.strRegionId = "NPD" Then

                        Try
                            objBalanceInfo = fn_getCFIBalanceEastInfo(Request.strAcctNum, Request.strRegionId, Request.strOrg)
                        Catch ex As Exception
                            LogErrorFile.WriteLog("RMICWWS-getCFIBalanceEastInfo_ForNPD", ex.ToString())
                            objBalanceInfo.RequestStatus.strMessageId = "RMIEXPTN"
                            objBalanceInfo.RequestStatus.strMessageDescription = ex.ToString
                        End Try
                    End If



                    '===== FOR MDVW
                    If Request.strRegionId = "MDVW" Then


                        Try
                            'objMDVW_RMVP_Data = New MDVW_RMVP_Data("MDVW") -- using SPA5
                            objMDVW_RMVP_Strata = New MDVW_RMVP_Strata("MDVW") ' using SPA3 for Strata
                            objEnvDS = MyBase.WSDataAccessObj.usp_GetCustomerAddressInfo(Request.strRegionId, Request.strAcctNum)

                            If Not (MyBase.WSDataAccessObj.IsEmptyRecordSet(objEnvDS)) Then
                                strEnv = objEnvDS.Tables(0).Rows(0)("strEnv")
                                strtmpOrg = objEnvDS.Tables(0).Rows(0)("strOrgCode")
                            End If


                            objResSPA5 = Nothing

                            'objResSPA5 = objMDVW_RMVP_Data.get_XBCLSPA5("MDVW", Request.strAcctNum.Trim(), strEnv.Trim(), 1)
                            objResSPA5 = objMDVW_RMVP_Strata.get_XBCLSPA3_Icollect("MDVW", Request.strAcctNum.Trim())  ' using SPA3 for Strata
                            If (objResSPA5 Is Nothing) Then
                                fn_initialize(objTSResp, objTDResp)
                                Return objTDResp
                            End If


                            'For Each objBill In objResSPA5.arrLstBalanceInfoDetails
                            For i As Integer = 0 To objResSPA5.arrLstBalanceInfoDetails.Count - 1
                                objBill = objResSPA5.arrLstBalanceInfoDetails(i)
                                If (objBill.intMonthPastInd = 0) Then
                                    MDVWcurTotalTotalDueAmt = objBill.curTotBilled
                                    MDVWcurBasicTotalDueAmt = objBill.curBasicAmt
                                    MDVWcurNonBasicTotalDueAmt = objBill.curNonBasicAmt
                                    MDVWcurTollTotalDueAmt = objBill.curTollAmt
                                    MDVWcurOcarTotalDueAmt = objBill.curOcarAmt
                                    MDVWcurNonTelecomeDueAmt = objBill.curOcarAmt

                                End If
                                If (objBill.intMonthPastInd = 1) Then
                                    MDVWcurTotalPastDueAmt = objBill.curTotBilled
                                    MDVWcurBasicPastDueAmt = objBill.curBasicAmt
                                    MDVWcurNonBasicPastDueAmt = objBill.curNonBasicAmt
                                    MDVWcurTollPastDueAmt = objBill.curTollAmt
                                    MDVWcurOcarPastDueAmt = objBill.curOcarAmt
                                    MDVWcurNonTelecomePastDueAmt = objBill.curOcarAmt
                                End If

                                If (objBill.intMonthPastInd = 2) Then
                                    MDVWcurTotalTrtbleAmt = objBill.curTotBilled
                                    MDVWcurBasicTrtbleAmt = objBill.curBasicAmt
                                    MDVWcurNonBasicTrtbleAmt = objBill.curNonBasicAmt
                                    MDVWcurTollTrtbleAmt = objBill.curTollAmt
                                    MDVWcurOcarTrtbleAmt = objBill.curOcarAmt
                                    MDVWcurNonTelecomeTrtbleAmt = objBill.curOcarAmt
                                End If
                            Next

                        Catch ex As Exception
                            LogErrorFile.WriteLog("RMICWWS-getTreatmentDetails", ex.ToString())
                        End Try
                    End If

                    '========

                End If



                objTDResp.strBTNNum = objTDResp.strBTNNum
                If blPassZero = False Then
                    objTDResp.strPendingRestoral = dsTD.Tables(0).Rows(0).Item(2)
                Else
                    objTDResp.strPendingRestoral = "N"
                End If
                objTDResp.strBasicBucketStatusInd = objTSResp.strBasicBucketStatusInd
                objTDResp.strNonBasicBucketStatusInd = objTSResp.strNonBasicBucketStatusInd
                objTDResp.strTollBucketStatusInd = objTSResp.strTollBucketStatusInd
                objTDResp.strOCARBucketStatusInd = objTSResp.strOCARBucketStatusInd
                objTDResp.strNonTelecomStatusInd = objTSResp.strNonTelecomStatusInd
                objTDResp.strDAStatusInd = objTSResp.strDAStatusInd


                If blPassZero = False Then
                    'For Each objRow As DataRow In dsTD.Tables(0).Rows
                    For i As Integer = 0 To dsTD.Tables(0).Rows.Count - 1
                        Dim objRow As DataRow = dsTD.Tables(0).Rows(i)
                        objTDDesc = New TD_Response.TD_Status_Description

                        objTDDesc.strBucketName = objRow("strBucketName")
                        'Select Case objRow("strBucketName")
                        Select Case objTDDesc.strBucketName
                            Case "Basic", "Regulated"
                                strStatus = objTSResp.strBasicBucketStatusInd
                            Case "Non-Basic", "Non Regulated"
                                strStatus = objTSResp.strNonBasicBucketStatusInd
                            Case "Toll"
                                strStatus = objTSResp.strTollBucketStatusInd
                            Case "OCAR"
                                strStatus = objTSResp.strOCARBucketStatusInd
                            Case "NonTelecom", "Non Telecom"
                                strStatus = objTSResp.strNonTelecomStatusInd
                            Case "DA"
                                strStatus = objTSResp.strDAStatusInd
                        End Select
                        objTDDesc.strBucketStatusInd = strStatus
                        objTDDesc.dtmTerminationDate = objRow("TermDate")

                        objTDDesc.dtmTerminationDate = objTDDesc.dtmTerminationDate.ToShortDateString()

                        Dim strTmp As String
                        strTmp = fn_getdesc(objTDDesc.strBucketName, "dtmBeginDate", objTSResp.arrStatusDesc)

                        If strTmp > "" Then
                            If IsDate(strTmp) Then
                                objTDDesc.dtmBeginDate = CDate(strTmp)
                            Else
                                objTDDesc.dtmBeginDate = New DateTime(1900, 1, 1)
                            End If
                        Else
                            objTDDesc.dtmBeginDate = New DateTime(1900, 1, 1)
                        End If

                        If Request.strRegionId.ToString.Trim() = "MDVW" Then
                            Dim dtTrtabledate As Date

                            dtTrtabledate = objRow("dtmTrtBillDate")

                            'Select Case objRow("strBucketName")
                            Select Case objTDDesc.strBucketName
                                Case "Basic", "Regulated"
                                    If Date.Compare(dtTrtabledate, "1900/01/01") = 0 Then
                                        objTDDesc.curTreatableAmount = MDVWcurBasicPastDueAmt
                                    Else
                                        objTDDesc.curTreatableAmount = MDVWcurBasicTrtbleAmt 'GetDueOnSpecificDateMDVW(objResSPA5, MDVWcurBasicTotalDueAmt, dtTrtabledate, EnBucketName.enBucketBasic)
                                    End If
                                    objTDDesc.curPastDueAmount = MDVWcurBasicPastDueAmt
                                    objTDDesc.TotalAmountDue = MDVWcurBasicTotalDueAmt

                                Case "Non-Basic", "Non Regulated"
                                    If Date.Compare(dtTrtabledate, "1900/01/01") = 0 Then
                                        objTDDesc.curTreatableAmount = MDVWcurNonBasicPastDueAmt
                                    Else
                                        objTDDesc.curTreatableAmount = MDVWcurNonBasicTrtbleAmt 'GetDueOnSpecificDateMDVW(objResSPA5, MDVWcurNonBasicTotalDueAmt, dtTrtabledate, EnBucketName.enBucketNonBasic)
                                    End If
                                    objTDDesc.curPastDueAmount = MDVWcurNonBasicPastDueAmt
                                    objTDDesc.TotalAmountDue = MDVWcurNonBasicTotalDueAmt

                                Case "Toll"
                                    If Date.Compare(dtTrtabledate, "1900/01/01") = 0 Then
                                        objTDDesc.curTreatableAmount = MDVWcurTollPastDueAmt
                                    Else
                                        objTDDesc.curTreatableAmount = MDVWcurTollTrtbleAmt ' GetDueOnSpecificDateMDVW(objResSPA5, MDVWcurTollTotalDueAmt, dtTrtabledate, EnBucketName.enBucketToll)
                                    End If
                                    objTDDesc.curPastDueAmount = MDVWcurTollPastDueAmt
                                    objTDDesc.TotalAmountDue = MDVWcurTollTotalDueAmt

                                Case "OCAR"
                                    objTDDesc.curPastDueAmount = 0.0
                                    objTDDesc.curTreatableAmount = 0.0
                                    objTDDesc.TotalAmountDue = 0.0
                                Case "NonTelecom", "Non Telecom"
                                    If Date.Compare(dtTrtabledate, "1900/01/01") = 0 Then
                                        objTDDesc.curTreatableAmount = MDVWcurOcarPastDueAmt
                                    Else
                                        objTDDesc.curTreatableAmount = MDVWcurOcarTrtbleAmt ' GetDueOnSpecificDateMDVW(objResSPA5, MDVWcurOcarTotalDueAmt, dtTrtabledate, EnBucketName.enBucketNonTelcom)
                                    End If
                                    objTDDesc.curPastDueAmount = MDVWcurOcarPastDueAmt
                                    objTDDesc.TotalAmountDue = MDVWcurOcarTotalDueAmt
                                Case "DA"
                                    objTDDesc.curPastDueAmount = 0.0
                                    objTDDesc.curTreatableAmount = 0.0
                                    objTDDesc.TotalAmountDue = 0.0
                            End Select

                        ElseIf Request.strRegionId.ToUpper().Trim() = "WEST" Then
                            'Select Case objRow("strBucketName")
                            Select Case objTDDesc.strBucketName
                                Case "Basic"
                                    objTDDesc.curPastDueAmount = objBalanceInfo.curPastDueBasic
                                    objTDDesc.curTreatableAmount = objBalanceInfo.curTreatableDueBasic

                                    objTDDesc.TotalAmountDue = objBalanceInfo.curTotalDueBasic

                                Case "Non-Basic"
                                    objTDDesc.curPastDueAmount = objBalanceInfo.curPastDueNonBasic
                                    objTDDesc.curTreatableAmount = objBalanceInfo.curTreatableDueNonBasic

                                    objTDDesc.TotalAmountDue = objBalanceInfo.curTotalDueNonBasic
                                Case "Toll"
                                    objTDDesc.curPastDueAmount = objBalanceInfo.curPastDueToll
                                    objTDDesc.curTreatableAmount = objBalanceInfo.curTreatableDueToll

                                    objTDDesc.TotalAmountDue = objBalanceInfo.curTotalDueToll
                                Case "OCAR"
                                    objTDDesc.curPastDueAmount = 0.0
                                    objTDDesc.curTreatableAmount = 0.0
                                    objTDDesc.TotalAmountDue = 0.0
                                Case "NonTelecom"
                                    objTDDesc.curPastDueAmount = 0.0
                                    objTDDesc.curTreatableAmount = 0.0
                                    objTDDesc.TotalAmountDue = 0.0
                                Case "DA"
                                    objTDDesc.curPastDueAmount = 0.0
                                    objTDDesc.curTreatableAmount = 0.0
                                    objTDDesc.TotalAmountDue = 0.0
                            End Select
                        ElseIf Request.strRegionId.ToUpper().Trim() = "NPD" Then
                            'Select Case objRow("strBucketName")
                            Select Case objTDDesc.strBucketName
                                Case "Basic"
                                    objTDDesc.curPastDueAmount = objBalanceInfo.curPastDueBasic
                                    objTDDesc.curTreatableAmount = objBalanceInfo.curTreatableDueBasic

                                    objTDDesc.TotalAmountDue = objBalanceInfo.curTotalDueBasic

                                Case "Non-Basic"
                                    objTDDesc.curPastDueAmount = objBalanceInfo.curPastDueNonBasic
                                    objTDDesc.curTreatableAmount = objBalanceInfo.curTreatableDueNonBasic

                                    objTDDesc.TotalAmountDue = objBalanceInfo.curTotalDueNonBasic
                                Case "Toll"
                                    objTDDesc.curPastDueAmount = objBalanceInfo.curPastDueToll
                                    objTDDesc.curTreatableAmount = objBalanceInfo.curTreatableDueToll

                                    objTDDesc.TotalAmountDue = objBalanceInfo.curTotalDueToll
                                Case "OCAR"
                                    objTDDesc.curPastDueAmount = 0.0
                                    objTDDesc.curTreatableAmount = 0.0
                                    objTDDesc.TotalAmountDue = 0.0
                                Case "NonTelecom"
                                    objTDDesc.curPastDueAmount = 0.0
                                    objTDDesc.curTreatableAmount = 0.0
                                    objTDDesc.TotalAmountDue = 0.0
                                Case "DA"
                                    objTDDesc.curPastDueAmount = 0.0
                                    objTDDesc.curTreatableAmount = 0.0
                                    objTDDesc.TotalAmountDue = 0.0
                            End Select
                        Else
                            objTDDesc.curPastDueAmount = objRow("CurPastdueamount")
                            objTDDesc.curTreatableAmount = objRow("curTreatableAmount")
                            objTDDesc.TotalAmountDue = objRow("curTotalDueAmount")

                        End If

                        objTDDesc.curNoticeAmount = objRow("curNoticeAmount")
                        objTDDesc.curSnpAmount = objRow("curSnpAmount")
                        arrLstStatus.Add(objTDDesc)
                        objTDDesc = Nothing

                    Next
                Else
                    ''intialize all values to zeros
                    fn_initialize(objTSResp, objTDResp)

                    objTDResp.arrStatusDesc = CType(arrLstStatus.ToArray(GetType(TD_Response.TD_Status_Description)), TD_Response.TD_Status_Description())
                    Return objTDResp

                End If

                objTDResp.arrStatusDesc = CType(arrLstStatus.ToArray(GetType(TD_Response.TD_Status_Description)), TD_Response.TD_Status_Description())

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS - getTreatmentDetails", ex.ToString())
            End Try

            ' check the number of buckets and do the sumup

            If Request.strRegionId.ToUpper().Trim() = "MDVW" Then
                fn_CheckNumBucketsAndSum(objTDResp, strtmpOrg)
            End If

            Return objTDResp

        End Function

        Public Function getTreatmentDetails(ByVal Request As TD_Request) As TD_Response

            Dim ObjTDRequest As New TD_Request
            Dim objTDResp As TD_Response = New TD_Response
            Dim objTDDesc As TD_Response.TD_Status_Description = New TD_Response.TD_Status_Description

            Dim objRequest As New TS_Request
            Dim objTSResp As TS_Response = New TS_Response
            Dim objTSDesc As TS_Response.TS_Status_Description = New TS_Response.TS_Status_Description


            Dim objTDRespStatus As TD_Response.TD_Response_Status = New TD_Response.TD_Response_Status
            objTDResp.ResponseStatus = objTDRespStatus

            Dim objWSCommon As WSCommonClasses = New WSCommonClasses
            Dim arrLstStatus As ArrayList = New ArrayList

            'to get info from CFI webmethod
            Dim objBalanceInfo As CFIBalanceInfo = New CFIBalanceInfo
            Dim blnIsanyDenied As Boolean = False
            Dim blPassZero As Boolean = False
            Dim strStatus As BucketStatus
            Dim dsTD As DataSet

            Dim dsCashInd As DataSet ' DataSet for Cash Indicator - WR67187 Walled Garden

            'Dim dtTD As DataTable
            'Dim drTS As DataRow
            'Dim strValue As String

            ' for MDVW
            Dim objMDVW_RMVP_Data As MDVW_RMVP_Data
            Dim objMDVW_RMVP_Strata As MDVW_RMVP_Strata
            Dim objResSPA5 As XBCLSPA5
            Dim strEnv As String = ""
            Dim objEnvDS As DataSet
            Dim MDVWcurTotalTotalDueAmt As Double
            Dim MDVWcurBasicTotalDueAmt As Double
            Dim MDVWcurNonBasicTotalDueAmt As Double
            Dim MDVWcurTollTotalDueAmt As Double
            Dim MDVWcurOcarTotalDueAmt As Double
            Dim MDVWcurNonTelecomeDueAmt As Double

            Dim MDVWcurTotalPastDueAmt As Double
            Dim MDVWcurBasicPastDueAmt As Double
            Dim MDVWcurNonBasicPastDueAmt As Double
            Dim MDVWcurTollPastDueAmt As Double
            Dim MDVWcurOcarPastDueAmt As Double
            Dim MDVWcurNonTelecomePastDueAmt As Double



            Dim MDVWcurTotalTrtbleAmt As Double
            Dim MDVWcurBasicTrtbleAmt As Double
            Dim MDVWcurNonBasicTrtbleAmt As Double
            Dim MDVWcurTollTrtbleAmt As Double
            Dim MDVWcurOcarTrtbleAmt As Double
            Dim MDVWcurNonTelecomeTrtbleAmt As Double

            ' For arbor
            Dim objGetBal As ArborWebservices
            Dim objArbResponse As ARBOR_TRX_RESPONSE = Nothing

            Dim objBill As BillDetails
            Dim strtmpOrg As String = Nothing


            Dim curTotalPastDueAmount As Double
            Dim curTotalTreatableAmount As Double
            Dim curTotalTotalAmountDue As Double
            Dim curTotalNoticeAmount As Double
            Dim curTotalSnpAmount As Double
            Dim objBalanceInfoDS As BalanceInfo = New BalanceInfo




            Try
                objTDResp.strRegionId = Request.strRegionId
                objTDResp.strAcctNum = Request.strAcctNum

                If (Not WSCommonClasses.CheckRegionType(Request.strRegionId.Trim)) Then
                    objTDRespStatus.strMessageId = "RMWTS001"
                    objTDRespStatus.strMessageDescription = "Invalid RegionId Specified"
                    Return objTDResp
                End If

                If (Request.strInputRequestType.ToUpper() = "A" Or Request.strInputRequestType.ToUpper() = "B") Then
                Else
                    objTDRespStatus.strMessageId = "RMWTS002"
                    objTDRespStatus.strMessageDescription = "Invalid Request Type."
                    Return objTDResp
                End If

                ' Call Treatment status method to populate status of the account
                objRequest.strAcctNum = Request.strAcctNum.Trim()
                objRequest.strApplicationId = Request.strApplicationId.Trim()
                objRequest.strInputRequestType = Request.strInputRequestType.Trim()
                objRequest.strOrg = Request.strOrg.Trim()
                objRequest.strRegionId = Request.strRegionId.Trim()

                objTSResp = (getTreatmentStatus(objRequest))

                ' DataSet for Cash Indicator - WR67187 Walled Garden
                'If Request.strApplicationId.Trim() = "WAG" Then
                'If (objTSResp.strBasicBucketStatusInd = BucketStatus.Denied Or objTSResp.strNonBasicBucketStatusInd = BucketStatus.Denied Or _
                '  objTSResp.strTollBucketStatusInd = BucketStatus.Denied Or objTSResp.strNonTelecomStatusInd = BucketStatus.Denied Or objTSResp.strOCARBucketStatusInd = BucketStatus.Denied) Then
                'If ((Request.strApplicationId.Trim().ToUpper() = "WAG") Or (Request.strApplicationId.Trim().ToUpper() = "VZCOM") Or (Request.strApplicationId.Trim().ToUpper() = "BILLPAY") Or (Request.strApplicationId.Trim().ToUpper() = "BILLVIEW") Or (Request.strApplicationId.Trim().ToUpper() = "MYACCOUNT") Or (Request.strApplicationId.Trim().ToUpper() = "IMG") Or (Request.strApplicationId.Trim().ToUpper() = "SBE")) Then
                Try
                    dsCashInd = MyBase.WSDataAccessObj.usp_GetCustomerAddressInfo(Request.strRegionId, Request.strAcctNum)

                    If (MyBase.WSDataAccessObj.IsEmptyRecordSet(dsCashInd)) Then
                        objTDRespStatus.strMessageId = "RMWTS001"
                        objTDRespStatus.strMessageDescription = "Invalid AcctNumber Specified"
                        'LogErrorFile.WriteLog("RMICWWS-getTreatmentDetails-CashOnlyInd  ", "Acct :" + Request.strAcctNum + "AppID :" + Request.strApplicationId + "Region :" + Request.strRegionId + "Org :" + Request.strOrg)
                        Return objTDResp
                    Else
                        If (MyBase.WSDataAccessObj.IsEmptyRecordSet(dsCashInd)) Then
                            objTSResp.strCashOnlyInd = "N"
                        ElseIf (dsCashInd.Tables(0).Rows(0)("strClass").ToString().Trim() = "") Then
                            objTDRespStatus.strMessageId = "RMWTS001"
                            objTDRespStatus.strMessageDescription = "Acct Not in Treatment"
                            'LogErrorFile.WriteLog("RMICWWS-getTreatmentDetails-CashOnlyInd  Not in Treat :", "Acct :" + Request.strAcctNum + "AppID :" + Request.strApplicationId + "Region :" + Request.strRegionId + "Org :" + Request.strOrg)
                            Return objTDResp
                        ElseIf (dsCashInd.Tables(0).Rows(0)("strCashOnlyInd").ToString().Trim() = "") Then
                            objTSResp.strCashOnlyInd = "N"
                        ElseIf (dsCashInd.Tables(0).Rows(0)("strCashOnlyInd").ToString().ToUpper() = "Y") Then
                            objTSResp.strCashOnlyInd = "Y"
                        Else
                            objTSResp.strCashOnlyInd = "N"
                        End If
                    End If

                Catch ex As Exception
                    LogErrorFile.WriteLog("RMICWWS-getTreatmentDetails-CashOnlyInd", ex.ToString())

                End Try

                'End If
                'End If

                'Get Balance details only if any one of the bucket is denied else send zeros
                If (objTSResp.strBasicBucketStatusInd = BucketStatus.Denied Or objTSResp.strNonBasicBucketStatusInd = BucketStatus.Denied Or _
                    objTSResp.strTollBucketStatusInd = BucketStatus.Denied Or objTSResp.strNonTelecomStatusInd = BucketStatus.Denied Or objTSResp.strOCARBucketStatusInd = BucketStatus.Denied) Then

                    blPassZero = False
                    blnIsanyDenied = True
                Else
                    blPassZero = False 'Need to send balance details even when all the buckets are live WR
                    blnIsanyDenied = False
                End If
                'blPassZero = False
                If blPassZero = False Then

                    ' Call Sproc to get the balances
                    dsTD = MyBase.WSDataAccessObj.usp_GetRMVPBalanceDetails(Request.strRegionId, Request.strAcctNum, Request.strOrg)

                    If (MyBase.WSDataAccessObj.IsEmptyRecordSet(dsTD)) Then

                        fn_initialize(objTSResp, objTDResp)
                        Return objTDResp
                    End If

                    If Request.strRegionId.Trim().ToUpper() = "VISION" Then
                        Dim objERAAccess As CBSSERAAccess = New CBSSERAAccess(Request.strRegionId)
                        ' Dim objBalanceInfoDS As BalanceInfo = New BalanceInfo
                        objBalanceInfoDS = objERAAccess.getBalanceInfo_DS(Request.strRegionId, Request.strAcctNum)

                        objTSResp.strCashOnlyInd = objBalanceInfoDS.strDSCashOnlyStatus
                    End If


                    If Request.strRegionId = "WEST" Then

                        'Arbor(WR22845 - Start)
                        If Request.strOrg = "ARB" Then
                            objGetBal = New ArborWebservices
                            objArbResponse = objGetBal.PostArborValues(Request.strAcctNum)

                        End If

                        Try
                            If (Request.strOrg <> "ARB") Then ' if Arbor Account skip the Icollect WS call
                                Dim objERAAccess As CBSSERAAccess = New CBSSERAAccess(Request.strRegionId)
                                objBalanceInfo = objERAAccess.getCBSS_CBSPCFA1_BalanceInfo(Request.strRegionId, Request.strAcctNum)
                            End If
                            ' Arbor WR22845 - end
                        Catch ex As Exception
                            LogErrorFile.WriteLog("RMICWWS-getCBSS_CBSPCFA1_BalanceInfo", ex.ToString())
                            objBalanceInfo.RequestStatus.strMessageId = "RMIEXPTN"
                            objBalanceInfo.RequestStatus.strMessageDescription = ex.ToString
                        End Try
                    End If

                    If ((Request.strRegionId = "NPD") Or (Request.strRegionId = "NY") Or (Request.strRegionId = "NE")) Then  'WR68132/WR68041
                        'If Request.strRegionId = "NPD" Then

                        Try
                            objBalanceInfo = fn_getCFIBalanceEastInfo(Request.strAcctNum, Request.strRegionId, Request.strOrg)
                            objTDResp.strBasicBundleInd = objTSResp.arrStatusDesc(0).strBasicBundleInd
                        Catch ex As Exception
                            LogErrorFile.WriteLog("RMICWWS-getCFIBalanceEastInfo_ForNPDNY", ex.ToString())
                            objBalanceInfo.RequestStatus.strMessageId = "RMIEXPTN"
                            objBalanceInfo.RequestStatus.strMessageDescription = ex.ToString
                        End Try
                    End If

                    '===== FOR MDVW
                    If Request.strRegionId = "MDVW" Then
                        Try
                            objMDVW_RMVP_Data = New MDVW_RMVP_Data("MDVW")
                            objMDVW_RMVP_Strata = New MDVW_RMVP_Strata("MDVW")

                            objEnvDS = MyBase.WSDataAccessObj.usp_GetCustomerAddressInfo(Request.strRegionId, Request.strAcctNum)

                            If Not (MyBase.WSDataAccessObj.IsEmptyRecordSet(objEnvDS)) Then
                                strEnv = objEnvDS.Tables(0).Rows(0)("strEnv")
                                strtmpOrg = objEnvDS.Tables(0).Rows(0)("strOrgCode")
                            End If

                            objResSPA5 = Nothing

                            'objResSPA5 = objMDVW_RMVP_Data.get_XBCLSPA5("MDVW", Request.strAcctNum.Trim(), strEnv.Trim(), 1)  'using SPA5
                            objResSPA5 = objMDVW_RMVP_Strata.get_XBCLSPA3_Icollect("MDVW", Request.strAcctNum.Trim())  ' using SPA3 for Strata

                            Try
                                objTDResp.strBasicBundleInd = objResSPA5.objAccountDtls.strBasicBundleInd 'DC Buketing Change
                            Catch ex As Exception
                            End Try


                            If (objResSPA5 Is Nothing) Then
                                fn_initialize(objTSResp, objTDResp)
                                Return objTDResp
                            End If


                            'For Each objBill In objResSPA5.arrLstBalanceInfoDetails
                            For i As Integer = 0 To objResSPA5.arrLstBalanceInfoDetails.Count - 1
                                objBill = objResSPA5.arrLstBalanceInfoDetails(i)
                                If (objBill.intMonthPastInd = 0) Then
                                    MDVWcurTotalTotalDueAmt = objBill.curTotBilled
                                    MDVWcurBasicTotalDueAmt = objBill.curBasicAmt
                                    MDVWcurNonBasicTotalDueAmt = objBill.curNonBasicAmt
                                    MDVWcurTollTotalDueAmt = objBill.curTollAmt
                                    MDVWcurOcarTotalDueAmt = objBill.curOcarAmt
                                    MDVWcurNonTelecomeDueAmt = objBill.curOcarAmt

                                End If
                                If (objBill.intMonthPastInd = 1) Then
                                    MDVWcurTotalPastDueAmt = objBill.curTotBilled
                                    MDVWcurBasicPastDueAmt = objBill.curBasicAmt
                                    MDVWcurNonBasicPastDueAmt = objBill.curNonBasicAmt
                                    MDVWcurTollPastDueAmt = objBill.curTollAmt
                                    MDVWcurOcarPastDueAmt = objBill.curOcarAmt
                                    MDVWcurNonTelecomePastDueAmt = objBill.curOcarAmt
                                End If

                                If (objBill.intMonthPastInd = 2) Then
                                    MDVWcurTotalTrtbleAmt = objBill.curTotBilled
                                    MDVWcurBasicTrtbleAmt = objBill.curBasicAmt
                                    MDVWcurNonBasicTrtbleAmt = objBill.curNonBasicAmt
                                    MDVWcurTollTrtbleAmt = objBill.curTollAmt
                                    MDVWcurOcarTrtbleAmt = objBill.curOcarAmt
                                    MDVWcurNonTelecomeTrtbleAmt = objBill.curOcarAmt
                                End If
                            Next

                        Catch ex As Exception
                            LogErrorFile.WriteLog("RMICWWS-getTreatmentDetails", ex.ToString())
                        End Try
                    End If

                    '========

                End If



                objTDResp.strBTNNum = objTDResp.strBTNNum
                ' If blPassZero = False Then
                If blnIsanyDenied = True Then
                    objTDResp.strPendingRestoral = dsTD.Tables(0).Rows(0).Item(2)
                Else
                    'Even the acct status is live - send the Restore order status 3/17/09 - Bala
                    objTDResp.strPendingRestoral = MyBase.WSDataAccessObj.usp_GetVZRestoreOrderStatus(Request.strRegionId, Request.strAcctNum, Request.strOrg)
                End If


                objTDResp.strBasicBucketStatusInd = objTSResp.strBasicBucketStatusInd
                objTDResp.strNonBasicBucketStatusInd = objTSResp.strNonBasicBucketStatusInd
                objTDResp.strTollBucketStatusInd = objTSResp.strTollBucketStatusInd
                objTDResp.strOCARBucketStatusInd = objTSResp.strOCARBucketStatusInd
                objTDResp.strNonTelecomStatusInd = objTSResp.strNonTelecomStatusInd
                objTDResp.strDAStatusInd = objTSResp.strDAStatusInd

                ' Added Cash only indicator for WR67187 Walled Garden
                objTDResp.strCashOnlyInd = objTSResp.strCashOnlyInd

                If blPassZero = False Then
                    'For Each objRow As DataRow In dsTD.Tables(0).Rows
                    For i As Integer = 0 To dsTD.Tables(0).Rows.Count - 1
                        Dim objRow As DataRow = dsTD.Tables(0).Rows(i)
                        objTDDesc = New TD_Response.TD_Status_Description

                        objTDDesc.strBucketName = objRow("strBucketName")
                        'Select Case objRow("strBucketName")
                        Select Case objTDDesc.strBucketName
                            Case "Basic", "Regulated"
                                strStatus = objTSResp.strBasicBucketStatusInd
                            Case "Non-Basic", "Non Regulated"
                                strStatus = objTSResp.strNonBasicBucketStatusInd
                            Case "Toll"
                                strStatus = objTSResp.strTollBucketStatusInd
                            Case "OCAR"
                                strStatus = objTSResp.strOCARBucketStatusInd
                            Case "NonTelecom", "Non Telecom"
                                strStatus = objTSResp.strNonTelecomStatusInd
                            Case "DA"
                                strStatus = objTSResp.strDAStatusInd
                        End Select
                        objTDDesc.strBucketStatusInd = strStatus
                        objTDDesc.dtmTerminationDate = objRow("TermDate")

                        objTDDesc.dtmTerminationDate = objTDDesc.dtmTerminationDate.ToShortDateString()
                        objTDDesc.dtmTransactionDate = New DateTime(1900, 1, 1)

                        Dim strTmp As String
                        strTmp = fn_getdesc(objTDDesc.strBucketName, "dtmBeginDate", objTSResp.arrStatusDesc)

                        If strTmp > "" Then
                            If IsDate(strTmp) Then
                                objTDDesc.dtmBeginDate = CDate(strTmp)
                            Else
                                objTDDesc.dtmBeginDate = New DateTime(1900, 1, 1)
                                objTDDesc.dtmTransactionDate = New DateTime(1900, 1, 1)
                            End If
                        Else
                            objTDDesc.dtmBeginDate = New DateTime(1900, 1, 1)
                            objTDDesc.dtmTransactionDate = New DateTime(1900, 1, 1)
                        End If

                        If Request.strRegionId.ToString.Trim() = "MDVW" Then
                            Dim dtTrtabledate As Date

                            dtTrtabledate = objRow("dtmTrtBillDate")

                            'Select Case objRow("strBucketName")
                            Select Case objTDDesc.strBucketName
                                Case "Basic", "Regulated"
                                    objTDDesc.curTreatableAmount = MDVWcurBasicTrtbleAmt
                                    objTDDesc.curPastDueAmount = MDVWcurBasicPastDueAmt
                                    objTDDesc.TotalAmountDue = MDVWcurBasicTotalDueAmt

                                Case "Non-Basic", "Non Regulated"
                                    objTDDesc.curTreatableAmount = MDVWcurNonBasicTrtbleAmt
                                    objTDDesc.curPastDueAmount = MDVWcurNonBasicPastDueAmt
                                    objTDDesc.TotalAmountDue = MDVWcurNonBasicTotalDueAmt

                                Case "Toll"
                                    objTDDesc.curTreatableAmount = MDVWcurTollTrtbleAmt
                                    objTDDesc.curPastDueAmount = MDVWcurTollPastDueAmt
                                    objTDDesc.TotalAmountDue = MDVWcurTollTotalDueAmt

                                Case "OCAR"
                                    objTDDesc.curPastDueAmount = 0.0
                                    objTDDesc.curTreatableAmount = 0.0
                                    objTDDesc.TotalAmountDue = 0.0
                                Case "NonTelecom", "Non Telecom"
                                    objTDDesc.curTreatableAmount = MDVWcurOcarTrtbleAmt
                                    objTDDesc.curPastDueAmount = MDVWcurOcarPastDueAmt
                                    objTDDesc.TotalAmountDue = MDVWcurOcarTotalDueAmt
                                Case "DA"
                                    objTDDesc.curPastDueAmount = 0.0
                                    objTDDesc.curTreatableAmount = 0.0
                                    objTDDesc.TotalAmountDue = 0.0
                            End Select

                        ElseIf Request.strRegionId.ToUpper().Trim() = "WEST" Then
                            ' Arbor WR22845 - 
                            If Request.strOrg = "ARB" Then ' if Arbor Account, get value from Sproc.
                                'Select Case objRow("strBucketName")
                                Select Case objTDDesc.strBucketName
                                    Case "Basic"
                                        objTDDesc.curPastDueAmount = 0.0
                                        objTDDesc.curTreatableAmount = 0.0
                                        objTDDesc.TotalAmountDue = 0.0

                                    Case "Non-Basic"

                                        'acct_real_time_bal = total due
                                        'acct_net_new_charges = current charges
                                        'acct_real_time_bal(-acct_net_new_charges = pastdue)
                                        'acct_real_time_bal = treatabledue
                                        'acct_curr_bal = total due before payment adjustment
                                        Dim strTotaldue As String
                                        Dim dblTotaldue As Double
                                        'FormatNumber(CDbl(strNumber), 2, -1, 0, -1). 
                                        Dim strCurrentcharge As String
                                        Dim dblCurrentcharge As String
                                        If Not objArbResponse.Response(0).acct_real_time_bal Is Nothing Then
                                            strTotaldue = objArbResponse.Response(0).acct_real_time_bal
                                            If strTotaldue = 0 Then
                                                dblTotaldue = 0.0
                                            Else
                                                dblTotaldue = FormatNumber(CDbl(Mid(strTotaldue, 1, strTotaldue.Length - 2) + "." + Right(strTotaldue, 2)), 2, -1, 0, -1)
                                            End If
                                        Else
                                            strTotaldue = 0.0
                                            dblTotaldue = 0.0
                                        End If
                                        If Not objArbResponse.Response(0).acct_net_new_charges Is Nothing Then
                                            strCurrentcharge = objArbResponse.Response(0).acct_net_new_charges
                                            If strCurrentcharge = 0 Then
                                                dblCurrentcharge = 0.0
                                            Else
                                                dblCurrentcharge = FormatNumber(CDbl(Mid(strCurrentcharge, 1, strCurrentcharge.Length - 2) + "." + Right(strCurrentcharge, 2)), 2, -1, 0, -1)
                                            End If

                                        Else
                                            strCurrentcharge = 0.0
                                            dblCurrentcharge = 0.0
                                        End If

                                        objTDDesc.curPastDueAmount = FormatNumber(CDbl(dblTotaldue - dblCurrentcharge), 2, -1, 0, -1)
                                        objTDDesc.curTreatableAmount = dblTotaldue
                                        objTDDesc.TotalAmountDue = dblTotaldue


                                    Case "Toll"
                                        objTDDesc.curPastDueAmount = 0.0
                                        objTDDesc.curTreatableAmount = 0.0
                                        objTDDesc.TotalAmountDue = 0.0
                                    Case "OCAR"
                                        objTDDesc.curPastDueAmount = 0.0
                                        objTDDesc.curTreatableAmount = 0.0
                                        objTDDesc.TotalAmountDue = 0.0
                                    Case "NonTelecom"
                                        objTDDesc.curPastDueAmount = 0.0
                                        objTDDesc.curTreatableAmount = 0.0
                                        objTDDesc.TotalAmountDue = 0.0
                                    Case "DA"
                                        objTDDesc.curPastDueAmount = 0.0
                                        objTDDesc.curTreatableAmount = 0.0
                                        objTDDesc.TotalAmountDue = 0.0
                                End Select
                                ' Arbor WR22845 - End
                            Else
                                'Select Case objRow("strBucketName") ' For non Arbor , Get value from Icollect .. [BAU]
                                Select Case objTDDesc.strBucketName
                                    Case "Basic"
                                        objTDDesc.curPastDueAmount = objBalanceInfo.curPastDueBasic
                                        objTDDesc.curTreatableAmount = objBalanceInfo.curTreatableDueBasic

                                        objTDDesc.TotalAmountDue = objBalanceInfo.curTotalDueBasic

                                    Case "Non-Basic"
                                        objTDDesc.curPastDueAmount = objBalanceInfo.curPastDueNonBasic
                                        objTDDesc.curTreatableAmount = objBalanceInfo.curTreatableDueNonBasic

                                        objTDDesc.TotalAmountDue = objBalanceInfo.curTotalDueNonBasic
                                    Case "Toll"
                                        objTDDesc.curPastDueAmount = objBalanceInfo.curPastDueToll
                                        objTDDesc.curTreatableAmount = objBalanceInfo.curTreatableDueToll

                                        objTDDesc.TotalAmountDue = objBalanceInfo.curTotalDueToll
                                    Case "OCAR"
                                        objTDDesc.curPastDueAmount = 0.0
                                        objTDDesc.curTreatableAmount = 0.0
                                        objTDDesc.TotalAmountDue = 0.0
                                    Case "NonTelecom"
                                        objTDDesc.curPastDueAmount = 0.0
                                        objTDDesc.curTreatableAmount = 0.0
                                        objTDDesc.TotalAmountDue = 0.0
                                    Case "DA"
                                        objTDDesc.curPastDueAmount = 0.0
                                        objTDDesc.curTreatableAmount = 0.0
                                        objTDDesc.TotalAmountDue = 0.0
                                End Select
                            End If

                        ElseIf Request.strRegionId.ToUpper().Trim() = "NPD" Or Request.strRegionId.ToUpper().Trim() = "NY" Or Request.strRegionId.ToUpper().Trim() = "NE" Then 'WR68132/WR68041
                            'ElseIf Request.strRegionId.ToUpper().Trim() = "NPD" Then
                            'Select Case objRow("strBucketName")
                            Select Case objTDDesc.strBucketName
                                Case "Basic"
                                    objTDDesc.curPastDueAmount = objBalanceInfo.curPastDueBasic
                                    objTDDesc.curTreatableAmount = objBalanceInfo.curTreatableDueBasic

                                    objTDDesc.TotalAmountDue = objBalanceInfo.curTotalDueBasic

                                Case "Non-Basic"
                                    objTDDesc.curPastDueAmount = objBalanceInfo.curPastDueNonBasic
                                    objTDDesc.curTreatableAmount = objBalanceInfo.curTreatableDueNonBasic

                                    objTDDesc.TotalAmountDue = objBalanceInfo.curTotalDueNonBasic
                                Case "Toll"
                                    objTDDesc.curPastDueAmount = objBalanceInfo.curPastDueToll
                                    objTDDesc.curTreatableAmount = objBalanceInfo.curTreatableDueToll

                                    objTDDesc.TotalAmountDue = objBalanceInfo.curTotalDueToll

                                Case "OCAR"
                                    objTDDesc.curPastDueAmount = 0.0
                                    objTDDesc.curTreatableAmount = 0.0
                                    objTDDesc.TotalAmountDue = 0.0
                                    If Request.strRegionId.ToUpper().Trim() = "NY" Then
                                        objTDDesc.curPastDueAmount = objBalanceInfo.curPastDueOCAR
                                        objTDDesc.curTreatableAmount = objBalanceInfo.curTreatableDueOCAR
                                        objTDDesc.TotalAmountDue = objBalanceInfo.curTotalDueOCAR
                                    End If
                                Case "NonTelecom"
                                    objTDDesc.curPastDueAmount = 0.0
                                    objTDDesc.curTreatableAmount = 0.0
                                    objTDDesc.TotalAmountDue = 0.0
                                Case "DA"
                                    objTDDesc.curPastDueAmount = 0.0
                                    objTDDesc.curTreatableAmount = 0.0
                                    objTDDesc.TotalAmountDue = 0.0
                            End Select
                        ElseIf Request.strRegionId.ToUpper().Trim() = "VISION" Then
                            Select Case objTDDesc.strBucketName
                                Case "Basic"

                                    objTDDesc.curPastDueAmount = objBalanceInfoDS.curPastDueBasic
                                    objTDDesc.curTreatableAmount = objBalanceInfoDS.curTreatableDueBasic
                                    objTDDesc.TotalAmountDue = objBalanceInfoDS.curTotalDueBasic

                                Case "Non-Basic"
                                    objTDDesc.curPastDueAmount = objBalanceInfoDS.curPastDueNonBasic
                                    objTDDesc.curTreatableAmount = objBalanceInfoDS.curTreatableDueNonBasic

                                    objTDDesc.TotalAmountDue = objBalanceInfoDS.curTotalDueNonBasic
                                Case "Toll"
                                    objTDDesc.curPastDueAmount = objBalanceInfoDS.curPastDueToll
                                    objTDDesc.curTreatableAmount = objBalanceInfoDS.curTreatableDueToll

                                    objTDDesc.TotalAmountDue = objBalanceInfoDS.curTotalDueToll
                                Case "OCAR"
                                    objTDDesc.curPastDueAmount = 0.0
                                    objTDDesc.curTreatableAmount = 0.0
                                    objTDDesc.TotalAmountDue = 0.0
                                Case "NonTelecom"
                                    objTDDesc.curPastDueAmount = 0.0
                                    objTDDesc.curTreatableAmount = 0.0
                                    objTDDesc.TotalAmountDue = 0.0
                                Case "DA"
                                    objTDDesc.curPastDueAmount = 0.0
                                    objTDDesc.curTreatableAmount = 0.0
                                    objTDDesc.TotalAmountDue = 0.0
                            End Select
                        Else
                            objTDDesc.curPastDueAmount = objRow("CurPastdueamount")
                            objTDDesc.curTreatableAmount = objRow("curTreatableAmount")
                            objTDDesc.TotalAmountDue = objRow("curTotalDueAmount")

                        End If


                        objTDDesc.curNoticeAmount = objRow("curNoticeAmount")
                        objTDDesc.curSnpAmount = objRow("curSnpAmount")

                        'curTotalNoticeAmount = curTotalNoticeAmount + objTDDesc.curNoticeAmount
                        'curTotalSnpAmount = curTotalSnpAmount + objTDDesc.curSnpAmount

                        curTotalPastDueAmount = Math.Round(curTotalPastDueAmount + objTDDesc.curPastDueAmount, 2)
                        curTotalTreatableAmount = Math.Round(curTotalTreatableAmount + objTDDesc.curTreatableAmount, 2)
                        curTotalTotalAmountDue = Math.Round(curTotalTotalAmountDue + objTDDesc.TotalAmountDue, 2)
                        curTotalNoticeAmount = Math.Round(curTotalNoticeAmount + objTDDesc.curNoticeAmount, 2)
                        curTotalSnpAmount = Math.Round(curTotalPastDueAmount + objTDDesc.curSnpAmount, 2)

                        arrLstStatus.Add(objTDDesc)
                        objTDDesc = Nothing

                    Next
                    '75288RM1-WAG Sum of Total Trt  Amount 07Mar12
                    'If Request.strApplicationId.Trim() <> "WAG" Then
                    'RMVP Change for separate Segment for Min Rest Amount WR68041
                    objTDDesc = New TD_Response.TD_Status_Description
                    objTDDesc.strBucketName = "ACCOUNT"
                    If (blnIsanyDenied = True) Then
                        objTDDesc.strBucketStatusInd = BucketStatus.Denied
                    Else
                        objTDDesc.strBucketStatusInd = BucketStatus.Live
                    End If

                    objTDDesc.dtmTerminationDate = New DateTime(1900, 1, 1)
                    objTDDesc.dtmBeginDate = New DateTime(1900, 1, 1)
                    objTDDesc.dtmTransactionDate = New DateTime(1900, 1, 1)
                    objTDDesc.curPastDueAmount = curTotalPastDueAmount
                    objTDDesc.curTreatableAmount = curTotalTreatableAmount
                    objTDDesc.TotalAmountDue = curTotalTotalAmountDue
                    objTDDesc.curNoticeAmount = curTotalNoticeAmount
                    objTDDesc.curSnpAmount = curTotalSnpAmount
                    arrLstStatus.Add(objTDDesc)
                    objTDDesc = Nothing
                    'End If
                    If ((Request.strApplicationId.Trim().ToUpper() = "VZCOM") Or (Request.strApplicationId.Trim().ToUpper() = "BILLPAY") Or (Request.strApplicationId.Trim().ToUpper() = "BILLVIEW") Or (Request.strApplicationId.Trim().ToUpper() = "MYACCOUNT") Or (Request.strApplicationId.Trim().ToUpper() = "IMG") Or (Request.strApplicationId.Trim().ToUpper() = "SBE")) Then
                        Dim DsEventData As New DataSet
                        Dim WSDataAccessObj As WSDataAccessGeneric = New WSDataAccessGeneric(objRequest.strRegionId)
                        DsEventData = WSDataAccessObj.usp_GetTreatmentData(objRequest.strAcctNum, objRequest.strOrg, objRequest.strApplicationId, objRequest.strRegionId)
                        objTDDesc = New TD_Response.TD_Status_Description
                        DsEventData = WSDataAccessObj.usp_GetTreatmentData(objRequest.strAcctNum, objRequest.strOrg, objRequest.strApplicationId, objRequest.strRegionId)
                        objTDDesc = New TD_Response.TD_Status_Description
                        objTDDesc.strBucketName = "TreatmentData"
                        objTDDesc.dtmTerminationDate = New DateTime(1900, 1, 1)
                        objTDDesc.dtmBeginDate = New DateTime(1900, 1, 1)
                        objTDDesc.dtmTransactionDate = New DateTime(1900, 1, 1)
                        If (DsEventData.Tables.Count > 0) Then
                            If (DsEventData.Tables(0).Rows.Count > 0) Then
                                objTDDesc.intEventId = DsEventData.Tables(0).Rows(0)("intSeqid")
                                objTDDesc.strEventType = DsEventData.Tables(0).Rows(0)("strEventType")
                                objTDDesc.strEventDesc = DsEventData.Tables(0).Rows(0)("strResultDesc")
                                objTDDesc.curEventAmount = DsEventData.Tables(0).Rows(0)("curAmount")
                                objTDDesc.dtmTransactionDate = DsEventData.Tables(0).Rows(0)("dtmTransactionDate")
                                objTDDesc.strMessage = DsEventData.Tables(0).Rows(0)("strText")

                                If objTDDesc.intEventId = "6" Then
                                    objTDDesc.curEventAmount = curTotalTreatableAmount
                                    objTDDesc.strMessage = objTDDesc.strMessage.Replace("0.00", objTDDesc.curEventAmount.ToString())
                                End If
                                If (objTDDesc.intEventId = "1") Or (objTDDesc.intEventId = "2") Or (objTDDesc.intEventId = "3") Then '76633 
                                    objTDDesc.applicableForView = "Y"
                                End If
                            Else
                                objTDDesc.intEventId = 0
                                objTDDesc.strEventType = ""
                                objTDDesc.strEventDesc = ""
                                objTDDesc.curEventAmount = 0.0
                                objTDDesc.dtmTransactionDate = New DateTime(1900, 1, 1)
                                objTDDesc.strMessage = ""
                            End If
                        Else
                            objTDDesc.intEventId = 0
                            objTDDesc.strEventType = ""
                            objTDDesc.strEventDesc = ""
                            objTDDesc.curEventAmount = 0.0
                            objTDDesc.dtmTransactionDate = New DateTime(1900, 1, 1)
                            objTDDesc.strMessage = ""
                        End If

                        If (blnIsanyDenied = True) And curTotalTreatableAmount > 0 Then
                            If curTotalTreatableAmount > 0 Then
                                objTDDesc.intEventId = "6"
                                objTDDesc.strEventType = "SUSPEND"
                                objTDDesc.strEventDesc = "Suspension Status"
                                objTDDesc.curEventAmount = curTotalTreatableAmount
                                objTDDesc.dtmTransactionDate = New DateTime(1900, 1, 1)
                                objTDDesc.dtmTerminationDate = DirectCast(arrLstStatus.Item(0), Verizon.RMICW.WebServices.TD_Response.TD_Status_Description).dtmTerminationDate
                                If ((Request.strApplicationId.Trim().ToUpper() = "VZCOM") Or (Request.strApplicationId.Trim().ToUpper() = "BILLPAY") Or (Request.strApplicationId.Trim().ToUpper() = "BILLVIEW")) Then 'Or (Request.strApplicationId.Trim().ToUpper() = "MYACCOUNT")) Then
                                    objTDDesc.strMessage = "You can reconnect services that have been suspended due to non-payment by paying $" + curTotalTreatableAmount.ToString() + " today. Once this payment is received, services will be restored within 1 hour.  Please keep in mind, if this payment is not received by " + objTDDesc.dtmTerminationDate + ", you will need to reapply for new service.  You can make multiple payments towards your balance as long as $" + curTotalTreatableAmount.ToString() + " is received before " + objTDDesc.dtmTerminationDate + "."
                                Else
                                    objTDDesc.strMessage = "You can reconnect services that have been suspended due to non-payment by paying $" + curTotalTreatableAmount.ToString() + "  today."
                                End If
                                ' objTDDesc.dtmTerminationDate = New DateTime(1900, 1, 1)
                                objTDDesc.dtmBeginDate = New DateTime(1900, 1, 1)

                            End If
                        End If
                    End If


                    arrLstStatus.Add(objTDDesc)
                    objTDDesc = Nothing
                Else 'The Treatment data should be sent either of the case [Snipped/LIVE]

                    ''intialize all values to zeros
                    'fn_initialize(objTSResp, objTDResp)

                    Dim intIndex As Integer = 0

                    For intIndex = 0 To arrBucket.Length - 1
                        objTDDesc = New TD_Response.TD_Status_Description
                        objTDDesc.strBucketName = arrBucket(intIndex).ToString

                        Select Case arrBucket(intIndex).ToString
                            Case "Basic"
                                strStatus = objTSResp.strBasicBucketStatusInd
                            Case "Non-Basic"
                                strStatus = objTSResp.strNonBasicBucketStatusInd
                            Case "Toll"
                                strStatus = objTSResp.strTollBucketStatusInd
                            Case "OCAR"
                                strStatus = objTSResp.strOCARBucketStatusInd
                            Case "NonTelecom"
                                strStatus = objTSResp.strNonTelecomStatusInd
                            Case "DA"
                                strStatus = objTSResp.strDAStatusInd
                        End Select


                        objTDDesc.strBucketStatusInd = strStatus

                        objTDDesc.dtmTransactionDate = New DateTime(1900, 1, 1)

                        Dim strTmp As String
                        strTmp = fn_getdesc(objTDDesc.strBucketName, "dtmBeginDate", objTSResp.arrStatusDesc)

                        If strTmp > "" Then
                            If IsDate(strTmp) Then
                                objTDDesc.dtmTerminationDate = CDate(strTmp)
                                objTDDesc.dtmBeginDate = CDate(strTmp)
                            Else
                                objTDDesc.dtmTerminationDate = New DateTime(1900, 1, 1)
                                objTDDesc.dtmBeginDate = New DateTime(1900, 1, 1)
                            End If
                        Else
                            objTDDesc.dtmTerminationDate = New DateTime(1900, 1, 1)
                            objTDDesc.dtmBeginDate = New DateTime(1900, 1, 1)
                        End If

                        objTDDesc.curPastDueAmount = 0.0
                        objTDDesc.curTreatableAmount = 0.0
                        objTDDesc.curNoticeAmount = 0.0
                        objTDDesc.curSnpAmount = 0.0
                        objTDDesc.TotalAmountDue = 0.0
                        arrLstStatus.Add(objTDDesc)
                        objTDDesc = Nothing

                    Next

                    If ((Request.strApplicationId.Trim().ToUpper() = "VZCOM") Or (Request.strApplicationId.Trim().ToUpper() = "BILLPAY") Or (Request.strApplicationId.Trim().ToUpper() = "BILLVIEW") Or (Request.strApplicationId.Trim().ToUpper() = "MYACCOUNT") Or (Request.strApplicationId.Trim().ToUpper() = "IMG") Or (Request.strApplicationId.Trim().ToUpper() = "SBE")) Then
                        Dim DsEventData As New DataSet
                        Dim WSDataAccessObj As WSDataAccessGeneric = New WSDataAccessGeneric(objRequest.strRegionId)
                        DsEventData = WSDataAccessObj.usp_GetTreatmentData(objRequest.strAcctNum, objRequest.strOrg, objRequest.strApplicationId, objRequest.strRegionId)
                        objTDDesc = New TD_Response.TD_Status_Description
                        DsEventData = WSDataAccessObj.usp_GetTreatmentData(objRequest.strAcctNum, objRequest.strOrg, objRequest.strApplicationId, objRequest.strRegionId)
                        objTDDesc = New TD_Response.TD_Status_Description
                        objTDDesc.strBucketName = "TreatmentData"
                        objTDDesc.dtmTerminationDate = New DateTime(1900, 1, 1)
                        objTDDesc.dtmBeginDate = New DateTime(1900, 1, 1)

                        If (DsEventData.Tables.Count > 0) Then
                            If (DsEventData.Tables(0).Rows.Count > 0) Then
                                objTDDesc.intEventId = DsEventData.Tables(0).Rows(0)("intSeqid")
                                objTDDesc.strEventType = DsEventData.Tables(0).Rows(0)("strEventType")
                                objTDDesc.strEventDesc = DsEventData.Tables(0).Rows(0)("strResultDesc")
                                objTDDesc.curEventAmount = DsEventData.Tables(0).Rows(0)("curAmount")
                                objTDDesc.dtmTransactionDate = DsEventData.Tables(0).Rows(0)("dtmTransactionDate")
                                objTDDesc.strMessage = DsEventData.Tables(0).Rows(0)("strText")
                                objTDDesc.dtmBeginDate = objTDDesc.dtmTransactionDate
                                If objTDDesc.intEventId = "6" Then
                                    objTDDesc.curEventAmount = curTotalTreatableAmount
                                    objTDDesc.strMessage = objTDDesc.strMessage.Replace("0.00", objTDDesc.curEventAmount.ToString())
                                End If
                                If (objTDDesc.intEventId = "1") Or (objTDDesc.intEventId = "2") Or (objTDDesc.intEventId = "3") Then '76633 
                                    objTDDesc.applicableForView = "Y"
                                End If
                            Else
                                objTDDesc.intEventId = 0
                                objTDDesc.strEventType = ""
                                objTDDesc.strEventDesc = ""
                                objTDDesc.curEventAmount = 0.0
                                objTDDesc.dtmTransactionDate = New DateTime(1900, 1, 1)
                                objTDDesc.strMessage = ""
                                objTDDesc.applicableForView = ""
                            End If
                        Else
                            objTDDesc.intEventId = 0
                            objTDDesc.strEventType = ""
                            objTDDesc.strEventDesc = ""
                            objTDDesc.curEventAmount = 0.0
                            objTDDesc.dtmTransactionDate = New DateTime(1900, 1, 1)
                            objTDDesc.strMessage = ""
                            objTDDesc.applicableForView = ""
                        End If
                    End If

                    If (blnIsanyDenied = True) And curTotalTreatableAmount > 0 Then
                        If curTotalTreatableAmount > 0 Then
                            objTDDesc.intEventId = "6"
                            objTDDesc.strEventType = "SUSPEND"
                            objTDDesc.strEventDesc = "Suspension Status"
                            objTDDesc.curEventAmount = curTotalTreatableAmount
                            objTDDesc.dtmTransactionDate = New DateTime(1900, 1, 1)
                            objTDDesc.dtmTerminationDate = New DateTime(1900, 1, 1)
                            objTDDesc.dtmBeginDate = New DateTime(1900, 1, 1)

                            'objTDDesc.strMessage = "You can reconnect services that have been suspended due to non-payment by paying $" + curTotalTreatableAmount.ToString() + "  today."
                            objTDDesc.strMessage = "You can reconnect services that have been suspended due to non-payment by paying $" + curTotalTreatableAmount.ToString() + "  today. Once this payment is received, services will be restored within 1 hour.Please keep in mind, if this payment is not received by " + objTDDesc.dtmTerminationDate + ", you will need to reapply for new service. You can make multiple payments towards your balance as long as " + curTotalTreatableAmount.ToString() + " is received before " + objTDDesc.dtmTerminationDate + "."

                            objTDDesc.dtmTerminationDate = DirectCast(arrLstStatus.Item(0), Verizon.RMICW.WebServices.TD_Response.TD_Status_Description).dtmTerminationDate
                            If ((Request.strApplicationId.Trim().ToUpper() = "VZCOM") Or (Request.strApplicationId.Trim().ToUpper() = "BILLPAY") Or (Request.strApplicationId.Trim().ToUpper() = "BILLVIEW")) Then 'Or (Request.strApplicationId.Trim().ToUpper() = "MYACCOUNT")) Then
                                objTDDesc.strMessage = "You can reconnect services that have been suspended due to non-payment by paying $" + curTotalTreatableAmount.ToString() + " today. Once this payment is received, services will be restored within 1 hour.  Please keep in mind, if this payment is not received by " + objTDDesc.dtmTerminationDate + ", you will need to reapply for new service.  You can make multiple payments towards your balance as long as $" + curTotalTreatableAmount.ToString() + " is received before " + objTDDesc.dtmTerminationDate + "."
                            Else
                                objTDDesc.strMessage = "You can reconnect services that have been suspended due to non-payment by paying $" + curTotalTreatableAmount.ToString() + "  today."
                            End If


                        End If
                    End If

                    arrLstStatus.Add(objTDDesc)
                    objTDDesc = Nothing
                End If

                objTDResp.arrStatusDesc = CType(arrLstStatus.ToArray(GetType(TD_Response.TD_Status_Description)), TD_Response.TD_Status_Description())

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS - getTreatmentDetails", Request.strAcctNum + ex.ToString())
            End Try

            ' check the number of buckets and do the sumup

            If Request.strRegionId.ToUpper().Trim() = "MDVW" Then
                fn_CheckNumBucketsAndSum(objTDResp, strtmpOrg)
            End If



            Return objTDResp

        End Function
        Private Function fn_getCFIBalanceEastInfo(ByVal strAcctnum As String, ByVal strRegionCd As String, ByVal strOrg As String) As CFIBalanceInfo

            Dim objERAAccess As CBSSERAAccess
            Dim objNPDBalance As New CFIBalanceInfo
            Try

                objERAAccess = New CBSSERAAccess(strRegionCd)

                Dim objRMICWwebsvcRetData As New CFIBalanceInfoAccum
                Dim objRMICWwebsvcInput As New CFIBalanceInput
                'Dim objCBSPCFA1_BalanceInfo As New CBSPCFA1_BalanceInfo


                Dim dtmbilldate As Date = "1900/01/01"
                Dim dtmbilldueDate As Date = "1900/01/01"
                Dim dtmProcessDate As Date = "1900/01/01"
                dtmProcessDate = Now.Date()
                Dim dtmPaybydate As Date = "1900/01/01"


                Dim dsCA As DataSet

                objRMICWwebsvcInput.strRegioncd = Trim(strRegionCd)
                objRMICWwebsvcInput.strAcctNum = Trim(strAcctnum)
                'objRMICWwebsvcInput.strGetPPX = 0
                objRMICWwebsvcInput.strGetPPX = "Y" '68041
                objRMICWwebsvcInput.strGetClaim = "N"
                objRMICWwebsvcInput.strOrg = Trim(strOrg)
                objRMICWwebsvcInput.curPPXAmt = 0
                objRMICWwebsvcInput.curBasicClaimAmt = 0
                objRMICWwebsvcInput.curNonBasicClaimAmt = 0
                objRMICWwebsvcInput.curTollClaimAmt = 0
                objRMICWwebsvcInput.curOCARClaimAmt = 0
                objRMICWwebsvcInput.dtmBillDate = dtmbilldate
                objRMICWwebsvcInput.dtmBillDueDate = dtmbilldueDate



                Dim strCategoryCd As String
                'Dim strBalanceType As String
                'Dim curCurrentCharges As Double
                'Dim cur30DaysCharges As Double
                'Dim cur60DaysCharges As Double
                'Dim cur90DaysCharges As Double
                'Dim cur120DaysCharges As Double
                'Dim curWriteOffAmt As Double
                'Dim curTotalCharges As Double


                Try


                    objRMICWwebsvcRetData = objERAAccess.getCBSS_CBSPCFA1_BalanceInfoEast(objRMICWwebsvcInput)

                    Dim sw As New StringWriter
                    Dim outXML As String

                    Dim ser As New XmlSerializer(objRMICWwebsvcRetData.GetType)
                    ser.Serialize(sw, objRMICWwebsvcRetData)

                    dsCA = MyBase.WSDataAccessObj.usp_GetCustomerAddressInfo(strRegionCd, strAcctnum)
                    If Not (MyBase.WSDataAccessObj.IsEmptyRecordSet(dsCA)) Then
                        dtmbilldueDate = dsCA.Tables(0).Rows(0)("dtmbilldueDate")

                    End If


                    If (objRMICWwebsvcRetData.RequestStatus.strMessageId = "100") Then
                        CommonLibrary.LogErrorFile.WriteLog("RMICW_OCM1Data", "Account Not Found")
                    Else
                        outXML = sw.ToString
                        'Dim dslogging As String
                        'Dim strlogvalue As String
                        'Dim XMLInput As String

                        '68041- get paybydate from CFA1
                        If Not objRMICWwebsvcRetData.arrLstBalanceDetails Is Nothing Then
                            Dim cfidate As CBSPCFA1_BalanceInfo
                            'For Each cfidate In objRMICWwebsvcRetData.arrLstBalanceDetails
                            For i As Integer = 0 To objRMICWwebsvcRetData.arrLstBalanceDetails.Count - 1
                                cfidate = objRMICWwebsvcRetData.arrLstBalanceDetails(i)
                                If Not cfidate.PrevPaymentDueDt Is Nothing Then
                                    If cfidate.PrevPaymentDueDt > "" Then
                                        If IsDate(cfidate.PrevPaymentDueDt) Then
                                            dtmPaybydate = CDate(cfidate.PrevPaymentDueDt)
                                        End If
                                    End If

                                End If

                            Next
                        End If
                        If objRMICWwebsvcRetData.arrLstBalanceBucketLevel Is Nothing Then
                            'initialize the balance to zero
                            objNPDBalance.curTotalDueBasic = 0
                            objNPDBalance.curPastDueBasic = 0
                            objNPDBalance.curTreatableDueBasic = 0
                            objNPDBalance.curTotalDueNonBasic = 0
                            objNPDBalance.curPastDueNonBasic = 0
                            objNPDBalance.curTreatableDueNonBasic = 0
                            objNPDBalance.curTotalDueToll = 0
                            objNPDBalance.curPastDueToll = 0
                            objNPDBalance.curTreatableDueToll = 0
                            objNPDBalance.curTotalDueOCAR = 0
                            objNPDBalance.curPastDueOCAR = 0
                            objNPDBalance.curTreatableDueOCAR = 0
                            objNPDBalance.curTotalDueCPE = 0
                            objNPDBalance.curpastDueCPE = 0
                            objNPDBalance.curTreatableDueCPE = 0
                            objNPDBalance.curTotalDueIP = 0
                            objNPDBalance.curPastDueIP = 0
                            objNPDBalance.curTreatableDueIP = 0
                            '===
                        Else

                            Dim cfir As CFIBalanceBucketLevel
                            'For Each cfir In objRMICWwebsvcRetData.arrLstBalanceBucketLevel
                            For j As Integer = 0 To objRMICWwebsvcRetData.arrLstBalanceBucketLevel.Count - 1
                                cfir = objRMICWwebsvcRetData.arrLstBalanceBucketLevel(j)

                                strCategoryCd = cfir.strCategoryCd
                                If strCategoryCd = "B" Then

                                    objNPDBalance.curTotalDueBasic = cfir.curTotalCharges
                                    Dim objTrtBalinfo As CBSPCFA1_BalanceInfo

                                    'For Each objTrtBalinfo In objRMICWwebsvcRetData.arrLstBalanceDetails
                                    For i As Integer = 0 To objRMICWwebsvcRetData.arrLstBalanceDetails.Count - 1
                                        objTrtBalinfo = objRMICWwebsvcRetData.arrLstBalanceDetails(i)
                                        If objTrtBalinfo.strBillingCategoryCode = "B" And objTrtBalinfo.strDataRecordType = "ET" Then
                                            objNPDBalance.curTreatableDueBasic = objTrtBalinfo.curTotalTreatableAmount

                                        End If
                                    Next



                                    'If (dtmbilldueDate.CompareTo(dtmProcessDate) > 0) Then
                                    If (dtmPaybydate.CompareTo(dtmProcessDate) > 0) Then '68041
                                        objNPDBalance.curPastDueBasic = cfir.curTotalCharges - (cfir.curCurrentCharges + cfir.cur30DaysCharges)
                                    Else
                                        objNPDBalance.curPastDueBasic = cfir.curTotalCharges
                                    End If

                                ElseIf strCategoryCd = "N" Then
                                    objNPDBalance.curTotalDueNonBasic = cfir.curTotalCharges

                                    'objNPDBalance.curTreatableDueNonBasic = cfir.curTotalTreatableAmount

                                    Dim objTrtBalinfo As CBSPCFA1_BalanceInfo
                                    'For Each objTrtBalinfo In objRMICWwebsvcRetData.arrLstBalanceDetails
                                    For i As Integer = 0 To objRMICWwebsvcRetData.arrLstBalanceDetails.Count - 1
                                        objTrtBalinfo = objRMICWwebsvcRetData.arrLstBalanceDetails(i)
                                        If objTrtBalinfo.strBillingCategoryCode = "N" And objTrtBalinfo.strDataRecordType = "ET" Then
                                            objNPDBalance.curTreatableDueNonBasic = objTrtBalinfo.curTotalTreatableAmount
                                        End If
                                    Next



                                    'If (dtmbilldueDate.CompareTo(dtmProcessDate) > 0) Then
                                    If (dtmPaybydate.CompareTo(dtmProcessDate) > 0) Then '68041
                                        objNPDBalance.curPastDueNonBasic = cfir.curTotalCharges - (cfir.curCurrentCharges + cfir.cur30DaysCharges)
                                    Else
                                        objNPDBalance.curPastDueNonBasic = cfir.curTotalCharges
                                    End If



                                ElseIf strCategoryCd = "T" Then
                                    objNPDBalance.curTotalDueToll = cfir.curTotalCharges

                                    'objNPDBalance.curTreatableDueToll = cfir.curTotalTreatableAmount

                                    Dim objTrtBalinfo As CBSPCFA1_BalanceInfo
                                    'For Each objTrtBalinfo In objRMICWwebsvcRetData.arrLstBalanceDetails
                                    For i As Integer = 0 To objRMICWwebsvcRetData.arrLstBalanceDetails.Count - 1
                                        objTrtBalinfo = objRMICWwebsvcRetData.arrLstBalanceDetails(i)
                                        If objTrtBalinfo.strBillingCategoryCode = "T" And objTrtBalinfo.strDataRecordType = "ET" Then
                                            objNPDBalance.curTreatableDueToll = objTrtBalinfo.curTotalTreatableAmount
                                        End If
                                    Next

                                    'If (dtmbilldueDate.CompareTo(dtmProcessDate) > 0) Then
                                    If (dtmPaybydate.CompareTo(dtmProcessDate) > 0) Then '68041
                                        objNPDBalance.curPastDueToll = cfir.curTotalCharges - (cfir.curCurrentCharges + cfir.cur30DaysCharges)
                                    Else
                                        objNPDBalance.curPastDueToll = cfir.curTotalCharges
                                    End If

                                ElseIf strCategoryCd = "O" Then
                                    objNPDBalance.curTotalDueOCAR = cfir.curTotalCharges

                                    'objNPDBalance.curTreatableDueOCAR = cfir.curTotalTreatableAmount

                                    Dim objTrtBalinfo As CBSPCFA1_BalanceInfo
                                    'For Each objTrtBalinfo In objRMICWwebsvcRetData.arrLstBalanceDetails
                                    For i As Integer = 0 To objRMICWwebsvcRetData.arrLstBalanceDetails.Count - 1
                                        objTrtBalinfo = objRMICWwebsvcRetData.arrLstBalanceDetails(i)
                                        If objTrtBalinfo.strBillingCategoryCode = "O" And objTrtBalinfo.strDataRecordType = "ET" Then
                                            objNPDBalance.curTreatableDueOCAR = objTrtBalinfo.curTotalTreatableAmount
                                        End If
                                    Next


                                    'If (dtmbilldueDate.CompareTo(dtmProcessDate) > 0) Then
                                    If (dtmPaybydate.CompareTo(dtmProcessDate) > 0) Then '68041
                                        objNPDBalance.curPastDueOCAR = cfir.curTotalCharges - (cfir.curCurrentCharges + cfir.cur30DaysCharges)
                                    Else
                                        objNPDBalance.curPastDueOCAR = cfir.curTotalCharges
                                    End If

                                ElseIf strCategoryCd = "CPE" Then
                                    objNPDBalance.curTotalDueCPE = cfir.curTotalCharges

                                    'objNPDBalance.curTreatableDueCPE = cfir.curTotalTreatableAmount

                                    Dim objTrtBalinfo As CBSPCFA1_BalanceInfo
                                    'For Each objTrtBalinfo In objRMICWwebsvcRetData.arrLstBalanceDetails
                                    For i As Integer = 0 To objRMICWwebsvcRetData.arrLstBalanceDetails.Count - 1
                                        objTrtBalinfo = objRMICWwebsvcRetData.arrLstBalanceDetails(i)
                                        If objTrtBalinfo.strBillingCategoryCode = "CPE" And objTrtBalinfo.strDataRecordType = "ET" Then
                                            objNPDBalance.curTreatableDueCPE = objTrtBalinfo.curTotalTreatableAmount
                                        End If
                                    Next




                                    'If (dtmbilldueDate.CompareTo(dtmProcessDate) > 0) Then
                                    If (dtmPaybydate.CompareTo(dtmProcessDate) > 0) Then '68041
                                        objNPDBalance.curpastDueCPE = cfir.curTotalCharges - (cfir.curCurrentCharges + cfir.cur30DaysCharges)
                                    Else
                                        objNPDBalance.curpastDueCPE = cfir.curTotalCharges
                                    End If

                                ElseIf strCategoryCd = "IP" Then
                                    objNPDBalance.curTotalDueIP = cfir.curTotalCharges

                                    'objNPDBalance.curTreatableDueIP = cfir.curTotalTreatableAmount

                                    Dim objTrtBalinfo As CBSPCFA1_BalanceInfo
                                    'For Each objTrtBalinfo In objRMICWwebsvcRetData.arrLstBalanceDetails
                                    For i As Integer = 0 To objRMICWwebsvcRetData.arrLstBalanceDetails.Count - 1
                                        objTrtBalinfo = objRMICWwebsvcRetData.arrLstBalanceDetails(i)
                                        If objTrtBalinfo.strBillingCategoryCode = "CPE" And objTrtBalinfo.strDataRecordType = "ET" Then
                                            objNPDBalance.curTreatableDueIP = objTrtBalinfo.curTotalTreatableAmount
                                        End If
                                    Next

                                    'If (dtmbilldueDate.CompareTo(dtmProcessDate) > 0) Then
                                    If (dtmPaybydate.CompareTo(dtmProcessDate) > 0) Then '68041
                                        objNPDBalance.curPastDueIP = cfir.curTotalCharges - (cfir.curCurrentCharges + cfir.cur30DaysCharges)
                                    Else
                                        objNPDBalance.curPastDueIP = cfir.curTotalCharges
                                    End If



                                End If

                            Next
                        End If
                    End If
                Catch ex As Exception
                    LogErrorFile.WriteLog("RMICW_WS_GetCFIBalanceEastInfo - failed", ex.ToString() + strAcctnum + "/" + strOrg + "/" + strRegionCd + "/" + dtmPaybydate.ToString())
                End Try
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICW_WS_GetCFIBalanceEastInfo", ex.ToString() + strAcctnum + "/" + strOrg + "/" + strRegionCd)
                Throw ex
            End Try

            Return objNPDBalance


        End Function


        Private Function fn_CheckNumBucketsAndSum(ByRef objTDResp As TD_Response, ByVal strorg As String) As Object

            'MD AND DC  B ---> ALL THE BKTS Except DA  ,DA -->DA

            Dim intindex As Integer
            Dim objTDRespDesc As TD_Response.TD_Status_Description = Nothing
            Dim curTmpTrtAmt As Double, curTmpPastDueAmt As Double, curTmpTotalDueAmt As Double


            Select Case strorg
                Case "501", "502", "504", "505", "506", "514", "701", "702", "704", "705", "706", "714", "805", "806"

                    curTmpTrtAmt = 0.0
                    curTmpPastDueAmt = 0.0
                    curTmpTotalDueAmt = 0.0
                    For intindex = 0 To objTDResp.arrStatusDesc.Length - 1
                        If objTDResp.arrStatusDesc(intindex).strBucketName = "Basic" Then
                            curTmpTrtAmt = objTDResp.arrStatusDesc(intindex).curTreatableAmount
                            curTmpPastDueAmt = objTDResp.arrStatusDesc(intindex).curPastDueAmount
                            curTmpTotalDueAmt = objTDResp.arrStatusDesc(intindex).TotalAmountDue
                        End If
                        If objTDResp.arrStatusDesc(intindex).strBucketName = "Non-Basic" Then
                            curTmpTrtAmt = curTmpTrtAmt + objTDResp.arrStatusDesc(intindex).curTreatableAmount
                            curTmpPastDueAmt = curTmpPastDueAmt + objTDResp.arrStatusDesc(intindex).curPastDueAmount
                            curTmpTotalDueAmt = curTmpTotalDueAmt + objTDResp.arrStatusDesc(intindex).TotalAmountDue
                        End If
                        If objTDResp.arrStatusDesc(intindex).strBucketName = "Toll" Then
                            curTmpTrtAmt = curTmpTrtAmt + objTDResp.arrStatusDesc(intindex).curTreatableAmount
                            curTmpPastDueAmt = curTmpPastDueAmt + objTDResp.arrStatusDesc(intindex).curPastDueAmount
                            curTmpTotalDueAmt = curTmpTotalDueAmt + objTDResp.arrStatusDesc(intindex).TotalAmountDue
                        End If
                        If objTDResp.arrStatusDesc(intindex).strBucketName = "NonTelecom" Then
                            curTmpTrtAmt = curTmpTrtAmt + objTDResp.arrStatusDesc(intindex).curTreatableAmount
                            curTmpPastDueAmt = curTmpPastDueAmt + objTDResp.arrStatusDesc(intindex).curPastDueAmount
                            curTmpTotalDueAmt = curTmpTotalDueAmt + objTDResp.arrStatusDesc(intindex).TotalAmountDue
                        End If

                    Next

                    For intindex = 0 To objTDResp.arrStatusDesc.Length - 1

                        If objTDResp.arrStatusDesc(intindex).strBucketName = "Basic" Then
                            objTDResp.arrStatusDesc(intindex).curTreatableAmount = curTmpTrtAmt
                            objTDResp.arrStatusDesc(intindex).curPastDueAmount = curTmpPastDueAmt
                            objTDResp.arrStatusDesc(intindex).TotalAmountDue = curTmpTotalDueAmt
                        ElseIf objTDResp.arrStatusDesc(intindex).strBucketName <> "DA" Then
                            objTDResp.arrStatusDesc(intindex).curTreatableAmount = 0.0
                            objTDResp.arrStatusDesc(intindex).curPastDueAmount = 0.0
                            objTDResp.arrStatusDesc(intindex).TotalAmountDue = 0.0
                        End If
                    Next
                    'VA B -->BA BKT AND NB---->N,T,O BKTS AND DA---->DA

                Case "401", "402", "404", "405", "406", "414", "901", "902", "904", "905", "906", "914"

                    curTmpTrtAmt = 0.0
                    curTmpPastDueAmt = 0.0
                    curTmpTotalDueAmt = 0.0

                    For intindex = 0 To objTDResp.arrStatusDesc.Length - 1

                        If objTDResp.arrStatusDesc(intindex).strBucketName = "Non-Basic" Then
                            curTmpTrtAmt = objTDResp.arrStatusDesc(intindex).curTreatableAmount
                            curTmpPastDueAmt = objTDResp.arrStatusDesc(intindex).curPastDueAmount
                            curTmpTotalDueAmt = objTDResp.arrStatusDesc(intindex).TotalAmountDue
                        End If
                        If objTDResp.arrStatusDesc(intindex).strBucketName = "Toll" Then
                            curTmpTrtAmt = curTmpTrtAmt + objTDResp.arrStatusDesc(intindex).curTreatableAmount
                            curTmpPastDueAmt = curTmpPastDueAmt + objTDResp.arrStatusDesc(intindex).curPastDueAmount
                            curTmpTotalDueAmt = curTmpTotalDueAmt + objTDResp.arrStatusDesc(intindex).TotalAmountDue
                        End If
                        If objTDResp.arrStatusDesc(intindex).strBucketName = "NonTelecom" Then
                            curTmpTrtAmt = curTmpTrtAmt + objTDResp.arrStatusDesc(intindex).curTreatableAmount
                            curTmpPastDueAmt = curTmpPastDueAmt + objTDResp.arrStatusDesc(intindex).curPastDueAmount
                            curTmpTotalDueAmt = curTmpTotalDueAmt + objTDResp.arrStatusDesc(intindex).TotalAmountDue
                        End If

                    Next

                    For intindex = 0 To objTDResp.arrStatusDesc.Length - 1

                        If objTDResp.arrStatusDesc(intindex).strBucketName = "Non-Basic" Then
                            objTDResp.arrStatusDesc(intindex).curTreatableAmount = curTmpTrtAmt
                            objTDResp.arrStatusDesc(intindex).curPastDueAmount = curTmpPastDueAmt
                            objTDResp.arrStatusDesc(intindex).TotalAmountDue = curTmpTotalDueAmt
                        ElseIf objTDResp.arrStatusDesc(intindex).strBucketName <> "DA" And objTDResp.arrStatusDesc(intindex).strBucketName <> "Basic" Then
                            objTDResp.arrStatusDesc(intindex).curTreatableAmount = 0.0
                            objTDResp.arrStatusDesc(intindex).curPastDueAmount = 0.0
                            objTDResp.arrStatusDesc(intindex).TotalAmountDue = 0.0
                        End If
                    Next

            End Select

        End Function
        Private Function fn_getdesc(ByVal strBucket As String, ByVal strReturnvalue As String, ByVal objTSDesc() As TS_Response.TS_Status_Description) As String

            Dim intindex As Integer
            Dim strAlternatBucket As String = ""

            'Select Case (strBucket)
            '    Case "Basic"
            '        strAlternatBucket = ",Regulated"
            '    Case "Non-Basic"
            '        strAlternatBucket = ",Non Regulated,Non-Regulated,Non Basic,"
            '    Case "NonTelecom"
            '        strAlternatBucket = ",Non Telecom"

            'End Select
            'For intindex = 0 To objTSDesc.Length - 1
            '    If objTSDesc(intindex).strBucketName = strBucket Or objTSDesc(intindex).strBucketName = strAlternatBucket Then
            '        Select Case LCase(strReturnvalue)
            '            Case "dtmbegindate"
            '                Return objTSDesc(intindex).dtmBeginDate.ToString
            '            Case "strbucketstatusdesc"
            '                Return objTSDesc(intindex).strBucketStatusDesc
            '            Case "strbucketstatusind"
            '                Return objTSDesc(intindex).strBucketStatusInd
            '            Case "strcategorycd"
            '                Return objTSDesc(intindex).strCategoryCd
            '        End Select
            '    End If
            'Next

            Select Case (strBucket)
                Case "Basic"
                    strAlternatBucket = ",Regulated,"
                Case "Non-Basic"

                    strAlternatBucket = ",Non Regulated,Non-Regulated,Non Basic,"
                Case "NonTelecom"

                    strAlternatBucket = ",Non Telecom,"
                Case "Toll"
                    strAlternatBucket = ",Toll,"
                Case "OCAR"
                    strAlternatBucket = ",OCAR,"
                Case "DA"
                    strAlternatBucket = ",DA,"

            End Select
            For intindex = 0 To objTSDesc.Length - 1

                'New Logic
                If objTSDesc(intindex).strBucketName = strBucket Or strAlternatBucket.IndexOf("," + objTSDesc(intindex).strBucketName + ",") >= 0 Then
                    Select Case LCase(strReturnvalue)
                        Case "dtmbegindate"
                            Return objTSDesc(intindex).dtmBeginDate.ToString
                        Case "strbucketstatusdesc"
                            Return objTSDesc(intindex).strBucketStatusDesc
                        Case "strbucketstatusind"
                            Return objTSDesc(intindex).strBucketStatusInd
                        Case "strcategorycd"
                            Return objTSDesc(intindex).strCategoryCd
                    End Select
                End If
            Next

        End Function
        Private Function fn_initialize(ByVal objTSResp As TS_Response, ByRef objTDResp As TD_Response) As String
            Dim intIndex As Integer = 0
            Dim arrLstStatus As ArrayList = New ArrayList
            Dim strStatus As BucketStatus
            Dim objTDDesc As TD_Response.TD_Status_Description


            For intIndex = 0 To arrBucket.Length - 1
                objTDDesc = New TD_Response.TD_Status_Description
                objTDDesc.strBucketName = arrBucket(intIndex).ToString

                Select Case arrBucket(intIndex).ToString
                    Case "Basic"
                        strStatus = objTSResp.strBasicBucketStatusInd
                    Case "Non-Basic"
                        strStatus = objTSResp.strNonBasicBucketStatusInd
                    Case "Toll"
                        strStatus = objTSResp.strTollBucketStatusInd
                    Case "OCAR"
                        strStatus = objTSResp.strOCARBucketStatusInd
                    Case "NonTelecom"
                        strStatus = objTSResp.strNonTelecomStatusInd
                    Case "DA"
                        strStatus = objTSResp.strDAStatusInd
                End Select


                objTDDesc.strBucketStatusInd = strStatus

                Dim strTmp As String
                strTmp = fn_getdesc(objTDDesc.strBucketName, "dtmBeginDate", objTSResp.arrStatusDesc)

                If strTmp > "" Then
                    If IsDate(strTmp) Then
                        objTDDesc.dtmTerminationDate = CDate(strTmp)
                        objTDDesc.dtmBeginDate = CDate(strTmp)
                    Else
                        objTDDesc.dtmTerminationDate = New DateTime(1900, 1, 1)
                        objTDDesc.dtmBeginDate = New DateTime(1900, 1, 1)
                    End If
                Else
                    objTDDesc.dtmTerminationDate = New DateTime(1900, 1, 1)
                    objTDDesc.dtmBeginDate = New DateTime(1900, 1, 1)
                End If

                objTDDesc.curPastDueAmount = 0.0
                objTDDesc.curTreatableAmount = 0.0
                objTDDesc.curNoticeAmount = 0.0
                objTDDesc.curSnpAmount = 0.0
                objTDDesc.TotalAmountDue = 0.0
                arrLstStatus.Add(objTDDesc)
                objTDDesc = Nothing

            Next


            objTDResp.arrStatusDesc = CType(arrLstStatus.ToArray(GetType(TD_Response.TD_Status_Description)), TD_Response.TD_Status_Description())
        End Function
#End Region

#Region "Treatment Status for the SBM "

        Public Function getTreatmentStatusForSBM(ByVal strRegionId As String, ByVal strAcctNum As String, ByVal strOrg As String, ByVal strRshipCode As String) As TS_ResponseForSBM

            Dim objTS_ResponseSBM As TS_ResponseForSBM = New TS_ResponseForSBM
            'If Value is CROSS-E,HOA-H,MULTIBAN-M,PARENTCHILD-P Call GetChildAccountByParentCAN -WR62854 RSS

            Try


                Select Case True

                    Case strRegionId Is Nothing Or strRegionId.Trim = ""
                        objTS_ResponseSBM.RequestStatus.strMessageId = "INVRGNID"
                        objTS_ResponseSBM.RequestStatus.strMessageDescription = "Invalid Region Id passed."
                        Return objTS_ResponseSBM
                    Case strAcctNum Is Nothing Or strAcctNum.Trim = ""
                        objTS_ResponseSBM.RequestStatus.strMessageId = "INVACNBR"
                        objTS_ResponseSBM.RequestStatus.strMessageDescription = "Invalid Account Number passed as Input."
                        Return objTS_ResponseSBM
                    Case strOrg Is Nothing Or strAcctNum.Trim = ""
                        objTS_ResponseSBM.RequestStatus.strMessageId = "INVORG"
                        objTS_ResponseSBM.RequestStatus.strMessageDescription = "Invalid Org passed as Input."
                        Return objTS_ResponseSBM
                End Select

                Dim objERAAccess As CBSSERAAccess = New CBSSERAAccess(strRegionId)
                Dim objSBMDetails As SummaryBillDetails
                'objSBMDetails = objERAAccess.getAcctsForSBM(strRegionId, strAcctNum, strRshipCode)
                objSBMDetails = objERAAccess.getAcctsForSBM(strRegionId, strAcctNum, strRshipCode)

                If objSBMDetails.RequestStatus.strMessageId.Trim > "" Then
                    objTS_ResponseSBM.RequestStatus.strMessageId = objSBMDetails.RequestStatus.strMessageId
                    objTS_ResponseSBM.RequestStatus.strMessageDescription = objSBMDetails.RequestStatus.strMessageDescription
                    Return objTS_ResponseSBM
                End If
                '***WR62854 A2R Complex Call PSPS for all the BB Child  


                Dim objRequest As TS_Request

                '********************************
                Dim objTS_Response As TS_Response = New TS_Response()
                '********************************



                Try
                    Dim objChildList As SBMAcctList = New SBMAcctList()
                    Dim strChildListXML As String = ""
                    Select Case strRshipCode.Trim()
                        Case "P", "M", "H", "E", ""
                            Try
                                'TO DO ***************
                                'Dim sw As New StringWriter
                                'Dim ser As New XmlSerializer(GetType(SummaryBillDetails))
                                'ser.Serialize(sw, objSBMDetails)
                                'strChildListXML = sw.ToString
                                'Dim dtTS As DataTable
                                'Dim drTS As DataRow
                                'Dim strprodType As String
                                'Dim dsTS As DataSet = MyBase.WSDataAccessObj.usp_GetSBMProductStatus(strRegionId, strChildListXML, strRshipCode)
                                'For Each dtTS In dsTS.Tables
                                '    For Each drTS In dtTS.Rows
                                '        strprodType = drTS("prodType").ToString()
                                '        objChildList.strStatus = drTS("strStatus").ToString()
                                '        objChildList.strAcctNum = drTS("strAcctNum").ToString()
                                '        If strprodType.Trim() = "" Then
                                '            strprodType = "NONE"
                                '        End If
                                '        If objChildList.strStatus.Trim() = "" Then
                                '            objChildList.strStatus = "LIVE"
                                '        End If
                                '        objTS_Response.strAcctNum = objChildList.strAcctNum
                                '        objTS_Response.strStatus = objChildList.strStatus
                                '        objTS_ResponseSBM.arrLstTSList.Add(objTS_Response)
                                '    Next drTS
                                'Next dtTS
                                'TO DO ***************


                                'For Each objChildList In objSBMDetails.arrLstAcctList
                                For i As Integer = 0 To objSBMDetails.arrLstAcctList.Count - 1
                                    objChildList = objSBMDetails.arrLstAcctList(i)
                                    objRequest = New TS_Request
                                    objRequest.strAcctNum = objChildList.strAcctNum
                                    objRequest.strApplicationId = "ICOLLECT"
                                    objRequest.strInputRequestType = "A"
                                    objRequest.strOrg = strOrg
                                    objRequest.strRegionId = strRegionId

                                    '************************************************
                                    'added to populate BTN
                                    objTS_Response = getTreatmentStatus(objRequest)
                                    objTS_Response.strBTNNum = objChildList.strBTNNum
                                    objTS_Response.strClassOfService = objChildList.strClassOfService
                                    objTS_ResponseSBM.arrLstTSList.Add(objTS_Response)
                                    '************************************************

                                    'objTS_ResponseSBM.arrLstTSList.Add(getTreatmentStatus(objRequest))

                                Next



                                Return objTS_ResponseSBM
                            Catch ex As Exception
                                LogErrorFile.WriteLog("RMICWWS - getTreatmentStatusSBM", ex.ToString())
                                objTS_ResponseSBM.RequestStatus.strMessageId = "RMIEXPTN"
                                objTS_ResponseSBM.RequestStatus.strMessageDescription = ex.ToString

                            End Try

                            If objSBMDetails.RequestStatus.strMessageId.Trim > "" Then
                                objTS_ResponseSBM.RequestStatus.strMessageId = objSBMDetails.RequestStatus.strMessageId
                                objTS_ResponseSBM.RequestStatus.strMessageDescription = objSBMDetails.RequestStatus.strMessageDescription
                                Return objTS_ResponseSBM
                            End If

                    End Select


                Catch ex As Exception

                End Try



                Dim objAcctList As SBMAcctList
                'Dim objRequest As TS_Request

                '********************************
                'Dim objTS_Response As TS_Response
                '********************************

                'For Each objAcctList In objSBMDetails.arrLstAcctList
                For i As Integer = 0 To objSBMDetails.arrLstAcctList.Count - 1
                    objAcctList = objSBMDetails.arrLstAcctList(i)
                    objRequest = New TS_Request
                    objRequest.strAcctNum = objAcctList.strAcctNum
                    objRequest.strApplicationId = "ICOLLECT"
                    objRequest.strInputRequestType = "A"
                    objRequest.strOrg = strOrg
                    objRequest.strRegionId = strRegionId

                    '************************************************
                    'added to populate BTN
                    objTS_Response = getTreatmentStatus(objRequest)
                    objTS_Response.strBTNNum = objAcctList.strBTNNum
                    objTS_Response.strClassOfService = objAcctList.strClassOfService

                    objTS_ResponseSBM.arrLstTSList.Add(objTS_Response)
                    '************************************************

                    'objTS_ResponseSBM.arrLstTSList.Add(getTreatmentStatus(objRequest))

                Next
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS - getTreatmentStatusSBM", ex.ToString())
                objTS_ResponseSBM.RequestStatus.strMessageId = "RMIEXPTN"
                objTS_ResponseSBM.RequestStatus.strMessageDescription = ex.ToString
            End Try

            Return objTS_ResponseSBM
        End Function

#End Region

#Region "getAccountInfo"

        Public Function getAccountInfo(ByVal strRegionId As String, ByVal strInpType As String, ByVal strAcctNum As String, ByVal strOrg As String) As AccountInfo

            Dim objAcctInfo As AccountInfo = New AccountInfo
            Try

                objAcctInfo.strAcctNum = strAcctNum
                Select Case True

                    Case strRegionId Is Nothing Or strRegionId.Trim = ""
                        objAcctInfo.RequestStatus.strMessageId = "INVRGNID"
                        objAcctInfo.RequestStatus.strMessageDescription = "Invalid Region Id passed."
                        Return objAcctInfo
                    Case strAcctNum Is Nothing Or strAcctNum.Trim = ""
                        objAcctInfo.RequestStatus.strMessageId = "INVACNBR"
                        objAcctInfo.RequestStatus.strMessageDescription = "Invalid Account Number passed as Input."
                        Return objAcctInfo
                    Case strInpType Is Nothing Or strInpType.Trim = ""
                        objAcctInfo.RequestStatus.strMessageId = "INVRQST"
                        objAcctInfo.RequestStatus.strMessageDescription = "Invalid Request Type."
                        Return objAcctInfo
                    Case strOrg Is Nothing
                        objAcctInfo.RequestStatus.strMessageId = "INVORG"
                        objAcctInfo.RequestStatus.strMessageDescription = "Invalid Org."
                        Return objAcctInfo
                End Select


                Dim ds As DataSet = MyBase.WSDataAccessObj.usp_GetRMICWInfo(strRegionId, strInpType, strAcctNum, strOrg)
                Dim dt As DataTable
                Dim dr As DataRow
                Dim strTableName As String
                Dim strCategoryCd As String
                Dim objRequest As RequestDetails
                Dim objWSCommon As WSCommonClasses = New WSCommonClasses
                Dim arrLstStatus As ArrayList = New ArrayList


                'For Each dt In ds.Tables
                For i As Integer = 0 To ds.Tables.Count - 1
                    dt = ds.Tables(i)
                    'For Each dr In dt.Rows
                    For j As Integer = 0 To dt.Rows.Count - 1
                        dr = dt.Rows(j)

                        strTableName = dr("strTableName")
                        Select Case strTableName.Trim()
                            Case "BTNFTN"
                                objAcctInfo.strFTNNum = dr("strFTNNum")
                                objAcctInfo.strFTNStatus = dr("strStatusCd")
                            Case "RQST"
                                objRequest = New RequestDetails
                                objRequest.intRequestId = dr("intRequestId")
                                objRequest.strAcctNum = dr("strAcctNum")
                                objRequest.strActn = dr("strActn")
                                objRequest.strOrg = dr("strOrg")
                                objRequest.strClass = dr("strClass")
                                objRequest.strOriginationId = dr("stroriginationId")
                                objRequest.strStatusCd = dr("strStatusCd")
                                objRequest.strReturnCd = dr("strReturncd")
                                objRequest.strLongDesc = dr("strLongDesc")
                                objRequest.strArchiveInd = dr("strArchiveInd")
                                objRequest.strLogonId = dr("strLogonId")
                                objRequest.strActnClsCd = dr("strActnClsCd")
                                objRequest.strDestSystem = dr("strDestSystem")
                                objRequest.strActnDescription = dr("strDescription")

                                If (objRequest.strStatusCd.Trim = "SV" Or objRequest.strStatusCd.Trim = "VN" Or objRequest.strStatusCd.Trim = "VC" Or objRequest.strStatusCd.Trim = "SI") Then

                                    objAcctInfo.strPendingRequest = objRequest.strActnDescription

                                    Select Case objRequest.strActn.Trim
                                        Case "SB", "DB", "ST", "SL", "TCB", "TCD", "SN", "DN", "DT", "DL", "TCD"
                                            objAcctInfo.blnDenyStatusChangePending = True
                                    End Select
                                End If

                                objAcctInfo.arrLstRequest.Add(objRequest)
                            Case "STATUS"

                                strCategoryCd = dr("strCategoryCd")
                                Select Case strCategoryCd.Trim()
                                    Case "B"
                                        objAcctInfo.TrtStatus.strBasicBucketStatusInd = objWSCommon.getBucketStatus(dr("strTrtStatusDesc"), dr("strActn"))
                                    Case "T"
                                        objAcctInfo.TrtStatus.strTollBucketStatusInd = objWSCommon.getBucketStatus(dr("strTrtStatusDesc"), dr("strActn"))
                                    Case "N"
                                        objAcctInfo.TrtStatus.strNonBasicBucketStatusInd = objWSCommon.getBucketStatus(dr("strTrtStatusDesc"), dr("strActn"))
                                    Case "O"
                                        objAcctInfo.TrtStatus.strOCARBucketStatusInd = objWSCommon.getBucketStatus(dr("strTrtStatusDesc"), dr("strActn"))
                                    Case "D"
                                        objAcctInfo.TrtStatus.strDAStatusInd = objWSCommon.getBucketStatus(dr("strTrtStatusDesc"), dr("strActn"))
                                End Select


                                Dim objTSDesc As TS_Response.TS_Status_Description = New TS_Response.TS_Status_Description
                                objTSDesc.strBucketName = dr("strCategoryDescription")
                                objTSDesc.strBucketStatusInd = objWSCommon.getBucketStatus(dr("strTrtStatusDesc"), dr("strActn"))
                                objTSDesc.strBucketStatusDesc = dr("strTrtStatusDesc")
                                objTSDesc.strCategoryCd = dr("strCategoryCd")
                                objTSDesc.dtmBeginDate = dr("dtmBeginDate")


                                If (Not strOrg Is Nothing) Then
                                    If (strOrg.Trim = "SC1") Then
                                        If (objAcctInfo.TrtStatus.strTollBucketStatusInd = BucketStatus.Denied) Then
                                            objTSDesc.strBucketStatusDesc = "Denied Lifeline/PostBill"
                                        End If
                                    End If
                                End If

                                arrLstStatus.Add(objTSDesc)


                        End Select


                    Next j
                Next i


                If (arrLstStatus.Count > 0) Then
                    objAcctInfo.TrtStatus.arrStatusDesc = CType(arrLstStatus.ToArray(GetType(TS_Response.TS_Status_Description)), TS_Response.TS_Status_Description())
                Else
                    objAcctInfo.TrtStatus.Initialize(strRegionId)
                End If

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS - getAccountInfo", ex.ToString())
                objAcctInfo.RequestStatus.strMessageId = "RMIEXPTN"
                objAcctInfo.RequestStatus.strMessageDescription = ex.ToString
            End Try

            Return objAcctInfo


        End Function
#End Region

#Region "getuCSRData"

        Public Function getuCSRData(ByVal uCSRRequest As uCSR_DetailsInp) As uCSR_DetailsOut

            'Dim objuCSR_DetailsInp As uCSR_DetailsInp = New uCSR_DetailsInp
            Dim objuCSR_DetailsOut As uCSR_DetailsOut = New uCSR_DetailsOut

            Try

                Select Case True

                    Case uCSRRequest.strAcctNum.Trim Is Nothing Or uCSRRequest.strAcctNum.Trim() = ""
                        objuCSR_DetailsOut.strMessageId = "INVACNBR"
                        objuCSR_DetailsOut.strMessageDescription = "AcctNum Invalid"
                        objuCSR_DetailsOut.strAcctNum = " "
                    Case uCSRRequest.strCANNum.Trim Is Nothing Or uCSRRequest.strCANNum.Trim() = ""
                        objuCSR_DetailsOut.strMessageId = "INVCANNB"
                        objuCSR_DetailsOut.strMessageDescription = "CANNum Invalid"
                    Case uCSRRequest.strActn.Trim <> "S" And uCSRRequest.strActn.Trim <> "R" And uCSRRequest.strActn.Trim <> "T"
                        objuCSR_DetailsOut.strMessageId = "INVACTN"
                        objuCSR_DetailsOut.strMessageDescription = "strActn Invalid. Valid acnts are S, R and T."
                    Case uCSRRequest.strServiceType.Trim.ToUpper() <> "VIDEO" And uCSRRequest.strServiceType.Trim.ToUpper() <> "DATA" And uCSRRequest.strServiceType.Trim.ToUpper() <> "PPV" And uCSRRequest.strServiceType.Trim.ToUpper() <> "VOICE" And uCSRRequest.strServiceType.Trim.ToUpper() <> "HSI" And uCSRRequest.strServiceType.Trim.ToUpper() <> "VASIP" And uCSRRequest.strServiceType.Trim.ToUpper() <> "ACCOUNT"
                        objuCSR_DetailsOut.strMessageId = "INVSERVC"
                        objuCSR_DetailsOut.strMessageDescription = "strServiceType Invalid. Valid values are VIDEO, DATA , PPV , HSI , VASIP and ACCOUNT."
                        'strLECBilledStatus
                    Case uCSRRequest.strLECBilledStatus.Trim <> "Y" And uCSRRequest.strLECBilledStatus.Trim <> "N"
                        objuCSR_DetailsOut.strMessageId = "INVLBSTS"
                        objuCSR_DetailsOut.strMessageDescription = "strLECBilledStatus Invalid. Valid values are Y and N."
                    Case Else
                        objuCSR_DetailsOut.strMessageId = " "
                        objuCSR_DetailsOut.strMessageDescription = " "

                End Select


                If objuCSR_DetailsOut.strMessageId.Trim = "" Then

                    'MyBase.WSDataAccessObj.usp_InsertUpdateuCSRData(uCSRRequest.strCANNum.Trim, uCSRRequest.strAcctNum.Trim, uCSRRequest.strActn.Trim, uCSRRequest.strServiceType.Trim, uCSRRequest.strCompanyCode.Trim, uCSRRequest.strServiceOrderNum.Trim, uCSRRequest.strLECBilledStatus.Trim)
                    MyBase.WSDataAccessObj.usp_InsertUpdateuCSRData(uCSRRequest.strCANNum.Trim, uCSRRequest.strAcctNum.Trim, uCSRRequest.strActn.Trim, uCSRRequest.strServiceType.Trim, uCSRRequest.strCompanyCode.Trim, uCSRRequest.strServiceOrderNum.Trim, uCSRRequest.strLECBilledStatus.Trim, uCSRRequest.strRAO.Trim, uCSRRequest.strPCAN, uCSRRequest.strDCR, uCSRRequest.strAccountId, uCSRRequest.strServiceId)

                    objuCSR_DetailsOut.strMessageId = "RMUCSR00"
                    objuCSR_DetailsOut.strMessageDescription = "Success"
                    objuCSR_DetailsOut.strAcctNum = uCSRRequest.strAcctNum.Trim

                    'Dim ds As DataSet = MyBase.WSDataAccessObj.usp_InsertUpdateuCSRData(uCSRRequest.strCANNum, uCSRRequest.strAcctNum, uCSRRequest.strActn, uCSRRequest.strServiceType, uCSRRequest.strCompanyCode, uCSRRequest.strServiceOrderNum, uCSRRequest.strLECBilledStatus)
                    'Dim dt As DataTable
                    'Dim dr As DataRow

                End If


            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS - getuCSRData", ex.ToString())
                objuCSR_DetailsOut.strMessageId = "RMIEXPTN"
                objuCSR_DetailsOut.strMessageDescription = ex.ToString

            End Try

            Return objuCSR_DetailsOut

        End Function
#End Region

#Region "insertFIOSData"
        Public Function insertFIOSData(ByVal strRegionCd As String, ByVal strXml As String, ByVal strExtendedParm As String, ByVal strEnvironment As String) As Object

            Try

                'MyBase.WSDataAccessObj.usp_InsertUpdateuCSRData(uCSRRequest.strCANNum.Trim, uCSRRequest.strAcctNum.Trim, uCSRRequest.strActn.Trim, uCSRRequest.strServiceType.Trim, uCSRRequest.strCompanyCode.Trim, uCSRRequest.strServiceOrderNum.Trim, uCSRRequest.strLECBilledStatus.Trim)
                If strRegionCd <> "WEST" Then
                    strEnvironment = System.Environment.MachineName
                End If
                MyBase.WSDataAccessObj.usp_InsertSSPMasterAndChild(strRegionCd, strXml, strExtendedParm, strEnvironment)



            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS - getuCSRData", ex.ToString())

            End Try



        End Function
#End Region
#Region "usp_UpdateSSPResponse"
        Public Function usp_UpdateSSPResponse(ByVal strRegionCd As String, ByVal strXml As String, ByVal strExtendedParm As String) As Object

            Try


                MyBase.WSDataAccessObj.usp_UpdateSSPResponse(strRegionCd, strXml, strExtendedParm)



            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS - getuCSRData", ex.ToString())

            End Try



        End Function
#End Region

#Region "insertFIOSData"
        Public Function CheckAffRequestByRequestId(ByVal strRegionId As String, ByVal strAcctNum As String, ByVal intRequestId As Integer, ByVal strDestSystem As String, ByVal strAffActn As String, ByVal intStatus As Integer) As Integer

            Dim i As Integer

            Try
                i = MyBase.WSDataAccessObj.usp_CheckAffRequestByRequestId(strRegionId, strAcctNum, intRequestId, strDestSystem, strAffActn, intStatus)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS - CheckAffRequestByRequestId", ex.ToString())

            End Try
            Return i

        End Function
#End Region



    End Class

End Namespace

