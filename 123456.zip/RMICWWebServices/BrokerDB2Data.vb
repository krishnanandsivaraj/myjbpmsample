Imports CommonLibrary
Imports IBM.Data.DB2
Namespace Verizon.RMICW.WebServices


    Public Class ERARequest
        Public strRegionId As String
        Public strERAName As String
        Public strAcctNum As String
        Public strBTNNum As String
       
     
        Public strInpTyp As String
        Public strExtInput As String
        Public strReqType As String
        Public strStartInstance As String
        Public strFmtType As String
        Public intGetNum As Integer
        Public strScope As String
        Public strCFIInp As String
        Public strAssocVideoCAN As String
        Public strTrtOrgCode As String

        Public strRetNum As String
        Public strBBCan As String
        Public strTargetTN As String
        Public strInputValue As String

      
    End Class

    Public Class ERAResponse
        Public strERAName As String
        Public strAcctNum As String
        Public strMsgCode As String
        Public strMsgText As String
        Public intSQLRC As Integer
        Public strEXTOut As String
        Public strSQLTKN As String
        Public strSQLST As String


        Public DB2DS As DataSet

        Public Sub New()

            strMsgCode = " "
            strMsgText = " "
            intSQLRC = 0
            strEXTOut = " "
            strSQLTKN = " "
            strSQLST = " "
            DB2DS = New DataSet

        End Sub
    End Class


    Public Class BrokerDB2Data
        Inherits RMICWWSBase

        Public ReqERA As ERARequest
        Public strDBConnection As String
        Public strDBSchema As String


        Public Sub New(ByVal obj As ERARequest)
            MyBase.New(obj.strRegionId)
            ReqERA = obj
        End Sub


        Public ReadOnly Property PERAConnectionString(ByVal strType As String) As String
            Get
                Dim strCBSSEnv As String = CommonFunctions.GetCBSSEnvironmnet(ReqERA.strAcctNum.Trim)
                If strType.Trim = "EOI" Then
                    Return MyBase.WSDataAccessObj.usp_GetControlParmByName("Control" & ReqERA.strRegionId.Trim, "EOI-CONN-" & strCBSSEnv.Trim)
                Else
                    Return MyBase.WSDataAccessObj.usp_GetControlParmByName("Control" & ReqERA.strRegionId.Trim, "CBSS-CONN-" & strCBSSEnv.Trim)
                End If


            End Get
        End Property



        Public Sub getCBSSEnvironemntVariables(ByVal strType As String)
            Dim strValue As String
            strValue = MyBase.WSDataAccessObj.usp_GetEnvironment("Control" & ReqERA.strRegionId.Trim, ReqERA.strAcctNum, strType)

            Dim arrStr() As String
            arrStr = strValue.Split("#")
            If (arrStr.Length < 2) Then
                Throw New Exception("Not able to find the Environment " & strType)
            Else
                strDBConnection = arrStr(0)
                strDBSchema = arrStr(1)
            End If

            'Dim strCBSSEnv As String = CommonFunctions.GetCBSSEnvironmnet(ReqERA.strAcctNum.Trim)
            'If strType.Trim = "EOI" Then
            '    Return MyBase.WSDataAccessObj.usp_GetControlParmByName("Control" & ReqERA.strRegionId.Trim, "EOI-SCH-" & strCBSSEnv.Trim)
            'Else
            '    Return MyBase.WSDataAccessObj.usp_GetControlParmByName("Control" & ReqERA.strRegionId.Trim, "CBSS-SCH-" & strCBSSEnv.Trim)
            'End If

        End Sub

        Public Sub getCBSSEnvironemntVariablesEast(ByVal strType As String)
            Dim strValue As String

            strValue = MyBase.WSDataAccessObj.usp_GetControlParmByName("Control" & ReqERA.strRegionId.Trim, "CBSS-t" & ReqERA.strRegionId.Trim)

            Dim arrStr() As String
            arrStr = strValue.Split("#")
            If (arrStr.Length < 2) Then
                Throw New Exception("Not able to find the Environment " & strType)
            Else
                strDBConnection = arrStr(0)
                strDBSchema = arrStr(1)
            End If

        End Sub




        Public ReadOnly Property PERASPSignature(ByVal strType As String) As String
            Get
                Dim strCBSSEnv As String = CommonFunctions.GetCBSSEnvironmnet(ReqERA.strAcctNum.Trim)
                If strType.Trim = "EOI" Then
                    Return MyBase.WSDataAccessObj.usp_GetControlParmByName("Control" & ReqERA.strRegionId.Trim, "EOI-SCH-" & strCBSSEnv.Trim)
                Else
                    Return MyBase.WSDataAccessObj.usp_GetControlParmByName("Control" & ReqERA.strRegionId.Trim, "CBSS-SCH-" & strCBSSEnv.Trim)
                End If


            End Get
        End Property

        Public Function ERADB2Connect() As ERAResponse

            Dim DB2Conn As DB2Connection
            Dim DB2Cmd As DB2Command
            Dim DB2Adapter As DB2DataAdapter
            Dim DB2DS As DataSet
            Dim objERAResponse As ERAResponse = New ERAResponse


            Try
                DB2Conn = New DB2Connection
                DB2Cmd = New DB2Command
                DB2Adapter = New DB2DataAdapter

                'getCBSSEnvironemntVariables("CBSS")
                If ReqERA.strRegionId.Trim = "WEST" Then
                    getCBSSEnvironemntVariables("CBSS")
                Else
                    getCBSSEnvironemntVariablesEast("CBSSEast")
                End If


                DB2Conn.ConnectionString = strDBConnection
                DB2Cmd.CommandType = CommandType.StoredProcedure
                DB2Cmd.CommandText = String.Concat(strDBSchema, ".", ReqERA.strERAName.Trim)
                DB2Cmd.CommandTimeout = 30
                DB2Cmd.Connection = DB2Conn

                'open and beginTran. changes reqd for commit
                DB2Conn.Open()
                DB2Cmd.Transaction = DB2Conn.BeginTransaction()

                'If ReqERA.strERAName.Trim = "CBSPCFA1" Then
                '    SetDB2CmdParmsCFA1(DB2Cmd) 'for CBSPCFA1 - CFI balance
                'Else
                '    SetDB2CmdParmsERA1(DB2Cmd) 'for the rest of ERAs
                'End If

    

                If ReqERA.strRegionId.Trim = "WEST" Then

                    If ReqERA.strERAName.Trim = "CBSPCFA1" Then
                        SetDB2CmdParmsCFA1(DB2Cmd) 'for CBSPCFA1 - WEST CFI balance
                    ElseIf ReqERA.strERAName = "CBSPCFA3" Then
                        SetDB2CmdParmsCFA3(DB2Cmd)
                    Else
                        SetDB2CmdParmsERA1(DB2Cmd) 'for the rest of ERAs
                    End If
                Else
                    If ReqERA.strERAName.Trim = "CBSPTRA9" Then
                        SetDB2CmdParmsTRA9East(DB2Cmd) 'for the rest of ERAs

                    ElseIf ReqERA.strERAName = "CBSPCFA3" Then
                        SetDB2CmdParmsCFA3(DB2Cmd)
                    Else
                        'East CFI balances
                        SetDB2CmdParmsCFA1East(DB2Cmd) 'for CBSPCFA1 - EAST CFI balance
                    End If
                End If


                DB2Adapter.SelectCommand = DB2Cmd
                DB2Adapter.Fill(objERAResponse.DB2DS)

                objERAResponse.strMsgCode = CType(DB2Cmd.Parameters("MSGCODE").Value, String)
                objERAResponse.strMsgText = CType(DB2Cmd.Parameters("MSGTXT").Value, String)
                objERAResponse.strSQLST = CType(DB2Cmd.Parameters("SQLST").Value, String)
                objERAResponse.strSQLTKN = CType(DB2Cmd.Parameters("SQLTKN").Value, String)

                'If ((ReqERA.strRegionId.Trim = "NE" Or ReqERA.strRegionId.Trim = "NY" Or ReqERA.strRegionId.Trim = "NPD" Or ReqERA.strRegionId.Trim = "MDVW") And ReqERA.strERAName.Trim = "CBSPCFA1") Then
                '    objERAResponse.strEXTOut = CType(DB2Cmd.Parameters("EXTOUTG").Value, String)
                'Else
                '    objERAResponse.strEXTOut = CType(DB2Cmd.Parameters("EXTOUT").Value, String)
                'End If

                objERAResponse.strEXTOut = CType(DB2Cmd.Parameters("EXTOUT").Value, String)
                objERAResponse.intSQLRC = CType(DB2Cmd.Parameters("SQLRC").Value, Integer)


            Catch DB2Ex As DB2Exception
                LogErrorFile.WriteLog("RMICWWS-CBSSERA", DB2Ex.ToString())
                Throw (DB2Ex)
            Catch Ex As Exception
                LogErrorFile.WriteLog("RMICWWS-CBSSERA", Ex.ToString())
                Throw (Ex)
            Finally
                'added Commit per CBSS recommendation 02-09-2006
                'DB2Adapter.SelectCommand.Transaction.Commit()
                DB2Cmd.Transaction.Commit()

                If (DB2Conn Is Nothing) Then
                Else
                    If (DB2Conn.State = ConnectionState.Open) Then
                        DB2Conn.Close()
                    End If
                End If

                If (Not DB2Cmd Is Nothing) Then
                    DB2Cmd.Dispose()
                End If
                If (Not DB2Conn Is Nothing) Then
                    DB2Conn.Dispose()
                End If

            End Try

            Return objERAResponse
        End Function



        Public Sub SetDB2CmdParmsERA1(ByRef Db2Cmd As DB2Command)

            Try

                With Db2Cmd.Parameters
                    .Add("INPTYPE", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("INPVALU", DB2Type.VarChar, 50).Direction = ParameterDirection.Input
                    .Add("STRINST", DB2Type.VarChar, 40).Direction = ParameterDirection.Input
                    .Add("GETNUM", DB2Type.Integer, 4).Direction = ParameterDirection.Input
                    .Add("RETNUM", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("SCOPE", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("TARGETTN", DB2Type.Char, 10).Direction = ParameterDirection.Input
                    .Add("REQTYPE", DB2Type.Char, 2).Direction = ParameterDirection.Input
                    .Add("FMTYPE", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("OUTSEQ", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("CORRELID", DB2Type.VarChar, 18).Direction = ParameterDirection.Input
                    .Add("DEBUGLVL", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("EXTINPUT", DB2Type.Char, 8).Direction = ParameterDirection.Input
                    .Add("TOTNUM", DB2Type.Integer, 4).Direction = ParameterDirection.Input


                    .Add("MSGCODE", DB2Type.Char, 3).Direction = ParameterDirection.Output
                    .Add("MSGTXT", DB2Type.VarChar, 100).Direction = ParameterDirection.Output
                    .Add("SQLRC", DB2Type.Integer, 4).Direction = ParameterDirection.Output
                    .Add("SQLTKN", DB2Type.VarChar, 70).Direction = ParameterDirection.Output
                    .Add("SQLST", DB2Type.Char, 5).Direction = ParameterDirection.Output
                    .Add("EXTOUT", DB2Type.VarChar, 250).Direction = ParameterDirection.Output

                End With
                With Db2Cmd.Parameters
                    .Item("INPTYPE").Value = ReqERA.strInpTyp
                    .Item("INPVALU").Value = ReqERA.strAcctNum

                    If ReqERA.strTrtOrgCode = "B" And ReqERA.strAssocVideoCAN <> "" Then
                        .Item("INPVALU").Value = ReqERA.strAssocVideoCAN
                    End If

                    .Item("STRINST").Value = ReqERA.strStartInstance
                    .Item("GETNUM").Value = ReqERA.intGetNum
                    .Item("RETNUM").Value = "Y"
                    .Item("SCOPE").Value = ReqERA.strScope
                    .Item("TARGETTN").Value = " "
                    .Item("REQTYPE").Value = ReqERA.strReqType  '00
                    .Item("FMTYPE").Value = ReqERA.strFmtType
                    .Item("OUTSEQ").Value = "0"
                    .Item("CORRELID").Value = " "
                    .Item("DEBUGLVL").Value = "0"
                    .Item("EXTINPUT").Value = ReqERA.strExtInput   '"YYY Y"
                    .Item("TOTNUM").Value = 0


                    .Item("MSGCODE").Value = " "
                    .Item("MSGTXT").Value = " "
                    .Item("SQLRC").Value = 0
                    .Item("SQLTKN").Value = " "
                    .Item("SQLST").Value = " "
                    .Item("EXTOUT").Value = " "


                End With
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-BrokerDB2Data", ex.ToString)
                Throw ex
            End Try




        End Sub

        Public Sub SetDB2CmdParmsCFA1(ByRef Db2Cmd As DB2Command)

            Try

                With Db2Cmd.Parameters
                    .Add("INPTYPE", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("INPVALU", DB2Type.VarChar, 50).Direction = ParameterDirection.Input
                    .Add("STRINST", DB2Type.VarChar, 40).Direction = ParameterDirection.Input
                    .Add("GETNUM", DB2Type.Integer, 4).Direction = ParameterDirection.Input
                    .Add("RETNUM", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("SCOPE", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("TARGETTN", DB2Type.Char, 10).Direction = ParameterDirection.Input
                    .Add("REQTYPE", DB2Type.Char, 2).Direction = ParameterDirection.Input
                    .Add("FMTYPE", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("OUTSEQ", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("CORRELID", DB2Type.VarChar, 18).Direction = ParameterDirection.Input
                    .Add("DEBUGLVL", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    '.Add("EXTINPUT", DB2Type.Char, 8).Direction = ParameterDirection.Input
                    .Add("EXTINPUT", DB2Type.Char, 13).Direction = ParameterDirection.Input

                    '.Add("TOTNUM", DB2Type.Integer, 4).Direction = ParameterDirection.Input
                    .Add("DATAIN", DB2Type.Clob, 100000).Direction = ParameterDirection.Input
                    .Add("TOTSAN", DB2Type.Integer, 4).Direction = ParameterDirection.Input

                    .Add("MSGCODE", DB2Type.Char, 3).Direction = ParameterDirection.Output
                    .Add("MSGTXT", DB2Type.VarChar, 100).Direction = ParameterDirection.Output
                    .Add("SQLRC", DB2Type.Integer, 4).Direction = ParameterDirection.Output
                    .Add("SQLTKN", DB2Type.VarChar, 70).Direction = ParameterDirection.Output
                    .Add("SQLST", DB2Type.Char, 5).Direction = ParameterDirection.Output
                    .Add("EXTOUT", DB2Type.VarChar, 250).Direction = ParameterDirection.Output


                End With
                With Db2Cmd.Parameters
                    .Item("INPTYPE").Value = ReqERA.strInpTyp
                    .Item("INPVALU").Value = ReqERA.strAcctNum
                    .Item("STRINST").Value = ReqERA.strStartInstance
                    .Item("GETNUM").Value = ReqERA.intGetNum
                    .Item("RETNUM").Value = "Y"
                    .Item("SCOPE").Value = ReqERA.strScope
                    .Item("TARGETTN").Value = " "
                    .Item("REQTYPE").Value = ReqERA.strReqType  '00
                    .Item("FMTYPE").Value = ReqERA.strFmtType
                    .Item("OUTSEQ").Value = "0"
                    .Item("CORRELID").Value = " "
                    .Item("DEBUGLVL").Value = "0"
                    .Item("EXTINPUT").Value = ReqERA.strExtInput   '"YYY Y"
                    '"            Y" ; //passing Y in the 13th position will give the Bill Due date 
                    '.Item("TOTNUM").Value = 0
                    '.Item("DATAIN").Value = Nothing
                    .Item("DATAIN").Value = ReqERA.strCFIInp

                    .Item("MSGCODE").Value = " "
                    .Item("MSGTXT").Value = " "
                    .Item("SQLRC").Value = 0
                    .Item("SQLTKN").Value = " "
                    .Item("SQLST").Value = " "
                    .Item("EXTOUT").Value = " "


                End With
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-BrokerDB2Data", ex.ToString)
                Throw ex
            End Try




        End Sub

        Public Sub SetDB2CmdParmsCFA3(ByRef Db2Cmd As DB2Command)

            Try

                With Db2Cmd.Parameters
                    .Add("INPTYPE", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("INPVALU", DB2Type.VarChar, 50).Direction = ParameterDirection.Input
                    .Add("STRINST", DB2Type.VarChar, 40).Direction = ParameterDirection.Input
                    .Add("NUMINST", DB2Type.Integer, 1).Direction = ParameterDirection.Input
                    '.Add("GETNUM", DB2Type.Integer, 4).Direction = ParameterDirection.Input
                    .Add("RETNUM", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("SCOPE", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("TARGETTN", DB2Type.Char, 10).Direction = ParameterDirection.Input
                    .Add("REQTYPE", DB2Type.Char, 2).Direction = ParameterDirection.Input
                    .Add("FMTYPE", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("OUTSEQ", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("CORRELID", DB2Type.VarChar, 18).Direction = ParameterDirection.Input
                    .Add("DEBUGLVL", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("EXTINPUT", DB2Type.VarChar, 100).Direction = ParameterDirection.Input

                    '.Add("TOTNUM", DB2Type.Integer, 4).Direction = ParameterDirection.Input
                    '.Add("DATAIN", DB2Type.Clob, 100000).Direction = ParameterDirection.Input
                    .Add("TOTSANS", DB2Type.Integer, 4).Direction = ParameterDirection.Input

                    .Add("MSGCODE", DB2Type.Char, 3).Direction = ParameterDirection.Output
                    .Add("MSGTXT", DB2Type.VarChar, 100).Direction = ParameterDirection.Output
                    .Add("SQLRC", DB2Type.Integer, 4).Direction = ParameterDirection.Output
                    .Add("SQLTKN", DB2Type.VarChar, 70).Direction = ParameterDirection.Output
                    .Add("SQLST", DB2Type.Char, 5).Direction = ParameterDirection.Output
                    .Add("EXTOUT", DB2Type.VarChar, 250).Direction = ParameterDirection.Output


                End With
                With Db2Cmd.Parameters
                    .Item("INPTYPE").Value = ReqERA.strInpTyp
                    .Item("INPVALU").Value = ReqERA.strAcctNum
                    .Item("STRINST").Value = ReqERA.strStartInstance
                    .Item("NUMINST").Value = 0
                    '.Item("GETNUM").Value = ReqERA.intGetNum
                    .Item("RETNUM").Value = " "
                    .Item("SCOPE").Value = ReqERA.strScope
                    .Item("TARGETTN").Value = " "
                    .Item("REQTYPE").Value = ReqERA.strReqType  '00
                    .Item("FMTYPE").Value = ReqERA.strFmtType
                    .Item("OUTSEQ").Value = "0"
                    .Item("CORRELID").Value = " "
                    .Item("DEBUGLVL").Value = "0"
                    .Item("EXTINPUT").Value = ReqERA.strExtInput  
                    .Item("TOTSANS").Value = 0
                    

                    .Item("MSGCODE").Value = " "
                    .Item("MSGTXT").Value = " "
                    .Item("SQLRC").Value = 0
                    .Item("SQLTKN").Value = " "
                    .Item("SQLST").Value = " "
                    .Item("EXTOUT").Value = " "


                End With
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-BrokerDB2Data", ex.ToString)
                Throw ex
            End Try




        End Sub


        Public Sub SetDB2CmdParmsCFA1East(ByRef Db2Cmd As DB2Command)

            Try

                With Db2Cmd.Parameters
                    .Add("INPTYPE", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("INPVALU", DB2Type.VarChar, 50).Direction = ParameterDirection.Input
                    .Add("STRTINST", DB2Type.VarChar, 40).Direction = ParameterDirection.Input
                    .Add("GETNUM", DB2Type.Integer, 4).Direction = ParameterDirection.Input
                    .Add("RETNUM", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("SCOPE", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("TARGETTN", DB2Type.Char, 10).Direction = ParameterDirection.Input
                    .Add("REQTYPE", DB2Type.Char, 2).Direction = ParameterDirection.Input
                    .Add("FMTTYPE", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("OUTSEQ", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("CORRELID", DB2Type.VarChar, 18).Direction = ParameterDirection.Input
                    .Add("DEBUGLVL", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("EXTINPUT", DB2Type.Char, 100).Direction = ParameterDirection.Input

                    '.Add("TOTNUM", DB2Type.Integer, 4).Direction = ParameterDirection.Input
                    .Add("DATAIN", DB2Type.Clob, 97000).Direction = ParameterDirection.Input

                    'not used in input
                    .Add("TOTSAN", DB2Type.Integer, 4).Direction = ParameterDirection.Output
                    .Add("MSGCODE", DB2Type.Char, 3).Direction = ParameterDirection.Output
                    .Add("MSGTXT", DB2Type.VarChar, 100).Direction = ParameterDirection.Output
                    .Add("SQLRC", DB2Type.Integer, 4).Direction = ParameterDirection.Output
                    .Add("SQLTKN", DB2Type.VarChar, 70).Direction = ParameterDirection.Output
                    .Add("SQLST", DB2Type.Char, 5).Direction = ParameterDirection.Output
                    .Add("EXTOUT", DB2Type.VarChar, 250).Direction = ParameterDirection.Output


                End With
                With Db2Cmd.Parameters
                    .Item("INPTYPE").Value = ReqERA.strInpTyp
                    .Item("INPVALU").Value = ReqERA.strAcctNum
                    .Item("STRTINST").Value = ReqERA.strStartInstance
                    .Item("GETNUM").Value = ReqERA.intGetNum
                    .Item("RETNUM").Value = " "
                    .Item("SCOPE").Value = ReqERA.strScope
                    .Item("TARGETTN").Value = " "
                    .Item("REQTYPE").Value = ReqERA.strReqType  '00
                    .Item("FMTTYPE").Value = ReqERA.strFmtType
                    .Item("OUTSEQ").Value = "0"
                    .Item("CORRELID").Value = " "
                    .Item("DEBUGLVL").Value = "0"
                    .Item("EXTINPUT").Value = ReqERA.strExtInput   '"YYY Y"
                    '"            Y" ; //passing Y in the 13th position will give the Bill Due date 
                    '.Item("TOTNUM").Value = 0
                    '.Item("DATAIN").Value = Nothing
                    .Item("DATAIN").Value = ReqERA.strCFIInp

                    'not used in input
                    .Item("TOTSAN").Value = 0
                    .Item("MSGCODE").Value = " "
                    .Item("MSGTXT").Value = " "
                    .Item("SQLRC").Value = 0
                    .Item("SQLTKN").Value = " "
                    .Item("SQLST").Value = " "
                    .Item("EXTOUT").Value = " "


                End With
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-BrokerDB2Data", ex.ToString)
                Throw ex
            End Try




        End Sub

        Public Sub SetDB2CmdParmsTRA9East(ByRef Db2Cmd As DB2Command)

            Try

                With Db2Cmd.Parameters
                    .Add("INPTYPE", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("INPVALU", DB2Type.VarChar, 50).Direction = ParameterDirection.Input
                    .Add("STRTINST", DB2Type.VarChar, 40).Direction = ParameterDirection.Input
                    .Add("GETNUM", DB2Type.Integer, 4).Direction = ParameterDirection.Input
                    .Add("RETNUM", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("SCOPE", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("TARGETTN", DB2Type.Char, 10).Direction = ParameterDirection.Input
                    .Add("REQTYPE", DB2Type.Char, 2).Direction = ParameterDirection.Input
                    .Add("FMTTYPE", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("OUTSEQ", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("CORRELID", DB2Type.VarChar, 18).Direction = ParameterDirection.Input
                    .Add("DEBUGLVL", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("EXTINPUT", DB2Type.Char, 100).Direction = ParameterDirection.Input

                    '.Add("TOTNUM", DB2Type.Integer, 4).Direction = ParameterDirection.Input


                    'not used in input
                    .Add("TOTSAN", DB2Type.Integer, 4).Direction = ParameterDirection.Output
                    .Add("MSGCODE", DB2Type.Char, 3).Direction = ParameterDirection.Output
                    .Add("MSGTXT", DB2Type.VarChar, 100).Direction = ParameterDirection.Output
                    .Add("SQLRC", DB2Type.Integer, 4).Direction = ParameterDirection.Output
                    .Add("SQLTKN", DB2Type.VarChar, 70).Direction = ParameterDirection.Output
                    .Add("SQLST", DB2Type.Char, 5).Direction = ParameterDirection.Output
                    .Add("EXTOUT", DB2Type.VarChar, 250).Direction = ParameterDirection.Output


                End With
                With Db2Cmd.Parameters
                    .Item("INPTYPE").Value = ReqERA.strInpTyp '1 or 2
                    .Item("INPVALU").Value = ReqERA.strAcctNum
                    .Item("STRTINST").Value = ReqERA.strStartInstance 'spaces
                    .Item("GETNUM").Value = ReqERA.intGetNum '0
                    .Item("RETNUM").Value = " "
                    .Item("SCOPE").Value = ReqERA.strScope 'spaces
                    .Item("TARGETTN").Value = " "
                    .Item("REQTYPE").Value = ReqERA.strReqType  '00
                    .Item("FMTTYPE").Value = ReqERA.strFmtType ' 1  
                    .Item("OUTSEQ").Value = "0"
                    .Item("CORRELID").Value = " "
                    .Item("DEBUGLVL").Value = "0"
                    .Item("EXTINPUT").Value = ReqERA.strExtInput 'spaces
                    'not used in input
                    .Item("TOTSAN").Value = 0
                    .Item("MSGCODE").Value = " "
                    .Item("MSGTXT").Value = " "
                    .Item("SQLRC").Value = 0
                    .Item("SQLTKN").Value = " "
                    .Item("SQLST").Value = " "
                    .Item("EXTOUT").Value = " "


                End With
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-TRA9BrokerDB2Data", ex.ToString)
                Throw ex
            End Try




        End Sub


        Public Function EOIDB2Connect() As ERAResponse

            Dim DB2Conn As DB2Connection
            Dim DB2Cmd As DB2Command
            Dim DB2Adapter As DB2DataAdapter
            Dim DB2DS As DataSet
            Dim objERAResponse As ERAResponse = New ERAResponse


            Try
                DB2Conn = New DB2Connection
                DB2Cmd = New DB2Command
                DB2Adapter = New DB2DataAdapter


                getCBSSEnvironemntVariables("EOI")
                DB2Conn.ConnectionString = strDBConnection
                DB2Cmd.CommandType = CommandType.StoredProcedure
                DB2Cmd.CommandText = String.Concat(strDBSchema, ".", ReqERA.strERAName.Trim)
                DB2Cmd.CommandTimeout = 30
                DB2Cmd.Connection = DB2Conn
                SetDB2CmdParmsEOI(DB2Cmd)
                DB2Adapter.SelectCommand = DB2Cmd
                DB2Adapter.Fill(objERAResponse.DB2DS)

                objERAResponse.strMsgCode = CType(DB2Cmd.Parameters("ASSETRTNCD").Value, String)
                objERAResponse.strMsgText = CType(DB2Cmd.Parameters("ASSETRTNTXT").Value, String)
                objERAResponse.strSQLST = CType(DB2Cmd.Parameters("SQLST").Value, String)
                objERAResponse.strSQLTKN = CType(DB2Cmd.Parameters("SQLTKN").Value, String)
                objERAResponse.strEXTOut = CType(DB2Cmd.Parameters("EXTOUT").Value, String)
                objERAResponse.intSQLRC = CType(DB2Cmd.Parameters("SQLRC").Value, Integer)



            Catch DB2Ex As DB2Exception
                LogErrorFile.WriteLog("RMICWWS-CBSSERA", DB2Ex.ToString())
                Throw (DB2Ex)
            Catch Ex As Exception
                LogErrorFile.WriteLog("RMICWWS-CBSSERA", Ex.ToString())
                Throw (Ex)
            Finally
                If (DB2Conn Is Nothing) Then
                Else
                    If (DB2Conn.State = ConnectionState.Open) Then
                        DB2Conn.Close()
                    End If
                End If

                If (Not DB2Cmd Is Nothing) Then
                    DB2Cmd.Dispose()
                End If
                If (Not DB2Conn Is Nothing) Then
                    DB2Conn.Dispose()
                End If

            End Try

            Return objERAResponse
        End Function

        Public Sub SetDB2CmdParmsEOI(ByRef Db2Cmd As DB2Command)

            Try

                With Db2Cmd.Parameters
                    .Add("INPTYPE", DB2Type.Char, 1).Direction = ParameterDirection.InputOutput
                    .Add("INPVALU", DB2Type.VarChar, 50).Direction = ParameterDirection.InputOutput
                    .Add("STRINST", DB2Type.VarChar, 40).Direction = ParameterDirection.InputOutput
                    .Add("GETNUM", DB2Type.Integer, 4).Direction = ParameterDirection.InputOutput
                    .Add("RETNUM", DB2Type.Char, 1).Direction = ParameterDirection.InputOutput
                    '.Add("SCOPE", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    '.Add("TARGETTN", DB2Type.Char, 10).Direction = ParameterDirection.Input
                    .Add("REQTYPE", DB2Type.Char, 2).Direction = ParameterDirection.InputOutput
                    .Add("FMTYPE", DB2Type.Char, 1).Direction = ParameterDirection.InputOutput
                    .Add("OUTSEQ", DB2Type.Char, 1).Direction = ParameterDirection.InputOutput
                    .Add("CORRELID", DB2Type.VarChar, 18).Direction = ParameterDirection.InputOutput
                    .Add("DEBUGLVL", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("EXTINPUT", DB2Type.VarChar, 100).Direction = ParameterDirection.InputOutput
                    .Add("TOTNUM", DB2Type.Integer, 4).Direction = ParameterDirection.InputOutput


                    .Add("ASSETTYP", DB2Type.Char, 1).Direction = ParameterDirection.Output
                    .Add("ASSETRTNCD", DB2Type.Char, 6).Direction = ParameterDirection.Output
                    .Add("ASSETRTNTXT", DB2Type.VarChar, 100).Direction = ParameterDirection.Output
                    .Add("SQLRC", DB2Type.Integer, 4).Direction = ParameterDirection.Output
                    .Add("SQLTKN", DB2Type.VarChar, 70).Direction = ParameterDirection.Output
                    .Add("SQLST", DB2Type.Char, 5).Direction = ParameterDirection.Output
                    .Add("EXTOUT", DB2Type.VarChar, 250).Direction = ParameterDirection.Output

                End With
                With Db2Cmd.Parameters
                    .Item("INPTYPE").Value = ReqERA.strInpTyp
                    .Item("INPVALU").Value = ReqERA.strAcctNum
                    .Item("STRINST").Value = ReqERA.strStartInstance
                    .Item("GETNUM").Value = 50
                    .Item("RETNUM").Value = "Y"
                    .Item("REQTYPE").Value = ReqERA.strReqType  '00
                    .Item("FMTYPE").Value = ReqERA.strFmtType '0 - raw Output
                    .Item("OUTSEQ").Value = "0"
                    .Item("CORRELID").Value = " "
                    .Item("DEBUGLVL").Value = "0"
                    .Item("EXTINPUT").Value = ReqERA.strExtInput   '"YYY Y"
                    .Item("TOTNUM").Value = 0


                    .Item("ASSETTYP").Value = " "
                    .Item("ASSETRTNCD").Value = " "
                    .Item("ASSETRTNTXT").Value = " "
                    .Item("SQLRC").Value = 0
                    .Item("SQLTKN").Value = " "
                    .Item("SQLST").Value = " "
                    .Item("EXTOUT").Value = " "


                End With
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-BrokerDB2Data", ex.ToString)
                Throw ex
            End Try




        End Sub



    End Class
#Region "STRA DB2 ACCESS" 'Bala 07/07

    Public Class STRARequest
        Public strRegionId As String
        Public strERAName As String
        Public strAcctNum As String
        Public strSVRQNum As String
        Public strBTNNum As String


        Public In_REQ_Read_Ind As String
        Public In_REQ_BLACT_F As Integer
        Public In_REQ_SVRQ As Integer
        Public In_REQ_BEG_EFF_D As String

    End Class

    Public Class STRAResponse
        Public strERAName As String
        Public strAcctNum As String

        Public Out_RES_Return_Code As Integer
        Public Out_RES_Error_Msg As String
        Public Out_RES_SQLCode As Integer
        Public Out_RES_SQLState As String



        Public DB2DS As DataSet

        Public Sub New()

            Out_RES_Error_Msg = " "
            Out_RES_Return_Code = 0
            Out_RES_SQLCode = 0
            Out_RES_SQLState = " "

            DB2DS = New DataSet

        End Sub
    End Class

    Public Class BrokerSTRADB2Data
        Inherits RMICWWSBase

        Public ReqSTRA As STRARequest
        Public strDBConnection As String
        Public strDBSchema As String


        Public Sub New(ByVal obj As STRARequest)
            MyBase.New(obj.strRegionId)
            ReqSTRA = obj

        End Sub


        'Public Sub GetSPConnectionString() '(ByVal strType As String)

        '    Dim strSTRAEnv As String = "X"
        '    'Return MyBase.WSDataAccessObj.usp_GetControlParmByName("Control" & ReqSTRA.strRegionId.Trim, "ERA-MDVW-" & strSTRAEnv.Trim)
        '    strDBConnection = MyBase.WSDataAccessObj.usp_GetControlParmByName("Control" & ReqSTRA.strRegionId.Trim, "ERA-MDVW-" & strSTRAEnv.Trim)


        'End Sub



        Public Sub GetSPConnectionString(ByVal strType As String)
            Dim strValue As String
            Dim strSTRAEnv As String

            'strValue = MyBase.WSDataAccessObj.usp_GetEnvironment("Control" & ReqSTRA.strRegionId.Trim, ReqSTRA.strAcctNum, strType)
            strValue = MyBase.WSDataAccessObj.usp_GetControlParmByName("Control" & ReqSTRA.strRegionId.Trim, "ERA-" & strType.Trim)

            Dim arrStr() As String
            arrStr = strValue.Split("#")
            If (arrStr.Length < 2) Then
                Throw New Exception("Not able to find the Environment " & strType)
            Else
                strDBConnection = arrStr(0)
                strDBSchema = arrStr(1)
            End If

        End Sub


        Public Function STRADB2Connect(ByVal strEnv) As STRAResponse

            Dim DB2Conn As DB2Connection
            Dim DB2Cmd As DB2Command
            Dim DB2Adapter As DB2DataAdapter
            Dim DB2DS As DataSet
            Dim objSTRAResponse As STRAResponse = New STRAResponse


            Try
                DB2Conn = New DB2Connection
                DB2Cmd = New DB2Command
                DB2Adapter = New DB2DataAdapter


                'getSTRAEnvironemntVariables("STRA")
                GetSPConnectionString(strEnv)
                DB2Conn.ConnectionString = strDBConnection
                DB2Cmd.CommandType = CommandType.StoredProcedure
                DB2Cmd.CommandText = String.Concat(strDBSchema, ".", "XCO_XBCLSP05") 'ReqSTRA.strERAName.Trim)
                DB2Cmd.CommandTimeout = 30
                DB2Cmd.Connection = DB2Conn
                'SetDB2CmdParmsXBCLSP06(DB2Cmd)
                SetDB2CmdParmsSTRA(DB2Cmd)
                DB2Adapter.SelectCommand = DB2Cmd
                DB2Adapter.Fill(objSTRAResponse.DB2DS)

                objSTRAResponse.Out_RES_SQLCode = CType(DB2Cmd.Parameters("RES_SQLCODE").Value, String)
                objSTRAResponse.Out_RES_SQLState = CType(DB2Cmd.Parameters("RES_SQLSTATE").Value, String)
                objSTRAResponse.Out_RES_Return_Code = CType(DB2Cmd.Parameters("RES_RETURN_CODE").Value, String)
                objSTRAResponse.Out_RES_Error_Msg = CType(DB2Cmd.Parameters("RES_ERROR_MSG").Value, String)


            Catch DB2Ex As DB2Exception
                LogErrorFile.WriteLog("RMICWWS-STRAERA", DB2Ex.ToString())
                Throw (DB2Ex)
            Catch Ex As Exception
                LogErrorFile.WriteLog("RMICWWS-STRAERA", Ex.ToString())
                Throw (Ex)
            Finally
                If (DB2Conn Is Nothing) Then
                Else
                    If (DB2Conn.State = ConnectionState.Open) Then
                        DB2Conn.Close()
                    End If
                End If

                If (Not DB2Cmd Is Nothing) Then
                    DB2Cmd.Dispose()
                End If
                If (Not DB2Conn Is Nothing) Then
                    DB2Conn.Dispose()
                End If

            End Try

            Return objSTRAResponse

        End Function

        Public Sub SetDB2CmdParmsSTRA(ByRef Db2Cmd As DB2Command)

            Try

                With Db2Cmd.Parameters
                    .Add("REQ_READ_IND", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("REQ_SVRQ", DB2Type.Integer, 4).Direction = ParameterDirection.Input
                    .Add("REQ_BLACT", DB2Type.Integer, 4).Direction = ParameterDirection.Input


                    .Add("RES_RETURN_CODE", DB2Type.Integer, 4).Direction = ParameterDirection.Output
                    .Add("RES_ERROR_MSG", DB2Type.VarChar, 200).Direction = ParameterDirection.Output
                    .Add("RES_SQLCODE", DB2Type.Integer, 4).Direction = ParameterDirection.Output
                    .Add("RES_SQLSTATE", DB2Type.Char, 5).Direction = ParameterDirection.Output

                End With

                With Db2Cmd.Parameters
                    .Item("REQ_READ_IND").Value = ReqSTRA.In_REQ_Read_Ind
                    .Item("REQ_SVRQ").Value = ReqSTRA.In_REQ_SVRQ
                    .Item("REQ_BLACT").Value = ReqSTRA.In_REQ_BLACT_F

                    .Item("RES_RETURN_CODE").Value = 0
                    .Item("RES_ERROR_MSG").Value = " "
                    .Item("RES_SQLCODE").Value = 0
                    .Item("RES_SQLSTATE").Value = " "

                End With
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-BrokerSTRADB2Data", ex.ToString)
                Throw ex
            End Try

        End Sub

        Public Sub SetDB2CmdParmsXBCLSP06(ByRef Db2Cmd As DB2Command)

            Try

                With Db2Cmd.Parameters
                    .Add("REQ_READ_IND", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("REQ_BLACT", DB2Type.Integer, 4).Direction = ParameterDirection.Input
                    .Add("REQ_BEG_EFF_D", DB2Type.Char, 10).Direction = ParameterDirection.Input


                    .Add("RES_RETURN_CODE", DB2Type.Integer, 4).Direction = ParameterDirection.Output
                    .Add("RES_ERROR_MSG", DB2Type.VarChar, 200).Direction = ParameterDirection.Output
                    .Add("RES_SQLCODE", DB2Type.Integer, 4).Direction = ParameterDirection.Output
                    .Add("RES_SQLSTATE", DB2Type.Char, 5).Direction = ParameterDirection.Output

                End With

                With Db2Cmd.Parameters
                    .Item("REQ_READ_IND").Value = ReqSTRA.In_REQ_Read_Ind
                    .Item("REQ_BLACT").Value = ReqSTRA.In_REQ_BLACT_F
                    .Item("REQ_BEG_EFF_D").Value = ReqSTRA.In_REQ_BEG_EFF_D

                    .Item("RES_RETURN_CODE").Value = 0
                    .Item("RES_ERROR_MSG").Value = " "
                    .Item("RES_SQLCODE").Value = 0
                    .Item("RES_SQLSTATE").Value = " "

                End With
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-BrokerSTRADB2Data", ex.ToString)
                Throw ex
            End Try

        End Sub



        Public Function SP06B2Connect(ByVal strEnv, ByVal strRegionCd) As SP06Response 'WR22719

            Dim DB2Conn As DB2Connection
            Dim DB2Cmd As DB2Command
            Dim DB2Adapter As DB2DataAdapter
            Dim DB2DS As DataSet
            Dim objSP06Response As SP06Response = New SP06Response


            Try
                DB2Conn = New DB2Connection
                DB2Cmd = New DB2Command
                DB2Adapter = New DB2DataAdapter


                'getSTRAEnvironemntVariables("STRA")
                GetSPConnectionString(strEnv)
                DB2Conn.ConnectionString = strDBConnection
                DB2Cmd.CommandType = CommandType.StoredProcedure
                DB2Cmd.CommandText = String.Concat(strDBSchema, ".", "XCO_XBCLSP06") 'ReqSTRA.strERAName.Trim)
                DB2Cmd.CommandTimeout = 30
                DB2Cmd.Connection = DB2Conn
                SetDB2CmdParmsXBCLSP06(DB2Cmd)
                DB2Adapter.SelectCommand = DB2Cmd
                DB2Adapter.Fill(objSP06Response.DB2DS)

                objSP06Response.Out_RES_SQLCode = CType(DB2Cmd.Parameters("RES_SQLCODE").Value, String)
                objSP06Response.Out_RES_SQLState = CType(DB2Cmd.Parameters("RES_SQLSTATE").Value, String)
                objSP06Response.Out_RES_Return_Code = CType(DB2Cmd.Parameters("RES_RETURN_CODE").Value, String)
                objSP06Response.Out_RES_Error_Msg = CType(DB2Cmd.Parameters("RES_ERROR_MSG").Value, String)


            Catch DB2Ex As DB2Exception
                LogErrorFile.WriteLog("RMICWWS-STRAERA", DB2Ex.ToString())
                Throw (DB2Ex)
            Catch Ex As Exception
                LogErrorFile.WriteLog("RMICWWS-STRAERA", Ex.ToString())
                Throw (Ex)
            Finally
                If (DB2Conn Is Nothing) Then
                Else
                    If (DB2Conn.State = ConnectionState.Open) Then
                        DB2Conn.Close()
                    End If
                End If

                If (Not DB2Cmd Is Nothing) Then
                    DB2Cmd.Dispose()
                End If
                If (Not DB2Conn Is Nothing) Then
                    DB2Conn.Dispose()
                End If

            End Try

            Return objSP06Response

        End Function




    End Class






    'WR22719 

    Public Class SP06Request
        Public strRegionId As String
        Public strERAName As String
        Public strAcctNum As String
        Public strSVRQNum As String
        Public strBTNNum As String
        


        Public In_REQ_Read_Ind As String
        Public In_REQ_BLACT_F As Integer
        Public In_REQ_SVRQ As Integer
        Public In_REQ_BEG_EFF_D As String

    End Class

    Public Class SP06Response
        Public strERAName As String
        Public strAcctNum As String
        Public strPNTAcctNum As String
        Public strCHILDAcctNum As String
        Public strBegEffDate As String
        Public strEndEffDate As String

        Public Out_RES_Return_Code As Integer
        Public Out_RES_Error_Msg As String
        Public Out_RES_SQLCode As Integer
        Public Out_RES_SQLState As String

        Public arrLstSBMDetails As ArrayList




        Public DB2DS As DataSet

        Public Sub New()

            Out_RES_Error_Msg = " "
            Out_RES_Return_Code = 0
            Out_RES_SQLCode = 0
            Out_RES_SQLState = " "

            DB2DS = New DataSet

        End Sub
    End Class


    Public Class BrokerSP06DB2Data
        Inherits RMICWWSBase

        Public ReqSP06 As SP06Request
        Public strDBConnection As String
        Public strDBSchema As String


        Public Sub New(ByVal obj As SP06Request)
            MyBase.New(obj.strRegionId)
            ReqSP06 = obj

        End Sub



        Public Sub GetSPConnectionString(ByVal strType As String)
            Dim strValue As String
            Dim strSTRAEnv As String

            'strValue = MyBase.WSDataAccessObj.usp_GetEnvironment("Control" & ReqSTRA.strRegionId.Trim, ReqSTRA.strAcctNum, strType)
            strValue = MyBase.WSDataAccessObj.usp_GetControlParmByName("Control" & ReqSP06.strRegionId.Trim, "ERA-" & strType.Trim)

            Dim arrStr() As String
            arrStr = strValue.Split("#")
            If (arrStr.Length < 2) Then
                Throw New Exception("Not able to find the Environment " & strType)
            Else
                strDBConnection = arrStr(0)
                strDBSchema = arrStr(1)
            End If

        End Sub

        Public Sub SetDB2CmdParmsSTRA(ByRef Db2Cmd As DB2Command)

            Try

                With Db2Cmd.Parameters
                    .Add("REQ_READ_IND", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("REQ_SVRQ", DB2Type.Integer, 4).Direction = ParameterDirection.Input
                    .Add("REQ_BLACT", DB2Type.Integer, 4).Direction = ParameterDirection.Input


                    .Add("RES_RETURN_CODE", DB2Type.Integer, 4).Direction = ParameterDirection.Output
                    .Add("RES_ERROR_MSG", DB2Type.VarChar, 200).Direction = ParameterDirection.Output
                    .Add("RES_SQLCODE", DB2Type.Integer, 4).Direction = ParameterDirection.Output
                    .Add("RES_SQLSTATE", DB2Type.Char, 5).Direction = ParameterDirection.Output

                End With

                With Db2Cmd.Parameters
                    .Item("REQ_READ_IND").Value = ReqSP06.In_REQ_Read_Ind
                    .Item("REQ_SVRQ").Value = ReqSP06.In_REQ_SVRQ
                    .Item("REQ_BLACT").Value = ReqSP06.In_REQ_BLACT_F

                    .Item("RES_RETURN_CODE").Value = 0
                    .Item("RES_ERROR_MSG").Value = " "
                    .Item("RES_SQLCODE").Value = 0
                    .Item("RES_SQLSTATE").Value = " "

                End With
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-BrokerSTRADB2Data", ex.ToString)
                Throw ex
            End Try

        End Sub

        Public Sub SetDB2CmdParmsXBCLSP06(ByRef Db2Cmd As DB2Command)

            Try

                With Db2Cmd.Parameters
                    .Add("REQ_READ_IND", DB2Type.Char, 1).Direction = ParameterDirection.Input
                    .Add("REQ_BLACT", DB2Type.Integer, 4).Direction = ParameterDirection.Input
                    .Add("REQ_BEG_EFF_D", DB2Type.Char, 10).Direction = ParameterDirection.Input


                    .Add("RES_RETURN_CODE", DB2Type.Integer, 4).Direction = ParameterDirection.Output
                    .Add("RES_ERROR_MSG", DB2Type.VarChar, 200).Direction = ParameterDirection.Output
                    .Add("RES_SQLCODE", DB2Type.Integer, 4).Direction = ParameterDirection.Output
                    .Add("RES_SQLSTATE", DB2Type.Char, 5).Direction = ParameterDirection.Output

                End With

                With Db2Cmd.Parameters
                    .Item("REQ_READ_IND").Value = ReqSP06.In_REQ_Read_Ind
                    .Item("REQ_BLACT").Value = ReqSP06.In_REQ_BLACT_F
                    .Item("REQ_BEG_EFF_D").Value = ReqSP06.In_REQ_BEG_EFF_D

                    .Item("RES_RETURN_CODE").Value = 0
                    .Item("RES_ERROR_MSG").Value = " "
                    .Item("RES_SQLCODE").Value = 0
                    .Item("RES_SQLSTATE").Value = " "

                End With
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-BrokerSTRADB2Data", ex.ToString)
                Throw ex
            End Try

        End Sub

        Public Function SP06DB2Connect(ByVal strEnv, ByVal strRegionCd) As SP06Response 'WR22719

            Dim DB2Conn As DB2Connection
            Dim DB2Cmd As DB2Command
            Dim DB2Adapter As DB2DataAdapter
            Dim DB2DS As DataSet
            Dim objSP06Response As SP06Response = New SP06Response


            Try
                DB2Conn = New DB2Connection
                DB2Cmd = New DB2Command
                DB2Adapter = New DB2DataAdapter


                'getSTRAEnvironemntVariables("STRA")
                GetSPConnectionString(strEnv)
                DB2Conn.ConnectionString = strDBConnection
                DB2Cmd.CommandType = CommandType.StoredProcedure
                DB2Cmd.CommandText = String.Concat(strDBSchema, ".", "XCO_XBCLSP06") 'ReqSTRA.strERAName.Trim)
                DB2Cmd.CommandTimeout = 30
                DB2Cmd.Connection = DB2Conn
                SetDB2CmdParmsXBCLSP06(DB2Cmd)
                DB2Adapter.SelectCommand = DB2Cmd
                DB2Adapter.Fill(objSP06Response.DB2DS)

                objSP06Response.Out_RES_SQLCode = CType(DB2Cmd.Parameters("RES_SQLCODE").Value, String)
                objSP06Response.Out_RES_SQLState = CType(DB2Cmd.Parameters("RES_SQLSTATE").Value, String)
                objSP06Response.Out_RES_Return_Code = CType(DB2Cmd.Parameters("RES_RETURN_CODE").Value, String)
                objSP06Response.Out_RES_Error_Msg = CType(DB2Cmd.Parameters("RES_ERROR_MSG").Value, String)


            Catch DB2Ex As DB2Exception
                LogErrorFile.WriteLog("RMICWWS-STRAERA", DB2Ex.ToString())
                Throw (DB2Ex)
            Catch Ex As Exception
                LogErrorFile.WriteLog("RMICWWS-STRAERA", Ex.ToString())
                Throw (Ex)
            Finally
                If (DB2Conn Is Nothing) Then
                Else
                    If (DB2Conn.State = ConnectionState.Open) Then
                        DB2Conn.Close()
                    End If
                End If

                If (Not DB2Cmd Is Nothing) Then
                    DB2Cmd.Dispose()
                End If
                If (Not DB2Conn Is Nothing) Then
                    DB2Conn.Dispose()
                End If

            End Try

            Return objSP06Response

        End Function




    End Class



#End Region







End Namespace
