Imports CommonLibrary
Imports IBM.Data.DB2
Imports System.Xml
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Collections
Imports System.Xml.Serialization
Imports System.IO
Imports System.Xml.Linq
Imports System.Linq
Imports System.Collections.Generic
Imports System.Net


Namespace Verizon.RMICW.WebServices




    Public Class CBSSERAAccess
        Inherits RMICWWSBase

        Public Sub New(ByVal strRegionId As String)
            MyBase.New(strRegionId)
        End Sub

#Region "getCBSS_CBSPERA1"
        Public Function getCBSS_CBSPERA1(ByVal strRegionId As String, ByVal strAcctNum As String) As CBSPERA1

            Dim objCBSPERA1 As CBSPERA1 = New CBSPERA1
            Try
                Dim reqObj As ERARequest = New ERARequest
                Dim resObj As ERAResponse
                Dim DB2DT As DataTable
                Dim DB2DR As DataRow
                Dim strInpValue As String



                Select Case True

                    Case strRegionId Is Nothing Or strRegionId.Trim = ""
                        objCBSPERA1.RequestStatus.strMessageId = "INVRGNID"
                        objCBSPERA1.RequestStatus.strMessageDescription = "Invalid Region Id passed."
                        Return objCBSPERA1
                    Case strAcctNum Is Nothing Or strAcctNum.Trim = ""
                        objCBSPERA1.RequestStatus.strMessageId = "INVACNBR"
                        objCBSPERA1.RequestStatus.strMessageDescription = "Invalid Account Number passed as Input."
                        Return objCBSPERA1
                End Select

                reqObj.strAcctNum = strAcctNum
                reqObj.strERAName = "CBSPERA1"
                reqObj.strExtInput = "YYY Y"
                reqObj.strInpTyp = "1"
                reqObj.strReqType = "00"
                reqObj.strRegionId = strRegionId
                reqObj.strFmtType = "0"
                reqObj.intGetNum = 0
                reqObj.strStartInstance = " "
                reqObj.strScope = " "

                Dim obj As BrokerDB2Data = New BrokerDB2Data(reqObj)
                resObj = obj.ERADB2Connect()




                Select Case True

                    Case Not resObj.intSQLRC = 0
                        objCBSPERA1.RequestStatus.strMessageId = resObj.intSQLRC.ToString
                        objCBSPERA1.RequestStatus.strMessageDescription = resObj.strMsgText
                        Return objCBSPERA1
                    Case MyBase.WSDataAccessObj.IsEmptyRecordSet(resObj.DB2DS)
                        objCBSPERA1.RequestStatus.strMessageId = "100"
                        objCBSPERA1.RequestStatus.strMessageDescription = "No Matching Record Found in CBSS"
                        Return objCBSPERA1
                End Select

                'For Each DB2DT In resObj.DB2DS.Tables
                For i As Integer = 0 To resObj.DB2DS.Tables.Count - 1
                    DB2DT = resObj.DB2DS.Tables(i)
                    'For Each DB2DR In DB2DT.Rows
                    For j As Integer = 0 To DB2DT.Rows.Count - 1
                        DB2DR = DB2DT.Rows(j)
                        strInpValue = DB2DR(2)
                    Next j
                Next i


                Dim arrLst As ArrayList = New ArrayList
                Dim fxdFld As _fixedField = New _fixedField

                fxdFld.strFldName = "strCustomerBillingDayCurrent"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 2
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strEndUserName"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 28
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strBillingCompanyCode"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 4
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strCustomerAccountStatus"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "dblDerivedTotalAmountDue"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 13
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "dtmCurrentBillingDate"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 8
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strGradeOfService"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 3
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "dtmInitialAccountEstabdDate"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 8
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strLocationCode"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 4
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "dtmMasterServiceDate"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 8
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strStateCode"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 2
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strSummaryAccountNumber"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 10
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strAccountTypeCode"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strNgbAccountNumber"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 7
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strCPNIOption"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strAreaCentralOfficeCode"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 3
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strFinanceLineOfBusinessCode"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 4
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strNonPubNonListCode"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strWorthlessCheckIndr"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strStdIndustrialClassification"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 4
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strServiceRepPositionNumber"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 2
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strUpdateProcessDate"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 8
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strPendingOrderFlag"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strAccountTelephoneNumber"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 10
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strConcessionCode"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strVactionOrSeasonalSignal"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strCanBeReachedAtNumber"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 10
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strCanBeReachedAtExtNumber"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 4
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strAuthorizedPartyName"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 20
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strTreatmentExceptionIdentifier"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strTaxIdentifier"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 16
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strSocialSecurityNumber"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 9
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strCrbCompanyCode"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strInitAccEstDateMaster"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 8
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strTelephoneNumberMaster"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 10
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strArrearsBillingIndicator"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strBillPeriodCode"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strCustAcctSumyBlgCd"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strCustomerNumberOfBills"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 2
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strLacTrackingCode"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 2
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strSpecialHandlingCode"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strTaxApplicabilityFlags"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 50
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strTaxExemptCode"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strCustomerCreditClass"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "dtmAccountTerminationDate"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 8
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strFinalBillStatus"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 2
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "dtmServiceOrderDate"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 8
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strServiceOrderNumber"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 8
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strBillingRevenueAccountingOffice"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 3
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strSalesAreaCode"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 3
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strCbssScanLine"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 18
                arrLst.Add(fxdFld)


                Dim objCommon As CommonFunctions = New CommonFunctions


                objCommon.ParseFixedLayout(strInpValue, arrLst)
                objCommon.getTheFileFormat(arrLst, "CBSPERA1", objCBSPERA1)


            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-CBSPERA1", "AcctNum: " & strAcctNum & " Erroring Out " & ex.ToString)
                objCBSPERA1.RequestStatus.strMessageId = "RMIEXPTN"
                objCBSPERA1.RequestStatus.strMessageDescription = ex.ToString

            End Try
            Return objCBSPERA1

        End Function
#End Region

#Region "getCBSS_AcctLineInfo"
        Public Function getCBSS_AcctLineInfo(ByVal strRegionId As String, ByVal strAcctNum As String) As AcctLineLevelInfo

            Dim objLineInfo As AcctLineLevelInfo = New AcctLineLevelInfo
            Dim objLineInfoTemp As AcctLineLevelInfo = New AcctLineLevelInfo
            Dim dtmDefaultEndDate As DateTime = New DateTime(9998, 12, 31)
            Dim strTRTOrgCode As String = ""
            Dim strAssocVideoCAN As String = ""

            Try
                Dim reqObj As ERARequest = New ERARequest
                Dim resObj As ERAResponse
                Dim DB2DT As DataTable
                Dim DB2DR As DataRow
                Dim strInpValue As String






                Try

                    If strRegionId = "FRAUDWEST" Then

                        strRegionId = "WEST"
                        Dim dsCA As DataSet = MyBase.WSDataAccessObj.usp_GetCustomerAddressInfo(strRegionId, strAcctNum.Trim())
                        If MyBase.WSDataAccessObj.IsEmptyRecordSet(dsCA) Then
                        Else
                            strTRTOrgCode = dsCA.Tables(0).Rows(0).Item("strTRTOrgCode")
                            strAssocVideoCAN = dsCA.Tables(0).Rows(0).Item("strAssocVideoCAN")
                            If strTRTOrgCode.Trim() = "B" And strAssocVideoCAN.Trim() <> "" Then
                                reqObj.strAssocVideoCAN = strAssocVideoCAN.Trim()
                                reqObj.strTrtOrgCode = strTRTOrgCode.Trim()
                            End If
                        End If
                    End If
                Catch exCA As Exception
                    LogErrorFile.WriteLog("RMICWWS-CBSPERA2", "AcctNum: " & strAcctNum & " Erroring Out During CA Look up for strAssocVideoCAN" & exCA.ToString)
                End Try





                Select Case True

                    Case strRegionId Is Nothing Or strRegionId.Trim = ""
                        objLineInfo.RequestStatus.strMessageId = "INVRGNID"
                        objLineInfo.RequestStatus.strMessageDescription = "Invalid Region Id passed."
                        Return objLineInfo
                    Case strAcctNum Is Nothing Or strAcctNum.Trim = ""
                        objLineInfo.RequestStatus.strMessageId = "INVACNBR"
                        objLineInfo.RequestStatus.strMessageDescription = "Invalid Account Number passed as Input."
                        Return objLineInfo
                End Select

                reqObj.strAcctNum = strAcctNum
                reqObj.strERAName = "CBSPERA2"
                reqObj.strExtInput = "YYYYYYY"
                reqObj.strInpTyp = "1"
                reqObj.strReqType = "00"
                reqObj.strRegionId = strRegionId
                reqObj.intGetNum = 200
                reqObj.strFmtType = "0"
                reqObj.strStartInstance = "0"
                reqObj.strScope = "A"

                Dim obj As BrokerDB2Data = New BrokerDB2Data(reqObj)
                resObj = obj.ERADB2Connect()


                resObj.intSQLRC = 0


                Select Case True

                    Case Not resObj.intSQLRC = 0
                        objLineInfo.RequestStatus.strMessageId = resObj.intSQLRC.ToString
                        objLineInfo.RequestStatus.strMessageDescription = resObj.strMsgText
                        Return objLineInfo
                    Case MyBase.WSDataAccessObj.IsEmptyRecordSet(resObj.DB2DS)
                        objLineInfo.RequestStatus.strMessageId = "100"
                        objLineInfo.RequestStatus.strMessageDescription = "No Matching Record Found in CBSS"
                        Return objLineInfo
                End Select




                objLineInfo.strAcctNum = strAcctNum

                Dim arrLst As ArrayList = New ArrayList
                Dim fxdFld As _fixedField = New _fixedField

                fxdFld.strFldName = "strTypeSubAcct"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strSubAcctServiceType"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strTelephoneNo"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 10
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strLocationCode"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 4
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "dtmSubAccountEstimateDate"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 8
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "dtmSubAccountTermDate"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 8
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strTaxDistrictCd"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 6
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strProdSvcRa"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 2
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strPriInSrceCde"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 3
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strPriIxcPrSrce"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 3
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strAcoCode"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 3
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strIlIxCrrCode"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 5
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strInPrePrvdrId"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 5
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strMeasuredSvcCd"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strSmrgAssocInd"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strCircuitID"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 33
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strIlPrePrvdrID"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 5
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strUssRatingCode"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 4
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strIlIxCrrStCd"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strIlPreStCd"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strRotaryGroupNo"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strRotaryGpseqNo"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 5
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strLineTypeCode"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strInterlataRrn"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 10
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strIntralataRrn"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 10
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strBillBlockInd"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strEqacCarrierNmInter"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 4
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strEqacCarrierDesInter"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 55
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strEqacCarrierNmIntra"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 4
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strEqacCarrierDesIntra"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 55
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strDiryAdvIndr"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strHcpDiscIndr"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "dtmMasterSvcDate"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 8
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "dtmIlIxcEffvDt"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 8
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "dtmInPrePrEfDt"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 8
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "dtmIlPrePrEfDt"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 8
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strInPreStCd"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strTlBlgExCode"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "dtmBlockEffDate"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 8
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "dtmBlockTermDate"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 8
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strClecBllTypCd"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strMsdSvcDtlOpt"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strDerivedClecLineType"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)


                fxdFld = New _fixedField
                fxdFld.strFldName = "strTabEntEffectiveDate"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 8
                arrLst.Add(fxdFld)


                fxdFld = New _fixedField
                fxdFld.strFldName = "strTabEntexpirationDate"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 8
                arrLst.Add(fxdFld)


                fxdFld = New _fixedField
                fxdFld.strFldName = "strDerviedLPICResaleInd"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)


                fxdFld = New _fixedField
                fxdFld.strFldName = "strLRNNumber"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 10
                arrLst.Add(fxdFld)



                Dim objCommon As CommonFunctions = New CommonFunctions
                Dim objLineLevel As LineLevelInfo
                Dim objTempLine As String = ""




                'For Each DB2DT In resObj.DB2DS.Tables
                For i As Integer = 0 To resObj.DB2DS.Tables.Count - 1
                    DB2DT = resObj.DB2DS.Tables(i)
                    'For Each DB2DR In DB2DT.Rows
                    For j As Integer = 0 To DB2DT.Rows.Count - 1
                        DB2DR = DB2DT.Rows(j)
                        strInpValue = DB2DR(2)
                        objLineLevel = New LineLevelInfo
                        strInpValue = Regex.Replace(strInpValue, "[^\w$.* ]", "")
                        objCommon.ParseFixedLayout(strInpValue, arrLst)
                        objCommon.getTheFileFormat(arrLst, "LineLevelInfo", objLineLevel)

                        objLineInfoTemp.arrLstLineDetails.Add(objLineLevel)
                        objLineInfoTemp.arrLstLineDetails.Sort(New clsGenericSort())

                    Next j
                Next i





                'For Each objLineLevel In objLineInfoTemp.arrLstLineDetails
                For i As Integer = 0 To objLineInfoTemp.arrLstLineDetails.Count - 1
                    objLineLevel = objLineInfoTemp.arrLstLineDetails(i)
                    If objTempLine.Trim() <> objLineLevel.strTelephoneNo Then
                        If objLineLevel.dtmSubAccountTermDate > dtmDefaultEndDate Then
                            objLineInfo.arrLstLineDetails.Add(objLineLevel)
                            objTempLine = objLineLevel.strTelephoneNo
                        End If

                    End If

                Next




            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-CBSPERA2", "AcctNum: " & strAcctNum & " Erroring Out " & ex.ToString)
                objLineInfo.RequestStatus.strMessageId = "RMIEXPTN"
                objLineInfo.RequestStatus.strMessageDescription = ex.ToString

            End Try
            Return objLineInfo

        End Function
#End Region

        'Public Function getCBSS_CBSEZRA9(ByVal strRegionId As String, ByVal strAcctNum As String) As CBSEZRA9

        '    Dim objCBSEZRA9 As CBSEZRA9 = New CBSEZRA9
        '    Try
        '        Dim reqObj As ERARequest = New ERARequest
        '        Dim resObj As ERAResponse
        '        Dim DB2DT As DataTable
        '        Dim DB2DR As DataRow
        '        Dim strInpValue As String



        '        Select Case True

        '            Case strRegionId Is Nothing Or strRegionId.Trim = ""
        '                objCBSEZRA9.RequestStatus.strMessageId = "INVRGNID"
        '                objCBSEZRA9.RequestStatus.strMessageDescription = "Invalid Region Id passed."
        '                Return objCBSEZRA9
        '            Case strAcctNum Is Nothing Or strAcctNum.Trim = ""
        '                objCBSEZRA9.RequestStatus.strMessageId = "INVACNBR"
        '                objCBSEZRA9.RequestStatus.strMessageDescription = "Invalid Account Number passed as Input."
        '                Return objCBSEZRA9
        '        End Select

        '        reqObj.strAcctNum = strAcctNum
        '        reqObj.strERAName = "CBSEZRA9"
        '        reqObj.strExtInput = "YYY Y"
        '        reqObj.strInpTyp = "1"
        '        reqObj.strReqType = "00"
        '        reqObj.strRegionId = strRegionId
        '        reqObj.strFmtType = "0"

        '        Dim obj As BrokerDB2Data = New BrokerDB2Data(reqObj)
        '        resObj = obj.ERADB2Connect()


        '        resObj.intSQLRC = 0


        '        Select Case True

        '            Case Not resObj.intSQLRC = 0
        '                objCBSEZRA9.RequestStatus.strMessageId = resObj.intSQLRC.ToString
        '                objCBSEZRA9.RequestStatus.strMessageDescription = resObj.strMsgText
        '                Return objCBSEZRA9
        '            Case MyBase.WSDataAccessObj.IsEmptyRecordSet(resObj.DB2DS)
        '                objCBSEZRA9.RequestStatus.strMessageId = "100"
        '                objCBSEZRA9.RequestStatus.strMessageDescription = "No Matching Record Found in CBSS"
        '                Return objCBSEZRA9
        '        End Select

        '        For Each DB2DT In resObj.DB2DS.Tables
        '            For Each DB2DR In DB2DT.Rows
        '                strInpValue = DB2DR(2)
        '            Next DB2DR
        '        Next DB2DT


        '        Dim arrLst As ArrayList = New ArrayList
        '        Dim fxdFld As _fixedField = New _fixedField

        '        fxdFld.strFldName = "strCCFD"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 1240
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCCDTypeOfDataRec"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 2
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCCDCreditData"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 1
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCCDAdvPayDepCde"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 1
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "dblCCDTotDepositsDis"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 13
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "dblCCDAcCrLimAmtDis"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 13
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCCDAcCrLimId"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 1
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "dteCCDAcCrLimEfDt"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 8
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCCDTreatExceptId"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 1
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCCDTrHistoryStat"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 24
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCCDTlBlockStCd"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 1
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCCDWorChkIndr"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 1
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCCDCredRiskCd"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 1
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCCDCustCreditCl"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 1
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCCDDiscReason"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 1
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCCDTreatInstruct"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 94
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCCDCredBureauCd"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 2
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCCDCreditInfo"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 94
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCCDPartnerName"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 20
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCCDTrElgbltyCode"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 1
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCDDTypeOfDataRec"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 2
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCDDDepositData"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 1
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCDDCustPmtRctNo"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 6
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCDDCollnCtrLocn"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 4
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "dblCDDTotDepositsDis"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 13
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "dteCDDDepPaidDate"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 8
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "dblCDDDepRefAmountDis"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 13
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "dteCDDDepRefDat"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 8
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCDDDepRefDispCd"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 1
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCADTypeOfDataRec"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 2
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCADAdjustmentData"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 1
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCADAdjmtBatchId"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 2
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCADPmtAdjSeqNo"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 6
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCADAdjmtActnCode"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 2
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "dteCADAdjustmentDate"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 8
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCADAdjmtTypeCode"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 2
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "dblCADBasicAdjmtAmtDis"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 13
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCADBlCatgCd"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 1
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCADJnlEntDpCode"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 2
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCADPsPvdrId"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 5
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "dblCADTotalAdjmtAmtDis"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 13
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCADTypeOfAdjmt"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 2
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCADSubcic"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 8
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "dteCADAdjBillDt"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 8
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCADClecId"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 5
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCADVoucherNumDis"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 16
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCADVoucherLineNoDis"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 10
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCPDTypeOfDataRec"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 2
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCPDPaymentData"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 1
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCPDCashCollnData"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 8
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCPDCollnCtrLocn"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 4
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCPDCustPmtAmtDis"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 13
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCPDCustPmtType"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 2
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCPDComAcctCkNum"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 17
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCPDBankRouteNum"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 9
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCPDNonStdCkInfo"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 6
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCPDCkAcctNum"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 16
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCPDConAcctCkNum"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 10
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCPDPmtTransNum"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 4
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCBDTypeOfDataRec"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 2
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCBDBalanceData"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 1
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCBDPsPvdrId"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 5
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "strCBDBlCatgCd"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 1
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "dblCBDCurBillChgDis"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 13
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "dblCBDPresentBlChgsDis"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 13
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "dblCBDPrevBal30DayDis"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 13
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "dblCBDPrevBal60DayDis"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 13
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "dblCBDPrevBal90DayDis"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 13
        '        arrLst.Add(fxdFld)

        '        fxdFld.strFldName = "dblCBDTotalBlAmtDis"
        '        fxdFld.fldType = Type.GetType("System.String")
        '        fxdFld.intLength = 13
        '        arrLst.Add(fxdFld)

        '        Dim objCommon As CommonFunctions = New CommonFunctions


        '        objCommon.ParseFixedLayout(strInpValue, arrLst)
        '        objCommon.getTheFileFormat(arrLst, "CBSEZRA9", objCBSEZRA9)


        '    Catch ex As Exception
        '        LogErrorFile.WriteLog("RMICWWS-CBSEZRA9", "AcctNum: " & strAcctNum & " Erroring Out " & ex.ToString)
        '        objCBSEZRA9.RequestStatus.strMessageId = "RMIEXPTN"
        '        objCBSEZRA9.RequestStatus.strMessageDescription = ex.ToString

        '    End Try
        '    Return objCBSEZRA9

        'End Function


        Public Function getCBSS_CBSPTRA9_Full(ByVal strRegionId As String, ByVal strAcctNum As String, ByVal strReqType As String, ByVal strExtInput As String, ByVal strAppId As String, ByVal strGetOption As String) As XmlDocument

            Dim objAcctBalanceInfo As AcctBalanceInfo = New AcctBalanceInfo

            Dim strXml As String = ""
            Dim xmlTRA9 As XmlDocument


            Try
                Dim reqObj As ERARequest = New ERARequest
                Dim resObj As ERAResponse
                Dim DB2DT As DataTable
                Dim DB2DR As DataRow
                Dim strInpValue As String

                reqObj.strExtInput = strExtInput

                If strRegionId.Trim().ToUpper() = "WEST" Then
                    reqObj.strInpTyp = "1"
                    If reqObj.strExtInput.Trim() = "" Then
                        'reqObj.strExtInput = "YY Y"
                        reqObj.strExtInput = "YYA"
                    End If
                Else
                    reqObj.strInpTyp = "2"
                    If reqObj.strExtInput.Trim() = "" Then
                        reqObj.strExtInput = "YYA"
                    End If
                End If

                If strRegionId.Trim().ToUpper() = "MDVW" Then
                    strAcctNum = "000" + strAcctNum
                End If

                reqObj.strAcctNum = strAcctNum.Trim + "       "
                reqObj.strERAName = "CBSPTRA9"
                reqObj.intGetNum = 0

                If strReqType.Trim() = "" Then
                    strReqType = "05"
                End If

                reqObj.strReqType = strReqType
                reqObj.strFmtType = "1"
                reqObj.strRegionId = strRegionId
                Dim obj As BrokerDB2Data = New BrokerDB2Data(reqObj)
                resObj = obj.ERADB2Connect()



                'Select Case True

                '    Case Not resObj.intSQLRC = 0
                '        objAcctBalanceInfo.RequestStatus.strMessageId = resObj.intSQLRC.ToString
                '        objAcctBalanceInfo.RequestStatus.strMessageDescription = resObj.strMsgText
                '        Return objAcctBalanceInfo

                '    Case MyBase.WSDataAccessObj.IsEmptyRecordSet(resObj.DB2DS)
                '        objAcctBalanceInfo.RequestStatus.strMessageId = "100"
                '        objAcctBalanceInfo.RequestStatus.strMessageDescription = "No Matching Record Found in CBSS"
                '        Return objAcctBalanceInfo
                'End Select

                Dim arrLst As ArrayList = New ArrayList

                Dim xmlDoc As XmlDocument

                Dim xmlEle As XmlElement



                xmlTRA9 = New XmlDocument

                'For Each DB2DT In resObj.DB2DS.Tables
                For i As Integer = 0 To resObj.DB2DS.Tables.Count - 1
                    DB2DT = resObj.DB2DS.Tables(i)
                    'For Each DB2DR In DB2DT.Rows
                    For j As Integer = 0 To DB2DT.Rows.Count - 1
                        DB2DR = DB2DT.Rows(j)
                        strInpValue = DB2DR(2)
                        'xmlDoc = New XmlDocument
                        'xmlDoc.LoadXml(strInpValue)
                        strXml = strXml + strInpValue


                    Next j
                Next i

                If resObj.DB2DS.Tables.Count = 0 Then
                    strXml = "MsgCode " + resObj.strMsgCode.ToString() + "MsgText " + resObj.strMsgText.ToString()
                    strXml = System.Text.RegularExpressions.Regex.Replace(strXml, "[+~!@#$%^&*()_+{}|]", "")
                    strXml = System.Text.RegularExpressions.Regex.Replace(strXml, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline))
                    strXml = "<TRA9>" + strXml + "</TRA9>"
                    xmlTRA9.LoadXml(strXml)
                    xmlTRA9.LoadXml(System.Text.RegularExpressions.Regex.Replace(xmlTRA9.OuterXml, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline)))
                Else
                    strXml = strXml.Trim()
                    strXml = System.Text.RegularExpressions.Regex.Replace(strXml, "[+~!@#$%^&*()_+{}|]", "")
                    strXml = System.Text.RegularExpressions.Regex.Replace(strXml, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline))
                    strXml = strXml.Replace("tra9:", "")
                    strXml = System.Text.RegularExpressions.Regex.Replace(strXml, "[^\x09\x0A\x0D\x20-\xD7FF\xE000-\xFFFD\x10000-x10FFFF]", "")
                    strXml = "<TRA9>" + strXml + "</TRA9>"
                    xmlTRA9.XmlResolver = Nothing
                    xmlTRA9.LoadXml(strXml)

                End If


                If strGetOption.Trim() = "1" Then
                    Dim eraDS As DataSet
                    Try
                        strXml = strXml.Replace("tra9:", "")
                        eraDS = MyBase.WSDataAccessObj.usp_InsertERAResponse(strAcctNum, strRegionId, "TRA9", strXml)
                    Catch exTra9 As Exception
                        LogErrorFile.WriteLog("WSTRA9_Full", exTra9.ToString())

                    End Try


                End If


            Catch ex As Exception

                LogErrorFile.WriteLog("RMICWWS-CBSPTRA9", "AcctNum: " & strAcctNum & " Erroring Out " & ex.ToString)
                strXml = ex.ToString
                strXml = System.Text.RegularExpressions.Regex.Replace(strXml, "[+~!@#$%^&*()_+{}|]", "")
                strXml = System.Text.RegularExpressions.Regex.Replace(strXml, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline))
                strXml = "<TRA9>" + ex.ToString + "</TRA9>"
                xmlTRA9.XmlResolver = Nothing
                xmlTRA9.LoadXml(strXml)
                xmlTRA9.LoadXml(System.Text.RegularExpressions.Regex.Replace(xmlTRA9.OuterXml, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline)))

            End Try

            Return xmlTRA9


        End Function


        Public Function getCBSS_CBSPTRA9_CreditInfo(ByVal strRegionId As String, ByVal strAcctNum As String) As CBSPTRA9_CreditInfo

            Dim objCreditInfo As CBSPTRA9_CreditInfo = New CBSPTRA9_CreditInfo
            Try
                Dim reqObj As ERARequest = New ERARequest
                Dim resObj As ERAResponse
                Dim DB2DT As DataTable
                Dim DB2DR As DataRow
                Dim strInpValue As String

                Select Case True

                    Case strRegionId Is Nothing Or strRegionId.Trim = ""
                        objCreditInfo.RequestStatus.strMessageId = "INVRGNID"
                        objCreditInfo.RequestStatus.strMessageDescription = "Invalid Region Id passed."
                        Return objCreditInfo
                    Case strAcctNum Is Nothing Or strAcctNum.Trim = ""
                        objCreditInfo.RequestStatus.strMessageId = "INVACNBR"
                        objCreditInfo.RequestStatus.strMessageDescription = "Invalid Account Number passed as Input."
                        Return objCreditInfo
                End Select

                reqObj.strAcctNum = strAcctNum
                reqObj.strERAName = "CBSPTRA9"
                reqObj.strExtInput = " "
                reqObj.strInpTyp = "1"
                reqObj.strReqType = "00"
                reqObj.strRegionId = strRegionId
                reqObj.strFmtType = "1"
                reqObj.strStartInstance = "0"
                reqObj.intGetNum = 0
                reqObj.strStartInstance = " "
                reqObj.strScope = " "

                Dim obj As BrokerDB2Data = New BrokerDB2Data(reqObj)
                resObj = obj.ERADB2Connect()





                Select Case True

                    Case Not resObj.intSQLRC = 0
                        objCreditInfo.RequestStatus.strMessageId = resObj.intSQLRC.ToString
                        objCreditInfo.RequestStatus.strMessageDescription = resObj.strMsgText
                        Return objCreditInfo
                    Case MyBase.WSDataAccessObj.IsEmptyRecordSet(resObj.DB2DS)
                        objCreditInfo.RequestStatus.strMessageId = "100"
                        objCreditInfo.RequestStatus.strMessageDescription = "No Matching Record Found in CBSS"
                        Return objCreditInfo
                End Select




                'For Each DB2DT In resObj.DB2DS.Tables
                For i As Integer = 0 To resObj.DB2DS.Tables.Count - 1
                    DB2DT = resObj.DB2DS.Tables(i)
                    'For Each DB2DR In DB2DT.Rows
                    For j As Integer = 0 To DB2DT.Rows.Count - 1
                        DB2DR = DB2DT.Rows(j)
                        strInpValue = DB2DR(2)
                    Next j
                Next i

                Dim xmlDoc As XmlDocument = New XmlDocument
                Dim xmlEle As XmlElement
                Dim strCreditLimitEffDt As String



                xmlDoc.XmlResolver = Nothing
                xmlDoc.LoadXml(strInpValue)
                xmlEle = xmlDoc.DocumentElement

                objCreditInfo.strAdvPayDepCd = xmlEle.GetElementsByTagName("AdvancePaymentDepositCode").Item(0).InnerXml()
                objCreditInfo.curTotalDeposits = Convert.ToDouble(xmlEle.GetElementsByTagName("AccountCreditLimitAmount").Item(0).InnerXml())
                objCreditInfo.curAcctCreditLimiAmt = Convert.ToDouble(xmlEle.GetElementsByTagName("AccountCreditLimitAmount").Item(0).InnerXml())
                objCreditInfo.strAcctCreditLimitId = xmlEle.GetElementsByTagName("AcctCreditLimitIdentifier").Item(0).InnerXml()
                strCreditLimitEffDt = xmlEle.GetElementsByTagName("AcctCreditLimitEffvDate").Item(0).InnerXml()


                objCreditInfo.dtmAcctCreditLimitEffDt = New DateTime(strCreditLimitEffDt.Substring(0, 4), strCreditLimitEffDt.Substring(4, 2), strCreditLimitEffDt.Substring(6, 2))
                objCreditInfo.strTrtExceptionId = xmlEle.GetElementsByTagName("TreatmentExceptionIdentifier").Item(0).InnerXml()
                objCreditInfo.strTrtHistory = xmlEle.GetElementsByTagName("TreatmentHistoryStatus").Item(0).InnerXml()
                objCreditInfo.strTollBlockStatusCd = xmlEle.GetElementsByTagName("TollBlockStatusCode").Item(0).InnerXml()
                objCreditInfo.strWorthlessCheckInd = xmlEle.GetElementsByTagName("WorthlessCheckIndr").Item(0).InnerXml()
                objCreditInfo.strCreditRiskCd = xmlEle.GetElementsByTagName("CreditRiskCode").Item(0).InnerXml()
                objCreditInfo.strCustCreditCl = xmlEle.GetElementsByTagName("CustomerCreditClass").Item(0).InnerXml()
                objCreditInfo.strDiscReason = xmlEle.GetElementsByTagName("DisconnectReason").Item(0).InnerXml()
                objCreditInfo.strTrtInstruction = xmlEle.GetElementsByTagName("TreatmentInstruction").Item(0).InnerXml()
                objCreditInfo.strCreditBureauCd = xmlEle.GetElementsByTagName("CreditBureauCode").Item(0).InnerXml()
                objCreditInfo.strCreditInfo = xmlEle.GetElementsByTagName("CreditInformation").Item(0).InnerXml()
                objCreditInfo.strPartnerName = xmlEle.GetElementsByTagName("PartnerName").Item(0).InnerXml()
                objCreditInfo.strTrtEligibilityCd = xmlEle.GetElementsByTagName("TreatmentEligibilityCode").Item(0).InnerXml()
                objCreditInfo.strResponsibleParty = xmlEle.GetElementsByTagName("ResponsiblePartyName").Item(0).InnerXml()




            Catch ex As Exception

                LogErrorFile.WriteLog("RMICWWS-CBSPTRA9", "AcctNum: " & strAcctNum & " Erroring Out " & ex.ToString)
                objCreditInfo.RequestStatus.strMessageId = "RMIEXPTN"
                objCreditInfo.RequestStatus.strMessageDescription = ex.ToString

            End Try

            Return objCreditInfo
        End Function

        Public Function getCBSS_CBSPTRA9_CustomerBalance(ByVal strRegionId As String, ByVal strAcctNum As String, ByVal strReqType As String, ByVal strExtInput As String, ByVal strAppId As String, ByVal strGetOption As String) As AcctBalanceInfo



            Dim objAcctBalanceInfo As AcctBalanceInfo = New AcctBalanceInfo


            Try
                Dim reqObj As ERARequest = New ERARequest
                Dim resObj As ERAResponse
                Dim DB2DT As DataTable
                Dim DB2DR As DataRow
                Dim strInpValue As String

                Select Case True

                    Case strRegionId Is Nothing Or strRegionId.Trim = ""
                        objAcctBalanceInfo.RequestStatus.strMessageId = "INVRGNID"
                        objAcctBalanceInfo.RequestStatus.strMessageDescription = "Invalid Region Id passed."
                        Return objAcctBalanceInfo

                    Case strAcctNum Is Nothing Or strAcctNum.Trim = ""

                        objAcctBalanceInfo.RequestStatus.strMessageId = "INVACNBR"
                        objAcctBalanceInfo.RequestStatus.strMessageDescription = "Invalid Account Number passed as Input."
                        Return objAcctBalanceInfo

                End Select
                reqObj.strExtInput = strExtInput.Trim()
                reqObj.strAcctNum = strAcctNum.Trim()
                reqObj.strReqType = strReqType.Trim()
                reqObj.strERAName = "CBSPTRA9"
                If reqObj.strExtInput.Trim() = "" Then
                    reqObj.strExtInput = "NC" 'Get the Current Balance DataRecordType will be CB instead of B - Bal Tx Process uses NC & 04 
                End If

                reqObj.strInpTyp = "1"

                If reqObj.strReqType.Trim() = "" Then
                    strReqType = "04"
                End If



                If strRegionId.Trim().ToUpper() = "MDVW" Then
                    strAcctNum = "000" + strAcctNum
                End If

                reqObj.strAcctNum = strAcctNum.Trim + "       "


                '************************************************
                If strAppId = "BKCY" Then

                    reqObj.strExtInput = strExtInput

                    If strRegionId.Trim().ToUpper() = "WEST" Then
                        reqObj.strInpTyp = "1"
                        If reqObj.strExtInput.Trim() = "" Then
                            'reqObj.strExtInput = "YY Y"
                            reqObj.strExtInput = "YYA"
                        End If
                    Else
                        reqObj.strInpTyp = "2"
                        If reqObj.strExtInput.Trim() = "" Then
                            reqObj.strExtInput = "YYA"
                        End If
                    End If

                    If strReqType.Trim() = "" Then
                        strReqType = "05"
                    End If
                End If


                '*************************************************



                reqObj.strReqType = strReqType
                reqObj.strFmtType = "1"
                reqObj.strRegionId = strRegionId
                reqObj.intGetNum = 0
                reqObj.strStartInstance = " "
                reqObj.strScope = " "
                Dim objTRA9 As BrokerDB2Data = New BrokerDB2Data(reqObj)
                resObj = objTRA9.ERADB2Connect()











                'Select Case True

                '    Case Not resObj.intSQLRC = 0
                '        objAcctBalanceInfo.RequestStatus.strMessageId = resObj.intSQLRC.ToString
                '        objAcctBalanceInfo.RequestStatus.strMessageDescription = resObj.strMsgText
                '        Return objAcctBalanceInfo

                '    Case MyBase.WSDataAccessObj.IsEmptyRecordSet(resObj.DB2DS)
                '        objAcctBalanceInfo.RequestStatus.strMessageId = "100"
                '        objAcctBalanceInfo.RequestStatus.strMessageDescription = "No Matching Record Found in CBSS"
                '        Return objAcctBalanceInfo
                'End Select


                objAcctBalanceInfo.strAcctNum = strAcctNum
                Dim arrLst As ArrayList = New ArrayList

                Dim xmlDoc As XmlDocument
                Dim xmlEle As XmlElement


                Dim objCommon As CommonFunctions = New CommonFunctions
                Dim objCBSPTRA9_CustomerBalance As CBSPTRA9_CustomerBalance

                'For Each DB2DT In resObj.DB2DS.Tables
                For i As Integer = 0 To resObj.DB2DS.Tables.Count - 1
                    DB2DT = resObj.DB2DS.Tables(i)
                    'For Each DB2DR In DB2DT.Rows
                    For j As Integer = 0 To DB2DT.Rows.Count - 1
                        DB2DR = DB2DT.Rows(j)
                        strInpValue = DB2DR(2)

                        objCBSPTRA9_CustomerBalance = New CBSPTRA9_CustomerBalance
                        'strInpValue = Regex.Replace(strInpValue, "[^\w$.* ]", "")
                        'objCommon.ParseFixedLayout(strInpValue, arrLst)
                        'objCommon.getTheFileFormat(arrLst, "CBSPTRA9_CustomerBalance", objCBSPTRA9_CustomerBalance)

                        xmlDoc = New XmlDocument
                        xmlDoc.XmlResolver = Nothing
                        xmlDoc.LoadXml(strInpValue)
                        xmlEle = xmlDoc.DocumentElement


                        If (xmlEle.GetElementsByTagName("DataRecordType").Item(0).InnerXml() = "B") Or (xmlEle.GetElementsByTagName("DataRecordType").Item(0).InnerXml() = "CB") Or (xmlEle.GetElementsByTagName("DataRecordType").Item(0).InnerXml() = "TB") Then
                            objCBSPTRA9_CustomerBalance.strDataRecordType = xmlEle.GetElementsByTagName("DataRecordType").Item(0).InnerXml()
                            objCBSPTRA9_CustomerBalance.strProductServiceProviderId = xmlEle.GetElementsByTagName("ProductServiceProviderId").Item(0).InnerXml()
                            objCBSPTRA9_CustomerBalance.strBillingCategoryCode = xmlEle.GetElementsByTagName("BillingCategoryCode").Item(0).InnerXml()
                            objCBSPTRA9_CustomerBalance.curProviderCurrentBillCharges = Convert.ToDouble(xmlEle.GetElementsByTagName("ProviderCurrentBillCharges").Item(0).InnerXml())
                            objCBSPTRA9_CustomerBalance.curPresentBillCharges = Convert.ToDouble(xmlEle.GetElementsByTagName("PresentBillCharges").Item(0).InnerXml())
                            objCBSPTRA9_CustomerBalance.curPreviousBalance30Day = Convert.ToDouble(xmlEle.GetElementsByTagName("PreviousBalance30Day").Item(0).InnerXml())
                            objCBSPTRA9_CustomerBalance.curPreviousBalance60Day = Convert.ToDouble(xmlEle.GetElementsByTagName("PreviousBalance60Day").Item(0).InnerXml())
                            objCBSPTRA9_CustomerBalance.curPreviousBalance90Day = Convert.ToDouble(xmlEle.GetElementsByTagName("PreviousBalance90Day").Item(0).InnerXml())
                            objCBSPTRA9_CustomerBalance.curTotalBillableAmount = Convert.ToDouble(xmlEle.GetElementsByTagName("TotalBillableAmount").Item(0).InnerXml())
                            objCBSPTRA9_CustomerBalance.curCurrentDemandCharges = Convert.ToDouble(xmlEle.GetElementsByTagName("CurrentDemandCharges").Item(0).InnerXml())
                            objCBSPTRA9_CustomerBalance.curPreviousBalance15Day = Convert.ToDouble(xmlEle.GetElementsByTagName("PreviousBalance15Day").Item(0).InnerXml())
                            objCBSPTRA9_CustomerBalance.curPreviousBalance45Day = Convert.ToDouble(xmlEle.GetElementsByTagName("PreviousBalance45Day").Item(0).InnerXml())
                            objCBSPTRA9_CustomerBalance.curPreviousBalance75Day = Convert.ToDouble(xmlEle.GetElementsByTagName("PreviousBalance75Day").Item(0).InnerXml())
                            objCBSPTRA9_CustomerBalance.curPreviousDemandCharges = Convert.ToDouble(xmlEle.GetElementsByTagName("PreviousDemandCharges").Item(0).InnerXml())
                            objCBSPTRA9_CustomerBalance.strBalanceType = xmlEle.GetElementsByTagName("BalanceType").Item(0).InnerXml()
                            objCBSPTRA9_CustomerBalance.curUnbilledCharges = Convert.ToDouble(xmlEle.GetElementsByTagName("UnbilledCharges").Item(0).InnerXml())
                            objCBSPTRA9_CustomerBalance.strBalanceDate = xmlEle.GetElementsByTagName("BalanceDate").Item(0).InnerXml()


                            objAcctBalanceInfo.arrLstBalanceDetails.Add(objCBSPTRA9_CustomerBalance)

                        End If


                        'If xmlEle.GetElementsByTagName("ProductServiceProviderId").Count > 0 Then
                        '    objCBSPTRA9_CustomerBalance.strProductServiceProviderId = xmlEle.GetElementsByTagName("ProductServiceProviderId").Item(0).InnerXml()
                        'End If



                    Next j
                Next i




            Catch ex As Exception

                LogErrorFile.WriteLog("RMICWWS-CBSPTRA9", "AcctNum: " & strAcctNum & " Erroring Out " & ex.ToString)
                objAcctBalanceInfo.RequestStatus.strMessageId = "RMIEXPTN"
                objAcctBalanceInfo.RequestStatus.strMessageDescription = ex.ToString

            End Try

            Return objAcctBalanceInfo

        End Function

        Public Function getCBSS_CBSPTRA9_Adjustment(ByVal strRegionId As String, ByVal strAcctNum As String) As AdjustmentInfo

            Dim objAdjustmentInfo As AdjustmentInfo = New AdjustmentInfo

            Try
                Dim reqObj As ERARequest = New ERARequest
                Dim resObj As ERAResponse
                Dim DB2DT As DataTable
                Dim DB2DR As DataRow
                Dim strInpValue As String

                Select Case True

                    Case strRegionId Is Nothing Or strRegionId.Trim = ""
                        objAdjustmentInfo.RequestStatus.strMessageId = "INVRGNID"
                        objAdjustmentInfo.RequestStatus.strMessageDescription = "Invalid Region Id passed."
                        Return objAdjustmentInfo

                    Case strAcctNum Is Nothing Or strAcctNum.Trim = ""

                        objAdjustmentInfo.RequestStatus.strMessageId = "INVACNBR"
                        objAdjustmentInfo.RequestStatus.strMessageDescription = "Invalid Account Number passed as Input."
                        Return objAdjustmentInfo

                End Select

                reqObj.strAcctNum = strAcctNum
                reqObj.strERAName = "CBSPTRA9"
                reqObj.strExtInput = "Y"
                reqObj.strInpTyp = "1"
                reqObj.strReqType = "02"
                reqObj.strRegionId = strRegionId
                reqObj.strFmtType = "1"
                reqObj.strStartInstance = "0"
                reqObj.intGetNum = 0
                reqObj.strStartInstance = " "
                reqObj.strScope = " "

                Dim obj As BrokerDB2Data = New BrokerDB2Data(reqObj)
                resObj = obj.ERADB2Connect()



                Select Case True

                    Case Not resObj.intSQLRC = 0
                        objAdjustmentInfo.RequestStatus.strMessageId = resObj.intSQLRC.ToString
                        objAdjustmentInfo.RequestStatus.strMessageDescription = resObj.strMsgText
                        Return objAdjustmentInfo

                    Case MyBase.WSDataAccessObj.IsEmptyRecordSet(resObj.DB2DS)
                        objAdjustmentInfo.RequestStatus.strMessageId = "100"
                        objAdjustmentInfo.RequestStatus.strMessageDescription = "No Matching Record Found in CBSS"
                        Return objAdjustmentInfo
                End Select


                objAdjustmentInfo.strAcctNum = strAcctNum
                Dim arrLst As ArrayList = New ArrayList

                Dim xmlDoc As XmlDocument
                Dim xmlEle As XmlElement


                Dim objCommon As CommonFunctions = New CommonFunctions
                Dim objCBSPTRA9_Adjustment As CBSPTRA9_Adjustment

                'For Each DB2DT In resObj.DB2DS.Tables
                For i As Integer = 0 To resObj.DB2DS.Tables.Count - 1
                    DB2DT = resObj.DB2DS.Tables(i)
                    'For Each DB2DR In DB2DT.Rows
                    For j As Integer = 0 To DB2DT.Rows.Count - 1
                        DB2DR = DB2DT.Rows(j)
                        strInpValue = DB2DR(2)


                        objCBSPTRA9_Adjustment = New CBSPTRA9_Adjustment


                        'strInpValue = Regex.Replace(strInpValue, "[^\w$.* ]", "")
                        'objCommon.ParseFixedLayout(strInpValue, arrLst)
                        'objCommon.getTheFileFormat(arrLst, "CBSPTRA9_CustomerBalance", objCBSPTRA9_CustomerBalance)

                        xmlDoc = New XmlDocument
                        xmlDoc.XmlResolver = Nothing
                        xmlDoc.LoadXml(strInpValue)
                        xmlEle = xmlDoc.DocumentElement


                        objCBSPTRA9_Adjustment.curBasicAdjustmentAmount = Convert.ToDouble(xmlEle.GetElementsByTagName("BasicAdjustmentAmount").Item(0).InnerXml())
                        objCBSPTRA9_Adjustment.curTotalAdjustmentAmount = Convert.ToDouble(xmlEle.GetElementsByTagName("TotalAdjustmentAmount").Item(0).InnerXml())

                        objCBSPTRA9_Adjustment.strAdjustmentActionCode = xmlEle.GetElementsByTagName("AdjustmentActionCode").Item(0).InnerXml()
                        objCBSPTRA9_Adjustment.strAdjustmentBatchId = xmlEle.GetElementsByTagName("AdjustmentBatchId").Item(0).InnerXml()
                        objCBSPTRA9_Adjustment.strAdjustmentDate = xmlEle.GetElementsByTagName("AdjustmentDate").Item(0).InnerXml()
                        objCBSPTRA9_Adjustment.strAdjustmentForCustBillDate = xmlEle.GetElementsByTagName("AdjustmentForCustBillDate").Item(0).InnerXml()
                        objCBSPTRA9_Adjustment.strAdjustmentType = xmlEle.GetElementsByTagName("AdjustmentType").Item(0).InnerXml()
                        objCBSPTRA9_Adjustment.strAdjustmentTypeCode = xmlEle.GetElementsByTagName("AdjustmentTypeCode").Item(0).InnerXml()
                        objCBSPTRA9_Adjustment.strBillingCategoryCode = xmlEle.GetElementsByTagName("BillingCategoryCode").Item(0).InnerXml()
                        objCBSPTRA9_Adjustment.strClecId = xmlEle.GetElementsByTagName("ClecId").Item(0).InnerXml()
                        objCBSPTRA9_Adjustment.strDataRecordType = xmlEle.GetElementsByTagName("DataRecordType").Item(0).InnerXml()
                        objCBSPTRA9_Adjustment.strJournalEntryDpCode = xmlEle.GetElementsByTagName("JournalEntryDpCode").Item(0).InnerXml()
                        objCBSPTRA9_Adjustment.strPaymentAdjustmentSeqNumber = xmlEle.GetElementsByTagName("PaymentAdjustmentSeqNumber").Item(0).InnerXml()
                        objCBSPTRA9_Adjustment.strProductServiceProviderId = xmlEle.GetElementsByTagName("ProductServiceProviderId").Item(0).InnerXml()
                        objCBSPTRA9_Adjustment.strReturnedCheckReasonCode = xmlEle.GetElementsByTagName("ReturnedCheckReasonCode").Item(0).InnerXml()
                        objCBSPTRA9_Adjustment.strSecondaryBlgCarrierIdCode = xmlEle.GetElementsByTagName("SecondaryBlgCarrierIdCode").Item(0).InnerXml()
                        objCBSPTRA9_Adjustment.strVoucherLineNumber = xmlEle.GetElementsByTagName("VoucherLineNumber").Item(0).InnerXml()
                        objCBSPTRA9_Adjustment.strVoucherNumber = xmlEle.GetElementsByTagName("VoucherNumber").Item(0).InnerXml()


                        objAdjustmentInfo.arrLstAdjustmentDetails.Add(objCBSPTRA9_Adjustment)


                    Next j
                Next i


            Catch ex As Exception

                LogErrorFile.WriteLog("RMICWWS-CBSPTRA9", "AcctNum: " & strAcctNum & " Erroring Out " & ex.ToString)
                objAdjustmentInfo.RequestStatus.strMessageId = "RMIEXPTN"
                objAdjustmentInfo.RequestStatus.strMessageDescription = ex.ToString

            End Try

            Return objAdjustmentInfo

        End Function

        'CBSPCFA1 - Calculate Customer Balances
        Public Function getCBSS_CBSPCFA1_BalanceInfo(ByVal strRegionId As String, ByVal strAcctNum As String) As CFIBalanceInfo

            'Dim objAcctBalanceInfo As AcctBalanceInfo = New AcctBalanceInfo
            Dim objCFIBalanceInfo As CFIBalanceInfo = New CFIBalanceInfo
            Dim strUrl As String = ""
            Dim curPPXAmt As Double = 0
            Dim curAdjAmt As Double = 0
            Dim objCFIInp As CFIBalanceInput = New CFIBalanceInput
            Dim strCFIxml As String = ""


            Try
                Dim reqObj As ERARequest = New ERARequest
                Dim resObj As ERAResponse
                Dim DB2DT As DataTable
                Dim DB2DR As DataRow
                Dim strInpValue As String

                Select Case True

                    Case strRegionId Is Nothing Or strRegionId.Trim = ""

                        objCFIBalanceInfo.RequestStatus.strMessageId = "INVRGNID"
                        objCFIBalanceInfo.RequestStatus.strMessageDescription = "Invalid Region Id passed."
                        Return objCFIBalanceInfo


                    Case strAcctNum Is Nothing Or strAcctNum.Trim = ""

                        objCFIBalanceInfo.RequestStatus.strMessageId = "INVACNBR"
                        objCFIBalanceInfo.RequestStatus.strMessageDescription = "Invalid Account Number passed as Input."
                        Return objCFIBalanceInfo

                End Select

                reqObj.strAcctNum = strAcctNum
                reqObj.strERAName = "CBSPCFA1"
                'reqObj.strExtInput = " "
                reqObj.strExtInput = "            Y" 'passing Y in the 13th position will give the Bill Due date back
                reqObj.strInpTyp = "1"
                reqObj.strReqType = "00"
                reqObj.strRegionId = strRegionId
                reqObj.strFmtType = "1"
                reqObj.strStartInstance = "0"
                reqObj.intGetNum = 0
                reqObj.strStartInstance = " "
                reqObj.strScope = "A"





                'cmd.Parameters["@EXTINPUT"].Value = "            Y" ; //passing Y in the 13th position will give the Bill Due date back


                Try
                    Dim objWsMain As WSMain = New WSMain
                    Dim xmlResultDoc As XmlDocument = New XmlDocument
                    xmlResultDoc = objWsMain.getPPXinfo(MyBase.RegionId.Trim, strAcctNum)
                    If Not xmlResultDoc Is Nothing Then
                        Try
                            Dim AmountList As XmlNodeList = xmlResultDoc.SelectNodes("//NewDataSet/Table")
                            Dim ReturnCdNode As XmlNode
                            Dim strAmount As String
                            Dim strAmountAdj As String
                            Dim strReturnCd As String = ""
                            '    For Each ReturnCdNode In AmountList
                            Dim Amount As XmlNode
                            If Not AmountList Is Nothing Then
                                'For Each Amount In AmountList
                                For i As Integer = 0 To AmountList.Count - 1
                                    Amount = AmountList(i)
                                    strReturnCd = Amount.SelectSingleNode("strvenderid").InnerText.ToString()
                                    If strReturnCd = "R01" OrElse strReturnCd = "M06" Then

                                        If Not Amount.SelectSingleNode("curppxamount") Is Nothing Then
                                            curAdjAmt += Amount.SelectSingleNode("curppxamount").InnerText.ToString() * -1
                                        End If
                                    Else
                                        If Not Amount.SelectSingleNode("curppxamount") Is Nothing Then
                                            curPPXAmt += Amount.SelectSingleNode("curppxamount").InnerText.ToString()
                                        End If
                                    End If
                                Next
                            End If
             
                        Catch ex As Exception
                            curPPXAmt = 0.0
                            LogErrorFile.WriteLog("getCBSS_CBSPCFA1_BalanceInfo West", "AcctNum: " & strAcctNum & " Erroring Out while getting PPX amount " & ex.ToString)
                        End Try
                    End If

                Catch ex As Exception
                    LogErrorFile.WriteLog("getCBSS_CBSPCFA1_BalanceInfo West", "AcctNum: " & strAcctNum & " Erroring Out while getting PPX Info " & ex.ToString)
                End Try

                objCFIInp.strGetPPX = "N"
                objCFIInp.strGetAdj = "N"
                If curPPXAmt > 0 Then
                    objCFIInp.curPPXAmt = curPPXAmt
                    objCFIInp.strGetPPX = "Y"
                End If

                If curAdjAmt > 0 Then
                    objCFIInp.curAdjAmt = curAdjAmt
                    objCFIInp.strGetAdj = "Y"

                End If

                objCFIInp.strRegioncd = strRegionId

                reqObj.strCFIInp = getCFIDataIn(objCFIInp)


                Dim obj As BrokerDB2Data = New BrokerDB2Data(reqObj)
                resObj = obj.ERADB2Connect()


                Select Case True

                    Case Not resObj.intSQLRC = 0
                        objCFIBalanceInfo.RequestStatus.strMessageId = resObj.intSQLRC.ToString
                        objCFIBalanceInfo.RequestStatus.strMessageDescription = resObj.strMsgText
                        Return objCFIBalanceInfo

                    Case MyBase.WSDataAccessObj.IsEmptyRecordSet(resObj.DB2DS)
                        objCFIBalanceInfo.RequestStatus.strMessageId = "100"
                        objCFIBalanceInfo.RequestStatus.strMessageDescription = "No Matching Record Found in CBSS"
                        Return objCFIBalanceInfo
                End Select

                'need BillDueDate to calculate Past Due
                'PastDue = TotalDue - current changes that's not due
                Dim dtBillDueDate As Date
                Dim curCurrentChargesNotDueBasic As Double = 0
                Dim curCurrentChargesNotDueNonBasic As Double = 0
                Dim curCurrentChargesNotDueToll As Double = 0


                dtBillDueDate = Convert.ToDateTime(resObj.strEXTOut)


                objCFIBalanceInfo.strAcctNum = strAcctNum
                Dim arrLst As ArrayList = New ArrayList

                Dim xmlDoc As XmlDocument
                Dim xmlEle As XmlElement


                Dim objCommon As CommonFunctions = New CommonFunctions
                'Dim objCBSPTRA9_CustomerBalance As CBSPTRA9_CustomerBalance
                Dim objCBSPCFA1_BalanceInfo As CBSPCFA1_BalanceInfo

                'varibles for TotalDue, TreatbaleDue and PastDue
                'Dim curTotalDueBasic As Double = 0
                'Dim curTotalDueNonBasic As Double = 0
                'Dim curTotalDueToll As Double = 0
                'Dim curTreatableDueBasic As Double
                'Dim curTreatableDueNonBasic As Double
                'Dim curTreatableDueToll As Double
                'Dim curPastDueBasic As Double
                'Dim curPastDueNonBasic As Double
                'Dim curPastDueToll As Double

                'For Each DB2DT In resObj.DB2DS.Tables
                For i As Integer = 0 To resObj.DB2DS.Tables.Count - 1
                    DB2DT = resObj.DB2DS.Tables(i)
                    'For Each DB2DR In DB2DT.Rows
                    For j As Integer = 0 To DB2DT.Rows.Count - 1
                        DB2DR = DB2DT.Rows(j)
                        strInpValue = DB2DR(2)

                        'objCBSPTRA9_CustomerBalance = New CBSPTRA9_CustomerBalance
                        objCBSPCFA1_BalanceInfo = New CBSPCFA1_BalanceInfo
                        'strInpValue = Regex.Replace(strInpValue, "[^\w$.* ]", "")
                        'objCommon.ParseFixedLayout(strInpValue, arrLst)
                        'objCommon.getTheFileFormat(arrLst, "CBSPTRA9_CustomerBalance", objCBSPTRA9_CustomerBalance)

                        xmlDoc = New XmlDocument
                        xmlDoc.XmlResolver = Nothing
                        xmlDoc.LoadXml(strInpValue)

                        strCFIxml = strCFIxml + strInpValue


                        xmlEle = xmlDoc.DocumentElement

                        Dim strKeyDataRecordType As String

                        strKeyDataRecordType = xmlEle.GetElementsByTagName("KeyDataRecordType").Item(0).InnerXml()

                        If strKeyDataRecordType.Trim = "CB" Then

                            objCBSPCFA1_BalanceInfo.strKeyDataRecordType = xmlEle.GetElementsByTagName("KeyDataRecordType").Item(0).InnerXml()
                            objCBSPCFA1_BalanceInfo.strKeyProductServiceProviderId = xmlEle.GetElementsByTagName("KeyProductServiceProviderId").Item(0).InnerXml()
                            objCBSPCFA1_BalanceInfo.strKeyBillingCategoryCode = xmlEle.GetElementsByTagName("KeyBillingCategoryCode").Item(0).InnerXml()

                            objCBSPCFA1_BalanceInfo.strDataRecordType = xmlEle.GetElementsByTagName("DataRecordType").Item(0).InnerXml()
                            objCBSPCFA1_BalanceInfo.strBalanceDate = xmlEle.GetElementsByTagName("BalanceDate").Item(0).InnerXml()
                            objCBSPCFA1_BalanceInfo.strProductServiceProviderId = xmlEle.GetElementsByTagName("ProductServiceProviderId").Item(0).InnerXml()
                            objCBSPCFA1_BalanceInfo.strBillingCategoryCode = xmlEle.GetElementsByTagName("BillingCategoryCode").Item(0).InnerXml()


                            objCBSPCFA1_BalanceInfo.curCurrentBillCharges = Convert.ToDouble(xmlEle.GetElementsByTagName("CurrentBillCharges").Item(0).InnerXml())
                            objCBSPCFA1_BalanceInfo.curDeferredBillingAmount = Convert.ToDouble(xmlEle.GetElementsByTagName("DeferredBillingAmount").Item(0).InnerXml())
                            objCBSPCFA1_BalanceInfo.curHistoryDeferredAmount = Convert.ToDouble(xmlEle.GetElementsByTagName("HistoryDeferredAmount").Item(0).InnerXml())
                            objCBSPCFA1_BalanceInfo.strLatePaymentIndicator = xmlEle.GetElementsByTagName("LatePaymentIndicator").Item(0).InnerXml()

                            objCBSPCFA1_BalanceInfo.curPreviousBalance15Day = Convert.ToDouble(xmlEle.GetElementsByTagName("PreviousBalance15Day").Item(0).InnerXml())
                            objCBSPCFA1_BalanceInfo.curPreviousBalance30Day = Convert.ToDouble(xmlEle.GetElementsByTagName("PreviousBalance30Day").Item(0).InnerXml())
                            objCBSPCFA1_BalanceInfo.curPreviousBalance45Day = Convert.ToDouble(xmlEle.GetElementsByTagName("PreviousBalance45Day").Item(0).InnerXml())
                            objCBSPCFA1_BalanceInfo.curPreviousBalance60Day = Convert.ToDouble(xmlEle.GetElementsByTagName("PreviousBalance60Day").Item(0).InnerXml())
                            objCBSPCFA1_BalanceInfo.curPreviousBalance75Day = Convert.ToDouble(xmlEle.GetElementsByTagName("PreviousBalance75Day").Item(0).InnerXml())
                            objCBSPCFA1_BalanceInfo.curPreviousBalance90Day = Convert.ToDouble(xmlEle.GetElementsByTagName("PreviousBalance90Day").Item(0).InnerXml())

                            objCBSPCFA1_BalanceInfo.strProviderBillIndicator = xmlEle.GetElementsByTagName("ProviderBillIndicator").Item(0).InnerXml()
                            objCBSPCFA1_BalanceInfo.strProviderStatus = xmlEle.GetElementsByTagName("ProviderStatus").Item(0).InnerXml()
                            objCBSPCFA1_BalanceInfo.curTotalAmountDueProvider = Convert.ToDouble(xmlEle.GetElementsByTagName("TotalAmountDueProvider").Item(0).InnerXml())
                            objCBSPCFA1_BalanceInfo.curTotalWriteoffAmount = Convert.ToDouble(xmlEle.GetElementsByTagName("TotalWriteoffAmount").Item(0).InnerXml())



                            objCBSPCFA1_BalanceInfo.curTotalBillableAmount = Convert.ToDouble(xmlEle.GetElementsByTagName("TotalBillableAmount").Item(0).InnerXml())

                            objCBSPCFA1_BalanceInfo.curCurrentDemandCharges = Convert.ToDouble(xmlEle.GetElementsByTagName("CurrentDemandCharges").Item(0).InnerXml())
                            objCBSPCFA1_BalanceInfo.curPreviousDemandCharges = Convert.ToDouble(xmlEle.GetElementsByTagName("PreviousDemandCharges").Item(0).InnerXml())
                            objCBSPCFA1_BalanceInfo.curPresentBillCharges = Convert.ToDouble(xmlEle.GetElementsByTagName("PresentBillCharges").Item(0).InnerXml())
                            objCBSPCFA1_BalanceInfo.strLastLpcAppliedDate = xmlEle.GetElementsByTagName("LastLpcAppliedDate").Item(0).InnerXml()
                            objCBSPCFA1_BalanceInfo.strLpcAppliedDate = xmlEle.GetElementsByTagName("LpcAppliedDate").Item(0).InnerXml()
                            objCBSPCFA1_BalanceInfo.curYtdLateCharges = Convert.ToDouble(xmlEle.GetElementsByTagName("YtdLateCharges").Item(0).InnerXml())
                            objCBSPCFA1_BalanceInfo.curUnbilledCharges = Convert.ToDouble(xmlEle.GetElementsByTagName("UnbilledCharges").Item(0).InnerXml())

                            objCFIBalanceInfo.arrLstBalanceDetails.Add(objCBSPCFA1_BalanceInfo)

                            'calculate TotalDue for Basic, NB and Toll
                            Select Case objCBSPCFA1_BalanceInfo.strBillingCategoryCode
                                Case "B"
                                    objCFIBalanceInfo.curTotalDueBasic = objCFIBalanceInfo.curTotalDueBasic + objCBSPCFA1_BalanceInfo.curTotalAmountDueProvider
                                Case "N", "4"
                                    objCFIBalanceInfo.curTotalDueNonBasic = objCFIBalanceInfo.curTotalDueNonBasic + objCBSPCFA1_BalanceInfo.curTotalAmountDueProvider
                                Case "L", "T"
                                    objCFIBalanceInfo.curTotalDueToll = objCFIBalanceInfo.curTotalDueToll + objCBSPCFA1_BalanceInfo.curTotalAmountDueProvider
                                Case "4"
                                    objCFIBalanceInfo.curTotalDueNonBasic = objCFIBalanceInfo.curTotalDueNonBasic + objCBSPCFA1_BalanceInfo.curTotalAmountDueProvider

                            End Select

                            'accumalate charges that's not due and deduct from TotalDue
                            'will be used for past due calculation
                            If dtBillDueDate > Today() Then ' means this charge is not due yet.

                                Select Case objCBSPCFA1_BalanceInfo.strBillingCategoryCode
                                    Case "B"
                                        curCurrentChargesNotDueBasic = curCurrentChargesNotDueBasic + objCBSPCFA1_BalanceInfo.curCurrentBillCharges
                                    Case "N", "4"
                                        curCurrentChargesNotDueNonBasic = curCurrentChargesNotDueNonBasic + objCBSPCFA1_BalanceInfo.curCurrentBillCharges
                                    Case "L", "T"
                                        'curCurrentChargesNotDueToll = curCurrentChargesNotDueBasic + objCBSPCFA1_BalanceInfo.curCurrentBillCharges
                                        curCurrentChargesNotDueToll = curCurrentChargesNotDueToll + objCBSPCFA1_BalanceInfo.curCurrentBillCharges
                                End Select

                            End If

                        End If

                        If strKeyDataRecordType.Trim = "TB" Then

                            objCBSPCFA1_BalanceInfo.strKeyDataRecordType = xmlEle.GetElementsByTagName("KeyDataRecordType").Item(0).InnerXml()
                            objCBSPCFA1_BalanceInfo.strKeyProductServiceProviderId = xmlEle.GetElementsByTagName("KeyProductServiceProviderId").Item(0).InnerXml()
                            objCBSPCFA1_BalanceInfo.strKeyBillingCategoryCode = xmlEle.GetElementsByTagName("KeyBillingCategoryCode").Item(0).InnerXml()

                            objCBSPCFA1_BalanceInfo.strDataRecordType = xmlEle.GetElementsByTagName("DataRecordType").Item(0).InnerXml()
                            objCBSPCFA1_BalanceInfo.strTreatmentLetterId = xmlEle.GetElementsByTagName("TreatmentLetterId").Item(0).InnerXml() 'diff for TB
                            objCBSPCFA1_BalanceInfo.strBalanceDate = xmlEle.GetElementsByTagName("BalanceDate").Item(0).InnerXml()
                            objCBSPCFA1_BalanceInfo.strProductServiceProviderId = xmlEle.GetElementsByTagName("ProductServiceProviderId").Item(0).InnerXml()
                            objCBSPCFA1_BalanceInfo.strBillingCategoryCode = xmlEle.GetElementsByTagName("BillingCategoryCode").Item(0).InnerXml()


                            objCBSPCFA1_BalanceInfo.curCurrentBillCharges = Convert.ToDouble(xmlEle.GetElementsByTagName("CurrentBillCharges").Item(0).InnerXml())
                            objCBSPCFA1_BalanceInfo.curCurrentDemandCharges = Convert.ToDouble(xmlEle.GetElementsByTagName("CurrentDemandCharges").Item(0).InnerXml())
                            objCBSPCFA1_BalanceInfo.curPreviousDemandCharges = Convert.ToDouble(xmlEle.GetElementsByTagName("PreviousDemandCharges").Item(0).InnerXml())
                            objCBSPCFA1_BalanceInfo.curPresentBillCharges = Convert.ToDouble(xmlEle.GetElementsByTagName("PresentBillCharges").Item(0).InnerXml())

                            objCBSPCFA1_BalanceInfo.curPreviousBalance15Day = Convert.ToDouble(xmlEle.GetElementsByTagName("PreviousBalance15Day").Item(0).InnerXml())
                            objCBSPCFA1_BalanceInfo.curPreviousBalance30Day = Convert.ToDouble(xmlEle.GetElementsByTagName("PreviousBalance30Day").Item(0).InnerXml())
                            objCBSPCFA1_BalanceInfo.curPreviousBalance45Day = Convert.ToDouble(xmlEle.GetElementsByTagName("PreviousBalance45Day").Item(0).InnerXml())
                            objCBSPCFA1_BalanceInfo.curPreviousBalance60Day = Convert.ToDouble(xmlEle.GetElementsByTagName("PreviousBalance60Day").Item(0).InnerXml())
                            objCBSPCFA1_BalanceInfo.curPreviousBalance75Day = Convert.ToDouble(xmlEle.GetElementsByTagName("PreviousBalance75Day").Item(0).InnerXml())
                            objCBSPCFA1_BalanceInfo.curPreviousBalance90Day = Convert.ToDouble(xmlEle.GetElementsByTagName("PreviousBalance90Day").Item(0).InnerXml())

                            objCBSPCFA1_BalanceInfo.curTotalTreatableAmount = Convert.ToDouble(xmlEle.GetElementsByTagName("TotalTreatableAmount").Item(0).InnerXml())
                            objCBSPCFA1_BalanceInfo.curUnbilledCharges = Convert.ToDouble(xmlEle.GetElementsByTagName("UnbilledCharges").Item(0).InnerXml())

                            objCFIBalanceInfo.arrLstBalanceDetails.Add(objCBSPCFA1_BalanceInfo)

                            'calculate TreatableDue for Basic, NB and Toll
                            Select Case objCBSPCFA1_BalanceInfo.strBillingCategoryCode
                                Case "B"
                                    objCFIBalanceInfo.curTreatableDueBasic = objCFIBalanceInfo.curTreatableDueBasic + objCBSPCFA1_BalanceInfo.curTotalTreatableAmount
                                Case "N", "4"
                                    objCFIBalanceInfo.curTreatableDueNonBasic = objCFIBalanceInfo.curTreatableDueNonBasic + objCBSPCFA1_BalanceInfo.curTotalTreatableAmount
                                Case "L", "T"
                                    objCFIBalanceInfo.curTreatableDueToll = objCFIBalanceInfo.curTreatableDueToll + objCBSPCFA1_BalanceInfo.curTotalTreatableAmount
                            End Select

                        End If


                    Next j
                Next i

                'PastDue = TotalDue - current changes that's not due
                objCFIBalanceInfo.curPastDueBasic = objCFIBalanceInfo.curTotalDueBasic - curCurrentChargesNotDueBasic
                objCFIBalanceInfo.curPastDueNonBasic = objCFIBalanceInfo.curTotalDueNonBasic - curCurrentChargesNotDueNonBasic
                objCFIBalanceInfo.curPastDueToll = objCFIBalanceInfo.curTotalDueToll - curCurrentChargesNotDueToll


            Catch ex As Exception

                LogErrorFile.WriteLog("RMICWWS-CBSPCFA1", "AcctNum: " & strAcctNum & " Erroring Out " & ex.ToString & " Org " & objCFIInp.strOrg & " Region " & objCFIInp.strRegioncd)
                objCFIBalanceInfo.RequestStatus.strMessageId = "RMIEXPTN"
                objCFIBalanceInfo.RequestStatus.strMessageDescription = ex.ToString

            End Try

            'Return objAcctBalanceInfo
            'strCFIxml = strCFIxml.Replace("cfa1:", "")
            'strCFIxml = "<CFA1>" + strCFIxml + "</CFA1>"
            'LogErrorFile.WriteLog(objCFIInp.strAcctNum, strCFIxml.Trim())
            Return objCFIBalanceInfo

        End Function

        'CBSPCFA3 Begin
        Public Function getCBSS_CBSPCFA3(ByVal strRegionId As String, ByVal strAcctnum As String, ByVal strXMLLog As String) As XmlDocument

            'Dim objAcctBalanceInfo As AcctBalanceInfo = New AcctBalanceInfo
            Dim objCFIBalanceInfo As CFIBalanceInfo = New CFIBalanceInfo
            Dim strUrl As String = ""
            Dim objCFIInp As CFIBalanceInput = New CFIBalanceInput
            Dim strCFIxml As String = ""
            Dim strXml As String = ""
            Dim xmlCFA3 As XmlDocument


            Try
                Dim reqObj As ERARequest = New ERARequest
                Dim resObj As ERAResponse
                Dim DB2DT As DataTable
                Dim DB2DR As DataRow
                Dim strInpValue As String

                Select Case True

                    Case strRegionId Is Nothing Or strRegionId.Trim = ""
                        objCFIBalanceInfo.RequestStatus.strMessageId = "INVRGNID"
                        objCFIBalanceInfo.RequestStatus.strMessageDescription = "Invalid Region Id passed."
                        Return xmlCFA3

                    Case strAcctnum Is Nothing Or strAcctnum.Trim = ""
                        objCFIBalanceInfo.RequestStatus.strMessageId = "INVACNBR"
                        objCFIBalanceInfo.RequestStatus.strMessageDescription = "Invalid Account Number passed as Input."
                        Return xmlCFA3

                End Select

                reqObj.strInpTyp = "1"
                reqObj.strInputValue = strAcctnum
                reqObj.strStartInstance = " "
                reqObj.intGetNum = 0
                reqObj.strRetNum = " "
                reqObj.strScope = " "
                reqObj.strTargetTN = " "
                reqObj.strReqType = "00"
                reqObj.strFmtType = "1"
                'reqObj.strExtInput = "            A" 'Space � Unbilled Events Only,'Y� � Billed Events Only,'A� � All Events,'V� � Viewed Unbilled Events
                reqObj.strExtInput = "A            " 'Space � Unbilled Events Only,'Y� � Billed Events Only,'A� � All Events,'V� � Viewed Unbilled Events
                reqObj.strERAName = "CBSPCFA3"
                reqObj.strRegionId = strRegionId
                reqObj.strAcctNum = strAcctnum


                Dim obj As BrokerDB2Data = New BrokerDB2Data(reqObj)
                resObj = obj.ERADB2Connect()


                'Select Case True

                '    Case Not resObj.intSQLRC = 0
                '        objCFIBalanceInfo.RequestStatus.strMessageId = resObj.intSQLRC.ToString
                '        objCFIBalanceInfo.RequestStatus.strMessageDescription = resObj.strMsgText
                '        Return objCFIBalanceInfo

                '    Case MyBase.WSDataAccessObj.IsEmptyRecordSet(resObj.DB2DS)
                '        objCFIBalanceInfo.RequestStatus.strMessageId = "100"
                '        objCFIBalanceInfo.RequestStatus.strMessageDescription = "No Matching Record Found in CBSS"
                '        Return objCFIBalanceInfo
                'End Select

                Dim arrLst As ArrayList = New ArrayList
                Dim xmlDoc As XmlDocument
                Dim xmlEle As XmlElement


                xmlCFA3 = New XmlDocument

                'For Each DB2DT In resObj.DB2DS.Tables
                For i As Integer = 0 To resObj.DB2DS.Tables.Count - 1
                    DB2DT = resObj.DB2DS.Tables(i)
                    'For Each DB2DR In DB2DT.Rows
                    For j As Integer = 0 To DB2DT.Rows.Count - 1
                        DB2DR = DB2DT.Rows(j)
                        strInpValue = DB2DR(2)
                        'xmlDoc = New XmlDocument
                        'xmlDoc.LoadXml(strInpValue)
                        strXml = strXml + strInpValue

                    Next j
                Next i

                If resObj.DB2DS.Tables.Count = 0 Then
                    strXml = "MsgCode " + resObj.strMsgCode.ToString() + "MsgText " + resObj.strMsgText.ToString()
                    strXml = System.Text.RegularExpressions.Regex.Replace(strXml, "[+~!@#$%^&*()_+{}|]", "")
                    strXml = System.Text.RegularExpressions.Regex.Replace(strXml, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline))
                    strXml = "<CFA3>" + strXml + "</CFA3>"
                    strXml = strXml.Replace("cbl:", "")
                    xmlCFA3.XmlResolver = Nothing
                    xmlCFA3.LoadXml(strXml)
                    xmlCFA3.LoadXml(System.Text.RegularExpressions.Regex.Replace(xmlCFA3.OuterXml, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline)))
                Else
                    strXml = strXml.Trim()
                    strXml = System.Text.RegularExpressions.Regex.Replace(strXml, "[+~!@#$%^&*()_+{}|]", "")
                    strXml = System.Text.RegularExpressions.Regex.Replace(strXml, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline))
                    strXml = strXml.Replace("CFA3:", "")
                    strXml = strXml.Replace("cbl:", "")
                    strXml = System.Text.RegularExpressions.Regex.Replace(strXml, "[^\x09\x0A\x0D\x20-\xD7FF\xE000-\xFFFD\x10000-x10FFFF]", "")
                    strXml = "<CFA3>" + strXml + "</CFA3>"
                    xmlCFA3.XmlResolver = Nothing
                    xmlCFA3.LoadXml(strXml)

                End If



                If Not xmlCFA3 Is Nothing Then 'Comment the Eventdecription
                    Try
                        Dim EventList As XmlNodeList = xmlCFA3.SelectNodes("//SegmentData")
                        Dim Event1 As XmlNode
                        'For Each Event1 In EventList
                        For i As Integer = 0 To EventList.Count - 1
                            Event1 = EventList(i)
                            Event1.SelectSingleNode("PPVEventDescription").InnerText = "******"
                        Next
                    Catch ex As Exception
                        LogErrorFile.WriteLog("getCBSS_CBSPCFA1_BalanceInfo West", "AcctNum: " & strAcctnum & " Erroring Out while getting PPX amount " & ex.ToString)
                    End Try
                End If


                If strXMLLog.ToUpper().Trim() = "Y" Then
                    Dim eraDS As DataSet
                    Try
                        strXml = strXml.Replace("CFA3:", "")
                        eraDS = MyBase.WSDataAccessObj.usp_InsertERAResponse(strAcctnum, strRegionId, "CFA3", strXml)
                    Catch exCFA3 As Exception
                        LogErrorFile.WriteLog("WSCFA3_Full", exCFA3.ToString())

                    End Try
                End If


            Catch ex As Exception

                LogErrorFile.WriteLog("RMICWWS-CBSPCFA3", "AcctNum: " & strAcctnum & " Erroring Out " & ex.ToString)
                strXml = ex.ToString
                strXml = System.Text.RegularExpressions.Regex.Replace(strXml, "[+~!@#$%^&*()_+{}|]", "")
                strXml = System.Text.RegularExpressions.Regex.Replace(strXml, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline))
                strXml = "<CFA3>" + ex.ToString + "</CFA3>"
                xmlCFA3.XmlResolver = Nothing
                xmlCFA3.LoadXml(strXml)
                xmlCFA3.LoadXml(System.Text.RegularExpressions.Regex.Replace(xmlCFA3.OuterXml, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline)))

            End Try

            Return xmlCFA3

        End Function

        'CBSPCFA3 End


        Public Function getCFIDataIn(ByVal objCFIInp As CFIBalanceInput) As String

            Dim strCFIInputParms As String = " "
            Dim strClaims As String
            Dim dblPPXAmt As Double = objCFIInp.curPPXAmt
            Dim dblAdjAmt As Double = objCFIInp.curAdjAmt
            Dim strPPXDate As String = "19000101"
            Dim spacerAdj As String = "000000000000000000"


            Dim spacer As String = "0000000000"  '12 0s for padding numeric values

            'Pending payments
            'Dim strPendingPayments = "00000"   ' 2 0s for payments & 3 0s for Adjustments
            Dim strPendingPayments = "00"   ' 2 0s for payments & 3 0s for Adjustments


            '(30 * 41) spaces for pending pyments


            Dim i As Int16

            'For i = 0 To 29
            'strPendingPayments = strPendingPayments + "                                         "
            'Next i

            'For i = 0 To 29
            'strPendingPayments = strPendingPayments + "19000101+000000000.00                    "
            'Next i

            'Pending Adjustments
            Dim strPendingAdjustments As String = "000"
            ' (100 * 60) spaces for pending adjustments

            'For i = 0 To 99
            'strPendingAdjustments = strPendingAdjustments + "                                                            "
            'strPendingAdjustments = strPendingAdjustments + "00000BACTYDP+000000000.00111111111111111               "
            '
            '           Next i

            'Claims values

            Dim strTotalPaymentClaim As String = "0.00"
            Dim strTotalBasicClaim As String = "0.00"
            Dim strTotalNonBasicClaim As String = "0.00"
            Dim strTotalTollClaim As String = "0.00"
            Dim strTotalCat4Claim As String = "0.00"
            Dim strTotalCat5Claim As String = "0.00"
            Dim strValue As String
            Dim strAdjAmount As String = "0.00"

            Dim strPPXAmount As String = "0.00"
            Dim dtmPPXDate As Date = Now.Date()




            ' strTotalPaymentClaim = objCFIInp.curPPXAmt.ToString("########0.00")
            'strTotalPaymentClaim = strTotalPaymentClaim.ToString("########0.00")
            strTotalBasicClaim = objCFIInp.curBasicClaimAmt.ToString("########0.00")
            strTotalNonBasicClaim = objCFIInp.curNonBasicClaimAmt.ToString("########0.00")
            strTotalTollClaim = objCFIInp.curTollClaimAmt.ToString("########0.00")
            strTotalCat4Claim = objCFIInp.curOCARClaimAmt.ToString("########0.00")
            strTotalCat5Claim = objCFIInp.curDACliamAmt.ToString("########0.00")

            'Add the PPX amt with the Claims Amt if there is any and send them both as the Total Payment Claim
            'strTotalPaymentClaim = (Convert.ToDouble(strTotalPaymentClaim) + dblPPXAmt).ToString("########0.00")

            'strTotalPaymentClaim = "+" + ((strTotalPaymentClaim.Length == 12) ? strTotalPaymentClaim : (spacer.Substring(0, (12-strTotalPaymentClaim.Length)) + strTotalPaymentClaim)) 

            If (strTotalPaymentClaim.Length = 12) Then
                strValue = strTotalPaymentClaim
            Else
                strValue = spacer.Substring(0, (12 - strTotalPaymentClaim.Length))
            End If

            strTotalPaymentClaim = "+" + strValue.Trim + strTotalPaymentClaim

            If (strTotalBasicClaim.Length = 12) Then
                strValue = strTotalBasicClaim
            Else
                strValue = spacer.Substring(0, (12 - strTotalBasicClaim.Length))
            End If

            strTotalBasicClaim = "+" + strValue.Trim + strTotalBasicClaim

            If (strTotalNonBasicClaim.Length = 12) Then
                strValue = strTotalNonBasicClaim
            Else
                strValue = spacer.Substring(0, (12 - strTotalNonBasicClaim.Length))
            End If

            strTotalNonBasicClaim = "+" + strValue.Trim + strTotalNonBasicClaim

            If (strTotalTollClaim.Length = 12) Then
                strValue = strTotalTollClaim
            Else
                strValue = spacer.Substring(0, (12 - strTotalTollClaim.Length))
            End If

            strTotalTollClaim = "+" + strValue.Trim + strTotalTollClaim

            If (strTotalCat4Claim.Length = 12) Then
                strValue = strTotalCat4Claim
            Else
                strValue = spacer.Substring(0, (12 - strTotalCat4Claim.Length))
            End If

            strTotalCat4Claim = "+" + strValue.Trim + strTotalCat4Claim

            If (strTotalCat5Claim.Length = 12) Then
                strValue = strTotalCat5Claim
            Else
                strValue = spacer.Substring(0, (12 - strTotalCat5Claim.Length))
            End If

            strTotalCat5Claim = "+" + strValue.Trim + strTotalCat5Claim


            'Concatenate all the Claims values
            strClaims = strTotalPaymentClaim.Trim + strTotalBasicClaim.Trim + strTotalNonBasicClaim.Trim + strTotalTollClaim.Trim + strTotalCat4Claim.Trim + strTotalCat5Claim.Trim



            'Concatenate all the Claims + Pending Payments + Pending Adjustments 
            'strCFIInputParms = strClaims.Trim + "                         " + strPendingPayments + strPendingAdjustments
            'strCFIInputParms = strClaims.Trim + "0000000000000" + strPendingPayments + strPendingAdjustments


            If ((objCFIInp.strGetPPX.Trim() = "Y") Or (objCFIInp.curPPXAmt > 0)) Then
                strPendingPayments = "01"
                strPPXAmount = objCFIInp.curPPXAmt.ToString("########0.00")

                If (strPPXAmount.Length = 12) Then
                    strValue = strPPXAmount
                Else
                    strValue = spacer.Substring(0, (12 - strPPXAmount.Length))
                End If

                strPPXAmount = "-" + strValue.Trim + strPPXAmount
                strPPXDate = dtmPPXDate.ToString("yyyyMMdd")
            End If

            If ((objCFIInp.strGetPPX.Trim() = "N") Or (objCFIInp.curPPXAmt = 0)) Then
                strPendingPayments = "00"
                strPPXAmount = objCFIInp.curPPXAmt.ToString("########0.00")

                If (strPPXAmount.Length = 12) Then
                    strValue = strPPXAmount
                Else
                    strValue = spacer.Substring(0, (12 - strPPXAmount.Length))
                End If

                strPPXAmount = "-" + strValue.Trim + strPPXAmount
                strPPXDate = dtmPPXDate.ToString("yyyyMMdd")
            End If


            If ((objCFIInp.strGetAdj.Trim() = "Y") Or (objCFIInp.curAdjAmt > 0)) Then
                strPendingAdjustments = "001"
                strAdjAmount = objCFIInp.curAdjAmt.ToString("########0.00")

                If (strAdjAmount.Length = 12) Then
                    strValue = strAdjAmount
                Else
                    strValue = spacerAdj.Substring(0, (12 - strAdjAmount.Length))
                End If
                strAdjAmount = "+" + strValue.Trim + strAdjAmount
            End If

            If (objCFIInp.strRegioncd = "WEST") Then
                strCFIInputParms = strClaims.Trim + "000000000000" + strPendingPayments + strPendingAdjustments + strPPXDate + strPPXAmount + "                    " + "0000000611" + "86  " + strAdjAmount + "999999999999999                  "
            Else
                strPendingPayments = "01"
                strCFIInputParms = strClaims.Trim + "000000000000" + strPendingPayments + strPendingAdjustments + strPPXDate + strPPXAmount + "                    " + "0000000611" + "    " + strAdjAmount + "123456789012345                  "

            End If

            
            'strCFIInputParms = strClaims.Trim + "000000000000" + strPendingPayments + strPendingAdjustments + strPPXDate + strPPXAmount  ' PROD

            Return strCFIInputParms

        End Function



        'East CFI CBSPCFA1 - Calculate Customer Balances
        Public Function getCBSS_CBSPCFA1_BalanceInfoEast(ByVal objCFIInp As CFIBalanceInput) As CFIBalanceInfoAccum

            'Dim objAcctBalanceInfo As AcctBalanceInfo = New AcctBalanceInfo
            Dim objCFIBalanceInfo As CFIBalanceInfoAccum = New CFIBalanceInfoAccum
            Dim strCFIxml As String = ""

            Dim strUrl As String
            Dim curPPXAmt As Double
            Dim curAdjAmt As Double = 0
            Dim xmlEle As XmlElement
            Dim arrLstPPXDetails As ArrayList

            Try
                Dim reqObj As ERARequest = New ERARequest
                Dim resObj As ERAResponse
                Dim DB2DT As DataTable
                Dim DB2DR As DataRow
                Dim strInpValue As String

                Select Case True

                    Case objCFIInp.strRegioncd Is Nothing Or objCFIInp.strRegioncd.Trim = ""

                        objCFIBalanceInfo.RequestStatus.strMessageId = "INVRGNID"
                        objCFIBalanceInfo.RequestStatus.strMessageDescription = "Invalid Region Id passed."
                        Return objCFIBalanceInfo


                    Case objCFIInp.strAcctNum Is Nothing Or objCFIInp.strAcctNum.Trim = ""

                        objCFIBalanceInfo.RequestStatus.strMessageId = "INVACNBR"
                        objCFIBalanceInfo.RequestStatus.strMessageDescription = "Invalid Account Number passed as Input."
                        Return objCFIBalanceInfo

                End Select

                reqObj.strRegionId = objCFIInp.strRegioncd
                reqObj.strAcctNum = objCFIInp.strAcctNum.Trim + "       " 'pass 20 characters
                reqObj.strERAName = "CBSPCFA1"
                'reqObj.strExtInput = "Y           Y" 'passing Y in the 13th position will give the Bill Due date back
                'reqObj.strExtInput = "  2011-04-19" 'If position 3 through 12 is a date field in the format CCYY-MM-DD, return the updated balances beginning with this billing cycle date and apply payments and adjustments since that billing cycle date.
                reqObj.strExtInput = " Y           " 'If position 2 = �Y�, Payment and/or Adjustment activity records will be returned in the result set.



                If (reqObj.strRegionId.Trim = "NY" Or reqObj.strRegionId.Trim = "NE" Or reqObj.strRegionId.Trim = "NPD") Then
                    reqObj.strInpTyp = "2"
                End If

                If (reqObj.strRegionId.Trim = "MDVW") Then
                    reqObj.strInpTyp = "3"
                End If

                reqObj.strReqType = "02"
                reqObj.strRegionId = objCFIInp.strRegioncd.Trim
                reqObj.strFmtType = "1"
                reqObj.strStartInstance = " "
                reqObj.intGetNum = 0
                'reqObj.strStartInstance = " "
                reqObj.strScope = " "



                Dim ClaimsDt As DataTable
                Dim ClaimsDr As DataRow
                Dim claimsDs As DataSet


                If ((MyBase.RegionId.Trim = "NY" Or MyBase.RegionId.Trim = "NE") And (objCFIInp.strGetClaim.Trim = "Y")) Then

                    Try
                        claimsDs = MyBase.WSDataAccessObj.usp_getClaims(MyBase.RegionId, objCFIInp.strAcctNum)
                        'For Each ClaimsDt In claimsDs.Tables
                        For i As Integer = 0 To claimsDs.Tables.Count - 1
                            ClaimsDt = claimsDs.Tables(i)
                            'For Each ClaimsDr In ClaimsDt.Rows
                            For j As Integer = 0 To ClaimsDt.Rows.Count - 1
                                ClaimsDr = ClaimsDt.Rows(j)
                                objCFIInp.curBasicClaimAmt = ClaimsDr("curBasicClaimAmt")
                                objCFIInp.curNonBasicClaimAmt = ClaimsDr("curNonBasicClaimAmt")
                                objCFIInp.curTollClaimAmt = ClaimsDr("curTollClaimAmt")
                                objCFIInp.curOCARClaimAmt = ClaimsDr("curOCARClaimAmt")
                            Next j
                        Next i
                    Catch ex As Exception
                        LogErrorFile.WriteLog("RMICWWS-CBSPCFA1-East", "AcctNum: " & objCFIInp.strAcctNum & " Erroring Out while retrieving the claims Info " & ex.ToString)
                    End Try
                End If

                'WR 68041 Pass PPX amount to CFI
                If (objCFIInp.strGetPPX.Trim = "Y") Then


                    Try

                        'Dim objWsMain As WSMain = New WSMain
                        'Dim xmlResultDoc As XmlDocument = New XmlDocument
                        'xmlResultDoc = objWsMain.getPPXinfo(objCFIInp.strRegioncd, objCFIInp.strAcctNum)

                        'If Not xmlResultDoc Is Nothing Then
                        '    Try
                        '        Dim AmountList As XmlNodeList = xmlResultDoc.SelectNodes("//NewDataSet/Table")
                        '        Dim Amount As XmlNode
                        '        For Each Amount In AmountList
                        '            If Not Amount.SelectSingleNode("curppxamount") Is Nothing Then
                        '                curPPXAmt += Amount.SelectSingleNode("curppxamount").InnerText.ToString()

                        '            End If
                        '        Next
                        '        objCFIInp.curPPXAmt = curPPXAmt
                        Dim objWsMain As WSMain = New WSMain
                        Dim xmlResultDoc As XmlDocument = New XmlDocument
                        xmlResultDoc = objWsMain.getPPXinfo(objCFIInp.strRegioncd, objCFIInp.strAcctNum)
                        If Not xmlResultDoc Is Nothing Then
                            Try
                                Dim AmountList As XmlNodeList = xmlResultDoc.SelectNodes("//NewDataSet/Table")
                                Dim ReturnCdNode As XmlNode
                                Dim strAmount As String = String.Empty
                                Dim strAmountAdj As String = String.Empty
                                Dim strReturnCd As String = ""
                                '    For Each ReturnCdNode In AmountList
                                Dim Amount As XmlNode
                                If Not AmountList Is Nothing Then
                                    'For Each Amount In AmountList
                                    For i As Integer = 0 To AmountList.Count - 1
                                        Amount = AmountList(i)
                                        strReturnCd = Amount.SelectSingleNode("strvenderid").InnerText.ToString()
                                        If strReturnCd = "R01" OrElse strReturnCd = "M06" Then

                                            If Not Amount.SelectSingleNode("curppxamount") Is Nothing Then
                                                curAdjAmt += Amount.SelectSingleNode("curppxamount").InnerText.ToString() * -1
                                            End If
                                        Else
                                            If Not Amount.SelectSingleNode("curppxamount") Is Nothing Then
                                                curPPXAmt += Amount.SelectSingleNode("curppxamount").InnerText.ToString()
                                            End If
                                        End If
                                    Next
                                End If
                            Catch ex As Exception
                                objCFIInp.curPPXAmt = 0.0
                                LogErrorFile.WriteLog("RMICWWS-CBSPCFA1-East", "AcctNum: " & objCFIInp.strAcctNum & " Erroring Out while getting PPX amount " & ex.ToString)
                            End Try
                        End If

                    Catch ex As Exception
                        LogErrorFile.WriteLog("RMICWWS-CBSPCFA1-East", "AcctNum: " & objCFIInp.strAcctNum & " Erroring Out while getting PPX Info " & ex.ToString)
                    End Try
                End If

                objCFIInp.strGetPPX = "N"
                objCFIInp.strGetAdj = "N"
                If curPPXAmt > 0 Then
                    objCFIInp.curPPXAmt = curPPXAmt
                    objCFIInp.strGetPPX = "Y"
                End If

                If curAdjAmt > 0 Then
                    objCFIInp.curAdjAmt = curAdjAmt
                    objCFIInp.strGetAdj = "Y"

                End If

                reqObj.strCFIInp = getCFIDataIn(objCFIInp)
                'cmd.Parameters["@EXTINPUT"].Value = "            Y" ; //passing Y in the 13th position will give the Bill Due date back

                Dim obj As BrokerDB2Data = New BrokerDB2Data(reqObj)

                resObj = obj.ERADB2Connect()


                Select Case True

                    Case Not resObj.intSQLRC = 0
                        objCFIBalanceInfo.RequestStatus.strMessageId = resObj.intSQLRC.ToString
                        objCFIBalanceInfo.RequestStatus.strMessageDescription = resObj.strMsgText
                        Return objCFIBalanceInfo

                    Case MyBase.WSDataAccessObj.IsEmptyRecordSet(resObj.DB2DS)
                        objCFIBalanceInfo.RequestStatus.strMessageId = "100"
                        objCFIBalanceInfo.RequestStatus.strMessageDescription = resObj.strMsgCode + "-" + resObj.strMsgText
                        Return objCFIBalanceInfo
                End Select

                'need BillDueDate to calculate Past Due
                'PastDue = TotalDue - current changes that's not due
                Dim dtBillDueDate As Date
                Dim dtmNPDBillDueDate As Date
                Dim strOrgCode As String = "000"
                Dim curCurrentChargesNotDueBasic As Double = 0
                Dim curCurrentChargesNotDueNonBasic As Double = 0
                Dim curCurrentChargesNotDueToll As Double = 0


                If (IsDate(resObj.strEXTOut)) Then
                    objCFIBalanceInfo.dtmBillDate = Convert.ToDateTime(resObj.strEXTOut)
                Else
                    objCFIBalanceInfo.dtmBillDate = Today()
                End If

                Dim blnPastBillDt As Boolean = False
                Dim intDayDiff As Integer = 0
                Dim ts As TimeSpan

                If reqObj.strRegionId.Trim = "NPD" Then
                    'ts = Today.Now.Subtract(objCFIBalanceInfo.dtmBillDate)
                    'intDayDiff = ts.Days
                    'If intDayDiff >= 26 Then
                    '    blnPastBillDt = True
                    'End If

                    'WR24338 NJ Buketing CA Look up and decide based on the PayByDate 
                    Dim objEnvDS As DataSet
                    objEnvDS = MyBase.WSDataAccessObj.usp_GetCustomerAddressInfo(objCFIInp.strRegioncd, objCFIInp.strAcctNum)
                    If Not (MyBase.WSDataAccessObj.IsEmptyRecordSet(objEnvDS)) Then
                        dtmNPDBillDueDate = objEnvDS.Tables(0).Rows(0)("dtmBillDueDate")
                        strOrgCode = objEnvDS.Tables(0).Rows(0)("strOrgCode")
                    End If
                    If (dtmNPDBillDueDate < Today.Date) Then
                        blnPastBillDt = True
                    End If

                    If strOrgCode.Trim() <> "" Then
                        objCFIInp.strOrg = strOrgCode
                    End If

                End If

                objCFIBalanceInfo.strAcctNum = objCFIInp.strAcctNum
                Dim arrLst As ArrayList = New ArrayList

                Dim xmlDoc As XmlDocument
                'Dim xmlEle As XmlElement


                Dim objCommon As CommonFunctions = New CommonFunctions
                'Dim objCBSPTRA9_CustomerBalance As CBSPTRA9_CustomerBalance
                Dim objCFIBasicBucket As CFIBalanceBucketLevel = New CFIBalanceBucketLevel
                objCFIBasicBucket.strCategoryCd = "B"
                Dim objCFINBBucket As CFIBalanceBucketLevel = New CFIBalanceBucketLevel
                objCFINBBucket.strCategoryCd = "N"
                Dim objCFITollBucket As CFIBalanceBucketLevel = New CFIBalanceBucketLevel
                objCFITollBucket.strCategoryCd = "T"
                Dim objCFIOCARBucket As CFIBalanceBucketLevel = New CFIBalanceBucketLevel
                objCFIOCARBucket.strCategoryCd = "O"
                Dim objCFICPEBucket As CFIBalanceBucketLevel = New CFIBalanceBucketLevel
                objCFICPEBucket.strCategoryCd = "CPE"

                Dim objCFIIPBucket As CFIBalanceBucketLevel = New CFIBalanceBucketLevel
                objCFIIPBucket.strCategoryCd = "IP"

                Dim objCFINETIPBucket As CFIBalanceBucketLevel = New CFIBalanceBucketLevel
                objCFINETIPBucket.strCategoryCd = "NETIP"


                'Dim objCFIIPREALBucket As CFIBalanceBucketLevel = New CFIBalanceBucketLevel
                'objCFIIPREALBucket.strCategoryCd = "IPREAL"



                Dim objCBSPCFA1_BalanceInfo As CBSPCFA1_BalanceInfo

                'varibles for TotalDue, TreatbaleDue and PastDue
                'Dim curTotalDueBasic As Double = 0
                'Dim curTotalDueNonBasic As Double = 0
                'Dim curTotalDueToll As Double = 0
                'Dim curTreatableDueBasic As Double
                'Dim curTreatableDueNonBasic As Double
                'Dim curTreatableDueToll As Double
                'Dim curPastDueBasic As Double
                'Dim curPastDueNonBasic As Double
                'Dim curPastDueToll As Double

                'For Each DB2DT In resObj.DB2DS.Tables
                For i As Integer = 0 To resObj.DB2DS.Tables.Count - 1
                    DB2DT = resObj.DB2DS.Tables(i)
                    'For Each DB2DR In DB2DT.Rows
                    For j As Integer = 0 To DB2DT.Rows.Count - 1
                        DB2DR = DB2DT.Rows(j)
                        strInpValue = DB2DR(2)

                        'objCBSPTRA9_CustomerBalance = New CBSPTRA9_CustomerBalance
                        objCBSPCFA1_BalanceInfo = New CBSPCFA1_BalanceInfo
                        'strInpValue = Regex.Replace(strInpValue, "[^\w$.* ]", "")
                        'objCommon.ParseFixedLayout(strInpValue, arrLst)
                        'objCommon.getTheFileFormat(arrLst, "CBSPTRA9_CustomerBalance", objCBSPTRA9_CustomerBalance)

                        xmlDoc = New XmlDocument
                        xmlDoc.XmlResolver = Nothing
                        xmlDoc.LoadXml(strInpValue)
                        xmlEle = xmlDoc.DocumentElement

                        strCFIxml = strCFIxml + strInpValue





                        Dim strKeyDataRecordType As String

                        strKeyDataRecordType = xmlEle.GetElementsByTagName("KeyDataRecordType").Item(0).InnerXml()

                        If Not xmlDoc.SelectSingleNode("//PaymentDueDt") Is Nothing Then
                            objCBSPCFA1_BalanceInfo.PaymentDueDt = xmlEle.GetElementsByTagName("PaymentDueDt").Item(0).InnerXml()
                        End If

                        If Not xmlDoc.SelectSingleNode("//PrevPaymentDueDt") Is Nothing Then
                            objCBSPCFA1_BalanceInfo.PrevPaymentDueDt = xmlEle.GetElementsByTagName("PrevPaymentDueDt").Item(0).InnerXml()
                        End If


                        If (strKeyDataRecordType.Trim = "EB" Or strKeyDataRecordType.Trim = "IP" Or strKeyDataRecordType.Trim = "ET") Then

                            objCBSPCFA1_BalanceInfo.strKeyDataRecordType = xmlEle.GetElementsByTagName("KeyDataRecordType").Item(0).InnerXml()
                            objCBSPCFA1_BalanceInfo.strKeyProductServiceProviderId = xmlEle.GetElementsByTagName("KeyProductServiceProviderId").Item(0).InnerXml()
                            objCBSPCFA1_BalanceInfo.strKeyBillingCategoryCode = xmlEle.GetElementsByTagName("KeyBillingCategoryCode").Item(0).InnerXml()

                            Select Case reqObj.strRegionId.Trim()
                                Case "NE", "NPD"
                                    If objCBSPCFA1_BalanceInfo.strKeyBillingCategoryCode = "4" Then
                                        objCBSPCFA1_BalanceInfo.strKeyBillingCategoryCode = "N"
                                    End If

                            End Select


                            objCBSPCFA1_BalanceInfo.strDataRecordType = xmlEle.GetElementsByTagName("DataRecordType").Item(0).InnerXml()
                            objCBSPCFA1_BalanceInfo.strBalanceDate = xmlEle.GetElementsByTagName("BalanceDate").Item(0).InnerXml()
                            objCBSPCFA1_BalanceInfo.strProductServiceProviderId = xmlEle.GetElementsByTagName("ProductServiceProviderId").Item(0).InnerXml()
                            objCBSPCFA1_BalanceInfo.strBillingCategoryCode = xmlEle.GetElementsByTagName("BillingCategoryCode").Item(0).InnerXml()


                            objCBSPCFA1_BalanceInfo.curCurrentBillCharges = Convert.ToDouble(xmlEle.GetElementsByTagName("CurrentBillCharges").Item(0).InnerXml())

                            If (strKeyDataRecordType.Trim = "EB" Or strKeyDataRecordType.Trim = "IP") Then
                                objCBSPCFA1_BalanceInfo.curDeferredBillingAmount = Convert.ToDouble(xmlEle.GetElementsByTagName("DeferredBillingAmount").Item(0).InnerXml())
                                objCBSPCFA1_BalanceInfo.curHistoryDeferredAmount = Convert.ToDouble(xmlEle.GetElementsByTagName("HistoryDeferredAmount").Item(0).InnerXml())
                                objCBSPCFA1_BalanceInfo.strLatePaymentIndicator = xmlEle.GetElementsByTagName("LatePaymentIndicator").Item(0).InnerXml()

                                objCBSPCFA1_BalanceInfo.strProviderBillIndicator = xmlEle.GetElementsByTagName("ProviderBillIndicator").Item(0).InnerXml()
                                objCBSPCFA1_BalanceInfo.strProviderStatus = xmlEle.GetElementsByTagName("ProviderStatus").Item(0).InnerXml()
                                objCBSPCFA1_BalanceInfo.curTotalAmountDueProvider = Convert.ToDouble(xmlEle.GetElementsByTagName("TotalAmountDueProvider").Item(0).InnerXml())
                                objCBSPCFA1_BalanceInfo.curTotalWriteoffAmount = Convert.ToDouble(xmlEle.GetElementsByTagName("TotalWriteoffAmount").Item(0).InnerXml())

                                If objCBSPCFA1_BalanceInfo.strProviderStatus.Trim().ToUpper = "R" Then
                                    objCBSPCFA1_BalanceInfo.curTotalRefferedAmount = Convert.ToDouble(xmlEle.GetElementsByTagName("TotalAmountDueProvider").Item(0).InnerXml())
                                    objCBSPCFA1_BalanceInfo.curCurrentBillCharges = 0
                                ElseIf objCBSPCFA1_BalanceInfo.strProviderStatus.Trim().ToUpper = "W" Then
                                    objCBSPCFA1_BalanceInfo.curTotalWriteoffAmount = Convert.ToDouble(xmlEle.GetElementsByTagName("TotalAmountDueProvider").Item(0).InnerXml())
                                    objCBSPCFA1_BalanceInfo.curCurrentBillCharges = 0
                                End If


                                objCBSPCFA1_BalanceInfo.curTotalBillableAmount = Convert.ToDouble(xmlEle.GetElementsByTagName("TotalBillableAmount").Item(0).InnerXml())


                                objCBSPCFA1_BalanceInfo.strLastLpcAppliedDate = xmlEle.GetElementsByTagName("LastLpcAppliedDate").Item(0).InnerXml()
                                objCBSPCFA1_BalanceInfo.strLpcAppliedDate = xmlEle.GetElementsByTagName("LpcAppliedDate").Item(0).InnerXml()
                                objCBSPCFA1_BalanceInfo.curYtdLateCharges = Convert.ToDouble(xmlEle.GetElementsByTagName("YtdLateCharges").Item(0).InnerXml())



                            End If


                            objCBSPCFA1_BalanceInfo.curPreviousBalance15Day = Convert.ToDouble(xmlEle.GetElementsByTagName("PreviousBalance15Day").Item(0).InnerXml())
                            objCBSPCFA1_BalanceInfo.curPreviousBalance30Day = Convert.ToDouble(xmlEle.GetElementsByTagName("PreviousBalance30Day").Item(0).InnerXml())
                            objCBSPCFA1_BalanceInfo.curPreviousBalance45Day = Convert.ToDouble(xmlEle.GetElementsByTagName("PreviousBalance45Day").Item(0).InnerXml())
                            objCBSPCFA1_BalanceInfo.curPreviousBalance60Day = Convert.ToDouble(xmlEle.GetElementsByTagName("PreviousBalance60Day").Item(0).InnerXml())
                            objCBSPCFA1_BalanceInfo.curPreviousBalance75Day = Convert.ToDouble(xmlEle.GetElementsByTagName("PreviousBalance75Day").Item(0).InnerXml())
                            objCBSPCFA1_BalanceInfo.curPreviousBalance90Day = Convert.ToDouble(xmlEle.GetElementsByTagName("PreviousBalance90Day").Item(0).InnerXml())
                            objCBSPCFA1_BalanceInfo.curPreviousBalance120Day = Convert.ToDouble(xmlEle.GetElementsByTagName("PreviousBalance120Day").Item(0).InnerXml())

                            objCBSPCFA1_BalanceInfo.curCurrentDemandCharges = Convert.ToDouble(xmlEle.GetElementsByTagName("CurrentDemandCharges").Item(0).InnerXml())
                            objCBSPCFA1_BalanceInfo.curPreviousDemandCharges = Convert.ToDouble(xmlEle.GetElementsByTagName("PreviousDemandCharges").Item(0).InnerXml())
                            objCBSPCFA1_BalanceInfo.curPresentBillCharges = Convert.ToDouble(xmlEle.GetElementsByTagName("PresentBillCharges").Item(0).InnerXml())

                            objCBSPCFA1_BalanceInfo.curUnbilledCharges = Convert.ToDouble(xmlEle.GetElementsByTagName("UnbilledCharges").Item(0).InnerXml())


                            If (strKeyDataRecordType.Trim = "ET") Then
                                objCBSPCFA1_BalanceInfo.curTotalTreatableAmount = Convert.ToDouble(xmlEle.GetElementsByTagName("TotalTreatableAmount").Item(0).InnerXml())
                            End If




                            objCFIBalanceInfo.arrLstBalanceDetails.Add(objCBSPCFA1_BalanceInfo)




                            'calculate TotalDue for Basic, NB and Toll

                            If objCBSPCFA1_BalanceInfo.strKeyBillingCategoryCode.Trim = "" Then
                                objCBSPCFA1_BalanceInfo.strKeyBillingCategoryCode = "B"
                            End If

                            If objCBSPCFA1_BalanceInfo.strBillingCategoryCode.Trim = "" Then
                                objCBSPCFA1_BalanceInfo.strBillingCategoryCode = "B"
                            End If




                            Select Case reqObj.strRegionId.Trim()
                                Case "NE", "NPD"
                                    If objCBSPCFA1_BalanceInfo.strBillingCategoryCode = "4" Then
                                        objCBSPCFA1_BalanceInfo.strBillingCategoryCode = "N"
                                    End If
                                Case "NY"  'Fix for CFI is returning Cat 4  as N  that�s causing us to include the 4 charges under N.



                                    Select Case objCBSPCFA1_BalanceInfo.strProductServiceProviderId.Trim()
                                        Case "09300", "09302", "09301", "09304", "09305"
                                            If objCBSPCFA1_BalanceInfo.strBillingCategoryCode = "N" Then
                                                objCBSPCFA1_BalanceInfo.strKeyBillingCategoryCode = "4"
                                            End If
                                    End Select


                                    If objCBSPCFA1_BalanceInfo.strKeyBillingCategoryCode = "4" Then 'WR68132
                                        objCBSPCFA1_BalanceInfo.strBillingCategoryCode = "T"
                                    End If
                                    If objCBSPCFA1_BalanceInfo.strKeyBillingCategoryCode = "T" Then 'WR68132
                                        objCBSPCFA1_BalanceInfo.strBillingCategoryCode = "O"
                                    End If

                            End Select



                            Select Case reqObj.strRegionId.Trim()
                                Case "NY", "NPD", "MDVW"

                                    If (strKeyDataRecordType.Trim = "EB" Or strKeyDataRecordType.Trim = "ET") Then



                                        Select Case objCBSPCFA1_BalanceInfo.strBillingCategoryCode
                                            Case "B"
                                                If strKeyDataRecordType.Trim = "ET" Then
                                                    objCFIBasicBucket.curTotalTreatableAmount = objCFIBasicBucket.curTotalTreatableAmount + objCBSPCFA1_BalanceInfo.curTotalTreatableAmount
                                                Else
                                                    objCFIBasicBucket.curWriteOffAmt = objCFIBasicBucket.curWriteOffAmt + objCBSPCFA1_BalanceInfo.curTotalWriteoffAmount
                                                    objCFIBasicBucket.curReferredAmt = objCFIBasicBucket.curReferredAmt + objCBSPCFA1_BalanceInfo.curTotalRefferedAmount



                                                    objCFIBasicBucket.curCurrentCharges = objCFIBasicBucket.curCurrentCharges + objCBSPCFA1_BalanceInfo.curCurrentBillCharges
                                                    objCFIBasicBucket.cur30DaysCharges = objCFIBasicBucket.cur30DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance30Day

                                                    objCFIBasicBucket.cur60DaysCharges = objCFIBasicBucket.cur60DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance60Day
                                                    objCFIBasicBucket.cur90DaysCharges = objCFIBasicBucket.cur90DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance90Day
                                                    objCFIBasicBucket.cur120DaysCharges = objCFIBasicBucket.cur120DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance120Day


                                                End If


                                            Case "N"
                                                If strKeyDataRecordType.Trim = "ET" Then
                                                    objCFINBBucket.curTotalTreatableAmount = objCFINBBucket.curTotalTreatableAmount + objCBSPCFA1_BalanceInfo.curTotalTreatableAmount
                                                Else
                                                    objCFINBBucket.curWriteOffAmt = objCFINBBucket.curWriteOffAmt + objCBSPCFA1_BalanceInfo.curTotalWriteoffAmount
                                                    objCFINBBucket.curReferredAmt = objCFINBBucket.curReferredAmt + objCBSPCFA1_BalanceInfo.curTotalRefferedAmount
                                                    objCFINBBucket.curCurrentCharges = objCFINBBucket.curCurrentCharges + objCBSPCFA1_BalanceInfo.curCurrentBillCharges
                                                    objCFINBBucket.cur30DaysCharges = objCFINBBucket.cur30DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance30Day

                                                    objCFINBBucket.cur60DaysCharges = objCFINBBucket.cur60DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance60Day
                                                    objCFINBBucket.cur90DaysCharges = objCFINBBucket.cur90DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance90Day
                                                    objCFINBBucket.cur120DaysCharges = objCFINBBucket.cur120DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance120Day


                                                End If


                                            Case "L", "T"

                                                If strKeyDataRecordType.Trim = "ET" Then
                                                    objCFITollBucket.curTotalTreatableAmount = objCFITollBucket.curTotalTreatableAmount + objCBSPCFA1_BalanceInfo.curTotalTreatableAmount
                                                    If (objCFIInp.strOrg.ToUpper.StartsWith("PA")) Or (objCFIInp.strOrg.ToUpper.StartsWith("NJ")) Then
                                                        objCFINBBucket.curTotalTreatableAmount = objCFINBBucket.curTotalTreatableAmount + objCFITollBucket.curTotalTreatableAmount
                                                        objCFITollBucket.curTotalTreatableAmount = 0
                                                    End If



                                                Else
                                                    If (objCFIInp.strOrg.ToUpper.StartsWith("PA")) Or (objCFIInp.strOrg.ToUpper.StartsWith("NJ")) Then
                                                        objCFINBBucket.curWriteOffAmt = objCFINBBucket.curWriteOffAmt + objCFITollBucket.curWriteOffAmt + objCBSPCFA1_BalanceInfo.curTotalWriteoffAmount
                                                        objCFINBBucket.curCurrentCharges = objCFINBBucket.curCurrentCharges + objCFITollBucket.curCurrentCharges + objCBSPCFA1_BalanceInfo.curCurrentBillCharges
                                                        objCFINBBucket.cur30DaysCharges = objCFINBBucket.cur30DaysCharges + objCFITollBucket.cur30DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance30Day

                                                        objCFINBBucket.cur60DaysCharges = objCFINBBucket.cur60DaysCharges + objCFITollBucket.cur60DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance60Day
                                                        objCFINBBucket.cur90DaysCharges = objCFINBBucket.cur90DaysCharges + objCFITollBucket.cur90DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance90Day
                                                        objCFINBBucket.cur120DaysCharges = objCFINBBucket.cur120DaysCharges + objCFITollBucket.cur120DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance120Day
                                                    Else
                                                        objCFITollBucket.curWriteOffAmt = objCFITollBucket.curWriteOffAmt + objCBSPCFA1_BalanceInfo.curTotalWriteoffAmount
                                                        objCFITollBucket.curReferredAmt = objCFITollBucket.curReferredAmt + objCBSPCFA1_BalanceInfo.curTotalRefferedAmount

                                                        objCFITollBucket.curCurrentCharges = objCFITollBucket.curCurrentCharges + objCBSPCFA1_BalanceInfo.curCurrentBillCharges
                                                        objCFITollBucket.cur30DaysCharges = objCFITollBucket.cur30DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance30Day

                                                        objCFITollBucket.cur60DaysCharges = objCFITollBucket.cur60DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance60Day
                                                        objCFITollBucket.cur90DaysCharges = objCFITollBucket.cur90DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance90Day
                                                        objCFITollBucket.cur120DaysCharges = objCFITollBucket.cur120DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance120Day

                                                    End If


                                                End If


                                            Case "4"

                                                If ((objCBSPCFA1_BalanceInfo.strProductServiceProviderId = "00625") Or _
                                                   (objCBSPCFA1_BalanceInfo.strProductServiceProviderId = "00222")) Then


                                                    objCFIIPBucket.curWriteOffAmt = objCFIIPBucket.curWriteOffAmt + objCBSPCFA1_BalanceInfo.curTotalWriteoffAmount
                                                    objCFIIPBucket.curReferredAmt = objCFIIPBucket.curReferredAmt + objCBSPCFA1_BalanceInfo.curTotalRefferedAmount

                                                    objCFIIPBucket.curCurrentCharges = objCFIIPBucket.curCurrentCharges + objCBSPCFA1_BalanceInfo.curCurrentBillCharges
                                                    objCFIIPBucket.cur30DaysCharges = objCFIIPBucket.cur30DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance30Day
                                                    objCFIIPBucket.cur60DaysCharges = objCFIIPBucket.cur60DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance60Day
                                                    objCFIIPBucket.cur90DaysCharges = objCFIIPBucket.cur90DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance90Day
                                                    objCFIIPBucket.cur120DaysCharges = objCFIIPBucket.cur120DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance120Day
                                                Else

                                                    objCFIOCARBucket.curWriteOffAmt = objCFIOCARBucket.curWriteOffAmt + objCBSPCFA1_BalanceInfo.curTotalWriteoffAmount
                                                    objCFIOCARBucket.curReferredAmt = objCFIOCARBucket.curReferredAmt + objCBSPCFA1_BalanceInfo.curTotalRefferedAmount

                                                    objCFIOCARBucket.curCurrentCharges = objCFIOCARBucket.curCurrentCharges + objCBSPCFA1_BalanceInfo.curCurrentBillCharges
                                                    objCFIOCARBucket.cur30DaysCharges = objCFIOCARBucket.cur30DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance30Day
                                                    objCFIOCARBucket.cur60DaysCharges = objCFIOCARBucket.cur60DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance60Day
                                                    objCFIOCARBucket.cur90DaysCharges = objCFIOCARBucket.cur90DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance90Day
                                                    objCFIOCARBucket.cur120DaysCharges = objCFIOCARBucket.cur120DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance120Day

                                                End If

                                            Case "5"
                                                objCFICPEBucket.curWriteOffAmt = objCFICPEBucket.curWriteOffAmt + objCBSPCFA1_BalanceInfo.curTotalWriteoffAmount
                                                objCFICPEBucket.curReferredAmt = objCFICPEBucket.curReferredAmt + objCBSPCFA1_BalanceInfo.curTotalRefferedAmount

                                                objCFICPEBucket.curCurrentCharges = objCFICPEBucket.curCurrentCharges + objCBSPCFA1_BalanceInfo.curCurrentBillCharges
                                                objCFICPEBucket.cur30DaysCharges = objCFICPEBucket.cur30DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance30Day
                                                objCFICPEBucket.cur60DaysCharges = objCFICPEBucket.cur60DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance60Day
                                                objCFICPEBucket.cur90DaysCharges = objCFICPEBucket.cur90DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance90Day
                                                objCFICPEBucket.cur120DaysCharges = objCFICPEBucket.cur120DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance120Day


                                            Case "O" 'WR68132

                                                If reqObj.strRegionId.Trim() = "NY" Then

                                                    If strKeyDataRecordType.Trim = "ET" Then
                                                        objCFIOCARBucket.curTotalTreatableAmount = objCFIOCARBucket.curTotalTreatableAmount + objCBSPCFA1_BalanceInfo.curTotalTreatableAmount
                                                    Else
                                                        objCFIOCARBucket.curWriteOffAmt = objCFIOCARBucket.curWriteOffAmt + objCBSPCFA1_BalanceInfo.curTotalWriteoffAmount
                                                        objCFIOCARBucket.curReferredAmt = objCFIOCARBucket.curReferredAmt + objCBSPCFA1_BalanceInfo.curTotalRefferedAmount

                                                        objCFIOCARBucket.curCurrentCharges = objCFIOCARBucket.curCurrentCharges + objCBSPCFA1_BalanceInfo.curCurrentBillCharges
                                                        objCFIOCARBucket.cur30DaysCharges = objCFIOCARBucket.cur30DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance30Day
                                                        objCFIOCARBucket.cur60DaysCharges = objCFIOCARBucket.cur60DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance60Day
                                                        objCFIOCARBucket.cur90DaysCharges = objCFIOCARBucket.cur90DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance90Day
                                                        objCFIOCARBucket.cur120DaysCharges = objCFIOCARBucket.cur120DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance120Day

                                                    End If
                                                End If



                                        End Select
                                    End If

                                    If reqObj.strRegionId.Trim() = "NPD" Then
                                        If (strKeyDataRecordType.Trim = "IP") Then
                                            objCFIIPBucket.curWriteOffAmt = objCFIIPBucket.curWriteOffAmt + objCBSPCFA1_BalanceInfo.curTotalWriteoffAmount
                                            objCFIIPBucket.curCurrentCharges = objCFIIPBucket.curCurrentCharges + objCBSPCFA1_BalanceInfo.curCurrentBillCharges
                                            objCFIIPBucket.cur30DaysCharges = objCFIIPBucket.cur30DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance30Day

                                            objCFIIPBucket.cur60DaysCharges = objCFIIPBucket.cur60DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance60Day
                                            objCFIIPBucket.cur90DaysCharges = objCFIIPBucket.cur90DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance90Day
                                            objCFIIPBucket.cur120DaysCharges = objCFIIPBucket.cur120DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance120Day


                                        End If
                                    End If

                                Case "NE"

                                    If strKeyDataRecordType.Trim = "EB" Then

                                        Select Case objCBSPCFA1_BalanceInfo.strBillingCategoryCode
                                            Case "B"

                                                'If (objCFIInp.strOrg = "351" Or objCFIInp.strOrg = "451") Then

                                                'If (objCBSPCFA1_BalanceInfo.strKeyProductServiceProviderId.Trim = "00000") Then
                                                '    objCFIBasicBucket.curWriteOffAmt = objCFIBasicBucket.curWriteOffAmt + objCBSPCFA1_BalanceInfo.curTotalWriteoffAmount
                                                '    objCFIBasicBucket.curCurrentCharges = objCFIBasicBucket.curCurrentCharges + objCBSPCFA1_BalanceInfo.curCurrentBillCharges
                                                '    objCFIBasicBucket.cur30DaysCharges = objCFIBasicBucket.cur30DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance30Day
                                                '    objCFIBasicBucket.cur60DaysCharges = objCFIBasicBucket.cur60DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance60Day
                                                '    objCFIBasicBucket.cur90DaysCharges = objCFIBasicBucket.cur90DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance90Day
                                                '    objCFIBasicBucket.cur120DaysCharges = objCFIBasicBucket.cur120DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance120Day
                                                'Else
                                                '    objCFITollBucket.curWriteOffAmt = objCFITollBucket.curWriteOffAmt + objCBSPCFA1_BalanceInfo.curTotalWriteoffAmount
                                                '    objCFITollBucket.curCurrentCharges = objCFITollBucket.curCurrentCharges + objCBSPCFA1_BalanceInfo.curCurrentBillCharges
                                                '    objCFITollBucket.cur30DaysCharges = objCFITollBucket.cur30DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance30Day
                                                '    objCFITollBucket.cur60DaysCharges = objCFITollBucket.cur60DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance60Day
                                                '    objCFITollBucket.cur90DaysCharges = objCFITollBucket.cur90DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance90Day
                                                '    objCFITollBucket.cur120DaysCharges = objCFITollBucket.cur120DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance120Day
                                                'End If

                                                'Else

                                                objCFIBasicBucket.curWriteOffAmt = objCFIBasicBucket.curWriteOffAmt + objCBSPCFA1_BalanceInfo.curTotalWriteoffAmount
                                                objCFIBasicBucket.curCurrentCharges = objCFIBasicBucket.curCurrentCharges + objCBSPCFA1_BalanceInfo.curCurrentBillCharges
                                                objCFIBasicBucket.cur30DaysCharges = objCFIBasicBucket.cur30DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance30Day
                                                objCFIBasicBucket.cur60DaysCharges = objCFIBasicBucket.cur60DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance60Day
                                                objCFIBasicBucket.cur90DaysCharges = objCFIBasicBucket.cur90DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance90Day
                                                objCFIBasicBucket.cur120DaysCharges = objCFIBasicBucket.cur120DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance120Day
                                                'End If

                                            Case "N"
                                                objCFINBBucket.curWriteOffAmt = objCFINBBucket.curWriteOffAmt + objCBSPCFA1_BalanceInfo.curTotalWriteoffAmount
                                                objCFINBBucket.curCurrentCharges = objCFINBBucket.curCurrentCharges + objCBSPCFA1_BalanceInfo.curCurrentBillCharges
                                                objCFINBBucket.cur30DaysCharges = objCFINBBucket.cur30DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance30Day
                                                objCFINBBucket.cur60DaysCharges = objCFINBBucket.cur60DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance60Day
                                                objCFINBBucket.cur90DaysCharges = objCFINBBucket.cur90DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance90Day
                                                objCFINBBucket.cur120DaysCharges = objCFINBBucket.cur120DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance120Day
                                            Case "L", "T", "5" 'WR68041
                                                objCFITollBucket.curWriteOffAmt = objCFITollBucket.curWriteOffAmt + objCBSPCFA1_BalanceInfo.curTotalWriteoffAmount
                                                objCFITollBucket.curCurrentCharges = objCFITollBucket.curCurrentCharges + objCBSPCFA1_BalanceInfo.curCurrentBillCharges
                                                objCFITollBucket.cur30DaysCharges = objCFITollBucket.cur30DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance30Day
                                                objCFITollBucket.cur60DaysCharges = objCFITollBucket.cur60DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance60Day
                                                objCFITollBucket.cur90DaysCharges = objCFITollBucket.cur90DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance90Day
                                                objCFITollBucket.cur120DaysCharges = objCFITollBucket.cur120DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance120Day
                                                'Case "4"

                                                '    If ((objCBSPCFA1_BalanceInfo.strProductServiceProviderId = "00625") Or _
                                                '       (objCBSPCFA1_BalanceInfo.strProductServiceProviderId = "00222")) Then


                                                '        objCFIIPBucket.curWriteOffAmt = objCFIIPBucket.curWriteOffAmt + objCBSPCFA1_BalanceInfo.curTotalWriteoffAmount
                                                '        objCFIIPBucket.curCurrentCharges = objCFIIPBucket.curCurrentCharges + objCBSPCFA1_BalanceInfo.curCurrentBillCharges
                                                '        objCFIIPBucket.cur30DaysCharges = objCFIIPBucket.cur30DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance30Day
                                                '        objCFIIPBucket.cur60DaysCharges = objCFIIPBucket.cur60DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance60Day
                                                '        objCFIIPBucket.cur90DaysCharges = objCFIIPBucket.cur90DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance90Day
                                                '        objCFIIPBucket.cur120DaysCharges = objCFIIPBucket.cur120DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance120Day
                                                '    Else

                                                '        objCFIOCARBucket.curWriteOffAmt = objCFIOCARBucket.curWriteOffAmt + objCBSPCFA1_BalanceInfo.curTotalWriteoffAmount
                                                '        objCFIOCARBucket.curCurrentCharges = objCFIOCARBucket.curCurrentCharges + objCBSPCFA1_BalanceInfo.curCurrentBillCharges
                                                '        objCFIOCARBucket.cur30DaysCharges = objCFIOCARBucket.cur30DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance30Day
                                                '        objCFIOCARBucket.cur60DaysCharges = objCFIOCARBucket.cur60DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance60Day
                                                '        objCFIOCARBucket.cur90DaysCharges = objCFIOCARBucket.cur90DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance90Day
                                                '        objCFIOCARBucket.cur120DaysCharges = objCFIOCARBucket.cur120DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance120Day

                                                '    End If

                                            Case "5"

                                                objCFIIPBucket.curWriteOffAmt = objCFIIPBucket.curWriteOffAmt + objCBSPCFA1_BalanceInfo.curTotalWriteoffAmount
                                                objCFIIPBucket.curCurrentCharges = objCFIIPBucket.curCurrentCharges + objCBSPCFA1_BalanceInfo.curCurrentBillCharges
                                                objCFIIPBucket.cur30DaysCharges = objCFIIPBucket.cur30DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance30Day
                                                objCFIIPBucket.cur60DaysCharges = objCFIIPBucket.cur60DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance60Day
                                                objCFIIPBucket.cur90DaysCharges = objCFIIPBucket.cur90DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance90Day
                                                objCFIIPBucket.cur120DaysCharges = objCFIIPBucket.cur120DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance120Day

                                        End Select
                                    End If

                                    'WR68041 commented
                                    'If strKeyDataRecordType.Trim = "IP" Then
                                    '    If (objCFIInp.strOrg = "351" Or objCFIInp.strOrg = "451") Then

                                    '        If (objCBSPCFA1_BalanceInfo.strProductServiceProviderId = "00000") Then
                                    '            objCFINETIPBucket.curWriteOffAmt = objCFINETIPBucket.curWriteOffAmt + objCBSPCFA1_BalanceInfo.curTotalWriteoffAmount
                                    '            objCFINETIPBucket.curCurrentCharges = objCFINETIPBucket.curCurrentCharges + objCBSPCFA1_BalanceInfo.curCurrentBillCharges
                                    '            objCFINETIPBucket.cur30DaysCharges = objCFINETIPBucket.cur30DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance30Day
                                    '            objCFINETIPBucket.cur60DaysCharges = objCFINETIPBucket.cur60DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance60Day
                                    '            objCFINETIPBucket.cur90DaysCharges = objCFINETIPBucket.cur90DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance90Day
                                    '            objCFINETIPBucket.cur120DaysCharges = objCFINETIPBucket.cur120DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance120Day
                                    '        Else
                                    '            objCFIIPBucket.curWriteOffAmt = objCFIIPBucket.curWriteOffAmt + objCBSPCFA1_BalanceInfo.curTotalWriteoffAmount
                                    '            objCFIIPBucket.curCurrentCharges = objCFIIPBucket.curCurrentCharges + objCBSPCFA1_BalanceInfo.curCurrentBillCharges
                                    '            objCFIIPBucket.cur30DaysCharges = objCFIIPBucket.cur30DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance30Day
                                    '            objCFIIPBucket.cur60DaysCharges = objCFIIPBucket.cur60DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance60Day
                                    '            objCFIIPBucket.cur90DaysCharges = objCFIIPBucket.cur90DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance90Day
                                    '            objCFIIPBucket.cur120DaysCharges = objCFIIPBucket.cur120DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance120Day

                                    '        End If

                                    '    End If

                                    'End If


                            End Select

                            'accumalate charges that's not due and deduct from TotalDue
                            'will be used for past due calculation
                            'If dtBillDueDate > Today() Then ' means this charge is not due yet.

                            '    Select Case objCBSPCFA1_BalanceInfo.strBillingCategoryCode
                            '        Case "B"
                            '            curCurrentChargesNotDueBasic = curCurrentChargesNotDueBasic + objCBSPCFA1_BalanceInfo.curCurrentBillCharges
                            '        Case "N"
                            '            curCurrentChargesNotDueNonBasic = curCurrentChargesNotDueNonBasic + objCBSPCFA1_BalanceInfo.curCurrentBillCharges
                            '        Case "L", "T"
                            '            'curCurrentChargesNotDueToll = curCurrentChargesNotDueBasic + objCBSPCFA1_BalanceInfo.curCurrentBillCharges
                            '            curCurrentChargesNotDueToll = curCurrentChargesNotDueToll + objCBSPCFA1_BalanceInfo.curCurrentBillCharges
                            '    End Select

                            'End If

                        End If

                    Next j
                Next i

                'WR68041 - commented 
                'If (reqObj.strRegionId.Trim() = "NE") Then

                '    If (objCFIInp.strOrg = "351" Or objCFIInp.strOrg = "451") Then

                '        objCFINETIPBucket.curCurrentCharges = CheckIPBalancesInNE(objCFINETIPBucket.curCurrentCharges, objCFIBasicBucket.curCurrentCharges)
                '        objCFINETIPBucket.cur30DaysCharges = CheckIPBalancesInNE(objCFINETIPBucket.cur30DaysCharges, objCFIBasicBucket.cur30DaysCharges)
                '        objCFINETIPBucket.cur60DaysCharges = CheckIPBalancesInNE(objCFINETIPBucket.cur60DaysCharges, objCFIBasicBucket.cur60DaysCharges)
                '        objCFINETIPBucket.cur90DaysCharges = CheckIPBalancesInNE(objCFINETIPBucket.cur90DaysCharges, objCFIBasicBucket.cur90DaysCharges)
                '        objCFINETIPBucket.cur120DaysCharges = CheckIPBalancesInNE(objCFINETIPBucket.cur120DaysCharges, objCFIBasicBucket.cur120DaysCharges)

                '        'WR13502 - NE Siva/Bala - changed the way to calculate IP Balances
                '        objCFIIPBucket.curCurrentCharges = CheckIPBalancesInNE(objCFIIPBucket.curCurrentCharges, objCFITollBucket.curCurrentCharges)
                '        objCFIIPBucket.cur30DaysCharges = CheckIPBalancesInNE(objCFIIPBucket.cur30DaysCharges, objCFITollBucket.cur30DaysCharges)
                '        objCFIIPBucket.cur60DaysCharges = CheckIPBalancesInNE(objCFIIPBucket.cur60DaysCharges, objCFITollBucket.cur60DaysCharges)
                '        objCFIIPBucket.cur90DaysCharges = CheckIPBalancesInNE(objCFIIPBucket.cur90DaysCharges, objCFITollBucket.cur90DaysCharges)
                '        objCFIIPBucket.cur120DaysCharges = CheckIPBalancesInNE(objCFIIPBucket.cur120DaysCharges, objCFITollBucket.cur120DaysCharges)


                '        objCFIBasicBucket.curCurrentCharges = objCFIBasicBucket.curCurrentCharges - objCFINETIPBucket.curCurrentCharges
                '        objCFIBasicBucket.cur30DaysCharges = objCFIBasicBucket.cur30DaysCharges - objCFINETIPBucket.cur30DaysCharges
                '        objCFIBasicBucket.cur60DaysCharges = objCFIBasicBucket.cur60DaysCharges - objCFINETIPBucket.cur60DaysCharges
                '        objCFIBasicBucket.cur90DaysCharges = objCFIBasicBucket.cur90DaysCharges - objCFINETIPBucket.cur90DaysCharges
                '        objCFIBasicBucket.cur120DaysCharges = objCFIBasicBucket.cur120DaysCharges - objCFINETIPBucket.cur120DaysCharges

                '        objCFITollBucket.curCurrentCharges = objCFITollBucket.curCurrentCharges - objCFIIPBucket.curCurrentCharges
                '        objCFITollBucket.cur30DaysCharges = objCFITollBucket.cur30DaysCharges - objCFIIPBucket.cur30DaysCharges
                '        objCFITollBucket.cur60DaysCharges = objCFITollBucket.cur60DaysCharges - objCFIIPBucket.cur60DaysCharges
                '        objCFITollBucket.cur90DaysCharges = objCFITollBucket.cur90DaysCharges - objCFIIPBucket.cur90DaysCharges
                '        objCFITollBucket.cur120DaysCharges = objCFITollBucket.cur120DaysCharges - objCFIIPBucket.cur120DaysCharges


                '        objCFIIPBucket.curCurrentCharges = objCFIIPBucket.curCurrentCharges + objCFINETIPBucket.curCurrentCharges
                '        objCFIIPBucket.cur30DaysCharges = objCFIIPBucket.cur30DaysCharges + objCFINETIPBucket.cur30DaysCharges
                '        objCFIIPBucket.cur60DaysCharges = objCFIIPBucket.cur60DaysCharges + objCFINETIPBucket.cur60DaysCharges
                '        objCFIIPBucket.cur90DaysCharges = objCFIIPBucket.cur90DaysCharges + objCFINETIPBucket.cur90DaysCharges
                '        objCFIIPBucket.cur120DaysCharges = objCFIIPBucket.cur120DaysCharges + objCFINETIPBucket.cur120DaysCharges
                '    End If

                'End If

                If (objCFIInp.strOrg.ToUpper.StartsWith("NJ4") Or objCFIInp.strOrg.ToUpper.StartsWith("NJ5") Or objCFIInp.strOrg.ToUpper.StartsWith("NJ6")) Then
                    'If (objCFIInp.strOrg.ToUpper.StartsWith("NJ")) Then

                    objCFIBasicBucket.curWriteOffAmt = objCFIBasicBucket.curWriteOffAmt + objCFINBBucket.curWriteOffAmt + objCFITollBucket.curWriteOffAmt + objCBSPCFA1_BalanceInfo.curTotalWriteoffAmount
                    objCFIBasicBucket.curCurrentCharges = objCFIBasicBucket.curCurrentCharges + objCFINBBucket.curCurrentCharges + objCFITollBucket.curCurrentCharges + objCBSPCFA1_BalanceInfo.curCurrentBillCharges
                    objCFIBasicBucket.cur30DaysCharges = objCFIBasicBucket.cur30DaysCharges + objCFINBBucket.cur30DaysCharges + objCFITollBucket.cur30DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance30Day

                    objCFIBasicBucket.cur60DaysCharges = objCFIBasicBucket.cur60DaysCharges + objCFINBBucket.cur60DaysCharges + objCFITollBucket.cur60DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance60Day
                    objCFIBasicBucket.cur90DaysCharges = objCFIBasicBucket.cur90DaysCharges + objCFINBBucket.cur90DaysCharges + objCFITollBucket.cur90DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance90Day
                    objCFIBasicBucket.cur120DaysCharges = objCFIBasicBucket.cur120DaysCharges + objCFINBBucket.cur120DaysCharges + objCFITollBucket.cur120DaysCharges + objCBSPCFA1_BalanceInfo.curPreviousBalance120Day

                    objCFINBBucket.curWriteOffAmt = 0
                    objCFITollBucket.curWriteOffAmt = 0

                    objCFINBBucket.curCurrentCharges = 0
                    objCFITollBucket.curCurrentCharges = 0

                    objCFINBBucket.cur30DaysCharges = 0
                    objCFITollBucket.cur30DaysCharges = 0

                    objCFINBBucket.cur60DaysCharges = 0
                    objCFITollBucket.cur60DaysCharges = 0

                    objCFINBBucket.cur90DaysCharges = 0
                    objCFITollBucket.cur90DaysCharges = 0


                    objCFINBBucket.cur120DaysCharges = 0
                    objCFITollBucket.cur120DaysCharges = 0


                    objCFIBasicBucket.curTotalTreatableAmount = objCFIBasicBucket.curTotalTreatableAmount + objCFINBBucket.curTotalTreatableAmount + objCFITollBucket.curTotalTreatableAmount
                    objCFINBBucket.curTotalTreatableAmount = 0
                    objCFITollBucket.curTotalTreatableAmount = 0



                End If




                'When the PAYBYDATE is in the PAST

                If blnPastBillDt Then

                    objCFIBasicBucket.cur90DaysCharges = objCFIBasicBucket.cur120DaysCharges + objCFIBasicBucket.cur90DaysCharges + objCFIBasicBucket.cur60DaysCharges
                    objCFIBasicBucket.cur60DaysCharges = objCFIBasicBucket.cur30DaysCharges
                    objCFIBasicBucket.cur30DaysCharges = objCFIBasicBucket.curCurrentCharges
                    objCFIBasicBucket.curCurrentCharges = 0
                    objCFIBasicBucket.cur120DaysCharges = 0

                    objCFINBBucket.cur90DaysCharges = objCFINBBucket.cur120DaysCharges + objCFINBBucket.cur90DaysCharges + objCFINBBucket.cur60DaysCharges
                    objCFINBBucket.cur60DaysCharges = objCFINBBucket.cur30DaysCharges
                    objCFINBBucket.cur30DaysCharges = objCFINBBucket.curCurrentCharges
                    objCFINBBucket.curCurrentCharges = 0
                    objCFINBBucket.cur120DaysCharges = 0


                    objCFITollBucket.cur90DaysCharges = objCFITollBucket.cur120DaysCharges + objCFITollBucket.cur90DaysCharges + objCFITollBucket.cur60DaysCharges
                    objCFITollBucket.cur60DaysCharges = objCFITollBucket.cur30DaysCharges
                    objCFITollBucket.cur30DaysCharges = objCFITollBucket.curCurrentCharges
                    objCFITollBucket.curCurrentCharges = 0
                    objCFITollBucket.cur120DaysCharges = 0

                    objCFIOCARBucket.cur90DaysCharges = objCFIOCARBucket.cur120DaysCharges + objCFIOCARBucket.cur90DaysCharges + objCFIOCARBucket.cur60DaysCharges
                    objCFIOCARBucket.cur60DaysCharges = objCFIOCARBucket.cur30DaysCharges
                    objCFIOCARBucket.cur30DaysCharges = objCFIOCARBucket.curCurrentCharges
                    objCFIOCARBucket.curCurrentCharges = 0
                    objCFIOCARBucket.cur120DaysCharges = 0

                    objCFICPEBucket.cur90DaysCharges = objCFICPEBucket.cur120DaysCharges + objCFICPEBucket.cur90DaysCharges + objCFICPEBucket.cur60DaysCharges
                    objCFICPEBucket.cur60DaysCharges = objCFICPEBucket.cur30DaysCharges
                    objCFICPEBucket.cur30DaysCharges = objCFICPEBucket.curCurrentCharges
                    objCFICPEBucket.curCurrentCharges = 0
                    objCFICPEBucket.cur120DaysCharges = 0

                    objCFIIPBucket.cur90DaysCharges = objCFIIPBucket.cur120DaysCharges + objCFIIPBucket.cur90DaysCharges + objCFIIPBucket.cur60DaysCharges
                    objCFIIPBucket.cur60DaysCharges = objCFIIPBucket.cur30DaysCharges
                    objCFIIPBucket.cur30DaysCharges = objCFIIPBucket.curCurrentCharges
                    objCFIIPBucket.curCurrentCharges = 0
                    objCFIIPBucket.cur120DaysCharges = 0


                End If


                objCFIBasicBucket.curTotalCharges = objCFIBasicBucket.curCurrentCharges + objCFIBasicBucket.cur30DaysCharges + objCFIBasicBucket.cur60DaysCharges + objCFIBasicBucket.cur90DaysCharges + objCFIBasicBucket.cur120DaysCharges
                objCFINBBucket.curTotalCharges = objCFINBBucket.curCurrentCharges + objCFINBBucket.cur30DaysCharges + objCFINBBucket.cur60DaysCharges + objCFINBBucket.cur90DaysCharges + objCFINBBucket.cur120DaysCharges
                objCFITollBucket.curTotalCharges = objCFITollBucket.curCurrentCharges + objCFITollBucket.cur30DaysCharges + objCFITollBucket.cur60DaysCharges + objCFITollBucket.cur90DaysCharges + objCFITollBucket.cur120DaysCharges
                objCFIOCARBucket.curTotalCharges = objCFIOCARBucket.curCurrentCharges + objCFIOCARBucket.cur30DaysCharges + objCFIOCARBucket.cur60DaysCharges + objCFIOCARBucket.cur90DaysCharges + objCFIOCARBucket.cur120DaysCharges
                objCFICPEBucket.curTotalCharges = objCFICPEBucket.curCurrentCharges + objCFICPEBucket.cur30DaysCharges + objCFICPEBucket.cur60DaysCharges + objCFICPEBucket.cur90DaysCharges + objCFICPEBucket.cur120DaysCharges
                objCFIIPBucket.curTotalCharges = objCFIIPBucket.curCurrentCharges + objCFIIPBucket.cur30DaysCharges + objCFIIPBucket.cur60DaysCharges + objCFIIPBucket.cur90DaysCharges + objCFIIPBucket.cur120DaysCharges


                objCFIBalanceInfo.arrLstBalanceBucketLevel.Add(objCFIBasicBucket)
                objCFIBalanceInfo.arrLstBalanceBucketLevel.Add(objCFINBBucket)
                objCFIBalanceInfo.arrLstBalanceBucketLevel.Add(objCFITollBucket)
                objCFIBalanceInfo.arrLstBalanceBucketLevel.Add(objCFIOCARBucket)
                objCFIBalanceInfo.arrLstBalanceBucketLevel.Add(objCFICPEBucket)
                objCFIBalanceInfo.arrLstBalanceBucketLevel.Add(objCFIIPBucket)
                'objCFIBalanceInfo.arrLstBalanceBucketLevel.Add(objCFIIPREALBucket)


                'Allocate Real IP 
                If (reqObj.strRegionId.Trim() = "NPD") Then
                    Dim objNBArray As CBSPCFA1_BalanceInfo
                    Dim objIPArray As CBSPCFA1_BalanceInfo
                    Dim objIPREALArray As CBSPCFA1_BalanceInfo = New CBSPCFA1_BalanceInfo
                    Dim objIPREALBalanceInfo As CFIBalanceInfoAccum = New CFIBalanceInfoAccum


                    'For Each objNBArray In objCFIBalanceInfo.arrLstBalanceDetails
                    For i As Integer = 0 To objCFIBalanceInfo.arrLstBalanceDetails.Count - 1
                        objNBArray = objCFIBalanceInfo.arrLstBalanceDetails(i)
                        If objNBArray.strKeyDataRecordType = "EB" And objNBArray.strKeyBillingCategoryCode = "N" Then

                            'For Each objIPArray In objCFIBalanceInfo.arrLstBalanceDetails
                            For j As Integer = 0 To objCFIBalanceInfo.arrLstBalanceDetails.Count - 1
                                objIPArray = objCFIBalanceInfo.arrLstBalanceDetails(j)
                                If objIPArray.strKeyDataRecordType = "IP" And objIPArray.strKeyBillingCategoryCode = "N" Then
                                    If (objNBArray.strProductServiceProviderId = objIPArray.strProductServiceProviderId) Then

                                        objIPREALArray.strKeyDataRecordType = "IPREAL"
                                        objIPREALArray.strDataRecordType = "IPREAL"


                                        objIPREALArray.strProductServiceProviderId = objIPArray.strProductServiceProviderId
                                        objIPREALArray.strKeyProductServiceProviderId = objIPArray.strKeyProductServiceProviderId
                                        objIPREALArray.strBillingCategoryCode = objIPArray.strBillingCategoryCode
                                        objIPREALArray.curCurrentBillCharges = CheckIPBalancesInNE(objIPArray.curCurrentBillCharges, objNBArray.curCurrentBillCharges)
                                        objIPREALArray.curPreviousBalance15Day = CheckIPBalancesInNE(objIPArray.curPreviousBalance30Day, objNBArray.curPreviousBalance15Day)
                                        objIPREALArray.curPreviousBalance30Day = CheckIPBalancesInNE(objIPArray.curPreviousBalance30Day, objNBArray.curPreviousBalance30Day)

                                        objIPREALArray.curPreviousBalance45Day = CheckIPBalancesInNE(objIPArray.curPreviousBalance30Day, objNBArray.curPreviousBalance45Day)
                                        objIPREALArray.curPreviousBalance60Day = CheckIPBalancesInNE(objIPArray.curPreviousBalance60Day, objNBArray.curPreviousBalance60Day)
                                        objIPREALArray.curPreviousBalance90Day = CheckIPBalancesInNE(objIPArray.curPreviousBalance90Day, objNBArray.curPreviousBalance90Day)
                                        objIPREALArray.curPreviousBalance120Day = CheckIPBalancesInNE(objIPArray.curPreviousBalance120Day, objNBArray.curPreviousBalance120Day)
                                        objIPREALArray.curTotalAmountDueProvider = CheckIPBalancesInNE(objIPArray.curTotalAmountDueProvider, objNBArray.curTotalAmountDueProvider)
                                        objIPREALArray.curTotalWriteoffAmount = CheckIPBalancesInNE(objIPArray.curTotalWriteoffAmount, objNBArray.curTotalWriteoffAmount)
                                        objIPREALArray.curTotalBillableAmount = CheckIPBalancesInNE(objIPArray.curTotalBillableAmount, objNBArray.curTotalBillableAmount)
                                        objIPREALArray.curCurrentDemandCharges = CheckIPBalancesInNE(objIPArray.curCurrentDemandCharges, objNBArray.curCurrentDemandCharges)
                                        objIPREALArray.curPreviousDemandCharges = CheckIPBalancesInNE(objIPArray.curPreviousDemandCharges, objNBArray.curPreviousDemandCharges)
                                        objIPREALArray.curPresentBillCharges = CheckIPBalancesInNE(objIPArray.curPresentBillCharges, objNBArray.curPresentBillCharges)
                                        objIPREALArray.curUnbilledCharges = CheckIPBalancesInNE(objIPArray.curUnbilledCharges, objNBArray.curUnbilledCharges)
                                        objIPREALArray.curTotalTreatableAmount = CheckIPBalancesInNE(objIPArray.curTotalTreatableAmount, objNBArray.curTotalTreatableAmount)
                                        objIPREALBalanceInfo.arrLstBalanceDetails.Add(objIPREALArray)
                                        objIPREALArray = New CBSPCFA1_BalanceInfo

                                    End If

                                End If

                            Next
                        End If


                    Next


                    'For Each objIPREALArray In objIPREALBalanceInfo.arrLstBalanceDetails
                    For k As Integer = 0 To objIPREALBalanceInfo.arrLstBalanceDetails.Count - 1
                        objIPREALArray = objIPREALBalanceInfo.arrLstBalanceDetails(k)

                        objCBSPCFA1_BalanceInfo = New CBSPCFA1_BalanceInfo

                        objCBSPCFA1_BalanceInfo.strKeyDataRecordType = objIPREALArray.strKeyDataRecordType
                        objCBSPCFA1_BalanceInfo.strDataRecordType = objIPREALArray.strDataRecordType
                        objCBSPCFA1_BalanceInfo.strProductServiceProviderId = objIPREALArray.strProductServiceProviderId
                        objCBSPCFA1_BalanceInfo.strKeyProductServiceProviderId = objIPREALArray.strKeyProductServiceProviderId
                        objCBSPCFA1_BalanceInfo.strBillingCategoryCode = objIPREALArray.strBillingCategoryCode
                        objCBSPCFA1_BalanceInfo.curCurrentBillCharges = objIPREALArray.curCurrentBillCharges
                        objCBSPCFA1_BalanceInfo.curPreviousBalance15Day = objIPREALArray.curPreviousBalance15Day
                        objCBSPCFA1_BalanceInfo.curPreviousBalance30Day = objIPREALArray.curPreviousBalance30Day
                        objCBSPCFA1_BalanceInfo.curPreviousBalance45Day = objIPREALArray.curPreviousBalance45Day
                        objCBSPCFA1_BalanceInfo.curPreviousBalance60Day = objIPREALArray.curPreviousBalance60Day
                        objCBSPCFA1_BalanceInfo.curPreviousBalance90Day = objIPREALArray.curPreviousBalance90Day
                        objCBSPCFA1_BalanceInfo.curPreviousBalance120Day = objIPREALArray.curPreviousBalance120Day
                        objCBSPCFA1_BalanceInfo.curTotalAmountDueProvider = objIPREALArray.curTotalAmountDueProvider
                        objCBSPCFA1_BalanceInfo.curTotalWriteoffAmount = objIPREALArray.curTotalWriteoffAmount
                        objCBSPCFA1_BalanceInfo.curTotalBillableAmount = objIPREALArray.curTotalBillableAmount
                        objCBSPCFA1_BalanceInfo.curCurrentDemandCharges = objIPREALArray.curCurrentDemandCharges
                        objCBSPCFA1_BalanceInfo.curPresentBillCharges = objIPREALArray.curPresentBillCharges
                        objCBSPCFA1_BalanceInfo.curUnbilledCharges = objIPREALArray.curUnbilledCharges
                        objCBSPCFA1_BalanceInfo.curTotalTreatableAmount = objIPREALArray.curTotalTreatableAmount

                        objCFIBalanceInfo.arrLstBalanceDetails.Add(objCBSPCFA1_BalanceInfo)
                        objCBSPCFA1_BalanceInfo = New CBSPCFA1_BalanceInfo

                    Next

                    '    'objCFIBalanceInfo.arrLstBalanceDetails.Add(objCBSPCFA1_BalanceInfo)
                    '    'objCBSPCFA1_BalanceInfo = New CBSPCFA1_BalanceInfo

                ElseIf (reqObj.strRegionId.Trim() = "NE") Then 'WR68041 added NE logic
                    Dim objNBArray As CBSPCFA1_BalanceInfo = New CBSPCFA1_BalanceInfo
                    Dim objIPArray As CBSPCFA1_BalanceInfo
                    Dim objIPREALArray As CBSPCFA1_BalanceInfo = New CBSPCFA1_BalanceInfo
                    Dim objIPREALBalanceInfo As CFIBalanceInfoAccum = New CFIBalanceInfoAccum

                    'For Each objIPArray In objCFIBalanceInfo.arrLstBalanceDetails
                    For i As Integer = 0 To objCFIBalanceInfo.arrLstBalanceDetails.Count - 1
                        objIPArray = objCFIBalanceInfo.arrLstBalanceDetails(i)
                        'If objIPArray.strKeyDataRecordType = "EB" And objIPArray.strKeyBillingCategoryCode = "5" Then
                        If objIPArray.strKeyBillingCategoryCode = "5" Then

                            objIPREALArray.strKeyDataRecordType = "IPREAL"
                            objIPREALArray.strDataRecordType = "IPREAL"
                            objIPREALArray.strProductServiceProviderId = objIPArray.strProductServiceProviderId
                            objIPREALArray.strKeyProductServiceProviderId = objIPArray.strKeyProductServiceProviderId
                            objIPREALArray.strBillingCategoryCode = objIPArray.strBillingCategoryCode
                            objCBSPCFA1_BalanceInfo.strProductServiceProviderId = objIPArray.strProductServiceProviderId 'objIPREALArray.strProductServiceProviderId
                            objCBSPCFA1_BalanceInfo.strKeyProductServiceProviderId = objIPArray.strKeyProductServiceProviderId
                            objCBSPCFA1_BalanceInfo.strBillingCategoryCode = objIPArray.strBillingCategoryCode
                            objCBSPCFA1_BalanceInfo.curCurrentBillCharges = objIPArray.curCurrentBillCharges
                            objCBSPCFA1_BalanceInfo.curPreviousBalance15Day = objIPArray.curPreviousBalance15Day
                            objCBSPCFA1_BalanceInfo.curPreviousBalance30Day = objIPArray.curPreviousBalance30Day
                            objCBSPCFA1_BalanceInfo.curPreviousBalance45Day = objIPArray.curPreviousBalance45Day
                            objCBSPCFA1_BalanceInfo.curPreviousBalance60Day = objIPArray.curPreviousBalance60Day
                            objCBSPCFA1_BalanceInfo.curPreviousBalance90Day = objIPArray.curPreviousBalance90Day
                            objCBSPCFA1_BalanceInfo.curPreviousBalance120Day = objIPArray.curPreviousBalance120Day
                            objCBSPCFA1_BalanceInfo.curTotalAmountDueProvider = objIPArray.curTotalAmountDueProvider
                            objCBSPCFA1_BalanceInfo.curTotalWriteoffAmount = objIPArray.curTotalWriteoffAmount
                            objCBSPCFA1_BalanceInfo.curTotalBillableAmount = objIPArray.curTotalBillableAmount
                            objCBSPCFA1_BalanceInfo.curCurrentDemandCharges = objIPArray.curCurrentDemandCharges
                            objCBSPCFA1_BalanceInfo.curPresentBillCharges = objIPArray.curPresentBillCharges
                            objCBSPCFA1_BalanceInfo.curUnbilledCharges = objIPArray.curUnbilledCharges
                            objCBSPCFA1_BalanceInfo.curTotalTreatableAmount = objIPArray.curTotalTreatableAmount

                            objIPREALBalanceInfo.arrLstBalanceDetails.Add(objIPREALArray)
                            objIPREALArray = New CBSPCFA1_BalanceInfo

                        End If
                    Next



                    'For Each objIPREALArray In objIPREALBalanceInfo.arrLstBalanceDetails
                    For i As Integer = 0 To objIPREALBalanceInfo.arrLstBalanceBucketLevel.Count - 1
                        objIPREALArray = objIPREALBalanceInfo.arrLstBalanceBucketLevel(i)

                        objCBSPCFA1_BalanceInfo = New CBSPCFA1_BalanceInfo

                        objCBSPCFA1_BalanceInfo.strKeyDataRecordType = objIPREALArray.strKeyDataRecordType
                        objCBSPCFA1_BalanceInfo.strDataRecordType = objIPREALArray.strDataRecordType


                        objCBSPCFA1_BalanceInfo.strProductServiceProviderId = objIPArray.strProductServiceProviderId
                        objCBSPCFA1_BalanceInfo.strKeyProductServiceProviderId = objIPArray.strKeyProductServiceProviderId
                        objCBSPCFA1_BalanceInfo.strBillingCategoryCode = objIPArray.strBillingCategoryCode
                        objCBSPCFA1_BalanceInfo.curCurrentBillCharges = objIPArray.curCurrentBillCharges
                        objCBSPCFA1_BalanceInfo.curPreviousBalance15Day = objIPArray.curPreviousBalance15Day
                        objCBSPCFA1_BalanceInfo.curPreviousBalance30Day = objIPArray.curPreviousBalance30Day
                        objCBSPCFA1_BalanceInfo.curPreviousBalance45Day = objIPArray.curPreviousBalance45Day
                        objCBSPCFA1_BalanceInfo.curPreviousBalance60Day = objIPArray.curPreviousBalance60Day
                        objCBSPCFA1_BalanceInfo.curPreviousBalance90Day = objIPArray.curPreviousBalance90Day
                        objCBSPCFA1_BalanceInfo.curPreviousBalance120Day = objIPArray.curPreviousBalance120Day
                        objCBSPCFA1_BalanceInfo.curTotalAmountDueProvider = objIPArray.curTotalAmountDueProvider
                        objCBSPCFA1_BalanceInfo.curTotalWriteoffAmount = objIPArray.curTotalWriteoffAmount
                        objCBSPCFA1_BalanceInfo.curTotalBillableAmount = objIPArray.curTotalBillableAmount
                        objCBSPCFA1_BalanceInfo.curCurrentDemandCharges = objIPArray.curCurrentDemandCharges
                        objCBSPCFA1_BalanceInfo.curPresentBillCharges = objIPArray.curPresentBillCharges
                        objCBSPCFA1_BalanceInfo.curUnbilledCharges = objIPArray.curUnbilledCharges
                        objCBSPCFA1_BalanceInfo.curTotalTreatableAmount = objIPArray.curTotalTreatableAmount

                        objCFIBalanceInfo.arrLstBalanceDetails.Add(objCBSPCFA1_BalanceInfo)
                        objCBSPCFA1_BalanceInfo = New CBSPCFA1_BalanceInfo

                    Next

                End If



            Catch ex As Exception

                LogErrorFile.WriteLog("RMICWWS-CBSPCFA1", "AcctNum: " & objCFIInp.strAcctNum & " Erroring Out " & ex.ToString & " Org " & objCFIInp.strOrg & " Region " & objCFIInp.strRegioncd)
                objCFIBalanceInfo.RequestStatus.strMessageId = "RMIEXPTN"
                objCFIBalanceInfo.RequestStatus.strMessageDescription = ex.ToString

            End Try

            If objCFIInp.strGetOption = "1" Then
                Dim eraDS As DataSet
                Try
                    strCFIxml = strCFIxml.Replace("cfa1:", "")
                    strCFIxml = "<CFA1>" + strCFIxml + "</CFA1>"
                    eraDS = MyBase.WSDataAccessObj.usp_InsertERAResponse(objCFIInp.strAcctNum, objCFIInp.strRegioncd, "CFA1", strCFIxml)
                    LogErrorFile.WriteLog(objCFIInp.strAcctNum, strCFIxml.Trim())
                Catch ex As Exception
                    LogErrorFile.WriteLog(objCFIInp.strAcctNum, "<CFA1>" + strCFIxml.Trim() + "</CFA1>")
                End Try
            ElseIf objCFIInp.strGetOption = "2" Then
                LogErrorFile.WriteLog(objCFIInp.strAcctNum, "<CFA1>" + strCFIxml.Trim() + "</CFA1>")
            End If


            Return objCFIBalanceInfo

        End Function

        Public Function getBalanceInfo_DS(ByVal strRegionId As String, ByVal strAcctNum As String) As BalanceInfo

            'Dim objAcctBalanceInfo As AcctBalanceInfo = New AcctBalanceInfo
            Dim objBalanceInfo As BalanceInfo = New BalanceInfo
            Dim strUrl As String = ""
            Dim curPPXAmt As Double = 0
            Dim strVisionAccountID As String
            Dim strVisionCustID As String
            Dim strDSxml As String = ""
            Dim dtmProcessDate As Date = "1900/01/01"
            dtmProcessDate = Now.Date()
            Dim dtmPaybydate As Date = "1900/01/01"
            Dim blnCurrent As Boolean = False
            Dim blnTransient As Boolean = False
            Dim blnTreatable As Boolean = False
            Dim strBalanceType As String = ""
            Dim objwsMain As New WSMain()

            Dim objFinanceProfile As FinanceProfile = New FinanceProfile()



            Try

                Select Case True

                    Case strRegionId Is Nothing Or strRegionId.Trim = ""

                        objBalanceInfo.RequestStatus.strMessageId = "INVRGNID"
                        objBalanceInfo.RequestStatus.strMessageDescription = "Invalid Region Id passed."
                        Return objBalanceInfo


                    Case strAcctNum Is Nothing Or strAcctNum.Trim = ""

                        objBalanceInfo.RequestStatus.strMessageId = "INVACNBR"
                        objBalanceInfo.RequestStatus.strMessageDescription = "Invalid Account Number passed as Input."
                        Return objBalanceInfo

                End Select
                If (strAcctNum >= 13) Then
                    strVisionCustID = strAcctNum.Substring(0, 9)
                    strVisionAccountID = strAcctNum.Substring(9, 4)
                Else
                    objBalanceInfo.RequestStatus.strMessageId = "INVACNBR"
                    objBalanceInfo.RequestStatus.strMessageDescription = "Invalid VISION Account Number passed as Input."
                    Return objBalanceInfo
                End If





                Dim dtBillDueDate As Date
                Dim curCurrentChargesNotDueBasic As Double = 0
                Dim curCurrentChargesNotDueNonBasic As Double = 0
                Dim curCurrentChargesNotDueToll As Double = 0





                objBalanceInfo.strAcctNum = strAcctNum
                Dim arrLst As ArrayList = New ArrayList

                Dim xmlDoc As XmlDocument
                Dim xmlEle As XmlElement


                Dim objCommon As CommonFunctions = New CommonFunctions
                Dim objDSBalanceInfo As DSBalanceInfo

                'Finance Profile CALL
                Dim sw As New StringWriter
                Dim XmlTxtReader As XmlTextReader
                Dim sr As StringReader
                Dim DatashareDataSet As New DataSet
                Dim strDSOutputXML As String
                Dim DSTable As DataTable
                Dim DSDataRow As DataRow
                Dim objXMLnode As XmlNode
                Dim strInpValue As String
                Dim strValue As String

                objFinanceProfile = objwsMain.GetDSFinanceProfile(strVisionCustID, strVisionAccountID, "E", "RMICW")

                'Serialize to xml
                Dim ser As New XmlSerializer(ObjFinanceProfile.GetType)
                ser.Serialize(sw, ObjFinanceProfile)
                strDSOutputXML = sw.ToString()
                Dim xDocCSR As New XmlDocument()
                Dim BalanceNode As XmlNodeList
                Dim strKeyDataType As String
                Dim xElement As XmlNodeList
                If strDSOutputXML <> "" Then
                    xDocCSR.LoadXml(strDSOutputXML)

                    xElement = xDocCSR.SelectNodes("//FinanceProfile/ErrorInfo")
                    If xElement IsNot Nothing AndAlso xElement.Count > 0 Then
                        'For Each xmlSuccess As XmlNode In xElement
                        For i As Integer = 0 To xElement.Count - 1
                            Dim xmlSuccess As XmlNode = xElement(i)
                            If xmlSuccess("IsError") IsNot Nothing AndAlso xmlSuccess("IsError").InnerText.ToString().Trim() = "true" Then
                                strValue = xmlSuccess("Message").InnerText.ToString()
                            End If
                        Next


                    End If


                    If strValue <> "Account not found in DataShare" Then
                        objDSBalanceInfo = New DSBalanceInfo
                        Dim objBalances As FinanceProfileAccountDetailsBalanceAccountBalanceByProviderAndCategory = New FinanceProfileAccountDetailsBalanceAccountBalanceByProviderAndCategory

                        If Not objFinanceProfile.AccountDetails.CashOnlyStatus Is Nothing Then
                            objBalanceInfo.strDSCashOnlyStatus = objFinanceProfile.AccountDetails.CashOnlyStatus
                        End If

                        'var varCCBillDate = From cc In doc.Element("TRA9").Elements("Cbsptra9XmlResultsBalance").ToList())
                        '                                  where cc.Element("SegmentData").Element("DataRecordType").Value == "CB"
                        '                                  select cc;
                        Try

                            Dim query As Object
                            'query = From objBalanceType As Object In objFinanceProfile.AccountDetails.Balance Where (objBalanceType.BalanceType.ToString().ToUpper() = "CURRENT") Select objBalanceType
                            query = From objBalanceType As FinanceProfileAccountDetailsBalanceAccountBalanceByProviderAndCategory In objFinanceProfile.AccountDetails.Balance Select objBalanceType
                            'For Each objBalanceType As FinanceProfileAccountDetailsBalanceAccountBalanceByProviderAndCategory In query
                            For i As Integer = 0 To query.Count - 1
                                Dim objBalanceType As FinanceProfileAccountDetailsBalanceAccountBalanceByProviderAndCategory = query(i)
                                Select Case objBalanceType.BalanceType.ToString().ToUpper()
                                    Case "CURRENT"
                                        blnCurrent = True
                                    Case "TRANSIENT"
                                        blnTransient = True
                                    Case "TREATMENT"
                                        blnTreatable = True
                                End Select
                            Next
                            If blnCurrent = True And blnTransient = True Then
                                strBalanceType = "TRANSIENT"
                            ElseIf blnCurrent = False And blnTransient = True Then
                                strBalanceType = "TRANSIENT"
                            ElseIf blnCurrent = True And blnTransient = False Then
                                strBalanceType = "CURRENT"
                            End If
                        Catch ex As Exception

                        End Try










                        Dim dblBasicTotalDue As Double = 0
                        Dim dblNBTotalDue As Double = 0
                        Dim dblTollTotalDue As Double = 0
                        Dim dblOcarTotalDue As Double = 0

                        'If Bill Date is in the Past then   TotaDue = PastDue 
                        'If Bill Date is in the Future then PastDue = TotaDue-CurrentCharges 

                        'Total Due  
                        For Each objBalances In objFinanceProfile.AccountDetails.Balance
                            If Not objBalances.BalanceType Is Nothing Then
                                If objBalances.BalanceType.ToUpper() = strBalanceType Then
                                    objDSBalanceInfo.strKeyDataRecordType = objBalances.BalanceType.ToUpper()
                                    objDSBalanceInfo.strKeyProductServiceProviderId = objBalances.ProviderID
                                    objDSBalanceInfo.strKeyBillingCategoryCode = objBalances.BillCategoryCode
                                    objDSBalanceInfo.strDataRecordType = objBalances.ProviderDescription
                                    objDSBalanceInfo.strBalanceDate = objBalances.BalanceDate
                                    objDSBalanceInfo.strProductServiceProviderId = objBalances.ProviderID
                                    objDSBalanceInfo.strBillingCategoryCode = objBalances.BillCategoryCode
                                    objDSBalanceInfo.curCurrentBillCharges = objBalances.CurrentBillCharges
                                    objDSBalanceInfo.curPreviousBalance30Day = objBalances.Day30Balance
                                    objDSBalanceInfo.curPreviousBalance60Day = objBalances.Day60Balance
                                    objDSBalanceInfo.curPreviousBalance90Day = objBalances.Day90Balance
                                    objDSBalanceInfo.curPreviousBalance120Day = objBalances.Day120Balance
                                    objDSBalanceInfo.curTotalAmountDueProvider = objBalances.TotalAmountDue
                                    objBalanceInfo.arrLstBalanceDetails.Add(objDSBalanceInfo)
                                    Select Case objBalances.BillCategoryCode
                                        Case "B"
                                            'objBalanceInfo.curTotalDueBasic = objBalanceInfo.curTotalDueBasic + objBalances.CurrentBillCharges + objBalances.Day30Balance + objBalances.Day60Balance + objBalances.Day90Balance + objBalances.Day120Balance
                                            dblBasicTotalDue = objBalanceInfo.curTotalDueBasic + objBalances.CurrentBillCharges + objBalances.Day30Balance + objBalances.Day60Balance + objBalances.Day90Balance + objBalances.Day120Balance
                                            objBalanceInfo.curTotalDueBasic += Math.Round(dblBasicTotalDue, 2)
                                        Case "N", "4"
                                            'objBalanceInfo.curTotalDueNonBasic += objBalanceInfo.curTotalDueNonBasic + objBalances.CurrentBillCharges + objBalances.Day30Balance + objBalances.Day60Balance + objBalances.Day90Balance + objBalances.Day120Balance
                                            dblNBTotalDue = objBalances.CurrentBillCharges + objBalances.Day30Balance + objBalances.Day60Balance + objBalances.Day90Balance + objBalances.Day120Balance
                                            objBalanceInfo.curTotalDueNonBasic += Math.Round(dblNBTotalDue, 2)

                                        Case "T"
                                            dblTollTotalDue = objBalanceInfo.curTotalDueToll + objBalances.CurrentBillCharges + objBalances.Day30Balance + objBalances.Day60Balance + objBalances.Day90Balance + objBalances.Day120Balance
                                            objBalanceInfo.curTotalDueToll += Math.Round(dblNBTotalDue, 2)

                                        Case "O"
                                            dblOcarTotalDue = objBalanceInfo.curTotalDueOCAR + objBalances.CurrentBillCharges + objBalances.Day30Balance + objBalances.Day60Balance + objBalances.Day90Balance + objBalances.Day120Balance
                                            objBalanceInfo.curTotalDueOCAR += Math.Round(dblNBTotalDue, 2)
                                    End Select

                                End If
                            End If
                        Next






                        'pastdue
                        Dim dblNBPastDue As Double = 0
                        Dim dbl4PastDue As Double = 0
                        Dim dblTollPastDue As Double = 0

                        For Each objBalances In objFinanceProfile.AccountDetails.Balance
                            If Not objBalances.BalanceType Is Nothing Then
                                If objBalances.BalanceType.ToUpper() = strBalanceType Then
                                    Select Case objBalances.BillCategoryCode
                                        Case "B"
                                            If (dtmPaybydate.CompareTo(dtmProcessDate) <= 0) Then
                                                objBalanceInfo.curPastDueBasic = objBalanceInfo.curPastDueBasic + objBalances.CurrentBillCharges + objBalances.Day30Balance + objBalances.Day60Balance + objBalances.Day90Balance + objBalances.Day120Balance
                                            ElseIf (dtmPaybydate.CompareTo(dtmProcessDate) > 0) Then
                                                objBalanceInfo.curPastDueBasic = objBalanceInfo.curPastDueBasic + objBalances.Day30Balance + objBalances.Day60Balance + objBalances.Day90Balance + objBalances.Day120Balance
                                            End If
                                        Case "N", "4"
                                            dbl4PastDue = objBalances.Day30Balance + objBalances.Day60Balance + objBalances.Day90Balance + objBalances.Day120Balance
                                            objBalanceInfo.curPastDueNonBasic += Math.Round(dbl4PastDue, 2)

                                            'If (dtmPaybydate.CompareTo(dtmProcessDate) <= 0) Then
                                            '    objBalanceInfo.curPastDueNonBasic = objBalanceInfo.curPastDueNonBasic + objBalances.CurrentBillCharges + objBalances.Day30Balance + objBalances.Day60Balance + objBalances.Day90Balance + objBalances.Day120Balance
                                            'ElseIf (dtmPaybydate.CompareTo(dtmProcessDate) > 0) Then
                                            '    objBalanceInfo.curPastDueNonBasic = objBalanceInfo.curPastDueNonBasic + objBalances.Day30Balance + objBalances.Day60Balance + objBalances.Day90Balance + objBalances.Day120Balance
                                            'End If
                                        Case "T"

                                            If (dtmPaybydate.CompareTo(dtmProcessDate) <= 0) Then
                                                objBalanceInfo.curPastDueToll = objBalanceInfo.curPastDueToll + objBalances.CurrentBillCharges + objBalances.Day30Balance + objBalances.Day60Balance + objBalances.Day90Balance + objBalances.Day120Balance
                                            ElseIf (dtmPaybydate.CompareTo(dtmProcessDate) > 0) Then
                                                objBalanceInfo.curPastDueToll = objBalanceInfo.curPastDueToll + objBalances.Day30Balance + objBalances.Day60Balance + objBalances.Day90Balance + objBalances.Day120Balance
                                            End If
                                        Case "O"

                                            If (dtmPaybydate.CompareTo(dtmProcessDate) <= 0) Then
                                                objBalanceInfo.curPastDueOCAR = objBalanceInfo.curPastDueOCAR + objBalances.CurrentBillCharges + objBalances.Day30Balance + objBalances.Day60Balance + objBalances.Day90Balance + objBalances.Day120Balance
                                            ElseIf (dtmPaybydate.CompareTo(dtmProcessDate) > 0) Then
                                                objBalanceInfo.curPastDueOCAR = objBalanceInfo.curPastDueOCAR + objBalances.Day30Balance + objBalances.Day60Balance + objBalances.Day90Balance + objBalances.Day120Balance
                                            End If
                                    End Select

                                End If
                            End If
                        Next




                        'Treatment

                        Dim dblNBTrtDue As Double = 0
                        Dim dbl4TrtDue As Double = 0
                        Dim dblTollTrtDue As Double = 0

                        For Each objBalances In objFinanceProfile.AccountDetails.Balance
                            If Not objBalances.BalanceType Is Nothing Then
                                If objBalances.BalanceType.ToUpper() = "TREATMENT" Then
                                    Select Case objBalances.BillCategoryCode
                                        Case "B"
                                            objBalanceInfo.curTreatableDueBasic = objBalanceInfo.curTreatableDueBasic + objBalances.CurrentBillCharges + objBalances.Day30Balance + objBalances.Day60Balance + objBalances.Day90Balance + objBalances.Day120Balance '+ cfir.curPastDueCharges

                                        Case "N", "4"
                                            dblNBTrtDue = objBalances.CurrentBillCharges + objBalances.Day30Balance + objBalances.Day60Balance + objBalances.Day90Balance + objBalances.Day120Balance '+ cfir.curPastDueCharges
                                            objBalanceInfo.curTreatableDueNonBasic += dblNBTrtDue
                                        Case "T"
                                            dblTollTrtDue = objBalanceInfo.curTreatableDueToll + objBalances.CurrentBillCharges + objBalances.Day30Balance + objBalances.Day60Balance + objBalances.Day90Balance + objBalances.Day120Balance '+ cfir.curPastDueCharges
                                            objBalanceInfo.curTreatableDueToll += dblTollTrtDue
                                        Case "O"
                                            objBalanceInfo.curTreatableDueOCAR = objBalanceInfo.curTreatableDueOCAR + objBalances.CurrentBillCharges + objBalances.Day30Balance + objBalances.Day60Balance + objBalances.Day90Balance + objBalances.Day120Balance '+ cfir.curPastDueCharges
                                    End Select
                                End If
                            End If
                        Next

                        objBalanceInfo.arrLstBalanceDetails.Add(objBalanceInfo)
                    End If


                End If


            Catch ex As Exception

                LogErrorFile.WriteLog("RMICWWS-DS_FinanceProfile", "AcctNum: " & strAcctNum & " Erroring Out " & ex.ToString)
                objBalanceInfo.RequestStatus.strMessageId = "RMIEXPTN"
                objBalanceInfo.RequestStatus.strMessageDescription = ex.ToString

            End Try


            Return objBalanceInfo

        End Function

        Public Function CheckIPBalancesInNE(ByVal curIPCharges As Double, ByVal curBucketCharge As Double) As Double

            Dim curCharges As Double = 0.0

            If (curIPCharges > 0) Then
                Select Case True
                    Case curIPCharges > curBucketCharge
                        curCharges = curBucketCharge
                    Case curIPCharges = curBucketCharge
                        curCharges = curIPCharges
                    Case curIPCharges < curBucketCharge
                        curCharges = curIPCharges
                End Select
            Else
                curCharges = curIPCharges
            End If

            Return curCharges

        End Function


        'Public Function getAcctsForSBM(ByVal strRegionId As String, ByVal strAcctNum As String, ByVal strRshipCode As String) As SummaryBillDetails
        Public Function getAcctsForSBM(ByVal strRegionId As String, ByVal strAcctNum As String, ByVal strRshipCode As String) As SummaryBillDetails

            Dim objSBMList As SummaryBillDetails = New SummaryBillDetails
            Dim objAcctList As SBMAcctList
            '1-If Value is CROSS-J,HOA-H,MULTIBAN-M,PARENTCHILD-P Call GetChildAccountByParentCAN -WR62854 RSS
            '2-getBillingGetAccountRelationshipsA2R � Find the RelationShip 
            '3-When 'P' Use InvoiceCAN,'H' Use ParentCAN,'M' Use LECAccount 
            '4- Call getparentChild(method) to get All the Children 
            '5-GetPSPSStatus� get internal PSPS Status 
            Dim objWsMain As WSMain = New WSMain
            Dim objSSPRqst As SSPRequestDetails = New SSPRequestDetails()
            objSSPRqst.strAcctNum = strAcctNum.Trim()
            objSSPRqst.strRegionId = strRegionId.Trim()


            'Portal Changes for RshipCode 
            'H-HOA Defauls ,S- SBM ,F- Fraud

            Select Case strRshipCode.ToUpper.Trim()
                Case "H"
                Case "S"
                    strRshipCode = ""
                Case "F"
                    strRshipCode = "F"
            End Select

            objSSPRqst.RshipCode = strRshipCode.Trim()
            objSSPRqst.RshipCode = "SBM"

            Try
                If strRshipCode.ToUpper.Trim() = "F" Then
                    Dim objLineInfo As AcctLineLevelInfo = New AcctLineLevelInfo

                    Dim objLineLevel As LineLevelInfo
                    objLineInfo = objWsMain.getCBSS_AcctLineInfo(strRegionId, strAcctNum)
                    'For Each objLineLevel In objLineInfo.arrLstLineDetails
                    For i As Integer = 0 To objLineInfo.arrLstLineDetails.Count - 1
                        objLineLevel = objLineInfo.arrLstLineDetails(i)
                        objAcctList = New SBMAcctList
                        objAcctList.strAcctNum = objLineLevel.strTelephoneNo
                        objAcctList.strBTNNum = strAcctNum
                        objSBMList.arrLstAcctList.Add(objAcctList)

                    Next
                    Return objSBMList

                End If
            Catch exF As Exception

                LogErrorFile.WriteLog("RMICWWS-getAcctsForSBM-Fraud", exF.ToString())
                objSBMList.RequestStatus.strMessageId = "100"
                objSBMList.RequestStatus.strMessageDescription = exF.ToString()
                Return objSBMList

            End Try




            Try
                Dim objclsFIos As clsFIOS = New clsFIOS()
                Dim getFIOSRequest As getFIOSDataInputDetails = New getFIOSDataInputDetails()
                getFIOSRequest.strAcctNum = strAcctNum.Trim()
                getFIOSRequest.strRegionId = strRegionId.Trim()


                If objSSPRqst.RshipCode = "" Then
                    Dim dsSBM As DataSet = usp_GetCustomerAddressInfo(MyBase.RegionId, strAcctNum)
                    If MyBase.WSDataAccessObj.IsEmptyRecordSet(dsSBM) Then
                        objSBMList.RequestStatus.strMessageId = "100"
                        objSBMList.RequestStatus.strMessageDescription = "AcctNum is not an SBM Acct."
                        Return objSBMList
                    Else
                        getFIOSRequest.strOrg = dsSBM.Tables(0).Rows(0).Item("strOrgCode")
                        getFIOSRequest.strEnvironment = dsSBM.Tables(0).Rows(0).Item("strEnv")
                    End If

                    objclsFIos.IntializeInput(objSSPRqst, getFIOSRequest, False, "")

                    objSSPRqst = objclsFIos.fnFindAccountRelationShipA2R(objSSPRqst)
                    strRshipCode = objSSPRqst.RshipCode.Trim()
                End If

                Select Case objSSPRqst.RshipCode.Trim()
                    Case "P", "H", "M", "E"
                        Dim objGetChildAccountByParentCANResponse As UCSRNACR.GetChildAccountByParentCANResponse = New UCSRNACR.GetChildAccountByParentCANResponse()
                        Dim objBroadbandCAN As UCSRNACR.ResultsBroadbandCAN = New UCSRNACR.ResultsBroadbandCAN
                        Dim objUCSRAccess As UCSRAccess = New UCSRAccess(strRegionId)
                        Select Case objSSPRqst.RshipCode.Trim()
                            Case "P", "H"

                                If objSSPRqst.RshipCode.Trim() = "P" And objSSPRqst.strOrgInd.Trim() = "L" Then
                                    objSSPRqst.strAcctType = "PARENTCAN"
                                Else
                                    'objSSPRqst.strAcctType = "INVOICECAN"
                                    objSSPRqst.strAcctType = "PARENTCAN"
                                End If


                                If objSSPRqst.RshipCode.Trim() = "H" Then
                                    objSSPRqst.strAcctType = "PARENTCAN"
                                End If
                                'Old Code Begin
                                'No need to call for M or E 
                                'objGetChildAccountByParentCANResponse = objUCSRAccess.GetChildAccountByParentCAN(objSSPRqst.strAcctNum, objSSPRqst.strAcctType, objSSPRqst.strRegionId)

                                'If Not objGetChildAccountByParentCANResponse.Message.messageNumber Is Nothing Then
                                '    If objGetChildAccountByParentCANResponse.Message.messageText.Trim() = "NO ERRORS" Then
                                '        For Each objBroadbandCAN In objGetChildAccountByParentCANResponse.Results.ParentCAN.BroadbandCAN
                                '            objAcctList = New SBMAcctList
                                '            objAcctList.strAcctNum = objBroadbandCAN.Value
                                '            objAcctList.strBTNNum = objSSPRqst.strAcctNum
                                '            'If Not objAcctList.strAcctNum.Trim = strAcctNum.Trim Then
                                '            'Only Add the LIVE Accounts ,Term Accounts SKIP Adding 
                                '            If objBroadbandCAN.RelationshipTermDate.Trim() = "9999-12-31" Then
                                '                objSBMList.arrLstAcctList.Add(objAcctList)
                                '            End If

                                '            'End If
                                '        Next
                                '        Return objSBMList
                                '    Else
                                '        objSBMList.RequestStatus.strMessageId = "100"
                                '        objSBMList.RequestStatus.strMessageDescription = objGetChildAccountByParentCANResponse.Message.messageText.Trim()
                                '        Return objSBMList
                                '    End If

                                'Else
                                '    objSBMList.RequestStatus.strMessageId = "100"
                                '    objSBMList.RequestStatus.strMessageDescription = "Empty Multi BBAND Returned"
                                '    Return objSBMList

                                'End If
                                'Old Code END


                                Dim xmldoc As New XmlDocument
                                Dim objRetrieveChildAccountforParent_SSPPA As RetrievedChildAccountByParent.RetrievalServiceResponse = New RetrievedChildAccountByParent.RetrievalServiceResponse()
                                ' Dim objBroadBandInfo As New RetrievedChildAccountByParent.RetrievalServiceResponse.RetrievalServiceResponseRetrievalAcceptedRetrievedChildAccountByParentIdParentAccount
                                Dim objRetrievedChildInfo As New RetrievedChildAccountByParent.RetrievalServiceResponseRetrievalAcceptedRetrievedChildAccountByParentIdParentAccountChildAccount
                                Dim xmlgetKeyResponseDeSer As XmlSerializer
                                xmldoc = objWsMain.RetrieveChildAccountforParent_SSPPA(objSSPRqst.strAcctNum.Trim(), objSSPRqst.strRegionId.Trim(), objSSPRqst.intRequestId.Trim())
                                Dim strResponsexml = xmldoc.InnerXml.ToString()

                                strResponsexml = System.Text.RegularExpressions.Regex.Replace(strResponsexml, "[+~!@#$%^&*()_+{}|]", "")
                                strResponsexml = System.Text.RegularExpressions.Regex.Replace(strResponsexml, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline))

                                Dim xRoot As XmlRootAttribute = New XmlRootAttribute()
                                xRoot.ElementName = "RetrievalServiceResponse"
                                xRoot.IsNullable = True
                                Dim xmlSSPResponseDeSer As XmlSerializer = New XmlSerializer(GetType(RetrievedChildAccountByParent.RetrievalServiceResponse), xRoot)
                                objRetrieveChildAccountforParent_SSPPA = CType(xmlSSPResponseDeSer.Deserialize(New StringReader(strResponsexml)), RetrievedChildAccountByParent.RetrievalServiceResponse)



                                If Not objRetrieveChildAccountforParent_SSPPA Is Nothing Then

                                    If Not objRetrieveChildAccountforParent_SSPPA.RetrievalAccepted Is Nothing Then
                                        If Not objRetrieveChildAccountforParent_SSPPA.RetrievalAccepted Is Nothing Then
                                            For Each objRetrievedChildInfo In objRetrieveChildAccountforParent_SSPPA.RetrievalAccepted(0)(0).ChildAccount
                                                objAcctList = New SBMAcctList
                                                objAcctList.strAcctNum = objRetrievedChildInfo.visionCustomerId + objRetrievedChildInfo.visionAccountId
                                                objAcctList.strBTNNum = objSSPRqst.strAcctNum
                                                If Not objAcctList.strAcctNum.Trim() = strAcctNum.Trim Then
                                                    If objRetrievedChildInfo.termDate.Trim() = "9999-12-31" Or objRetrievedChildInfo.termDate.Trim() = "12/31/9999" Then
                                                        objSBMList.arrLstAcctList.Add(objAcctList)
                                                    End If
                                                End If
                                            Next
                                            Return objSBMList
                                        Else
                                            objSBMList.RequestStatus.strMessageId = objRetrieveChildAccountforParent_SSPPA.ResponseInfo(0).Code.Trim()
                                            objSBMList.RequestStatus.strMessageDescription = objRetrieveChildAccountforParent_SSPPA.ResponseInfo(0).Description.Trim()
                                            Return objSBMList
                                        End If
                                    Else
                                        objSBMList.RequestStatus.strMessageId = objRetrieveChildAccountforParent_SSPPA.ResponseInfo(0).Code.Trim()
                                        objSBMList.RequestStatus.strMessageDescription = objRetrieveChildAccountforParent_SSPPA.ResponseInfo(0).Description.Trim()
                                        Return objSBMList
                                    End If
                                Else
                                    objSBMList.RequestStatus.strMessageId = "100"
                                    objSBMList.RequestStatus.strMessageDescription = "Empty Multi BBAND Returned"
                                    Return objSBMList
                                End If
                                   
                            Case "M", "E"

                                Dim objGetMultiBroadbandBillingOneLECResponse As UCSRNACR.GetMultiBroadbandBillingOneLECResponse = New UCSRNACR.GetMultiBroadbandBillingOneLECResponse()
                                Dim objGetChildAccountByParentCANRequest As UCSRNACR.GetChildAccountByParentCANRequest = New UCSRNACR.GetChildAccountByParentCANRequest
                                Dim objResultsBBOneLEC As UCSRNACR.ResultsBBOneLEC
                                'Dim objUCSRAccess As UCSRAccess = New UCSRAccess(objSSPRqst.strRegionId)
                                objGetMultiBroadbandBillingOneLECResponse = objUCSRAccess.GetMultiBroadbandBillingOneLEC(objSSPRqst.strAcctNum, objSSPRqst.strEastWestInd, "RMW", objSSPRqst.strRegionId.Trim())
                                If Not objGetMultiBroadbandBillingOneLECResponse Is Nothing Then
                                    If objGetMultiBroadbandBillingOneLECResponse.message.messageText.Trim() = "NO ERRORS" Then
                                        For Each objResultsBBOneLEC In objGetMultiBroadbandBillingOneLECResponse.results
                                            objAcctList = New SBMAcctList
                                            objAcctList.strAcctNum = objResultsBBOneLEC.Value
                                            objAcctList.strBTNNum = objSSPRqst.strAcctNum
                                            'If Not objAcctList.strAcctNum.Trim = strAcctNum.Trim Then
                                            If (objResultsBBOneLEC.BROADBANDTermDate = "99991231" Or objResultsBBOneLEC.BROADBANDTermDate = "") Then
                                                objSBMList.arrLstAcctList.Add(objAcctList) 'S7360506	

                                            End If

                                            'End If
                                        Next
                                        If objSBMList.arrLstAcctList.Count = 0 Then
                                            objSBMList.RequestStatus.strMessageId = "100"
                                            objSBMList.RequestStatus.strMessageDescription = "BROADBAND is Termed"

                                        End If

                                        Return objSBMList
                                    Else
                                        objSBMList.RequestStatus.strMessageId = "100"
                                        objSBMList.RequestStatus.strMessageDescription = objGetMultiBroadbandBillingOneLECResponse.message.messageText.Trim()
                                        Return objSBMList
                                    End If
                                Else
                                    objSBMList.RequestStatus.strMessageId = "100"
                                    objSBMList.RequestStatus.strMessageDescription = "Empty Multi BBAND Returned"
                                    Return objSBMList

                                End If

                        End Select

                End Select
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-getAcctsForSBM-GARA2R", ex.ToString())
                objSBMList.RequestStatus.strMessageId = "100"
                objSBMList.RequestStatus.strMessageDescription = ex.ToString()
                Return objSBMList
            End Try
            '**************************************************************
            'WR98048 iCollect Enhancement to Get COS from CA,skip the below logic by passing invalid region for MDVW - 20NOV2015
            If strRegionId.Trim() = "MDVW_1" Then
                objSBMList = getAcctsForSBM_MDVW(strRegionId, strAcctNum)

            Else
                Try
                    Dim reqObj As ERARequest = New ERARequest
                    Dim resObj As ERAResponse
                    Dim DB2DT As DataTable
                    Dim DB2DR As DataRow
                    Dim strInpValue As String
                    'Dim objAcctList As SBMAcctList

                    If MyBase.WSDataAccessObj.usp_GetControlParmByName("Control" & MyBase.RegionId.Trim, "DUMMYSBM").ToUpper.Trim = "TRUE" Then
                        Dim dsDummySBM As DataSet = getDummySBMDetails(MyBase.RegionId, strAcctNum)
                        Dim dtDummy As DataTable
                        Dim drDummy As DataRow

                        If MyBase.WSDataAccessObj.IsEmptyRecordSet(dsDummySBM) Then
                            objSBMList.RequestStatus.strMessageId = "100"
                            objSBMList.RequestStatus.strMessageDescription = "AcctNum is not an SBM Acct."
                            Return objSBMList

                        End If
                        'For Each dtDummy In dsDummySBM.Tables
                        For i As Integer = 0 To dsDummySBM.Tables.Count - 1
                            dtDummy = dsDummySBM.Tables(i)
                            'For Each drDummy In dtDummy.Rows
                            For j As Integer = 0 To dtDummy.Rows.Count - 1
                                drDummy = dtDummy.Rows(j)
                                objAcctList = New SBMAcctList
                                objAcctList.strAcctNum = drDummy("strSubAcctNum")
                                objAcctList.strBTNNum = drDummy("strBTNNum")
                                If Not objAcctList.strAcctNum.Trim = strAcctNum.Trim Then
                                    objSBMList.arrLstAcctList.Add(objAcctList)
                                End If
                            Next j
                        Next i

                        Return objSBMList
                    End If

                    'WR22845 - ARBOR
                    If (strRegionId.Trim() = "WEST") Then
                        Dim dsSBM As DataSet = getSBMDetailsArbor(MyBase.RegionId, strAcctNum)
                        Dim dtSBM As DataTable
                        Dim drSBM As DataRow

                        If MyBase.WSDataAccessObj.IsEmptyRecordSet(dsSBM) Then
                            objSBMList.RequestStatus.strMessageId = "100"
                            objSBMList.RequestStatus.strMessageDescription = "AcctNum is not an SBM Acct."
                            'Return objSBMList ' we decide that it is nonArbor. so BAU.
                        Else
                            Dim strOrg As String = dsSBM.Tables(0).Rows(0).Item("strOrgCode")
                            Dim strEnviorMent As String = dsSBM.Tables(0).Rows(0).Item("strEnviorMent")

                            'WR98048 iCollect Enhancement to Get COS from CA.
                            'If ((strRegionId.Trim() = "WEST") And (strEnviorMent.StartsWith("tARBR"))) Then
                            If strRegionId.Trim() = "WEST" Then
                                'For Each dtSBM In dsSBM.Tables
                                For i As Integer = 0 To dsSBM.Tables.Count - 1
                                    dtSBM = dsSBM.Tables(i)
                                    'For Each drSBM In dtSBM.Rows
                                    For j As Integer = 0 To dtSBM.Rows.Count - 1
                                        drSBM = dtSBM.Rows(j)
                                        objAcctList = New SBMAcctList
                                        objAcctList.strAcctNum = drSBM("strAcctNumber")
                                        'objAcctList.strBTNNum = drSBM("strMasterAccount") 'Source TN to BTNNum
                                        objAcctList.strBTNNum = drSBM("strTelephoneNum")
                                        objAcctList.strClassOfService = drSBM("strClassOfService")
                                        If Not objAcctList.strAcctNum.Trim = strAcctNum.Trim Then
                                            objSBMList.arrLstAcctList.Add(objAcctList)
                                        End If
                                    Next j
                                Next i
                                Return objSBMList
                            End If
                        End If
                    End If

                    'WR22720 - NPD
                    If (strRegionId.Trim().ToUpper() = "NPD" Or strRegionId.Trim().ToUpper() = "NY" Or strRegionId.Trim().ToUpper() = "NE" Or strRegionId.Trim().ToUpper() = "MDVW" Or strRegionId.Trim().ToUpper() = "VISION") Then
                        Dim strSBMType = "SBMNPD"
                        Dim dsSBM As DataSet
                        Dim dtSBM As DataTable
                        Dim drSBM As DataRow

                        If strRegionId = "VISION" Then
                            strSBMType = "VISN"
                        End If

                        If strRegionId = "NY" Then
                            strSBMType = "SBMNY"
                        End If
                        If strRegionId = "NE" Then
                            strSBMType = "SBMNE"
                        End If

                        If strRegionId = "MDVW" Then
                            strSBMType = "SBMMDVW"
                        End If

                        dsSBM = getSBMDetailsNPDNYNE(MyBase.RegionId, strAcctNum, strSBMType)


                        If MyBase.WSDataAccessObj.IsEmptyRecordSet(dsSBM) Then
                            objSBMList.RequestStatus.strMessageId = "100"
                            objSBMList.RequestStatus.strMessageDescription = "AcctNum is not an SBM Acct."

                        Else
                            'For Each dtSBM In dsSBM.Tables
                            For i As Integer = 0 To dsSBM.Tables.Count - 1
                                dtSBM = dsSBM.Tables(i)
                                'For Each drSBM In dtSBM.Rows
                                For j As Integer = 0 To dtSBM.Rows.Count - 1
                                    drSBM = dtSBM.Rows(j)
                                    objAcctList = New SBMAcctList
                                    objAcctList.strAcctNum = drSBM("strAcctNumber")
                                    objAcctList.strBTNNum = drSBM("strMasterAccount")
                                    objAcctList.strClassOfService = drSBM("strClassOfService")

                                    If Not objAcctList.strAcctNum.Trim = strAcctNum.Trim Then
                                        objSBMList.arrLstAcctList.Add(objAcctList)
                                    End If
                                Next j
                            Next i

                        End If
                        Return objSBMList
                    End If

                    Select Case True

                        Case strRegionId Is Nothing Or strRegionId.Trim = ""
                            objSBMList.RequestStatus.strMessageId = "INVRGNID"
                            objSBMList.RequestStatus.strMessageDescription = "Invalid Region Id passed."
                            Return objSBMList
                        Case strAcctNum Is Nothing Or strAcctNum.Trim = ""
                            objSBMList.RequestStatus.strMessageId = "INVACNBR"
                            objSBMList.RequestStatus.strMessageDescription = "Invalid Account Number passed as Input."
                            Return objSBMList
                    End Select

                    reqObj.strAcctNum = strAcctNum
                    reqObj.strERAName = "CBSPTRA1"
                    reqObj.strExtInput = " "
                    reqObj.strInpTyp = "1"
                    reqObj.strReqType = "00"
                    reqObj.strRegionId = strRegionId
                    reqObj.strFmtType = "1"
                    reqObj.strStartInstance = "0"

                    reqObj.intGetNum = 150

                    Dim obj As BrokerDB2Data = New BrokerDB2Data(reqObj)
                    resObj = obj.ERADB2Connect()




                    Select Case True

                        Case Not resObj.intSQLRC = 0
                            objSBMList.RequestStatus.strMessageId = resObj.intSQLRC.ToString
                            objSBMList.RequestStatus.strMessageDescription = resObj.strMsgText
                            Return objSBMList
                        Case Not resObj.strMsgCode.Trim = "I01"
                            objSBMList.RequestStatus.strMessageId = resObj.strMsgCode
                            objSBMList.RequestStatus.strMessageDescription = resObj.strMsgText
                            Return objSBMList
                        Case resObj.intSQLRC = 100
                            objSBMList.RequestStatus.strMessageId = resObj.intSQLRC.ToString
                            objSBMList.RequestStatus.strMessageDescription = resObj.strMsgText
                            Return objSBMList
                        Case MyBase.WSDataAccessObj.IsEmptyRecordSet(resObj.DB2DS)
                            objSBMList.RequestStatus.strMessageId = "100"
                            objSBMList.RequestStatus.strMessageDescription = "No Matching Record Found in CBSS"
                            Return objSBMList
                    End Select


                    Dim xmlDoc As XmlDocument
                    Dim xmlEle As XmlElement


                    'For Each DB2DT In resObj.DB2DS.Tables
                    'For Each DB2DR In DB2DT.Rows
                    For i As Integer = 0 To resObj.DB2DS.Tables.Count - 1
                        DB2DT = resObj.DB2DS.Tables(i)
                        'For Each DB2DR In DB2DT.Rows
                        For j As Integer = 0 To DB2DT.Rows.Count - 1
                            DB2DR = DB2DT.Rows(j)
                            strInpValue = DB2DR(2)

                            xmlDoc = New XmlDocument
                            xmlDoc.XmlResolver = Nothing
                            xmlDoc.LoadXml(strInpValue)
                            xmlEle = xmlDoc.DocumentElement
                            objAcctList = New SBMAcctList
                            objAcctList.strAcctNum = xmlEle.GetElementsByTagName("AccountNumber").Item(0).InnerXml()
                            objAcctList.strBTNNum = xmlEle.GetElementsByTagName("AccountTelephoneNumber").Item(0).InnerXml()

                            If Not objAcctList.strAcctNum.Trim = strAcctNum.Trim Then
                                objSBMList.arrLstAcctList.Add(objAcctList)
                            End If
                        Next j
                    Next i


                Catch ex As Exception

                    LogErrorFile.WriteLog("RMICWWS-CBSPTRA1", "AcctNum: " & strAcctNum & " Erroring Out " & ex.ToString)
                    objSBMList.RequestStatus.strMessageId = "RMIEXPTN"
                    objSBMList.RequestStatus.strMessageDescription = ex.ToString

                End Try
            End If


            Return objSBMList
        End Function


        Public Function getDummySBMDetails(ByVal strRegionId As String, ByVal strAcctNum As String) As DataSet

            Dim ds As DataSet = New DataSet
            Try
                Dim objDummyDA As WSDummyDataAccess = New WSDummyDataAccess
                ds = objDummyDA.usp_GetSBMRelation(strRegionId, strAcctNum)

            Catch ex As Exception
                LogErrorFile.WriteLog("WSDummy", ex.ToString)
            End Try

            Return ds
        End Function

        Public Function getSBMDetailsArbor(ByVal strRegionId As String, ByVal strAcctNum As String) As DataSet

            Dim ds As DataSet = New DataSet
            Try

                Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(strRegionId.Trim())
                ds = ObjDataAccess.usp_GetSBMRelationShip(strRegionId, "GETSBM", strAcctNum, "", "")

            Catch ex As Exception
                LogErrorFile.WriteLog("WSDummy", ex.ToString)
            End Try

            Return ds
        End Function

        Public Function usp_GetCustomerAddressInfo(ByVal strRegionId As String, ByVal strAcctNum As String) As DataSet

            Dim ds As DataSet = New DataSet
            Try

                Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(strRegionId.Trim())
                ds = ObjDataAccess.usp_GetCustomerAddressInfo(strRegionId, strAcctNum)

            Catch ex As Exception
                LogErrorFile.WriteLog("usp_GetCustomerAddressInfo", ex.ToString)
            End Try

            Return ds
        End Function


        Public Function getSBMDetailsNPDNYNE(ByVal strRegionId As String, ByVal strAcctNum As String, ByVal strType As String) As DataSet

            Dim ds As DataSet = New DataSet
            Try

                Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(strRegionId.Trim())
                ds = ObjDataAccess.usp_GetSBMRelationShip(strRegionId, strType, strAcctNum, "", "")

            Catch ex As Exception
                LogErrorFile.WriteLog("getSBMDetailsNPD", ex.ToString)
            End Try

            Return ds
        End Function

        Public Function getAcctsForSBM_MDVW(ByVal strRegionId As String, ByVal strAcctNum As String) As SummaryBillDetails

            Dim objSBMList As SummaryBillDetails = New SummaryBillDetails
            Dim resObj As SP06Response = New SP06Response
            Dim strEnv As String = ""

            Try

                Dim reqObj As SP06Request = New SP06Request
                Dim DB2DT As DataTable
                Dim DB2DR As DataRow
                Dim strInpValue As String
                Dim objAcctList As SBMAcctList = New SBMAcctList

                If MyBase.WSDataAccessObj.usp_GetControlParmByName("Control" & MyBase.RegionId.Trim, "DUMMYSBM").ToUpper.Trim = "TRUE" Then
                    Dim dsDummySBM As DataSet = getDummySBMDetails(MyBase.RegionId, strAcctNum)
                    Dim dtDummy As DataTable
                    Dim drDummy As DataRow

                    If MyBase.WSDataAccessObj.IsEmptyRecordSet(dsDummySBM) Then
                        objSBMList.RequestStatus.strMessageId = "100"
                        objSBMList.RequestStatus.strMessageDescription = "AcctNum is not an SBM Acct."
                        Return objSBMList

                    End If
                    'For Each dtDummy In dsDummySBM.Tables
                    For i As Integer = 0 To dsDummySBM.Tables.Count - 1
                        dtDummy = dsDummySBM.Tables(i)
                        'For Each drDummy In dtDummy.Rows
                        For j As Integer = 0 To dtDummy.Rows.Count - 1
                            drDummy = dtDummy.Rows(j)
                            objAcctList = New SBMAcctList
                            objAcctList.strAcctNum = drDummy("strSubAcctNum")
                            objAcctList.strBTNNum = drDummy("strBTNNum")
                            If Not objAcctList.strAcctNum.Trim = strAcctNum.Trim Then
                                objSBMList.arrLstAcctList.Add(objAcctList)
                            End If
                        Next j
                    Next i

                    Return objSBMList
                End If

                Select Case True

                    Case strRegionId Is Nothing Or strRegionId.Trim = ""
                        objSBMList.RequestStatus.strMessageId = "INVRGNID"
                        objSBMList.RequestStatus.strMessageDescription = "Invalid Region Id passed."
                        Return objSBMList
                    Case strAcctNum Is Nothing Or strAcctNum.Trim = ""
                        objSBMList.RequestStatus.strMessageId = "INVACNBR"
                        objSBMList.RequestStatus.strMessageDescription = "Invalid Account Number passed as Input."
                        Return objSBMList
                End Select



                reqObj.strAcctNum = strAcctNum
                reqObj.strERAName = "XCO_XBCLSP06"
                reqObj.strRegionId = strRegionId
                reqObj.In_REQ_Read_Ind = 1
                reqObj.strAcctNum = String.Format("{0:000000000}", CType(reqObj.strAcctNum, Integer))
                reqObj.In_REQ_BLACT_F = reqObj.strAcctNum

                reqObj.In_REQ_BEG_EFF_D = "9999-12-31"


                Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric
                Dim objEnvDS As DataSet


                objEnvDS = MyBase.WSDataAccessObj.usp_GetCustomerAddressInfo(reqObj.strRegionId, reqObj.strAcctNum)

                If Not (MyBase.WSDataAccessObj.IsEmptyRecordSet(objEnvDS)) Then
                    strEnv = objEnvDS.Tables(0).Rows(0)("strEnv")

                End If



                Dim obj As BrokerSP06DB2Data = New BrokerSP06DB2Data(reqObj)

                resObj = obj.SP06DB2Connect(strEnv.Trim(), "MDVW")




                Select Case True


                    Case Not resObj.Out_RES_Return_Code = 0
                        objSBMList.RequestStatus.strMessageId = resObj.Out_RES_SQLCode.ToString
                        objSBMList.RequestStatus.strMessageDescription = resObj.Out_RES_Error_Msg
                        Return objSBMList
                    Case resObj.Out_RES_SQLCode = 101
                        objSBMList.RequestStatus.strMessageId = "101"
                        objSBMList.RequestStatus.strMessageDescription = resObj.Out_RES_Error_Msg
                        Return objSBMList
                    Case resObj.Out_RES_SQLCode = 100
                        objSBMList.RequestStatus.strMessageId = "100"
                        objSBMList.RequestStatus.strMessageDescription = resObj.Out_RES_Error_Msg
                        Return objSBMList
                    Case MyBase.WSDataAccessObj.IsEmptyRecordSet(resObj.DB2DS)
                        objSBMList.RequestStatus.strMessageId = "100"
                        objSBMList.RequestStatus.strMessageDescription = "No Matching Record Found in EXPRESS"
                        Return objSBMList
                End Select


                Dim arrLst As ArrayList = New ArrayList
                Dim objCommon As CommonFunctions = New CommonFunctions
                'Dim objSTRAOrder As STRA_Order_Output = New STRA_Order_Output
                'Dim objSTRAOrderDetails As STRAOrderDetails

                'If Not MyBase.WSDataAccessObj.IsEmptyRecordSet(resObj.DB2DS) Then
                '    resObj.DB2DS.DataSetName = "AccountDetails"
                '    resObj.DB2DS.Tables(0).TableName = "RECORD"
                '    Dim strXMLData = resObj.DB2DS.GetXml()
                '    resObj.DB2DS = MyBase.WSDataAccessObj.USP_GetClassOfService(strXMLData)
                'End If

                'For Each DB2DT In resObj.DB2DS.Tables
                For i As Integer = 0 To resObj.DB2DS.Tables.Count - 1
                    DB2DT = resObj.DB2DS.Tables(i)
                    'For Each DB2DR In DB2DT.Rows
                    For j As Integer = 0 To DB2DT.Rows.Count - 1
                        DB2DR = DB2DT.Rows(j)
                        strInpValue = DB2DR(2)

                        objAcctList = New SBMAcctList
                        objAcctList.strBTNNum = DB2DR("PNT_DAG_ACCT_ID")
                        objAcctList.strAcctNum = DB2DR("CHLD_DAG_ACCT_ID")
                        'objAcctList.strClassOfService = DB2DR("CLASS_OF_SERVICE")
                        Dim intFrmt As Integer
                        intFrmt = CType(objAcctList.strAcctNum, Integer)
                        objAcctList.strAcctNum = String.Format("{0:000000000}", intFrmt)

                        If Not objAcctList.strAcctNum.Trim = strAcctNum.Trim Then
                            objSBMList.arrLstAcctList.Add(objAcctList)
                        End If
                    Next j
                Next i


            Catch ex As Exception

                LogErrorFile.WriteLog("RMICWWS-CBSPTRA1", "AcctNum: " & strAcctNum & " Erroring Out " & ex.ToString)
                objSBMList.RequestStatus.strMessageId = "RMIEXPTN"
                objSBMList.RequestStatus.strMessageDescription = ex.ToString

            End Try


            Return objSBMList
        End Function

    End Class

    Public Class clsGenericSort
        Implements IComparer
        Dim intCompareType As Integer


        Public Function Compare(ByVal x As Object, ByVal y As Object) As Integer Implements System.Collections.IComparer.Compare
            Compare = CType(x, LineLevelInfo).strTelephoneNo < CType(y, LineLevelInfo).strTelephoneNo

        End Function
    End Class

End Namespace
