Option Strict Off
Option Explicit On
Imports System
Imports System.Net
Imports System.Collections
Imports System.Text
Imports System.Security.Cryptography.X509Certificates
Imports System.Security
Imports System.IO
Imports CommonLibrary
Imports System.Xml.Serialization
Imports System.Xml
Namespace Verizon.RMICW.WebServices
    Partial Public Class ArborWebservices
        Public Function PostArborValues(ByVal stracctnum As String) As ARBOR_TRX_RESPONSE
            Dim strParmValue As String
            Dim strCertPath(0) As String
            Dim strResponseXml As String = ""
            Dim strRequestUri, strRequestXml As String
            Dim strXML As String = ""
            Dim arrValArr As Array
            Dim objRes As New ARBOR_TRX_RESPONSE
            Dim ds As New DataSet
            Dim strMethodtocall As String = "GTEAB_GetAcctSummary"
            Try

                strParmValue = GetParmValues("WEST")
                arrValArr = Split(strParmValue, ";")
                strRequestUri = arrValArr(0)
                strRequestXml = strXML
                strCertPath(0) = arrValArr(3)
                strRequestXml = "<ARBOR_TRX xmlns:xsd=\'http://www.w3.org/2001/XMLSchema\' xmlns:xsi=\'http://www.w3.org/2001/XMLSchema-instance\' TYPE=\'single\'  TRX_ID=\'ABCD\'><Request msg_num=\'700\' action=\'" + strMethodtocall + "\' seq_no=\'0\'><userid>" + arrValArr(1) + "</userid><password>" + arrValArr(2) + "</password><arc_version>2.0 Wed Aug 13 10:50:15 EDT 1997</arc_version><external_account_no>" + stracctnum + "</external_account_no><external_account_no_type>1</external_account_no_type></Request></ARBOR_TRX>"
                strRequestXml = strRequestXml.Replace("\", "")
                strResponseXml = GetResponse(strRequestUri, strRequestXml, strCertPath)
                strResponseXml = System.Web.HttpUtility.UrlDecode(strResponseXml)
                strResponseXml = strResponseXml.Replace("\", "'")


                Dim xmlSSPResponseDeSer As XmlSerializer = New XmlSerializer(GetType(ARBOR_TRX_RESPONSE))
                objRes = CType(xmlSSPResponseDeSer.Deserialize(New StringReader(strResponseXml)), ARBOR_TRX_RESPONSE)
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS - Get_Arbor_BalanceInfo", ex.ToString())
            End Try
            Return objRes
        End Function
      
        Public Function GetParmValues(ByVal strRegionID As String) As String

            Dim strParmName As String = "ATMARBORURL"
            Dim strURL As String = ""
            Dim strCntl As String = "Control" + strRegionID

            Dim WSDataAccessObj As WSDataAccessGeneric = New WSDataAccessGeneric(strRegionID)
            Try
                strURL = WSDataAccessObj.usp_GetControlParmByName(strCntl, strParmName)
            Catch ex As Exception
            End Try
            Return strURL
        End Function
        Public Function GetResponse(ByVal strRequestUri As String, ByVal strRequestXml As String, ByVal CertifatePath As String()) As String
            Dim HRequest As HttpWebRequest = Nothing
            Dim strResponse As String = ""
            Dim strCerPath As String
            Try
                HRequest = CType(WebRequest.Create(strRequestUri), HttpWebRequest)
                HRequest.Headers.Add("HTTP_Referer", "www.Verizon.com")
                HRequest.KeepAlive = False
                HRequest.Method = "POST"
                HRequest.ContentType = "application/x-www-form-urlencoded"
                HRequest.ContentLength = strRequestXml.Length
                HRequest.Timeout = 9999999
                HRequest.ConnectionGroupName = Guid.NewGuid.ToString()

                Dim i As Integer

                If (Not IsNothing(CertifatePath)) And CertifatePath.Length > 0 Then
                    For i = 0 To CertifatePath.Length - 1
                        strCerPath = CertifatePath(i)
                        HRequest.ClientCertificates.Add(System.Security.Cryptography.X509Certificates.X509Certificate.CreateFromCertFile(strCerPath))
                    Next
                    ServicePointManager.ServerCertificateValidationCallback = New Net.Security.RemoteCertificateValidationCallback(AddressOf ArborPolicy.ValidateServerCertificate)
                End If

                Dim Swriter As New StreamWriter(HRequest.GetRequestStream())

                With (Swriter)
                    Swriter.Write(strRequestXml)
                    Swriter.Flush()
                    Swriter.Close()
                End With

                Dim Wresponse As WebResponse = HRequest.GetResponse()

                With (Wresponse)
                    Dim Sreader As New StreamReader(Wresponse.GetResponseStream())
                    With (Sreader)
                        strResponse = Sreader.ReadToEnd()
                        Sreader.Close()
                    End With

                End With
            Catch ex As Exception
                If (Not IsNothing(HRequest)) Then
                    HRequest = Nothing
                    Throw ex
                End If
            Finally

            End Try
            Return strResponse
        End Function
    End Class

    Public Class ArborPolicy
        Implements ICertificatePolicy
        Public Function CheckValidationResult(ByVal srvPoint As System.Net.ServicePoint, ByVal certificate As System.Security.Cryptography.X509Certificates.X509Certificate, ByVal request As System.Net.WebRequest, ByVal certificateProblem As Integer) As Boolean 'Implements System.Net.ICertificatePolicy.CheckValidationResult
            Return True  ' Return True to force the certificate to be accepted.
        End Function

        Public Shared Function ValidateServerCertificate(ByVal sender As Object, ByVal certificate As X509Certificate, ByVal chain As X509Chain, ByVal sslPolicyErrors As Net.Security.SslPolicyErrors) As Boolean
            Return True
        End Function
    End Class

    Public Class ARBOR_TRX
        Public Request() As ARBOR_TRXRequest
        <System.Xml.Serialization.XmlAttributeAttribute()> _
         Public TYPE As String
        <System.Xml.Serialization.XmlAttributeAttribute()> _
        Public TRX_ID As String
    End Class
    Public Class ARBOR_TRXRequest
        Public userid As String
        Public password As String
        Public arc_version As String
        Public external_account_no As String
        Public external_account_no_type As String
        <System.Xml.Serialization.XmlAttributeAttribute()> _
         Public msg_num As String
        <System.Xml.Serialization.XmlAttributeAttribute()> _
        Public action As String
        <System.Xml.Serialization.XmlAttributeAttribute()> _
        Public seq_no As String
    End Class
    Public Class NewDataSet
        Public Items() As ARBOR_TRX
    End Class

    Public Class ARBOR_TRX_RESPONSE
        <System.Xml.Serialization.XmlElementAttribute("Response")> _
    Public Response() As ARBOR_TRX_RESPONSEResponse
        <System.Xml.Serialization.XmlAttributeAttribute()> _
        Public TRX_ID As String
        <System.Xml.Serialization.XmlAttributeAttribute()> _
   Public Status As String
    End Class
    Public Class ARBOR_TRX_RESPONSEResponse_old
        Public last_payment_received_amount As String
        Public wg_account_balance As String
        Public account_balance As String
        Public net_new_charges As String
        Public payment_due_date As String
        Public payment_method As String
        Public external_account_no As String
        Public msg_text As String
        Public msg_num As String
        <System.Xml.Serialization.XmlAttributeAttribute()> _
        Public seq_no As String
    End Class

    Public Class ARBOR_TRX_RESPONSEResponse
        Public acct_real_time_bal As String
        Public acct_total_paid As String
        Public acct_net_new_charges As String
        Public acct_curr_bal As String
        Public acct_prev_bill As String
        Public acct_billing_status As String
        Public avg_days_to_pay As String
        Public mkt_code As String
        Public acct_bill_freq As String
        Public acct_credit_rating As String
        Public acct_no_bill As String
        Public acct_bill_fmt As String
        Public acct_bill_disp_meth As String
        Public acct_category As String
        Public acct_bill_geocode As String
        Public acct_bill_country_code As String
        Public acct_bill_state As String
        Public acct_bill_zip As String
        Public acct_bill_county As String
        Public acct_bill_city As String
        Public acct_bill_address1 As String
        Public acct_bill_lname As String
        Public acct_bill_fname As String
        Public acct_date_active As String
        Public external_account_no_type As String
        Public external_account_no As String
        Public msg_text As String
        Public msg_num As String
        <System.Xml.Serialization.XmlAttributeAttribute()> _
              Public seq_no As String
    End Class


    Public Class NewDataSet1
        <System.Xml.Serialization.XmlElementAttribute("ARBOR_TRX_RESPONSE")> _
        Public Items() As ARBOR_TRX_RESPONSE
    End Class
End Namespace