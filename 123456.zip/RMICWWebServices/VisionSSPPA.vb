﻿Option Strict Off
Option Explicit On
Imports System.Web.Services
Imports CommonLibrary
Imports System.Xml
Imports System.Xml.Serialization
Imports System.IO
Imports System.Globalization
Imports System.Net
Imports System.Text.RegularExpressions
Imports Microsoft.Web.Services2.Security
Imports Microsoft.Web.Services2
Imports Microsoft.Web.Services2.Dime
Imports System.Web.Services.Protocols
Imports System.Diagnostics
Imports System.Threading
Imports System.ServiceModel
Imports Microsoft.Web.Services2.Security.Tokens
Imports Verizon.RMICW.WebServices


Public Class VisionSSPPA
#Region "PPV [Pay Per View webmethod - NCOG "
    <WebMethod(Description:="PPV webmethod from SSPPA")> _
    Public Function getPPVInfo(ByVal strAcctNum As String, ByVal intRequestid As Integer, ByVal strPPVServiceType As String) As XmlDataDocument
        Dim posturl As String = ""
        Dim xmliFinalDoc As XmlDocument = New XmlDocument
        Dim strUrl As String
        Dim strOutput As String = ""
        Dim strInputXml As String = ""
        'Dim MyEnumVal As getVZFullProfileRequest.stateTypeNcog
        Dim sw As New StringWriter
        Dim strRegionCd As String = "VISION"
        Dim xmlDoc As XmlDataDocument
        xmlDoc = New XmlDataDocument
        Try

            If strAcctNum.Trim().Length() <> 13 Then
                strOutput = "<getPPVInfo>" + strAcctNum + "  IS NOT VALID " + "</getPPVInfo>"
                xmlDoc.XmlResolver = Nothing
                xmlDoc.LoadXml(System.Text.RegularExpressions.Regex.Replace(strOutput, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline)))
                Return xmlDoc
            End If
            'If strRegionCd.ToUpper.Trim() = "WEST" Then
            '    strUrl = "HTTP://SACS1LRCW01.ITUTL1.ITCENT.EBIZ.VERIZON.COM/MARJUNSEPDEC/NCOGWEBSERVICES.ASMX"
            'Else
            '    strUrl = "HTTP://SACU1LRFCW01.ITUTL1.ITCENT.EBIZ.VERIZON.COM/MARJUNSEPDEC/NCOGWEBSERVICES.ASMX"
            'End If
            Dim ObjDataAccess As WSDataAccessGeneric = New WSDataAccessGeneric(strRegionCd.Trim())
            strUrl = ObjDataAccess.usp_GetControlParmByName("Control" + strRegionCd.Trim(), "SSPPA")
            'strUrl = "http://SACD1LRONA02.ITUTL1.ITCENT.EBIZ.VERIZON.COM/MarJunSepDec/NCOGWebServices.asmx"

            Dim objSSPPA As New SSPPA.NCOGWebServices
            objSSPPA.Url = strUrl
            Dim RequestContext As SoapContext
            RequestContext = objSSPPA.RequestSoapContext
            objSSPPA.Proxy = New WebProxy
            RequestContext.Security.Tokens.Clear()

            Dim userToken As UsernameToken = New UsernameToken("" + "RMW" + "", "" + "rmicw05" + "", PasswordOption.SendPlainText)
            RequestContext.Security.Tokens.Add(userToken)
            RequestContext.Security.MustUnderstand = False

            objSSPPA.Timeout = 90000
            objSSPPA.RequestSoapContext.Addressing.MustUnderstand = False
            Dim Objinp

            If (strPPVServiceType.ToUpper.ToString().Trim = "PPVEVENTS") Then
                Objinp = New getPPVInfoRequest
                Objinp.PPVService.PPVEvents = Nothing
            ElseIf (strPPVServiceType.ToUpper.ToString().Trim = "RBALEVENTS") Then
                Objinp = New getRemainingBalanceInfoRequest
            ElseIf (strPPVServiceType.ToUpper.ToString().Trim = "UNBILLEVENTS") Then
                Objinp = New getUnBilledInfoRequest
            ElseIf (strPPVServiceType.ToUpper.ToString().Trim = "BILLED") Then
                Objinp = New getPPVInfoRequest
                Objinp.PPVService.PPVEvents = Nothing
            ElseIf (strPPVServiceType.ToUpper.ToString().Trim = "ALLEVENTS") Then
                Objinp = New getPPVInfoRequest
                Objinp.PPVService.PPVEvents = Nothing
            End If

            Objinp.HeaderInfo.requestHeaderInfo.applicationName = "RMICW"
            Objinp.HeaderInfo.requestHeaderInfo.applicationId = "RMW"
            Objinp.HeaderInfo.requestHeaderInfo.ClientMachineName = System.Environment.MachineName
            Objinp.HeaderInfo.requestHeaderInfo.RepLoginCode = "RMICW"
            Objinp.HeaderInfo.requestHeaderInfo.AppServerName = System.Environment.MachineName
            Objinp.HeaderInfo.requestHeaderInfo.AppServerTimeStamp = Now().ToString("MM/dd/yyyy hh:mm:ss EST")
            Objinp.HeaderInfo.requestHeaderInfo.TrackingNumber = intRequestid



            If (strPPVServiceType.ToUpper.ToString().Trim = "PPVEVENTS") Then


                Objinp.PPVService.GetVisionPPVInfo.VisionCustomerId = strAcctNum.Substring(0, 9)
                Objinp.PPVService.GetVisionPPVInfo.VisionAccountId = strAcctNum.Substring(9, 4)
                Objinp.PPVService.GetVisionPPVInfo.RequestType = VISIONPPVRequestType.BILLED

                'Objinp.PPVService.PPVEvents.inputValue = strAcctNum
                'Objinp.PPVService.PPVEvents.requestType = "BILLED"
                'Objinp.PPVService.PPVEvents.region = strRegionCd
                'Objinp.PPVService.PPVEvents.inputTypeIndicator = inputTypeIndicatorType.BROADBAND
                'Objinp.PPVService.PPVEvents.requestType = "BILLED"
            ElseIf (strPPVServiceType.ToUpper.ToString().Trim = "BILLED") Then


                Objinp.PPVService.GetVisionPPVInfo.VisionCustomerId = strAcctNum.Substring(0, 9)
                Objinp.PPVService.GetVisionPPVInfo.VisionAccountId = strAcctNum.Substring(9, 4)
                Objinp.PPVService.GetVisionPPVInfo.RequestType = VISIONPPVRequestType.BILLED


            ElseIf (strPPVServiceType.ToUpper.ToString().Trim = "RBALEVENTS") Then
                Objinp.PPVService.GetVisionPPVInfo.VisionCustomerId = strAcctNum.Substring(0, 9)
                Objinp.PPVService.GetVisionPPVInfo.VisionAccountId = strAcctNum.Substring(9, 4)
                Objinp.PPVService.GetVisionPPVInfo.RequestType = VISIONPPVRequestType.VIEWED

                'Objinp.PPVService.RemainingBalanceInfo.inputValue = strAcctNum
                'Objinp.PPVService.RemainingBalanceInfo.region = strRegionCd
                'Objinp.PPVService.RemainingBalanceInfo.inputTypeIndicator = inputTypeIndicatorType.BROADBAND

            ElseIf (strPPVServiceType.ToUpper.ToString().Trim = "UNBILLEVENTS") Then
                Objinp.PPVService.GetVisionPPVInfo.VisionCustomerId = strAcctNum.Substring(0, 9)
                Objinp.PPVService.GetVisionPPVInfo.VisionAccountId = strAcctNum.Substring(9, 4)
                Objinp.PPVService.GetVisionPPVInfo.RequestType = VISIONPPVRequestType.UNBILLED
                'Objinp.PPVService.UnbilledVideoEvents.inputValue = strAcctNum
                'Objinp.PPVService.UnbilledVideoEvents.region = strRegionCd
                'Objinp.PPVService.UnbilledVideoEvents.inputTypeIndicator = inputTypeIndicatorType.BROADBAND
            ElseIf (strPPVServiceType.ToUpper.ToString().Trim = "ALLEVENTS") Then
                Objinp.PPVService.GetVisionPPVInfo.VisionCustomerId = strAcctNum.Substring(0, 9)
                Objinp.PPVService.GetVisionPPVInfo.VisionAccountId = strAcctNum.Substring(9, 4)
                Objinp.PPVService.GetVisionPPVInfo.RequestType = VISIONPPVRequestType.ALL
                'Objinp.PPVService.UnbilledVideoEvents.inputValue = strAcctNum
                'Objinp.PPVService.UnbilledVideoEvents.region = strRegionCd
                'Objinp.PPVService.UnbilledVideoEvents.inputTypeIndicator = inputTypeIndicatorType.BROADBAND
            End If


            Dim objNs As String = "http://verizon.com/ONE/"
            Dim ser As New XmlSerializer(Objinp.GetType)
            Dim ns As New XmlSerializerNamespaces()
            ns.Add(String.Empty, objNs)

            ser.Serialize(sw, Objinp, ns)
            strInputXml = sw.ToString()

            strInputXml = strInputXml.Replace(vbCrLf, "")
            strOutput = objSSPPA.getPPVInfo(strInputXml)
            xmlDoc.LoadXml(System.Text.RegularExpressions.Regex.Replace(strOutput, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline)))
        Catch ex As Exception
            LogErrorFile.WriteLog("RMICWWS-SSPPA:getPPVInfo" + strAcctNum + "/" + strRegionCd, ex.ToString())
            strOutput = "<getPPVInfo>" + ex.ToString() + "<getPPVInfo/>"
            xmlDoc.LoadXml(System.Text.RegularExpressions.Regex.Replace(strOutput, "(xmlns:?[^=]*=[""][^""]*[""])", "", (System.Text.RegularExpressions.RegexOptions.IgnoreCase) Or (System.Text.RegularExpressions.RegexOptions.Multiline)))
        End Try
        Return xmlDoc


    End Function
#End Region

End Class
