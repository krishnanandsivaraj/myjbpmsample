Imports CommonLibrary
Imports System.IO
Namespace Verizon.RMICW.WebServices

    <Serializable()> _
    Public Class StatusOfRequest
        Public strMessageId As String
        Public strMessageDescription As String

        Public Sub New()
            strMessageId = " "
            strMessageDescription = " "
        End Sub
    End Class
    Public Class RMICWWSBase
        Implements IDisposable
        Private strRegionId As String
        Private WSDataAccess As WSDataAccessGeneric

        Public Property RegionId()
            Get

                Return strRegionId
            End Get
            Set(ByVal Value)
                strRegionId = Value
            End Set
        End Property

        Public ReadOnly Property WSDataAccessObj() As WSDataAccessGeneric
            Get
                If (WSDataAccess Is Nothing) Then
                    WSDataAccess = New WSDataAccessGeneric(RegionId)
                    Return WSDataAccess
                Else
                    Return WSDataAccess
                End If

            End Get

        End Property

        Public Sub New(ByVal RegionId As String)
            strRegionId = RegionId
            WSDataAccess = New WSDataAccessGeneric(RegionId)

        End Sub

        Public Overloads Sub Dispose() Implements IDisposable.Dispose
            Dispose(True)
        End Sub

        Protected Overridable Overloads Sub Dispose(ByVal disposing As Boolean)
            'If disposing Then
            '    ' Free other state (managed objects).
            'End If
            ' Free your own state (unmanaged objects).
            ' Set large fields to null.
        End Sub

        Protected Overrides Sub Finalize()
            ' Simply call Dispose(False).
            Dispose(False)
        End Sub



    End Class




    Public Class WSCommonClasses

        Public Function getBucketStatus(ByVal strTrtStatusDesc As String, ByVal strActn As String) As BucketStatus


            Select Case True
                Case strTrtStatusDesc.ToUpper.Trim = "DENIED", strActn.StartsWith("S"), strActn.StartsWith("B"), strActn.StartsWith("TCB")
                    Return BucketStatus.Denied
                Case strTrtStatusDesc.ToUpper.Trim = "DENIED-MIGRATION", strActn.StartsWith("S"), strActn.StartsWith("B"), strActn.StartsWith("TCB")
                    Return BucketStatus.Denied
                Case strTrtStatusDesc.ToUpper.Trim = "TERMINATED", strTrtStatusDesc.ToUpper.Trim = "DISCONNECTED", strActn.StartsWith("D"), strActn.StartsWith("TCLD")
                    Return BucketStatus.Terminated
                Case Else
                    Return BucketStatus.Live
            End Select

        End Function


        Public Shared Function getBucketStatusString(ByVal enBucketStatus As BucketStatus)

            Select Case enBucketStatus
                Case BucketStatus.Terminated
                    Return "Terminated"
                Case BucketStatus.Live
                    Return "Live"
                Case BucketStatus.NA
                    Return "NA"
                Case BucketStatus.Denied
                    Return "Denied"
                Case Else
                    Return "Live"
            End Select
        End Function

        Public Shared Function CheckRegionType(ByVal strRegionId As String) As Boolean

            Select Case strRegionId.ToUpper.Trim
                Case "MDVW", "NE", "NY", "WEST", "NPD", "VISION"
                    Return True
                Case Else
                    Return False
            End Select
        End Function

        Public Shared Function CheckNull(ByVal strInp As String) As String
            If strInp Is Nothing Then
                Return (" ")
            Else
                Return strInp
            End If
        End Function
    End Class


#Region "SummayBillDetails for CBSPTRA1"


    Public Class SummaryBillDetails

        <System.Xml.Serialization.XmlElement(ElementName:="AcctList", Type:=GetType(SBMAcctList))> _
        Public arrLstAcctList As ArrayList
        Public RequestStatus As StatusOfRequest

        Public Sub New()

            arrLstAcctList = New ArrayList
            RequestStatus = New StatusOfRequest
        End Sub
    End Class

    Public Class SBMAcctList
        Public strAcctNum As String
        Public strBTNNum As String
        Public strStatus As String
        Public strClassOfService As String
        Public Sub New()
            strClassOfService = ""
        End Sub
    End Class

    Public Class E2EAcctList
        Public strAcctNum As String
        Public strOrg As String
        Public strRegionCd As String
        Public strEventType As String
        Public dtmPrcsdTs As DateTime
        Public strUserId As String
        Public strReason As String
        Public curTotalPastDue As Double
        Public curTotalDue As Double
        Public dtmSatisfyTs As DateTime
        Public strSystemId As String
        Public arrSubEvent() As SubEvent


        Public Sub New()
            strEventType = ""
            dtmPrcsdTs = "1900/01/01"
            strUserId = ""
            strReason = ""
            curTotalPastDue = 0.0
            curTotalDue = 0.0
            dtmSatisfyTs = "1900/01/01"
            strSystemId = ""
            strAcctNum = ""
            Dim objSubEvent As Array
            arrSubEvent = objSubEvent

        End Sub

        Public Class SubEvent
            Public strAcctNum As String
            Public strOrg As String
            Public strRegionCd As String
            Public strEventType As String
            Public dtmAddTs As DateTime
            Public strUserId As String
            Public strReason As String
            Public curTotalPastDue As Double
            Public curTotalDue As Double
            Public dtmExitTs As DateTime
            Public strSystemId As String
            Public ht As Hashtable

            Public Sub New()
                strEventType = ""
                dtmAddTs = "1900/01/01"
                strUserId = ""
                strReason = ""
                curTotalPastDue = 0.0
                curTotalDue = 0.0
                dtmExitTs = "1900/01/01"
                strSystemId = ""
                strAcctNum = ""
                ht = New Hashtable()
            End Sub

        End Class



    End Class
    

#End Region

#Region "Credit Info details for CBSPTRA9"


    <Serializable()> _
    Public Class CBSPTRA9_CreditInfo


        Public strAdvPayDepCd As String
        Public curTotalDeposits As Double
        Public curAcctCreditLimiAmt As Double
        Public strAcctCreditLimitId As String
        Public dtmAcctCreditLimitEffDt As DateTime
        Public strTrtExceptionId As String
        Public strTrtHistory As String
        Public strTollBlockStatusCd As String
        Public strWorthlessCheckInd As String
        Public strCreditRiskCd As String
        Public strCustCreditCl As String
        Public strDiscReason As String
        Public strTrtInstruction As String
        Public strCreditBureauCd As String
        Public strCreditInfo As String
        Public strPartnerName As String
        Public strTrtEligibilityCd As String
        Public strResponsibleParty As String
        Public RequestStatus As StatusOfRequest


        Public Sub New()

            RequestStatus = New StatusOfRequest
        End Sub

    End Class


#End Region

#Region "Customer Balance Info details for CBSPTRA9"

    <Serializable()> _
     Public Class AcctBalanceInfo
        Public strAcctNum As String

        <System.Xml.Serialization.XmlElement(ElementName:="CBSPTRA9_CustomerBalance", Type:=GetType(CBSPTRA9_CustomerBalance))> _
        Public arrLstBalanceDetails As ArrayList
        Public RequestStatus As StatusOfRequest

        Public Sub New()
            RequestStatus = New StatusOfRequest
            arrLstBalanceDetails = New ArrayList
        End Sub

    End Class


    <Serializable()> _
    Public Class CBSPTRA9_CustomerBalance

        ' 01 Cbsptra9XmlResultsBalance.
        '    10 SegmentKey.
        '       15 AccountNumber                    PIC X(010).
        '    10 SegmentNumber                       PIC S9(09) COMP.
        '    10 SegmentData.
        '       15 DataRecordType                   PIC x(002).
        '       15 ProductServiceProviderId         PIC x(005).
        '       15 BillingCategoryCode              PIC x(001).
        '       15 ProviderCurrentBillCharges       PIC -99999999999.99.
        '       15 PresentBillCharges               PIC -99999999999.99.
        '       15 PreviousBalance30Day             PIC -99999999999.99.
        '       15 PreviousBalance60Day             PIC -99999999999.99.
        '       15 PreviousBalance90Day             PIC -99999999999.99.
        '       15 TotalBillableAmount              PIC -99999999999.99.
        '       15 CurrentDemandCharges             PIC -99999999999.99.
        '       15 PreviousBalance15Day             PIC -99999999999.99.
        '       15 PreviousBalance45Day             PIC -99999999999.99.
        '       15 PreviousBalance75Day             PIC -99999999999.99.
        '       15 PreviousDemandCharges            PIC -99999999999.99.
        '       15 BalanceType                      PIC x(001).
        '       15 UnbilledCharges                  PIC -99999999999.99.
        '       15 BalanceDate                      PIC x(010).
        '****  END CBSERA10

        Public strAcctNum As String
        Public strDataRecordType As String
        Public strProductServiceProviderId As String
        Public strBillingCategoryCode As String
        Public curProviderCurrentBillCharges As Double
        Public curPresentBillCharges As Double
        Public curPreviousBalance30Day As Double
        Public curPreviousBalance60Day As Double
        Public curPreviousBalance90Day As Double
        Public curTotalBillableAmount As Double
        Public curCurrentDemandCharges As Double
        Public curPreviousBalance15Day As Double
        Public curPreviousBalance45Day As Double
        Public curPreviousBalance75Day As Double
        Public curPreviousDemandCharges As Double
        Public strBalanceType As String
        Public curUnbilledCharges As String
        Public strBalanceDate As String
        Public RequestStatus As StatusOfRequest

        Public Sub New()
            RequestStatus = New StatusOfRequest
        End Sub

    End Class


#End Region

#Region "CFI Customer Balance Info details for CBSPCFA1"

    <Serializable()> _
    Public Class CFIBalanceInput
        Public strAcctNum As String
        Public strRegioncd As String
        Public strOrg As String
        Public curPPXAmt As Double
        Public curAdjAmt As Double
        Public curBasicClaimAmt As Double
        Public curNonBasicClaimAmt As Double
        Public curTollClaimAmt As Double
        Public curOCARClaimAmt As Double
        Public curDACliamAmt As Double
        Public curOtherClaimAmt As Double

        Public dtmBillDate As DateTime
        Public dtmBillDueDate As DateTime

        Public strGetClaim As String
        Public strGetPPX As String
        Public strGetAdj As String
        Public strGetOption As String


        Public Sub New()
            strGetClaim = "N"
            strGetPPX = "N"
            strOrg = "000"

        End Sub

    End Class

  
    <Serializable()> _
    Public Class CFIBalanceBucketLevel
        Public strCategoryCd As String
        Public strBalanceType As String
        Public curCurrentCharges As Double
        Public cur30DaysCharges As Double
        Public cur60DaysCharges As Double
        Public cur90DaysCharges As Double
        Public cur120DaysCharges As Double
        Public curWriteOffAmt As Double
        Public curReferredAmt As Double
        Public curTotalCharges As Double
        Public curTotalTreatableAmount As Double

    End Class


    <Serializable()> _
 Public Class CFIBalanceInfoAccum
        Public strAcctNum As String
        Public dtmBillDate As DateTime

        <System.Xml.Serialization.XmlElement(ElementName:="CFIBalanceBucketLevel", Type:=GetType(CFIBalanceBucketLevel))> _
         Public arrLstBalanceBucketLevel As ArrayList

        <System.Xml.Serialization.XmlElement(ElementName:="CBSPCFA1_BalanceInfo", Type:=GetType(CBSPCFA1_BalanceInfo))> _
        Public arrLstBalanceDetails As ArrayList
        Public RequestStatus As StatusOfRequest

        Public Sub New()
            RequestStatus = New StatusOfRequest
            arrLstBalanceDetails = New ArrayList
            arrLstBalanceBucketLevel = New ArrayList

        End Sub

    End Class



    <Serializable()> _
     Public Class CFIBalanceInfo
        Public strAcctNum As String
        Public curTotalDueBasic As Double
        Public curTotalDueNonBasic As Double
        Public curTotalDueToll As Double
        Public curTotalDueOCAR As Double
        Public curTotalDueIP As Double
        Public curTotalDueCPE As Double
        Public curTotalDueDA As Double
        Public curTreatableDueBasic As Double
        Public curTreatableDueNonBasic As Double
        Public curTreatableDueToll As Double
        Public curTreatableDueOCAR As Double
        Public curTreatableDueIP As Double
        Public curTreatableDueCPE As Double
        Public curTreatableDueDA As Double
        Public curPastDueBasic As Double
        Public curPastDueNonBasic As Double
        Public curPastDueToll As Double
        Public curPastDueOCAR As Double
        Public curPastDueIP As Double
        Public curpastDueCPE As Double
        Public curPastDueDA As Double


        <System.Xml.Serialization.XmlElement(ElementName:="CBSPCFA1_BalanceInfo", Type:=GetType(CBSPCFA1_BalanceInfo))> _
        Public arrLstBalanceDetails As ArrayList
        Public RequestStatus As StatusOfRequest

        Public Sub New()
            RequestStatus = New StatusOfRequest
            arrLstBalanceDetails = New ArrayList

            curTotalDueBasic = 0
            curTotalDueNonBasic = 0
            curTotalDueToll = 0
            curTreatableDueBasic = 0
            curTreatableDueNonBasic = 0
            curTreatableDueToll = 0
            curPastDueBasic = 0
            curPastDueNonBasic = 0
            curPastDueToll = 0



        End Sub

    End Class

'Added for Vision
    <Serializable()> _
     Public Class BalanceInfo
        Public strAcctNum As String
        Public strDSCashOnlyStatus As String
        Public curTotalDueBasic As Double
        Public curTotalDueNonBasic As Double
        Public curTotalDueToll As Double
        Public curTotalDueOCAR As Double
        Public curTotalDueIP As Double
        Public curTotalDueCPE As Double
        Public curTotalDueDA As Double
        Public curTreatableDueBasic As Double
        Public curTreatableDueNonBasic As Double
        Public curTreatableDueToll As Double
        Public curTreatableDueOCAR As Double
        Public curTreatableDueIP As Double
        Public curTreatableDueCPE As Double
        Public curTreatableDueDA As Double
        Public curPastDueBasic As Double
        Public curPastDueNonBasic As Double
        Public curPastDueToll As Double
        Public curPastDueOCAR As Double
        Public curPastDueIP As Double
        Public curpastDueCPE As Double
        Public curPastDueDA As Double


        '  <System.Xml.Serialization.XmlElement(ElementName:="CBSPCFA1_BalanceInfo", Type:=GetType(CBSPCFA1_BalanceInfo))> _
        Public arrLstBalanceDetails As ArrayList
        Public RequestStatus As StatusOfRequest

        Public Sub New()
            strDSCashOnlyStatus = "N"
            RequestStatus = New StatusOfRequest
            arrLstBalanceDetails = New ArrayList

            curTotalDueBasic = 0
            curTotalDueNonBasic = 0
            curTotalDueToll = 0
            curTreatableDueBasic = 0
            curTreatableDueNonBasic = 0
            curTreatableDueToll = 0
            curPastDueBasic = 0
            curPastDueNonBasic = 0
            curPastDueToll = 0
        End Sub
    End Class


    <Serializable()> _
    Public Class CBSPCFA1_BalanceInfo

        Public strKeyDataRecordType As String
        Public strKeyProductServiceProviderId As String
        Public strKeyBillingCategoryCode As String

        Public strDataRecordType As String
        Public strBalanceDate As String
        Public strProductServiceProviderId As String
        Public strBillingCategoryCode As String

        Public curCurrentBillCharges As Double
        Public curDeferredBillingAmount As Double
        Public curHistoryDeferredAmount As Double
        Public strLatePaymentIndicator As String

        Public curPreviousBalance15Day As Double
        Public curPreviousBalance30Day As Double
        Public curPreviousBalance45Day As Double
        Public curPreviousBalance60Day As Double
        Public curPreviousBalance75Day As Double
        Public curPreviousBalance90Day As Double
        Public curPreviousBalance120Day As Double


        Public strProviderBillIndicator As String
        Public strProviderStatus As String
        Public curTotalAmountDueProvider As Double
        Public curTotalWriteoffAmount As Double
        Public curTotalRefferedAmount As Double
        Public curTotalBillableAmount As Double

        Public curCurrentDemandCharges As Double
        Public curPreviousDemandCharges As Double
        Public curPresentBillCharges As Double
        Public strLastLpcAppliedDate As String
        Public strLpcAppliedDate As String
        Public curYtdLateCharges As Double
        Public curUnbilledCharges As Double

        'for DataType "TB"
        Public strTreatmentLetterId As String
        Public curTotalTreatableAmount As Double

        'for Paybydate
        Public PaymentDueDt As String 'WR68041
        Public PrevPaymentDueDt As String '68041

        Public RequestStatus As StatusOfRequest

        Public Sub New()
            RequestStatus = New StatusOfRequest
        End Sub

    End Class


<Serializable()> _
  Public Class DSBalanceInfo

        Public strKeyDataRecordType As String
        Public strKeyProductServiceProviderId As String
        Public strKeyBillingCategoryCode As String

        Public strDataRecordType As String
        Public strBalanceDate As String
        Public strProductServiceProviderId As String
        Public strBillingCategoryCode As String

        Public curCurrentBillCharges As Double
        Public curDeferredBillingAmount As Double
        Public curHistoryDeferredAmount As Double
        Public strLatePaymentIndicator As String

        Public curPreviousBalance15Day As Double
        Public curPreviousBalance30Day As Double
        Public curPreviousBalance45Day As Double
        Public curPreviousBalance60Day As Double
        Public curPreviousBalance75Day As Double
        Public curPreviousBalance90Day As Double
        Public curPreviousBalance120Day As Double


        Public strProviderBillIndicator As String
        Public strProviderStatus As String
        Public curTotalAmountDueProvider As Double
        Public curTotalWriteoffAmount As Double
        Public curTotalRefferedAmount As Double
        Public curTotalBillableAmount As Double

        Public curCurrentDemandCharges As Double
        Public curPreviousDemandCharges As Double
        Public curPresentBillCharges As Double
        Public strLastLpcAppliedDate As String
        Public strLpcAppliedDate As String
        Public curYtdLateCharges As Double
        Public curUnbilledCharges As Double

        'for DataType "TB"
        Public strTreatmentLetterId As String
        Public curTotalTreatableAmount As Double

        'for Paybydate
        Public PaymentDueDt As String 'WR68041
        Public PrevPaymentDueDt As String '68041

        Public RequestStatus As StatusOfRequest

        Public Sub New()
            RequestStatus = New StatusOfRequest
        End Sub

    End Class

#End Region


#Region "Adjustment Info details for CBSPTRA9"

    <Serializable()> _
     Public Class AdjustmentInfo 'used for getCBSS_CBSPTRA9_Adjustment Webmethod
        Public strAcctNum As String

        <System.Xml.Serialization.XmlElement(ElementName:="CBSPTRA9_Adjustment", Type:=GetType(CBSPTRA9_Adjustment))> _
        Public arrLstAdjustmentDetails As ArrayList
        Public RequestStatus As StatusOfRequest

        Public Sub New()
            RequestStatus = New StatusOfRequest
            arrLstAdjustmentDetails = New ArrayList
        End Sub

    End Class

    <Serializable()> _
    Public Class CBSPTRA9_Adjustment
        'The folloiwng info is available at http://uxc3.verizon.com:8083/cbsera07.txt
        '****** DBA MAINTAINED INCLUDE * LAST UPDATE 20031003
        '*CBSERA07
        ' 01 Cbsptra9XmlResultsAdjustment.
        '    10 SegmentKey.
        '       15 AccountNumber                    PIC X(010).
        '    10 SegmentNumber                       PIC S9(09) COMP.
        '    10 SegmentData.
        '       15 DataRecordType                   PIC X(002).
        '       15 AdjustmentBatchId                PIC X(002).
        '       15 PaymentAdjustmentSeqNumber       PIC X(006).
        '       15 AdjustmentActionCode             PIC X(002).
        '       15 AdjustmentDate                   PIC X(008).
        '       15 AdjustmentTypeCode               PIC X(002).
        '       15 BasicAdjustmentAmount            PIC -999999999.99.
        '       15 BillingCategoryCode              PIC X(001).
        '       15 JournalEntryDpCode               PIC X(002).
        '       15 ProductServiceProviderId         PIC X(005).
        '       15 TotalAdjustmentAmount            PIC -999999999.99.
        '       15 AdjustmentType                   PIC X(002).
        '       15 SecondaryBlgCarrierIdCode        PIC X(008).
        '       15 AdjustmentForCustBillDate        PIC X(008).
        '       15 ClecId                           PIC X(005).
        '       15 VoucherNumber                    PIC -999999999999999.
        '       15 VoucherLineNumber                PIC -999999999.
        '       15 ReturnedCheckReasonCode          PIC X(003).
        '****  END CBSERA07

        Public strAcctNum As String
        Public strDataRecordType As String
        Public strAdjustmentBatchId As String
        Public strPaymentAdjustmentSeqNumber As String
        Public strAdjustmentActionCode As String
        Public strAdjustmentDate As String
        Public strAdjustmentTypeCode As String
        Public curBasicAdjustmentAmount As Double
        Public strBillingCategoryCode As String
        Public strJournalEntryDpCode As String
        Public strProductServiceProviderId As String
        Public curTotalAdjustmentAmount As Double
        Public strAdjustmentType As String
        Public strSecondaryBlgCarrierIdCode As String
        Public strAdjustmentForCustBillDate As String
        Public strClecId As String
        Public strVoucherNumber As String
        Public strVoucherLineNumber As String
        Public strReturnedCheckReasonCode As String

        'Public RequestStatus As StatusOfRequest

        'Public Sub New()
        '    RequestStatus = New StatusOfRequest
        'End Sub

    End Class

#End Region


#Region "uCSR Details Input"

    <Serializable()> _
    Public Class uCSR_DetailsInp

        Public strCANNum As String
        Public strAcctNum As String
        Public strActn As String
        Public strServiceType As String
        'Public strProcessedDate As DateTime
        Public strCompanyCode As String
        Public strServiceOrderNum As String
        Public strLECBilledStatus As String
        Public strRAO As String

        Public strRegionId As String
        'Public strInputRequestType As String
        'Public strOrg As String
        Public strApplicationId As String
        Public strPCAN As String
        Public strDCR As String
        Public strAccountId As String
        Public strServiceId As String



        Public Sub New()

            strCANNum = " "
            strAcctNum = " "
            strActn = " "
            strServiceType = " "
            strCompanyCode = " "
            strServiceOrderNum = " "
            strLECBilledStatus = " "
            strRAO = " "

            strRegionId = " "
            strApplicationId = " "
            strPCAN = " "
            strDCR = " "
            strAccountId = " "
            strServiceId = " "
        End Sub
    End Class

#End Region

#Region "uCSR Details Output"

    <Serializable()> _
        Public Class uCSR_DetailsOut

        Public strAcctNum As String
        Public strActn As String
        Public strStatus As String
        Public strReturnCd As String
        Public strMessageId As String
        Public strMessageDescription As String

        Public Sub New()

            strAcctNum = " "
            strActn = " "
            strStatus = " "
            strReturnCd = " "
            strMessageId = " "
            strMessageDescription = " "
        End Sub

    End Class

#End Region


#Region "Account Profile from CBSPERA1"



    <Serializable()> _
    Public Class CBSPERA1
        Public strAcctNum As String
        Public strCustomerBillingDayCurrent As String
        Public strEndUserName As String
        Public strBillingCompanyCode As String
        Public strCustomerAccountStatus As String
        Public dblDerivedTotalAmountDue As Double
        Public dtmCurrentBillingDate As DateTime
        Public strGradeOfService As String
        Public dtmInitialAccountEstabdDate As DateTime
        Public strLocationCode As String
        Public dtmMasterServiceDate As DateTime
        Public strStateCode As String
        Public strSummaryAccountNumber As String
        Public strAccountTypeCode As String
        Public strNgbAccountNumber As String
        Public strCPNIOption As String
        Public strAreaCentralOfficeCode As String
        Public strFinanceLineOfBusinessCode As String
        Public strNonPubNonListCode As String
        Public strWorthlessCheckIndr As String
        Public strStdIndustrialClassification As String
        Public strServiceRepPositionNumber As String
        Public strUpdateProcessDate As String
        Public strPendingOrderFlag As String
        Public strAccountTelephoneNumber As String
        Public strConcessionCode As String
        Public strVactionOrSeasonalSignal As String
        Public strCanBeReachedAtNumber As String
        Public strCanBeReachedAtExtNumber As String
        Public strAuthorizedPartyName As String
        Public strTreatmentExceptionIdentifier As String
        Public strTaxIdentifier As String
        Public strSocialSecurityNumber As String
        Public strCrbCompanyCode As String
        Public strInitAccEstDateMaster As String
        Public strTelephoneNumberMaster As String
        Public strArrearsBillingIndicator As String
        Public strBillPeriodCode As String
        Public strCustAcctSumyBlgCd As String
        Public strCustomerNumberOfBills As String
        Public strLacTrackingCode As String
        Public strSpecialHandlingCode As String
        Public strTaxApplicabilityFlags As String
        Public strTaxExemptCode As String
        Public strCustomerCreditClass As String
        Public dtmAccountTerminationDate As DateTime
        Public strFinalBillStatus As String
        Public dtmServiceOrderDate As DateTime
        Public strServiceOrderNumber As String
        Public strBillingRevenueAccountingOffice As String
        Public strSalesAreaCode As String
        Public strCbssScanLine As String

        Public RequestStatus As StatusOfRequest


        Public Sub New()

            RequestStatus = New StatusOfRequest
        End Sub

    End Class

#End Region


#Region "Acct Line Level Information from CBSPERA2 "

    <Serializable()> _
     Public Class AcctLineLevelInfo
        Public strAcctNum As String

        <System.Xml.Serialization.XmlElement(ElementName:="LineLevelInfo", Type:=GetType(LineLevelInfo))> _
        Public arrLstLineDetails As ArrayList
        Public RequestStatus As StatusOfRequest

        Public Sub New()
            RequestStatus = New StatusOfRequest
            arrLstLineDetails = New ArrayList
        End Sub

    End Class

    <Serializable()> _
 Public Class LineLevelInfo
        Public strAcctNum As String

        Public strTypeSubAcct As String
        Public strSubAcctServiceType As String
        Public strTelephoneNo As String
        Public strLocationCode As String
        Public dtmSubAccountEstimateDate As DateTime
        Public dtmSubAccountTermDate As DateTime
        Public strTaxDistrictCd As String
        Public strProdSvcRa As String
        Public strPriInSrceCde As String
        Public strPriIxcPrSrce As String
        Public strAcoCode As String
        Public strIlIxCrrCode As String
        Public strInPrePrvdrId As String
        Public strMeasuredSvcCd As String
        Public strSmrgAssocInd As String
        Public strCircuitID As String
        Public strIlPrePrvdrID As String
        Public strUssRatingCode As String
        Public strIlIxCrrStCd As String
        Public strIlPreStCd As String
        Public strRotaryGroupNo As String
        Public strRotaryGpseqNo As Double
        Public strLineTypeCode As String
        Public strInterlataRrn As String
        Public strIntralataRrn As String
        Public strBillBlockInd As String
        Public strEqacCarrierNmInter As String
        Public strEqacCarrierDesInter As String
        Public strEqacCarrierNmIntra As String
        Public strEqacCarrierDesIntra As String
        Public strDiryAdvIndr As String
        Public strHcpDiscIndr As String
        Public dtmMasterSvcDate As DateTime
        Public dtmIlIxcEffvDt As String
        Public dtmInPrePrEfDt As String
        Public dtmIlPrePrEfDt As String
        Public strInPreStCd As String
        Public strTlBlgExCode As String
        Public dtmBlockEffDate As String
        Public dtmBlockTermDate As String
        Public strClecBllTypCd As String
        Public strMsdSvcDtlOpt As String

        Public strDerivedClecLineType As String
        Public strTabEntEffectiveDate As String
        Public strTabEntexpirationDate As String
        Public strDerviedLPICResaleInd As String
        Public strLRNNumber As String


    End Class

#End Region
    <Serializable()> _
Public Class CBSEZRA9
        Public strAcctNum As String


        Public strCCFD As String
        Public strCCDTypeOfDataRec As String
        Public strCCDCreditData As String
        Public strCCDAdvPayDepCde As String
        Public dblCCDTotDepositsDis As Double
        Public dblCCDAcCrLimAmtDis As Double
        Public strCCDAcCrLimId As String
        Public dteCCDAcCrLimEfDt As DateTime
        Public strCCDTreatExceptId As String
        Public strCCDTrHistoryStat As String
        Public strCCDTlBlockStCd As String
        Public strCCDWorChkIndr As String
        Public strCCDCredRiskCd As String
        Public strCCDCustCreditCl As String
        Public strCCDDiscReason As String
        Public strCCDTreatInstruct As String
        Public strCCDCredBureauCd As String
        Public strCCDCreditInfo As String
        Public strCCDPartnerName As String
        Public strCCDTrElgbltyCode As String
        Public strCDDTypeOfDataRec As String
        Public strCDDDepositData As String
        Public strCDDCustPmtRctNo As String
        Public strCDDCollnCtrLocn As String
        Public dblCDDTotDepositsDis As Double
        Public dteCDDDepPaidDate As DateTime
        Public dblCDDDepRefAmountDis As Double
        Public dteCDDDepRefDat As DateTime
        Public strCDDDepRefDispCd As String
        Public strCADTypeOfDataRec As String
        Public strCADAdjustmentData As String
        Public strCADAdjmtBatchId As String
        Public strCADPmtAdjSeqNo As String
        Public strCADAdjmtActnCode As String
        Public dteCADAdjustmentDate As DateTime
        Public strCADAdjmtTypeCode As String
        Public dblCADBasicAdjmtAmtDis As Double
        Public strCAdblCatgCd As String
        Public strCADJnlEntDpCode As String
        Public strCADPsPvdrId As String
        Public dblCADTotalAdjmtAmtDis As Double
        Public strCADTypeOfAdjmt As String
        Public strCADSubcic As String
        Public dteCADAdjBillDt As DateTime
        Public strCADClecId As String
        Public strCADVoucherNumDis As String
        Public strCADVoucherLineNoDis As String
        Public strCPDTypeOfDataRec As String
        Public strCPDPaymentData As String
        Public strCPDCashCollnData As String
        Public strCPDCollnCtrLocn As String
        Public strCPDCustPmtAmtDis As String
        Public strCPDCustPmtType As String
        Public strCPDComAcctCkNum As String
        Public strCPDBankRouteNum As String
        Public strCPDNonStdCkInfo As String
        Public strCPDCkAcctNum As String
        Public strCPDConAcctCkNum As String
        Public strCPDPmtTransNum As String
        Public strCBDTypeOfDataRec As String
        Public strCBDBalanceData As String
        Public strCBDPsPvdrId As String
        Public strCBDblCatgCd As String
        Public dblCBDCurBillChgDis As Double
        Public dblCBDPresentBlChgsDis As Double
        Public dblCBDPrevBal30DayDis As Double
        Public dblCBDPrevBal60DayDis As Double
        Public dblCBDPrevBal90DayDis As Double
        Public dblCBDTotalBlAmtDis As Double

        Public RequestStatus As StatusOfRequest

        Public Sub New()
            RequestStatus = New StatusOfRequest
        End Sub
    End Class



#Region "Treatment Status for SBM"

    Public Class TS_ResponseForSBM

        <System.Xml.Serialization.XmlElement(ElementName:="TreatmentStatusList", Type:=GetType(TS_Response))> _
        Public arrLstTSList As ArrayList
        Public RequestStatus As StatusOfRequest

        Public Sub New()
            arrLstTSList = New ArrayList
            RequestStatus = New StatusOfRequest
        End Sub

    End Class

#End Region
#Region "Treatment Status Request"


    <Serializable()> _
    Public Class TS_Request
        Public strRegionId As String
        Public strInputRequestType As String
        Public strAcctNum As String
        Public strOrg As String
        Public strApplicationId As String

        Public Sub New()
            strRegionId = " "
            strInputRequestType = "A"
            strOrg = "000"
        End Sub
    End Class

#End Region
    Public Enum BucketStatus
        Live
        Denied
        Terminated
        NA
    End Enum

    <Serializable()> _
    Public Class TS_Response

        Private Const cstMsgInvRegion As String = "Invalid RegionId Specified"
        Private Const cstMsgInvOrg As String = "Org Need to be specified"
        Private Const cstMsgRequestType As String = "Request Type should be A or B"
        Private Const cstMsgDBFailure As String = "Database Failure, Internal Error."


        Public strRegionId As String
        Public strAcctNum As String
        Public strBTNNum As String
        Public strStatus As String
        Public strBasicBucketStatusInd As BucketStatus
        Public strNonBasicBucketStatusInd As BucketStatus
        Public strTollBucketStatusInd As BucketStatus
        Public strOCARBucketStatusInd As BucketStatus
        Public strNonTelecomStatusInd As BucketStatus
        Public strDAStatusInd As BucketStatus
        Public strCashOnlyInd As String ' Added Cash only indicator for WR67187 Walled Garden
        Public strPPVStatusInd As String ' 76588 PPV VOD   
        Public strBasicBundleInd As String 'Added for deleware
        Public strClassOfService As String 'Added for Icollect System Improvements
        Public arrStatusDesc() As TS_Status_Description
        Public ResponseStatus As TS_Response_Status

        Public Sub New()

            Dim arrLstStatus As ArrayList = New ArrayList
            strBTNNum = " "
            arrStatusDesc = CType(arrLstStatus.ToArray(GetType(TS_Response.TS_Status_Description)), TS_Response.TS_Status_Description())
            ResponseStatus = New TS_Response_Status
            strBasicBucketStatusInd = BucketStatus.Live
            strNonBasicBucketStatusInd = BucketStatus.Live

        End Sub

        <Serializable()> _
        Public Class TS_Status_Description
            Public strBucketName As String
            Public strCategoryCd As String
            Public strBucketStatusInd As BucketStatus
            Public strBucketStatusDesc As String
            Public dtmBeginDate As DateTime
            Public strBasicBundleInd As String



        End Class

        <Serializable()> _
        Public Class TS_Response_Status

            Public strMessageId As String
            Public strMessageDescription As String

            Public Sub New()
                strMessageId = " "
                strMessageDescription = " "

            End Sub
        End Class

        Public Sub Initialize(ByVal strRegionId As String)


            strBasicBucketStatusInd = BucketStatus.Live
            strNonBasicBucketStatusInd = BucketStatus.Live
            strTollBucketStatusInd = BucketStatus.Live
            strOCARBucketStatusInd = BucketStatus.NA
            strNonTelecomStatusInd = BucketStatus.NA
            strDAStatusInd = BucketStatus.NA

            Dim arrLstStatus As ArrayList = New ArrayList

            Dim objTSDesc As TS_Response.TS_Status_Description = New TS_Response.TS_Status_Description
            objTSDesc.strBucketName = "Basic"
            objTSDesc.strCategoryCd = "B"
            objTSDesc.strBucketStatusInd = BucketStatus.Live
            objTSDesc.strBucketStatusDesc = "Live"
            objTSDesc.dtmBeginDate = New DateTime(1900, 1, 1)
            arrLstStatus.Add(objTSDesc)


            objTSDesc = New TS_Response.TS_Status_Description
            objTSDesc.strCategoryCd = "N"
            objTSDesc.strBucketName = "Non-Basic"
            objTSDesc.strBucketStatusInd = BucketStatus.Live
            objTSDesc.strBucketStatusDesc = "Live"
            objTSDesc.dtmBeginDate = New DateTime(1900, 1, 1)
            arrLstStatus.Add(objTSDesc)

            objTSDesc = New TS_Response.TS_Status_Description
            objTSDesc.strCategoryCd = "T"
            objTSDesc.strBucketName = "Toll"
            objTSDesc.strBucketStatusInd = BucketStatus.Live
            objTSDesc.strBucketStatusDesc = "Live"
            objTSDesc.dtmBeginDate = New DateTime(1900, 1, 1)
            arrLstStatus.Add(objTSDesc)

            'arrStatusDesc = CType(arrLstStatus.ToArray(), TS_Response.TS_Status_Description())
            arrStatusDesc = CType(arrLstStatus.ToArray(GetType(TS_Response.TS_Status_Description)), TS_Response.TS_Status_Description())


            ResponseStatus = New TS_Response_Status


        End Sub

        Public Sub InitializeMDVW(ByVal strRegionId As String)


            strBasicBucketStatusInd = BucketStatus.Live
            strNonBasicBucketStatusInd = BucketStatus.Live
            strTollBucketStatusInd = BucketStatus.Live
            strOCARBucketStatusInd = BucketStatus.NA
            strNonTelecomStatusInd = BucketStatus.NA
            strDAStatusInd = BucketStatus.NA

            Dim arrLstStatus As ArrayList = New ArrayList

            Dim objTSDesc As TS_Response.TS_Status_Description = New TS_Response.TS_Status_Description
            objTSDesc.strBucketName = "Basic"
            objTSDesc.strCategoryCd = "B"
            objTSDesc.strBucketStatusInd = BucketStatus.Terminated
            objTSDesc.strBucketStatusDesc = "Terminated"
            objTSDesc.dtmBeginDate = New DateTime(1900, 1, 1)
            arrLstStatus.Add(objTSDesc)


            objTSDesc = New TS_Response.TS_Status_Description
            objTSDesc.strCategoryCd = "N"
            objTSDesc.strBucketName = "Non-Basic"
            objTSDesc.strBucketStatusInd = BucketStatus.Live
            objTSDesc.strBucketStatusDesc = "Live"
            objTSDesc.dtmBeginDate = New DateTime(1900, 1, 1)
            arrLstStatus.Add(objTSDesc)

            objTSDesc = New TS_Response.TS_Status_Description
            objTSDesc.strCategoryCd = "T"
            objTSDesc.strBucketName = "Toll"
            objTSDesc.strBucketStatusInd = BucketStatus.Live
            objTSDesc.strBucketStatusDesc = "Live"
            objTSDesc.dtmBeginDate = New DateTime(1900, 1, 1)
            arrLstStatus.Add(objTSDesc)

            'arrStatusDesc = CType(arrLstStatus.ToArray(), TS_Response.TS_Status_Description())
            arrStatusDesc = CType(arrLstStatus.ToArray(GetType(TS_Response.TS_Status_Description)), TS_Response.TS_Status_Description())


            ResponseStatus = New TS_Response_Status


        End Sub

    End Class

    Public Enum BucketStatusFIOS
        Live
        Blocked
        'InternationalBlock
        'AllBlock
        NA
    End Enum

    Public Enum FIOSBlockType
        BlockAll
        BlockIntl
    End Enum

#Region "Treatment Response for FIOS"
    <Serializable()> _
    Public Class TSFIOS_Response

        Public strRegionId As String
        Public strAcctNum As String
        Public strAcctType As String

        Public arrStatusDesc() As TSFIOS_Status_Description
        'Public ResponseStatus As TS_Response_Status
        Public ResponseStatus As StatusOfRequest

        Public Sub New()

            Dim arrLstStatus As ArrayList = New ArrayList
            strAcctNum = " "
            strAcctType = " "

            arrStatusDesc = CType(arrLstStatus.ToArray(GetType(TSFIOS_Response.TSFIOS_Status_Description)), TSFIOS_Response.TSFIOS_Status_Description())
            'ResponseStatus = New TS_Response_Status
            ResponseStatus = New StatusOfRequest

        End Sub

        <Serializable()> _
        Public Class TSFIOS_Status_Description
            Public strWTN As String
            Public strLineType As String
            Public strBlockType As FIOSBlockType
            Public strStatus As BucketStatusFIOS
            Public strPendingStatus As String
            Public strPendingDesc As String

            Public Sub New()
                strWTN = " "
                strLineType = " "
                strStatus = BucketStatusFIOS.Live
                'strPendingStatus = " "
                'strPendingDesc = " "
            End Sub
        End Class

        '<Serializable()> _
        'Public Class TS_Response_Status
        '    Public strMessageId As String
        '    Public strMessageDescription As String

        '    Public Sub New()
        '        strMessageId = " "
        '        strMessageDescription = " "
        '    End Sub
        'End Class

        Public Sub Initialize(ByVal strRegionId As String)

            Dim arrLstStatus As ArrayList = New ArrayList
            Dim objTSFIOSDesc As TSFIOS_Response.TSFIOS_Status_Description = New TSFIOS_Response.TSFIOS_Status_Description

            objTSFIOSDesc.strLineType = " "
            objTSFIOSDesc.strStatus = BucketStatusFIOS.Live
            objTSFIOSDesc.strWTN = " "
            arrLstStatus.Add(objTSFIOSDesc)

            arrStatusDesc = CType(arrLstStatus.ToArray(GetType(TSFIOS_Response.TSFIOS_Status_Description)), TSFIOS_Response.TSFIOS_Status_Description())
            'ResponseStatus = New TS_Response_Status
            ResponseStatus = New StatusOfRequest

        End Sub

    End Class
#End Region


#Region "Treatment Details Request for RMVP"
    'TD_Request for getTreatmentDetails

    <Serializable()> _
    Public Class TD_Request
        Public strRegionId As String
        Public strInputRequestType As String
        Public strAcctNum As String
        Public strOrg As String
        Public strApplicationId As String

        Public Sub New()
            strRegionId = " "
            strInputRequestType = "A"
            strOrg = "000"
        End Sub
    End Class

#End Region




#Region "RMICW TD_Response class for RMVP"
    'TD_Response for getTreatmentDetails
    <Serializable()> _
    Public Class TD_Response

        Private Const cstMsgInvRegion As String = "Invalid RegionId Specified"
        Private Const cstMsgInvOrg As String = "Org Need to be specified"
        Private Const cstMsgRequestType As String = "Request Type should be A or B"
        Private Const cstMsgDBFailure As String = "Database Failure, Internal Error."


        Public strRegionId As String
        Public strAcctNum As String
        Public strBTNNum As String
        Public strPendingRestoral As String

        ' Changes done for DC Bucketing
        Public strBasicBundleInd As String

        Public strBasicBucketStatusInd As BucketStatus
        Public strNonBasicBucketStatusInd As BucketStatus
        Public strTollBucketStatusInd As BucketStatus
        Public strOCARBucketStatusInd As BucketStatus
        Public strNonTelecomStatusInd As BucketStatus
        Public strDAStatusInd As BucketStatus
        Public strCashOnlyInd As String ' Added Cash only indicator for WR67187 Walled Garden


        Public arrStatusDesc() As TD_Status_Description
        Public ResponseStatus As TD_Response_Status

        Public Sub New()

            Dim arrLstStatus As ArrayList = New ArrayList
            strBTNNum = " "
            arrStatusDesc = CType(arrLstStatus.ToArray(GetType(TD_Response.TD_Status_Description)), TD_Response.TD_Status_Description())
            ResponseStatus = New TD_Response_Status

            strBasicBucketStatusInd = BucketStatus.Live
            strNonBasicBucketStatusInd = BucketStatus.Live
			strPendingRestoral = ""
        End Sub

        <Serializable()> _
        Public Class TD_Status_Description
            Public strBucketName As String
            Public strBucketStatusInd As BucketStatus
            Public dtmTerminationDate As DateTime
            Public curPastDueAmount As Double
            Public curTreatableAmount As Double
            Public curNoticeAmount As Double
            Public curSnpAmount As Double

            Public strCategoryCd As String
            Public strBucketStatusDesc As String
            Public dtmBeginDate As DateTime

            Public TotalAmountDue As Double
            Public intEventId As String
            Public strEventType As String
            Public strEventDesc As String
            Public curEventAmount As Double
            Public strMessage As String
            Public dtmTransactionDate As DateTime
            Public applicableForView As String
        End Class

        <Serializable()> _
        Public Class TD_Response_Status

            Public strMessageId As String
            Public strMessageDescription As String

            Public Sub New()
                strMessageId = " "
                strMessageDescription = " "

            End Sub
        End Class

        Public Sub Initialize(ByVal strRegionId As String)


            strBasicBucketStatusInd = BucketStatus.Live
            strNonBasicBucketStatusInd = BucketStatus.Live
            strTollBucketStatusInd = BucketStatus.Live
            strOCARBucketStatusInd = BucketStatus.NA
            strNonTelecomStatusInd = BucketStatus.NA
            strDAStatusInd = BucketStatus.NA
            strPendingRestoral = "N"
            strBTNNum = strAcctNum


            Dim arrLstStatus As ArrayList = New ArrayList

            Dim objTDDesc As TD_Response.TD_Status_Description = New TD_Response.TD_Status_Description

            objTDDesc.strBucketName = "Basic"
            objTDDesc.strCategoryCd = "B"
            objTDDesc.strBucketStatusInd = "Live"
            objTDDesc.strBucketStatusDesc = "Live"
            objTDDesc.dtmTerminationDate = New DateTime(1900, 1, 1)
            objTDDesc.curSnpAmount = "0.00"
            objTDDesc.curNoticeAmount = "0.00"
            objTDDesc.curPastDueAmount = "0.00"
            objTDDesc.curTreatableAmount = "0.00"
            objTDDesc.dtmTransactionDate = New DateTime(1900, 1, 1)

            arrLstStatus.Add(objTDDesc)


            objTDDesc = New TD_Response.TD_Status_Description
            objTDDesc.strCategoryCd = "N"
            objTDDesc.strBucketName = "Non-Basic"
            objTDDesc.strBucketStatusInd = "Live"
            objTDDesc.strBucketStatusDesc = "Live"
            objTDDesc.dtmTerminationDate = New DateTime(1900, 1, 1)
            objTDDesc.curSnpAmount = "0.00"
            objTDDesc.curNoticeAmount = "0.00"
            objTDDesc.curPastDueAmount = "0.00"
            objTDDesc.curTreatableAmount = "0.00"
            objTDDesc.dtmTransactionDate = New DateTime(1900, 1, 1)
            arrLstStatus.Add(objTDDesc)

            objTDDesc = New TD_Response.TD_Status_Description
            objTDDesc.strCategoryCd = "T"
            objTDDesc.strBucketName = "Toll"
            objTDDesc.strBucketStatusInd = "Live"
            objTDDesc.strBucketStatusDesc = "Live"
            objTDDesc.dtmTerminationDate = New DateTime(1900, 1, 1)
            objTDDesc.curSnpAmount = "0.00"
            objTDDesc.curNoticeAmount = "0.00"
            objTDDesc.curPastDueAmount = "0.00"
            objTDDesc.curTreatableAmount = "0.00"
            objTDDesc.dtmTransactionDate = New DateTime(1900, 1, 1)
            arrLstStatus.Add(objTDDesc)

            objTDDesc = New TD_Response.TD_Status_Description
            objTDDesc.strCategoryCd = "O"
            objTDDesc.strBucketName = "OCAR"
            objTDDesc.strBucketStatusInd = "Live"
            objTDDesc.strBucketStatusDesc = "Live"
            objTDDesc.dtmTerminationDate = New DateTime(1900, 1, 1)
            objTDDesc.curSnpAmount = "0.00"
            objTDDesc.curNoticeAmount = "0.00"
            objTDDesc.curPastDueAmount = "0.00"
            objTDDesc.curTreatableAmount = "0.00"
            objTDDesc.dtmTransactionDate = New DateTime(1900, 1, 1)
            arrLstStatus.Add(objTDDesc)

            objTDDesc = New TD_Response.TD_Status_Description
            objTDDesc.strCategoryCd = "O"
            objTDDesc.strBucketName = "NonTelecom"
            objTDDesc.strBucketStatusInd = "Live"
            objTDDesc.strBucketStatusDesc = "Live"
            objTDDesc.dtmTerminationDate = New DateTime(1900, 1, 1)
            objTDDesc.curSnpAmount = "0.00"
            objTDDesc.curNoticeAmount = "0.00"
            objTDDesc.curPastDueAmount = "0.00"
            objTDDesc.curTreatableAmount = "0.00"
            objTDDesc.dtmTransactionDate = New DateTime(1900, 1, 1)
            arrLstStatus.Add(objTDDesc)


            objTDDesc = New TD_Response.TD_Status_Description
            objTDDesc.strCategoryCd = "D"
            objTDDesc.strBucketName = "DA"
            objTDDesc.strBucketStatusInd = "Live"
            objTDDesc.strBucketStatusDesc = "Live"
            objTDDesc.dtmTerminationDate = New DateTime(1900, 1, 1)
            objTDDesc.curSnpAmount = "0.00"
            objTDDesc.curNoticeAmount = "0.00"
            objTDDesc.curPastDueAmount = "0.00"
            objTDDesc.curTreatableAmount = "0.00"
            objTDDesc.dtmTransactionDate = New DateTime(1900, 1, 1)
            arrLstStatus.Add(objTDDesc)

            objTDDesc = New TD_Response.TD_Status_Description
            objTDDesc.strBucketName = "TreatmentData"
            objTDDesc.dtmTerminationDate = New DateTime(1900, 1, 1)
            objTDDesc.TotalAmountDue = "0.00"
            objTDDesc.intEventId = "0"
            objTDDesc.strEventType = "NA"
            objTDDesc.strEventDesc = "NA"
            objTDDesc.curEventAmount = "0.00"
            objTDDesc.curTreatableAmount = "0.00"
            objTDDesc.strMessage = "NA"
            objTDDesc.dtmTransactionDate = New DateTime(1900, 1, 1)
            objTDDesc.applicableForView = "N"
            arrLstStatus.Add(objTDDesc)


            'arrStatusDesc = CType(arrLstStatus.ToArray(), TS_Response.TS_Status_Description())
            arrStatusDesc = CType(arrLstStatus.ToArray(GetType(TD_Response.TD_Status_Description)), TD_Response.TD_Status_Description())

            ResponseStatus = New TD_Response_Status


        End Sub


    End Class

#End Region



#Region "RMICW Request Web Service"

    <Serializable()> _
    Public Class RMICWRequestWS_Input
        Public strRegionId As String		
		Public strVisionCustomerId As String
        Public strVisionAccountId As String
        Public strAcctNum As String
        Public strBTNNum As String
        Public strOrg As String
        Public strClass As String
        Public strRequestActnType As String
        Public strRequestActn As String
        Public strSBMAcctNum As String
        Public strOriginationId As String
        Public strApplicationId As String
        Public strLogonId As String
        Public strRestoreFeeInd As String
        Public strNotationCd As String
        Public strConditionCd As String
        Public strEnvironment As String

        ' added for RMVP
        Public strRemarks As String = ""
        Public strReturnCD As String = ""


        Public Sub New()
			strAcctNum = ""
            strBTNNum = ""
            strVisionCustomerId = ""
            strVisionAccountId = ""
        End Sub
        Public Function getInput() As String

            Dim strValue = ""
            strValue += "RegionId:" & CheckValue(strRegionId)
            strValue += " Acct:" & CheckValue(strAcctNum)
            strValue += " BTN:" & CheckValue(strBTNNum)
            strValue += " Org:" & CheckValue(strOrg)
            strValue += " Class:" & CheckValue(strClass)
            strValue += " ActnType:" & CheckValue(strRequestActnType)
            strValue += " Actn:" & CheckValue(strRequestActn)
            strValue += " SBM:" & CheckValue(strSBMAcctNum)
            strValue += " Origination:" & CheckValue(strOriginationId)
            strValue += " Notation:" & CheckValue(strNotationCd)
            strValue += " ConditionCd:" & CheckValue(strConditionCd)
            strValue += " RstFee:" & CheckValue(strRestoreFeeInd)
            strValue += " Env: " & CheckValue(strEnvironment)


            Return strValue
        End Function

        Public Function CheckValue(ByVal strValue As String) As String


            If (strValue Is Nothing) Then
                Return " "
            Else
                Return strValue
            End If
        End Function



    End Class

    <Serializable()> _
    Public Class RMICWRequestWS_Output
        Public strAcctNum As String
        Public intRequestId As String
        Public strActn As String
        Public strMessageId As String
        Public strMessageDescription As String
        Public strRegionId As String

        Public Sub New()
            strMessageId = " "
            strMessageDescription = " "
        End Sub

    End Class

    <Serializable()> _
    Public Class ResultResponseWS_Input
        Public strRegionId As String
        Public intRequestId As String
        Public strAcctNum As String
        Public strApplicationId As String

    End Class

    <Serializable()> _
    Public Class ResultResponseWS_Output
        Public strStatusCd As String
        Public Response() As ResponseDetails
        Public OrderInformation() As OrderDetails

        Public Class ResponseDetails
            Public strAcctNum As String
            Public intRequestId As Long
            Public strActn As String
            Public dtmPrcsdTs As DateTime
            Public strStatusCd As String
            Public strReturnCd As String
            Public strReturnCdDesc As String
        End Class

        Public Class OrderDetails
            Public strOrderId As String
            Public strActn As String
            Public strOrderType As String
            Public strOrderStatusCd As String
        End Class

        Public strMessageId As String
        Public strMessageDescription As String

        Public Sub New()
            strMessageId = " "
            strMessageDescription = " "

        End Sub
    End Class
#End Region
#Region "get SSP URLt"
    Public Class wsGETURL
        Public Function getSSPURL(ByVal strRegionID As String, ByVal strParmName As String) As String
            Dim strURL As String = ""
            Dim strCntl As String = "Control" + strRegionID


            Dim WSDataAccessObj As WSDataAccessGeneric = New WSDataAccessGeneric(strRegionID)
            strURL = WSDataAccessObj.usp_GetControlParmByName(strCntl, strParmName)
            Return strURL
        End Function

#Region "get NSOP OrderImage URLt"
        Public Function getNSOPURL(ByVal strRegionID As String, ByVal strParmName As String) As String
            Dim strURL As String = ""
            Dim strCntl As String = "Control" + strRegionID

            Dim WSDataAccessObj As WSDataAccessGeneric = New WSDataAccessGeneric(strRegionID)
            strURL = WSDataAccessObj.usp_GetControlParmByName(strCntl, strParmName)
            Return strURL
        End Function
#End Region


        Public Function getWSRefActn(ByVal strRegionID As String, ByVal strType As String) As String
            Dim strREFActn As String = ""
            Dim strCntl As String = "Control" + strRegionID


            Dim WSDataAccessObj As WSDataAccessGeneric = New WSDataAccessGeneric(strRegionID)
            strREFActn = WSDataAccessObj.usp_GetRefAction(strRegionID, strType)
            Return strREFActn
        End Function



    End Class










#End Region

#Region "Product Status Request "
    <Serializable()> _
  Public Class ProductStatus_Request
        Public strRegionId As String
        Public strAcctNum As String
        Public strFIOSInd As String

        Public Sub New()
            strRegionId = " "
            strFIOSInd = "N"
        End Sub
    End Class

#End Region
    Public Enum ProductBucketStatus
        Live
        Denied
        Terminated
        NA
    End Enum

#Region "Product status_Response class "
    <Serializable()> _
    Public Class ProductStatus_Response

        Private Const cstMsgInvRegion As String = "Invalid RegionId Specified"
        Private Const cstMsgInvOrg As String = "Org Need to be specified"
        Private Const cstMsgRequestType As String = "Request Type should be A or B"
        Private Const cstMsgDBFailure As String = "Database Failure, Internal Error."


        Public strRegionId As String
        Public strAcctNum As String
        Public strDTVNum As String
        Public strDTVTreatmentStatus As String
        Public strVZWNum As String
        Public strVZWTreatmentStatus As String
        Public strProfileCAN As String
        Public strSSPBAN As String
        Public strSSPAcctID As String
        Public strVideoCAN As String
        Public arrStatusDesc() As Product_Status_Description
        Public ResponseStatus As Product_Response_Status


        Public Sub New()

            Dim arrLstStatus As ArrayList = New ArrayList
            arrStatusDesc = CType(arrLstStatus.ToArray(GetType(ProductStatus_Response.Product_Status_Description)), ProductStatus_Response.Product_Status_Description())
            ResponseStatus = New Product_Response_Status

        End Sub

        <Serializable()> _
        Public Class Product_Status_Description
            Public strProductName As String
            Public strTrtStatus As String
            Public strTrtDesc As String
            Public dtmBeginDate As DateTime
            Public dtmEndDate As DateTime
        End Class

        <Serializable()> _
        Public Class Product_Response_Status

            Public strMessageId As String
            Public strMessageDescription As String

            Public Sub New()
                strMessageId = " "
                strMessageDescription = " "

            End Sub
        End Class

        Public Sub InitializeDTV(ByVal strRegionId As String)

            Dim arrLstStatus As ArrayList = New ArrayList
            Dim objProdStatusDesc As ProductStatus_Response.Product_Status_Description = New ProductStatus_Response.Product_Status_Description

            objProdStatusDesc.strProductName = "DTV"
            objProdStatusDesc.strTrtDesc = "LIVE"
            objProdStatusDesc.dtmBeginDate = New DateTime(1900, 1, 1)
            objProdStatusDesc.dtmEndDate = objProdStatusDesc.dtmBeginDate.AddHours(4)
            arrLstStatus.Add(objProdStatusDesc)

            arrStatusDesc = CType(arrLstStatus.ToArray(GetType(ProductStatus_Response.Product_Status_Description)), ProductStatus_Response.Product_Status_Description())

            ResponseStatus = New Product_Response_Status


        End Sub

        Public Sub InitializeVZW(ByVal strRegionId As String)

            Dim arrLstStatus As ArrayList = New ArrayList
            Dim objProdStatusDesc As ProductStatus_Response.Product_Status_Description = New ProductStatus_Response.Product_Status_Description

            objProdStatusDesc.strProductName = "VZW"
            objProdStatusDesc.strTrtDesc = "LIVE"
            objProdStatusDesc.dtmBeginDate = New DateTime(1900, 1, 1)
            objProdStatusDesc.dtmEndDate = objProdStatusDesc.dtmBeginDate.AddHours(4)
            arrLstStatus.Add(objProdStatusDesc)

            arrStatusDesc = CType(arrLstStatus.ToArray(GetType(ProductStatus_Response.Product_Status_Description)), ProductStatus_Response.Product_Status_Description())

            ResponseStatus = New Product_Response_Status


        End Sub

        Public Sub Initialize(ByVal strRegionId As String)

            Dim arrLstStatus As ArrayList = New ArrayList
            Dim objProdStatusDesc As ProductStatus_Response.Product_Status_Description = New ProductStatus_Response.Product_Status_Description

            objProdStatusDesc.strProductName = "VZW"
            objProdStatusDesc.strTrtDesc = "LIVE"
            objProdStatusDesc.dtmBeginDate = New DateTime(1900, 1, 1)
            objProdStatusDesc.dtmEndDate = objProdStatusDesc.dtmBeginDate.AddHours(4)
            arrLstStatus.Add(objProdStatusDesc)

            objProdStatusDesc = New ProductStatus_Response.Product_Status_Description
            objProdStatusDesc.strProductName = "DTV"
            objProdStatusDesc.strTrtDesc = "LIVE"
            objProdStatusDesc.dtmBeginDate = New DateTime(1900, 1, 1)
            objProdStatusDesc.dtmEndDate = objProdStatusDesc.dtmBeginDate.AddHours(4)
            arrLstStatus.Add(objProdStatusDesc)

            arrStatusDesc = CType(arrLstStatus.ToArray(GetType(ProductStatus_Response.Product_Status_Description)), ProductStatus_Response.Product_Status_Description())

            ResponseStatus = New Product_Response_Status


        End Sub



    End Class

#End Region

#Region "Wirelss1Bill status Request "
    <Serializable()> _
  Public Class W1B_Request
        Public strRegionId As String
        Public strAcctNum As String

        Public Sub New()
            strRegionId = " "
        End Sub
    End Class

#End Region
#Region "Wireless1Bill status_Response class "
    <Serializable()> _
    Public Class W1B_Response

        Private Const cstMsgInvRegion As String = "Invalid RegionId Specified"
        Private Const cstMsgInvOrg As String = "Org Need to be specified"
        Private Const cstMsgRequestType As String = "Request Type should be A or B"
        Private Const cstMsgDBFailure As String = "Database Failure, Internal Error."


        Public strRegionId As String
        Public strAcctNum As String
        Public strBTNNum As String
        Public strMTNNum As String
        Public strMANNum As String
        Public strOneBillBucketStatus As String
        'Public strWirelessBucketStatusInd As BucketStatus
        Public strFSCID As String
        Public strZipCd As String
        Public strCustcode As String
        Public strExpressId As String
        Public strCANNum As String
        Public strVZCAcctNum As String
        Public strQualification As String
        Public strResults As String
        Public strResultcode As String
        Public strMessage As String

        'Public arrStatusDesc() As W1B_Status_Description
        Public Treatment() As W1B_Status_Description
        Public ResponseStatus As W1B_Response_Status

        Public Sub New()

            Dim arrLstStatus As ArrayList = New ArrayList
            strBTNNum = " "
            Treatment = CType(arrLstStatus.ToArray(GetType(W1B_Response.W1B_Status_Description)), W1B_Response.W1B_Status_Description())
            ResponseStatus = New W1B_Response_Status

            'strWirelessBucketStatusInd = BucketStatus.Live
            'strOneBillBucketStatusInd = BucketStatus.Live

        End Sub

        <Serializable()> _
        Public Class W1B_Status_Description
            Public strStatus As String
            Public strReasonCd As String
            Public dtmBeginDate As DateTime
        End Class

        <Serializable()> _
        Public Class W1B_Response_Status

            Public strMessageId As String
            Public strMessageDescription As String

            Public Sub New()
                strMessageId = " "
                strMessageDescription = " "

            End Sub
        End Class

        Public Sub Initialize(ByVal strRegionId As String)


            'strWirelessBucketStatusInd = BucketStatus.Live
            'strOneBillBucketStatusInd = BucketStatus.Live
            strBTNNum = ""

            Dim arrLstStatus As ArrayList = New ArrayList
            Dim objW1BDesc As W1B_Response.W1B_Status_Description = New W1B_Response.W1B_Status_Description

            objW1BDesc.strStatus = "Live"
            objW1BDesc.strReasonCd = "Enrolled"
            objW1BDesc.dtmBeginDate = New DateTime(1900, 1, 1)
            arrLstStatus.Add(objW1BDesc)

            'arrStatusDesc = CType(arrLstStatus.ToArray(GetType(W1B_Response.W1B_Status_Description)), W1B_Response.W1B_Status_Description())
            Treatment = CType(arrLstStatus.ToArray(GetType(W1B_Response.W1B_Status_Description)), W1B_Response.W1B_Status_Description())

            ResponseStatus = New W1B_Response_Status


        End Sub


    End Class

#End Region

    Public Class wsLogInput

        Public Function CheckLogInput1(ByVal strRegionID As String, ByVal strXml As String, ByVal strAcctnum As String, ByVal strParm As String) As String
            Dim strURL As String = ""
            Dim strCntl As String = "Control" + strRegionID
            Dim strDirName As String = ""
            Dim strfname As String = ""
            strDirName = LogErrorFile.GetLogDirName()

            If (Not strDirName Is Nothing) Then

                strfname = strDirName + "RMICWws" + strParm.Trim() + "_" + strAcctnum.Trim() + "_" + ".xml"
                Dim fs As FileStream = New FileStream(strfname, FileMode.Create)
                fs.Dispose()
            End If
            
        End Function
    End Class

End Namespace
