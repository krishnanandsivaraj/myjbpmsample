
'******************************************************************************************************
'                                                                                                    *
'                               CHANGE MANANGEMENT                                                   *
'                                                                                                    *
'******************************************************************************************************
' Date      Author                  Purpose                                             Identified By   *
'******************************************************************************************************
'07/27/09   Rahman            *Commented For AAIS to Tunneling Communication method      see AR07272009

'12/15/09   Rahman             Modified the Method to Update AAIS Response to SopChild   see AR12152009
'                              Request

'
' ******************************************************************************************************      


Imports CommonLibrary
Imports IBM.Data.DB2
Imports System.Xml
Imports System.Net
Imports System.Net.Sockets
Imports System.Text
Imports System.Threading

Imports System.Xml.Serialization
Imports System.IO
Imports System.Text.RegularExpressions

Imports Microsoft.Web.Services2.Security
Imports Microsoft.Web.Services2
Imports Microsoft.Web.Services2.Dime




Namespace Verizon.RMICW.WebServices

    Public Class MessageRequestInp

        Public strRegionId As String
        Public intRequestId As Long
        Public strAcctNum As String
        Public strBTNNum As String
        Public strActn As String
        Public strOrg As String
        Public strDestSystem As String
        Public strOverrideFlag As String
        Public strNotationCd As String
        Public strSyncFlag As String
        Public strAppId As String
        Public strRemarks As String
        Public strParentChildInd As String
        Public blnRetryFeed As Boolean
        Public strEnvironment As String
    End Class


    Public Class MessageResponse

        Public strInpType As String
        Public intRequestId As Long
        Public intSOPRequestId As Long
        Public strCompleteInd As String

        <System.Xml.Serialization.XmlElement(ElementName:="MessageList", Type:=GetType(MessageDetails))> _
        Public MessageList As ArrayList

        Public RequestStatus As StatusOfRequest

        Public Sub New()
            RequestStatus = New StatusOfRequest
            MessageList = New ArrayList
            strCompleteInd = "Y"
        End Sub

    End Class

    Public Class MessageDetails
        Public strWTN As String
        Public intChildSOPRequestId As Long
        Public strStatusCd As String
        Public strMessageId As String
        Public strMessageDesc As String
        Public dtmPrcsdTs As DateTime

    End Class


    Public Class MessageRequestOut

        Public intRequestId As Long
        Public intSOPRequestId As Long
        Public strAcctNum As String
        Public strActn As String



        Public RequestStatus As StatusOfRequest

        Public Sub New()
            RequestStatus = New StatusOfRequest
        End Sub

    End Class

    Public Class MessagePrcsParm
        Public Request As MessageRequestInp
        Public intSOPRequestId As String
        Public intSOPChildRequestId As Long
        Public intAAISSyncStatus As Integer
        Public intAAISAsyncStatus As Integer
        Public strRequestFrom As String

    End Class



    Public Class AAISAccess
        Inherits RMICWWSBase




        Public Sub New(ByVal strRegionId As String)
            MyBase.New(strRegionId)
        End Sub

#Region "getMessageResponse"

        Public Function getMessageResponse(ByVal strRegionId As String, ByVal strInpType As String, ByVal intRequestId As Long) As MessageResponse

            Dim MsgResp As MessageResponse = New MessageResponse

            Try

                Select Case True

                    Case strRegionId Is Nothing Or strRegionId.Trim = ""
                        MsgResp.RequestStatus.strMessageId = "INVREGN"
                        MsgResp.RequestStatus.strMessageDescription = "Invalid Region Specified."
                        Return MsgResp

                    Case strInpType Is Nothing Or strInpType.Trim = ""
                        MsgResp.RequestStatus.strMessageId = "INVINPTY"
                        MsgResp.RequestStatus.strMessageDescription = "Invalid Input Type is specified."
                        Return MsgResp
                    Case intRequestId = 0
                        MsgResp.RequestStatus.strMessageId = "INVRQST"
                        MsgResp.RequestStatus.strMessageDescription = "Invalid Request Id specified."
                        Return MsgResp
                    Case (strInpType.Trim <> "RQST" And strInpType.Trim <> "TRACK")
                        MsgResp.RequestStatus.strMessageId = "INVINPTY"
                        MsgResp.RequestStatus.strMessageDescription = "Invalid Input Type is specified."
                        Return MsgResp
                End Select

                Dim ds As DataSet = MyBase.WSDataAccessObj.usp_GetMessageResponse(strInpType, intRequestId)
                Dim dt As DataTable
                Dim dr As DataRow
                Dim objMsgDetails As MessageDetails

                If MyBase.WSDataAccessObj.IsEmptyRecordSet(ds) Then

                    MsgResp.RequestStatus.strMessageId = "INVRQST"
                    MsgResp.RequestStatus.strMessageDescription = "RequestId passed : " & intRequestId.ToString & " Not Available."
                    Return MsgResp

                End If


                'For Each dt In ds.Tables
                'For Each dr In dt.Rows
                For j As Integer = 0 To ds.Tables.Count - 1
                    dt = ds.Tables(j)
                    For i As Integer = 0 To dt.Rows.Count - 1
                        dr = dt.Rows(i)
                        MsgResp.intRequestId = dr("intRequestId")
                        MsgResp.intSOPRequestId = dr("intSOPRequestId")
                        objMsgDetails = New MessageDetails
                        objMsgDetails.intChildSOPRequestId = dr("intSOPChildRequestId")
                        objMsgDetails.strStatusCd = dr("strStatusCd")
                        objMsgDetails.strMessageId = dr("strResultId")
                        objMsgDetails.strMessageDesc = dr("strResultDesc")
                        objMsgDetails.dtmPrcsdTs = dr("dtmPrcsdTs")
                        objMsgDetails.strWTN = dr("strWTN")


                        If (objMsgDetails.strStatusCd.Trim = "CP" Or objMsgDetails.strStatusCd.Trim = "SE") Then
                        Else
                            MsgResp.strCompleteInd = "N"
                        End If

                        MsgResp.MessageList.Add(objMsgDetails)

                    Next i
                Next j




            Catch ex As Exception

                LogErrorFile.WriteLog("RMICWWS-getMessageResponse", "Rqst: " & intRequestId & " Erroring Out " & ex.ToString)
                MsgResp.RequestStatus.strMessageId = "RMIEXPTN"
                MsgResp.RequestStatus.strMessageDescription = ex.ToString
            End Try
            Return MsgResp
        End Function

#End Region



#Region "submitMessageRequest"

        Public Function submitMessageRequest(ByVal Request As MessageRequestInp) As MessageRequestOut

            Dim RequestOut As MessageRequestOut = New MessageRequestOut

            If Request.strEnvironment Is Nothing Then
                Request.strEnvironment = ""
            End If

            Try

                Select Case True

                    Case Request.strRegionId Is Nothing Or Request.strRegionId.Trim = ""
                        RequestOut.RequestStatus.strMessageId = "INVRGNID"
                        RequestOut.RequestStatus.strMessageDescription = "Invalid Region Id passed."
                        Return RequestOut
                    Case Request.strAcctNum Is Nothing Or Request.strAcctNum.Trim = ""
                        RequestOut.RequestStatus.strMessageId = "INVACNBR"
                        RequestOut.RequestStatus.strMessageDescription = "Invalid Account Number passed as Input."
                        Return RequestOut
                    Case Request.strActn Is Nothing Or Request.strActn.Trim = ""
                        RequestOut.RequestStatus.strMessageId = "INVACTN"
                        RequestOut.RequestStatus.strMessageDescription = "Invalid Action Specified."
                        Return RequestOut

                    Case Request.strDestSystem Is Nothing Or Request.strDestSystem.Trim = ""
                        RequestOut.RequestStatus.strMessageId = "INVDEST"
                        RequestOut.RequestStatus.strMessageDescription = "Invalid Dest System specified."
                        Return RequestOut

                    Case Request.strOverrideFlag Is Nothing Or Request.strOverrideFlag.Trim = ""
                        RequestOut.RequestStatus.strMessageId = "INVOVFLG"
                        RequestOut.RequestStatus.strMessageDescription = "Invalid Override Flag."
                        Return RequestOut

                    Case (Request.strActn.Trim <> "S" And Request.strActn.Trim <> "R" And Request.strActn.Trim <> "TLD" And Request.strActn.Trim <> "TLR" And Request.strActn.Trim <> "RLS")
                        RequestOut.RequestStatus.strMessageId = "INVACTN"
                        RequestOut.RequestStatus.strMessageDescription = "Invalid Actn. Valid Actns are R, S, TLD, TLR and RLS."
                        Return RequestOut


                    Case (Request.strEnvironment Is Nothing Or Request.strEnvironment.Trim = "")
                        RequestOut.RequestStatus.strMessageId = "INVENV"
                        RequestOut.RequestStatus.strMessageDescription = "Invalid Environment."
                        Return RequestOut
                End Select

                Dim intAAISSyncStatus As Integer = 0
                Dim intAAISAsyncStatus As Integer = 0
                Dim intSkipRequest As Integer = 0

                Dim RetObjSOP As retSOPClass = MyBase.WSDataAccessObj.usp_CheckSOPRequest(Request.strRegionId, Request.intRequestId, Request.strAcctNum, Request.strBTNNum, Request.strActn, Request.strDestSystem, Request.strSyncFlag, Request.strNotationCd, Request.strRemarks, Request.strAppId, Request.strOverrideFlag, 0, intAAISSyncStatus, intAAISAsyncStatus, intSkipRequest, Request.strOrg, Request.strEnvironment)

                RequestOut.intSOPRequestId = RetObjSOP.intSOPRequestId
                intAAISSyncStatus = RetObjSOP.intAAISSyncStatus
                intAAISAsyncStatus = RetObjSOP.intAAISAsyncStatus
                intSkipRequest = RetObjSOP.intSkipRequest

                If (intSkipRequest = 1) Then
                    Return RequestOut
                End If


                Try
                    Dim MsgInp As MessagePrcsParm = New MessagePrcsParm
                    MsgInp.Request = Request
                    MsgInp.intSOPRequestId = RequestOut.intSOPRequestId
                    MsgInp.intAAISSyncStatus = intAAISSyncStatus
                    MsgInp.intAAISAsyncStatus = intAAISAsyncStatus
                    MsgInp.strRequestFrom = "ORIGINAL"

                    If (((Request.strSyncFlag.Trim = "Y") Or (Request.strSyncFlag.Trim = "T")) And (intAAISSyncStatus = 1)) Then
                        ProcessAAISRequest(MsgInp)
                    Else
                        If (((Request.strSyncFlag.Trim = "N") Or (Request.strSyncFlag.Trim = "F")) And (intAAISAsyncStatus = 1)) Then
                            ProcessAAISRequest(MsgInp)
                        End If
                    End If

                Catch ex As Exception
                    LogErrorFile.WriteLog("RMICW-AAISWS", ex.ToString)
                End Try



            Catch ex As Exception

                LogErrorFile.WriteLog("RMICWWS-SubmitMessageRequest", "AcctNum: " & Request.strAcctNum & " Erroring Out " & ex.ToString)
                RequestOut.RequestStatus.strMessageId = "RMIEXPTN"
                RequestOut.RequestStatus.strMessageDescription = ex.ToString
            End Try

            Return RequestOut
        End Function

#End Region


#Region "SubmitParentRequestForAAIS"


#End Region



#Region "SubmitChildRequestForAAISAsync"
        ''Communication Thru Tunnelling
        'Public Function SubmitChildRequestForAAISAsync(ByVal arrLstAAISRequest As ArrayList, ByVal reqType As AAISRequest) As String

        '    Dim intInpCount As Integer
        '    Dim intSuccessfulCount As Integer
        '    Dim intUnSuccessfulCount As Integer
        '    Dim client As AAISClient

        '    'if the BatchFlag is TRUE, call SubmitChildRequestForAAISSyncBatch
        '    'at present not using aaisbatch mode. so commented out.

        '    'Dim strBatchFlag As String = " "
        '    'strBatchFlag = MyBase.WSDataAccessObj.usp_GetControlParmByName("ControlWEST", "AAISBatchFlag")
        '    'If (strBatchFlag.Trim = "TRUE") Then
        '    '    Me.SubmitChildRequestForAAISSyncBatch(arrLstAAISRequest, reqType)
        '    '    Exit Function
        '    'End If


        '    Try

        '        If (arrLstAAISRequest Is Nothing Or arrLstAAISRequest.Count < 1) Then
        '            LogErrorFile.WriteLog("RMICWAAISClient", "No Request to Process")
        '            Return "Input Count is 0. No Requests to Process"
        '        End If


        '        intInpCount = arrLstAAISRequest.Count
        '        Dim ipHostInfo As IPHostEntry = Dns.Resolve(Dns.GetHostName())
        '        Dim clientIPAddr As IPAddress = ipHostInfo.AddressList(0)
        '        Dim strclientIPAddr = clientIPAddr.ToString



        '        'Dim AAISServerIP As String = MyBase.WSDataAccessObj.usp_GetControlParmByName("ControlWEST", "AAISIP")
        '        'Dim arrIP As String() = AAISServerIP.Split(",")
        '        'Dim AAISServer, AAISPort, RMICWServer, RMICWPort As String
        '        'Dim strMSg As String


        '        Dim RMICWServer, RMICWPort As String
        '        Dim strMSg As String

        '        RMICWServer = strclientIPAddr
        '        RMICWPort = "11000"

        '        RMICWServer = strclientIPAddr
        '        RMICWPort = "11000"

        '        'Select Case arrIP.Length
        '        '    Case 2
        '        '        AAISServer = arrIP(0)
        '        '        AAISPort = arrIP(1)
        '        '    Case 3
        '        '        AAISServer = arrIP(0)
        '        '        AAISPort = arrIP(1)
        '        '        If (arrIP(2).Trim = ".") Then
        '        '            RMICWServer = strclientIPAddr
        '        '        Else
        '        '            RMICWServer = arrIP(2)
        '        '        End If

        '        '    Case 4
        '        '        AAISServer = arrIP(0)
        '        '        AAISPort = arrIP(1)
        '        '        RMICWServer = arrIP(2)
        '        '        RMICWPort = arrIP(3)
        '        '    Case Else
        '        '        LogErrorFile.WriteLog("RMICW-AAIS WS", " Parm specified in the tControlParm for the Server and Port is not valid: " & AAISServerIP)
        '        'End Select




        '        Dim AAISReq As AAISRequest

        '        For Each AAISReq In arrLstAAISRequest
        '            MyBase.WSDataAccessObj.usp_UpdateChildRequest("STATUS", Long.Parse(AAISReq.strRequestId), "SV", "STUDSV00", " ", " ", "AAISWS")

        '            client = New AAISClient(MyBase.RegionId)
        '            'AAISReq.strAAISServerIP = AAISServer
        '            'AAISReq.strAAISPort = AAISPort
        '            'AAISReq.strRMiCWServerIP = RMICWServer
        '            'AAISReq.strRMICWServerPort = RMICWPort



        '            If (AAISReq.strRMiCWServerIP.Trim = "") Or (AAISReq.strRMiCWServerIP.Trim = ".") Then
        '                AAISReq.strRMiCWServerIP = RMICWServer
        '            End If

        '            If (AAISReq.strRMICWServerPort.Trim = "") Then
        '                AAISReq.strRMICWServerPort = RMICWPort
        '            End If

        '            Try
        '                client.StartClient(AAISReq)
        '                intSuccessfulCount += 1
        '            Catch ex As Exception

        '                intUnSuccessfulCount += 1
        '                LogErrorFile.WriteLog("AAISClient", ex.ToString())

        '            Finally
        '                If (Not client Is Nothing) Then
        '                    client.Dispose()
        '                End If

        '            End Try
        '        Next AAISReq



        '    Catch ex As Exception
        '        LogErrorFile.WriteLog("SubmitChildRequestForAAIS", ex.ToString())
        '    Finally

        '    End Try

        '    Return "InpCount: " & intInpCount.ToString & " Successful: " & intSuccessfulCount.ToString & " UnSuccessful: " & intUnSuccessfulCount.ToString()
        'End Function


        Public Function SubmitChildRequestForAAISAsync(ByVal arrLstAAISRequest As ArrayList, ByVal reqType As AAISRequest) As String

            Dim intInpCount As Integer
            Dim intSuccessfulCount As Integer
            Dim intUnSuccessfulCount As Integer



            Dim objTxnMGR As TransactionManagerService = New TransactionManagerService
            Dim objRequestContext As SoapContext
            Dim responseXml As String = ""
            Dim objarrLst As ArrayList = New ArrayList
            Dim AAISReq As AAISRequest
            Dim obRmicwRequestArray As RmicwRequestArray = New RmicwRequestArray
            Dim objTNSuspendRestoreRequest As TNSuspendRestoreRequest = New TNSuspendRestoreRequest


            Try

                If (arrLstAAISRequest Is Nothing Or arrLstAAISRequest.Count < 1) Then
                    LogErrorFile.WriteLog("RMICWAAISClient", "No Request to Process")
                    Return "Input Count is 0. No Requests to Process"
                End If


                intInpCount = arrLstAAISRequest.Count
                'RMICW CallBack URL
                'Dim strURL As String = "http://113.130.72.167/RMICWWebServices/WSMain.asmx"
                Dim strURL As String = MyBase.WSDataAccessObj.usp_GetControlParmByName("ControlWEST", "RMICWURL")





                'For Each AAISReq In arrLstAAISRequest
                For i As Integer = 0 To arrLstAAISRequest.Count - 1
                    AAISReq = arrLstAAISRequest(i)
                    MyBase.WSDataAccessObj.usp_UpdateChildRequest("STATUS", Long.Parse(AAISReq.strRequestId), "SV", "STUDSV00", " ", "", "", " ", "AAISWS")

                    objTNSuspendRestoreRequest = New TNSuspendRestoreRequest
                    obRmicwRequestArray.aaisActn = AAISReq.strAAISActn
                    obRmicwRequestArray.compCode = "F"
                    obRmicwRequestArray.requestID = AAISReq.strRequestId
                    obRmicwRequestArray.rmicwURL = strURL
                    obRmicwRequestArray.syncFlag = AAISReq.strSyncFlag
                    obRmicwRequestArray.wkgTN = AAISReq.strWTN
                    objarrLst.Add(obRmicwRequestArray)
                    obRmicwRequestArray = New RmicwRequestArray
                    objTNSuspendRestoreRequest.rmicwReq = objarrLst.ToArray(GetType(RmicwRequestArray))

                Next i


                Try


                    objRequestContext = objTxnMGR.RequestSoapContext
                    objTxnMGR.Proxy = New WebProxy
                    objRequestContext.Security.Tokens.Clear()
                    Dim unt As Tokens.UsernameToken = New Tokens.UsernameToken("RMW", "rmicw05", Tokens.PasswordOption.SendPlainText)
                    objRequestContext.Security.Tokens.Add(unt)
                    objRequestContext.Security.MustUnderstand = False

                    objTxnMGR.Url = MyBase.WSDataAccessObj.usp_GetControlParmByName("ControlWEST", "AAISWSURL")
                    objTxnMGR.Timeout = 60000
                    objTxnMGR.RequestSoapContext.Addressing.MustUnderstand = False
                    objTxnMGR.Timeout = 90000
                    objTxnMGR.suspendRestoreTN(objTNSuspendRestoreRequest)

                    intSuccessfulCount += 1
                Catch ex As Exception

                    intUnSuccessfulCount += 1
                    LogErrorFile.WriteLog("AAISWS", ex.ToString())

                Finally


                End Try


            Catch ex As Exception
                LogErrorFile.WriteLog("SubmitChildRequestForAAIS", ex.ToString())
            Finally

            End Try

            Return "InpCount: " & intInpCount.ToString & " Successful: " & intSuccessfulCount.ToString & " UnSuccessful: " & intUnSuccessfulCount.ToString()
        End Function
#End Region



#Region "SubmitChildRequestForAAISSyncMULTI"

        'Public Function SubmitChildRequestForAAISSyncMULTI(ByVal arrLstAAISRequest As ArrayList, ByVal reqType As AAISRequest) As String

        '    Dim intInpCount As Integer
        '    Dim intSuccessfulCount As Integer
        '    Dim intUnSuccessfulCount As Integer
        '    Dim client As AAISClient

        '    Try

        '        If (arrLstAAISRequest Is Nothing Or arrLstAAISRequest.Count < 1) Then
        '            LogErrorFile.WriteLog("RMICWAAISClient", "No Request to Process")
        '            Return "Input Count is 0. No Requests to Process"
        '        End If


        '        intInpCount = arrLstAAISRequest.Count
        '        Dim ipHostInfo As IPHostEntry = Dns.Resolve(Dns.GetHostName())
        '        Dim clientIPAddr As IPAddress = ipHostInfo.AddressList(0)
        '        Dim strclientIPAddr = clientIPAddr.ToString



        '        Dim AAISServerIP As String = MyBase.WSDataAccessObj.usp_GetControlParmByName("ControlWEST", "AAISIP")
        '        Dim arrIP As String() = AAISServerIP.Split(",")
        '        Dim AAISServer, AAISPort, RMICWServer, RMICWPort As String
        '        Dim strMSg As String

        '        RMICWServer = strclientIPAddr
        '        RMICWPort = "11000"

        '        Select Case arrIP.Length
        '            Case 2
        '                AAISServer = arrIP(0)
        '                AAISPort = arrIP(1)
        '            Case 3
        '                AAISServer = arrIP(0)
        '                AAISPort = arrIP(1)
        '                If (arrIP(2).Trim = ".") Then
        '                    RMICWServer = strclientIPAddr
        '                Else
        '                    RMICWServer = arrIP(2)
        '                End If

        '            Case 4
        '                AAISServer = arrIP(0)
        '                AAISPort = arrIP(1)
        '                RMICWServer = arrIP(2)
        '                RMICWPort = arrIP(3)
        '            Case Else
        '                LogErrorFile.WriteLog("RMICW-AAIS WS", " Parm specified in the tControlParm for the Server and Port is not valid: " & AAISServerIP)
        '        End Select



        '        Dim AAISReq As AAISRequest



        '        For Each AAISReq In arrLstAAISRequest
        '            MyBase.WSDataAccessObj.usp_UpdateChildRequest("STATUS", Long.Parse(AAISReq.strRequestId), "SV", "STUDSV00", " ", " ", "AAISWS")
        '            AAISReq.strAAISServerIP = AAISServer
        '            AAISReq.strAAISPort = AAISPort
        '            AAISReq.strRMiCWServerIP = RMICWServer
        '            AAISReq.strRMICWServerPort = RMICWPort

        '        Next AAISReq


        '        Try
        '            client = New AAISClient(MyBase.RegionId)
        '            client.SendRequestToAAISSyncMulti(arrLstAAISRequest(0), arrLstAAISRequest)
        '        Catch ex As Exception
        '            LogErrorFile.WriteLog("AAISClient", ex.ToString)
        '        Finally
        '            If Not client Is Nothing Then
        '                client.Dispose()
        '            End If

        '        End Try

        '    Catch ex As Exception
        '        LogErrorFile.WriteLog("SubmitChildRequestForAAIS", ex.ToString())
        '    Finally
        '    End Try

        '    Return " "
        'End Function

        Public Function SubmitChildRequestForAAISSyncMULTI(ByVal arrLstAAISRequest As ArrayList, ByVal reqType As AAISRequest) As String

            Dim intInpCount As Integer
            Dim intSuccessfulCount As Integer
            Dim intUnSuccessfulCount As Integer
            Dim client As AAISClient


            Dim objTxnMGR As TransactionManagerService = New TransactionManagerService
            Dim objRequestContext As SoapContext
            Dim responseXml As String = ""
            Dim objarrLst As ArrayList = New ArrayList
            Dim AAISReq As AAISRequest
            Dim obRmicwRequestArray As RmicwRequestArray = New RmicwRequestArray
            Dim objTNSuspendRestoreRequest As TNSuspendRestoreRequest = New TNSuspendRestoreRequest

            Try

                If (arrLstAAISRequest Is Nothing Or arrLstAAISRequest.Count < 1) Then
                    LogErrorFile.WriteLog("RMICWAAISClient", "No Request to Process")
                    Return "Input Count is 0. No Requests to Process"
                End If


                intInpCount = arrLstAAISRequest.Count
                'RMICW CallBack URL
                'Dim strURL As String = "http://113.130.72.167/RMICWWebServices/WSMain.asmx"
                Dim strURL As String = MyBase.WSDataAccessObj.usp_GetControlParmByName("ControlWEST", "RMICWURL")






                'For Each AAISReq In arrLstAAISRequest
                For i As Integer = 0 To arrLstAAISRequest.Count - 1
                    AAISReq = arrLstAAISRequest(i)
                    MyBase.WSDataAccessObj.usp_UpdateChildRequest("STATUS", Long.Parse(AAISReq.strRequestId), "SV", "STUDSV00", " ", "", "", " ", "AAISWS")

                    objTNSuspendRestoreRequest = New TNSuspendRestoreRequest
                    obRmicwRequestArray.aaisActn = AAISReq.strAAISActn
                    obRmicwRequestArray.compCode = "F"
                    obRmicwRequestArray.requestID = AAISReq.strRequestId
                    obRmicwRequestArray.rmicwURL = strURL
                    obRmicwRequestArray.syncFlag = AAISReq.strSyncFlag
                    obRmicwRequestArray.wkgTN = AAISReq.strWTN
                    objarrLst.Add(obRmicwRequestArray)
                    obRmicwRequestArray = New RmicwRequestArray
                    objTNSuspendRestoreRequest.rmicwReq = objarrLst.ToArray(GetType(RmicwRequestArray))

                Next i


                Try

                    objRequestContext = objTxnMGR.RequestSoapContext
                    objTxnMGR.Proxy = New WebProxy
                    objRequestContext.Security.Tokens.Clear()
                    Dim unt As Tokens.UsernameToken = New Tokens.UsernameToken("RMW", "rmicw05", Tokens.PasswordOption.SendPlainText)
                    objRequestContext.Security.Tokens.Add(unt)
                    objRequestContext.Security.MustUnderstand = False

                    objTxnMGR.Url = MyBase.WSDataAccessObj.usp_GetControlParmByName("ControlWEST", "AAISWSURL")
                    objTxnMGR.Timeout = 60000
                    objTxnMGR.RequestSoapContext.Addressing.MustUnderstand = False
                    objTxnMGR.Timeout = 90000
                    objTxnMGR.suspendRestoreTN(objTNSuspendRestoreRequest)


                Catch ex As Exception
                    LogErrorFile.WriteLog("AAISClient", ex.ToString)
                Finally
                    If Not client Is Nothing Then
                        client.Dispose()
                    End If

                End Try

            Catch ex As Exception
                LogErrorFile.WriteLog("SubmitChildRequestForAAIS", ex.ToString())
            Finally
            End Try

            Return " "
        End Function

#End Region

#Region "SubmitChildRequestForAAISSyncBatch"

        'AAIS Communication thru Tunneling
        'Public Function SubmitChildRequestForAAISSyncBatch(ByVal arrLstAAISRequest As ArrayList, ByVal reqType As AAISRequest) As String

        '    Dim intInpCount As Integer
        '    Dim intSuccessfulCount As Integer
        '    Dim intUnSuccessfulCount As Integer
        '    Dim client As AAISClient

        '    Try

        '        If (arrLstAAISRequest Is Nothing Or arrLstAAISRequest.Count < 1) Then
        '            LogErrorFile.WriteLog("RMICWAAISClient", "No Request to Process")
        '            Return "Input Count is 0. No Requests to Process"
        '        End If


        '        intInpCount = arrLstAAISRequest.Count
        '        Dim ipHostInfo As IPHostEntry = Dns.Resolve(Dns.GetHostName())
        '        Dim clientIPAddr As IPAddress = ipHostInfo.AddressList(0)
        '        Dim strclientIPAddr = clientIPAddr.ToString



        '        Dim AAISServerIP As String = MyBase.WSDataAccessObj.usp_GetControlParmByName("ControlWEST", "AAISIP")
        '        Dim arrIP As String() = AAISServerIP.Split(",")
        '        Dim AAISServer, AAISPort, RMICWServer, RMICWPort As String
        '        Dim strMSg As String

        '        RMICWServer = strclientIPAddr
        '        RMICWPort = "11000"

        '        Select Case arrIP.Length
        '            Case 2
        '                AAISServer = arrIP(0)
        '                AAISPort = arrIP(1)
        '            Case 3
        '                AAISServer = arrIP(0)
        '                AAISPort = arrIP(1)
        '                If (arrIP(2).Trim = ".") Then
        '                    RMICWServer = strclientIPAddr
        '                Else
        '                    RMICWServer = arrIP(2)
        '                End If

        '            Case 4
        '                AAISServer = arrIP(0)
        '                AAISPort = arrIP(1)
        '                RMICWServer = arrIP(2)
        '                RMICWPort = arrIP(3)
        '            Case Else
        '                LogErrorFile.WriteLog("RMICW-AAIS WS", " Parm specified in the tControlParm for the Server and Port is not valid: " & AAISServerIP)
        '        End Select



        '        Dim AAISReq As AAISRequest



        '        For Each AAISReq In arrLstAAISRequest
        '            MyBase.WSDataAccessObj.usp_UpdateChildRequest("STATUS", Long.Parse(AAISReq.strRequestId), "SV", "STUDSV00", " ", " ", "AAISWS")
        '            AAISReq.strAAISServerIP = AAISServer
        '            AAISReq.strAAISPort = AAISPort
        '            AAISReq.strRMiCWServerIP = RMICWServer
        '            AAISReq.strRMICWServerPort = RMICWPort

        '        Next AAISReq


        '        Try
        '            client = New AAISClient(MyBase.RegionId)
        '            client.SendRequestToAAISSyncBatch(arrLstAAISRequest(0), arrLstAAISRequest)
        '        Catch ex As Exception
        '            LogErrorFile.WriteLog("AAISClient", ex.ToString)
        '        Finally
        '            If Not client Is Nothing Then
        '                client.Dispose()
        '            End If

        '        End Try

        '    Catch ex As Exception
        '        LogErrorFile.WriteLog("SubmitChildRequestForAAIS", ex.ToString())
        '    Finally
        '    End Try

        '    Return " "
        'End Function




        Public Function SubmitChildRequestForAAISSyncBatch(ByVal arrLstAAISRequest As ArrayList, ByVal reqType As AAISRequest) As String

            Dim intInpCount As Integer
            Dim intSuccessfulCount As Integer
            Dim intUnSuccessfulCount As Integer


            Dim objTxnMGR As TransactionManagerService = New TransactionManagerService
            Dim objRequestContext As SoapContext
            Dim responseXml As String = ""
            Dim objarrLst As ArrayList = New ArrayList
            Dim AAISReq As AAISRequest
            Dim obRmicwRequestArray As RmicwRequestArray = New RmicwRequestArray
            Dim objTNSuspendRestoreRequest As TNSuspendRestoreRequest = New TNSuspendRestoreRequest



            Try

                If (arrLstAAISRequest Is Nothing Or arrLstAAISRequest.Count < 1) Then
                    LogErrorFile.WriteLog("RMICWAAISClient", "No Request to Process")
                    Return "Input Count is 0. No Requests to Process"
                End If


                intInpCount = arrLstAAISRequest.Count
                'RMICW CallBack URL
                'Dim strURL As String = "http://113.130.72.167/RMICWWebServices/WSMain.asmx"
                Dim strURL As String = MyBase.WSDataAccessObj.usp_GetControlParmByName("ControlWEST", "RMICWURL")


                'For Each AAISReq In arrLstAAISRequest
                For i As Integer = 0 To arrLstAAISRequest.Count - 1
                    AAISReq = arrLstAAISRequest(i)
                    MyBase.WSDataAccessObj.usp_UpdateChildRequest("STATUS", Long.Parse(AAISReq.strRequestId), "SV", "STUDSV00", " ", "", "", " ", "AAISWS")

                    objTNSuspendRestoreRequest = New TNSuspendRestoreRequest
                    obRmicwRequestArray.aaisActn = AAISReq.strAAISActn
                    obRmicwRequestArray.compCode = "F"
                    obRmicwRequestArray.requestID = AAISReq.strRequestId
                    obRmicwRequestArray.rmicwURL = strURL
                    obRmicwRequestArray.syncFlag = AAISReq.strSyncFlag
                    obRmicwRequestArray.wkgTN = AAISReq.strWTN
                    objarrLst.Add(obRmicwRequestArray)
                    obRmicwRequestArray = New RmicwRequestArray
                    objTNSuspendRestoreRequest.rmicwReq = objarrLst.ToArray(GetType(RmicwRequestArray))

                Next i


                Try

                    objRequestContext = objTxnMGR.RequestSoapContext
                    objTxnMGR.Proxy = New WebProxy
                    objRequestContext.Security.Tokens.Clear()
                    Dim unt As Tokens.UsernameToken = New Tokens.UsernameToken("RMW", "rmicw05", Tokens.PasswordOption.SendPlainText)
                    objRequestContext.Security.Tokens.Add(unt)
                    objRequestContext.Security.MustUnderstand = False

                    objTxnMGR.Url = MyBase.WSDataAccessObj.usp_GetControlParmByName("ControlWEST", "AAISWSURL")
                    objTxnMGR.Timeout = 60000
                    objTxnMGR.RequestSoapContext.Addressing.MustUnderstand = False
                    objTxnMGR.Timeout = 90000
                    objTxnMGR.suspendRestoreTN(objTNSuspendRestoreRequest)

                Catch ex As Exception
                    LogErrorFile.WriteLog("AAISClient", ex.ToString)
                Finally


                End Try

            Catch ex As Exception
                LogErrorFile.WriteLog("SubmitChildRequestForAAIS", ex.ToString())
            Finally
            End Try

            Return " "
        End Function

#End Region

#Region "SubmitChildRequestForAAIS"

#Region "Rmicw to AAIS Communication thru Tunneling "   'AR 07.31.09

        'Public Function SubmitChildRequestForAAIS(ByVal arrLstAAISRequest As ArrayList, ByVal reqType As AAISRequest) As String

        '    Dim intInpCount As Integer
        '    Dim intSuccessfulCount As Integer
        '    Dim intUnSuccessfulCount As Integer
        '    Dim client As AAISClient


        '    Try

        '        If (arrLstAAISRequest Is Nothing Or arrLstAAISRequest.Count < 1) Then
        '            LogErrorFile.WriteLog("RMICWAAISClient", "No Request to Process")
        '            Return "Input Count is 0. No Requests to Process"
        '        End If

        '        intInpCount = arrLstAAISRequest.Count
        '        Dim ipHostInfo As IPHostEntry = Dns.Resolve(Dns.GetHostName())
        '        Dim clientIPAddr As IPAddress = ipHostInfo.AddressList(0)
        '        Dim strclientIPAddr = clientIPAddr.ToString

        '        Dim RMICWServer, RMICWPort As String
        '        Dim strMSg As String

        '        RMICWServer = strclientIPAddr
        '        RMICWPort = "11000"

        '        Dim AAISReq As AAISRequest

        '        client = New AAISClient(MyBase.RegionId)
        '        For Each AAISReq In arrLstAAISRequest

        '            MyBase.WSDataAccessObj.usp_UpdateChildRequest("STATUS", Long.Parse(AAISReq.strRequestId), "SV", "STUDSV00", " ", " ", "AAISWS")

        '            If (AAISReq.strRMiCWServerIP.Trim = "") Or (AAISReq.strRMiCWServerIP.Trim = ".") Then
        '                AAISReq.strRMiCWServerIP = RMICWServer
        '            End If

        '            If (AAISReq.strRMICWServerPort.Trim = "") Then
        '                AAISReq.strRMICWServerPort = RMICWPort
        '            End If
        '            Try
        '                client.StartClientSync(AAISReq)
        '                intSuccessfulCount += 1
        '            Catch ex As Exception
        '                intUnSuccessfulCount += 1
        '                LogErrorFile.WriteLog("AAISClient", ex.ToString())

        '            End Try
        '        Next AAISReq

        '    Catch ex As Exception
        '        LogErrorFile.WriteLog("SubmitChildRequestForAAIS", ex.ToString())
        '    Finally
        '        If (Not client Is Nothing) Then
        '            client.Dispose()
        '        End If
        '    End Try

        '    Return "InpCount: " & intInpCount.ToString & " Successful: " & intSuccessfulCount.ToString & " UnSuccessful: " & intUnSuccessfulCount.ToString()
        'End Function
#End Region

        ' Rmicw to AAIS Communication thru WebService "   'AR 07.31.09

        Public Function SubmitChildRequestForAAIS(ByVal arrLstAAISRequest As ArrayList, ByVal reqType As AAISRequest) As String

            Dim intInpCount As Integer
            Dim intSuccessfulCount As Integer
            Dim intUnSuccessfulCount As Integer


            Dim objTxnMGR As TransactionManagerService = New TransactionManagerService
            Dim objRequestContext As SoapContext
            Dim responseXml As String = ""
            Dim objarrLst As ArrayList = New ArrayList
            Dim AAISReq As AAISRequest
            Dim obRmicwRequestArray As RmicwRequestArray = New RmicwRequestArray
            Dim objTNSuspendRestoreRequest As TNSuspendRestoreRequest = New TNSuspendRestoreRequest
            Dim sw As New StringWriter
            Dim strAAISInputXML As String


            Try
                If (arrLstAAISRequest Is Nothing Or arrLstAAISRequest.Count < 1) Then
                    LogErrorFile.WriteLog("RMICWAAISClient", "No Request to Process")
                    Return "Input Count is 0. No Requests to Process"
                End If

                'RMICW CallBack URL
                'Dim strURL As String = "http://113.130.72.167/RMICWWebServices/WSMain.asmx"
                Dim strURL As String = MyBase.WSDataAccessObj.usp_GetControlParmByName("ControlWEST", "RMICWURL")


                'For Each AAISReq In arrLstAAISRequest
                For i As Integer = 0 To arrLstAAISRequest.Count - 1
                    AAISReq = arrLstAAISRequest(i)
                    MyBase.WSDataAccessObj.usp_UpdateChildRequest("STATUS", Long.Parse(AAISReq.strRequestId), "SV", "STUDSV00", " ", "", "", " ", "AAISWS")

                    objTNSuspendRestoreRequest = New TNSuspendRestoreRequest
                    obRmicwRequestArray.aaisActn = AAISReq.strAAISActn
                    obRmicwRequestArray.compCode = "F"
                    obRmicwRequestArray.requestID = AAISReq.strRequestId
                    obRmicwRequestArray.rmicwURL = strURL
                    obRmicwRequestArray.syncFlag = AAISReq.strSyncFlag
                    obRmicwRequestArray.wkgTN = AAISReq.strWTN
                    objarrLst.Add(obRmicwRequestArray)
                    obRmicwRequestArray = New RmicwRequestArray
                    objTNSuspendRestoreRequest.rmicwReq = objarrLst.ToArray(GetType(RmicwRequestArray))
                Next i


                Try
                    'fnSendAAISRequest(AAISReq)

                    objRequestContext = objTxnMGR.RequestSoapContext
                    objTxnMGR.Proxy = New WebProxy
                    objRequestContext.Security.Tokens.Clear()
                    Dim unt As Tokens.UsernameToken = New Tokens.UsernameToken("RMW", "rmicw05", Tokens.PasswordOption.SendPlainText)
                    objRequestContext.Security.Tokens.Add(unt)
                    objRequestContext.Security.MustUnderstand = False



                    If Not AAISReq.strAAISServerIP.ToString() Is Nothing Then
                        objTxnMGR.Url = AAISReq.strAAISServerIP.ToString()
                    Else
                        objTxnMGR.Url = MyBase.WSDataAccessObj.usp_GetControlParmByName("ControlWEST", "AAIS-WS-TPA")
                    End If

                    objTxnMGR.Timeout = 60000
                    objTxnMGR.RequestSoapContext.Addressing.MustUnderstand = False
                    objTxnMGR.Timeout = 90000
                    ServicePointManager.ServerCertificateValidationCallback = New Net.Security.RemoteCertificateValidationCallback(AddressOf DTVPolicy.ValidateServerCertificate)


                    Dim ser As New XmlSerializer(objTNSuspendRestoreRequest.GetType)
                    ser.Serialize(sw, objTNSuspendRestoreRequest)
                    strAAISInputXML = sw.ToString()

                    'LogErrorFile.WriteLog("RMICWWS-AAISInputXML", strAAISInputXML)

                    fnLoggingAAIS(AAISReq.strAcctNum, AAISReq.strAAISActn, AAISReq.strRequestId, strAAISInputXML, "I")

                    objTxnMGR.suspendRestoreTN(objTNSuspendRestoreRequest)
                    intSuccessfulCount += 1
                Catch ex As Exception
                    intUnSuccessfulCount += 1
                    LogErrorFile.WriteLog("AAISClient", ex.ToString())
                End Try


                'fnSendMultipleRequest(arrLstAAISRequest, AAISReq)
            Catch ex As Exception
                LogErrorFile.WriteLog("SubmitChildRequestForAAIS", ex.ToString())
            Finally
            End Try

            Return "InpCount: " & intInpCount.ToString & " Successful: " & intSuccessfulCount.ToString & " UnSuccessful: " & intUnSuccessfulCount.ToString()
        End Function

        Public Function fnLoggingAAIS(ByVal strAcctnum As String, ByVal strActn As String, ByVal strRequestid As String, ByVal strAAISxml As String, ByVal strType As String) As Object

            If (MyBase.WSDataAccessObj.usp_GetControlParmByName("ControlWEST", "LOGGINGAAIS").Trim() = "TRUE") Then
                Try
                    WSDataAccessObj.usp_InserttAuditLog("AAIS", strType, strAcctnum, strActn, "NA", "NA", "NA", strRequestid, 0, strAAISxml.Trim(), "WebSvc")
                Catch exfnLoggingAAIS As Exception
                    LogErrorFile.WriteLog("fnLoggingAAIS", exfnLoggingAAIS.ToString())
                End Try

            End If
            Return Nothing
        End Function

#End Region

#Region "RMICW to AAIS Communucation thru Tunnelling"   ' AR07272009

        'Public Function ProcessAAISRequest(ByVal MsgInp As MessagePrcsParm) As StatusOfRequest

        '    Dim strReturnMsg As String = ""
        '    Dim RequestStatus As StatusOfRequest = New StatusOfRequest
        '    Dim dtmDefaultEndDate As DateTime = New DateTime(9998, 12, 31)
        '    If MsgInp.strRequestFrom Is Nothing Then
        '        MsgInp.strRequestFrom = ""
        '    End If


        '    Try


        '        Dim objERAAccess As CBSSERAAccess = New CBSSERAAccess(MsgInp.Request.strRegionId)
        '        Dim AcctInfo As AcctLineLevelInfo
        '        Dim LineInfo As LineLevelInfo
        '        Dim intSOPChildRequest As Long


        '        Dim ipHostInfo As IPHostEntry = Dns.GetHostEntry(Dns.GetHostName())
        '        Dim clientIPAddr As IPAddress = ipHostInfo.AddressList(0)
        '        Dim strclientIPAddr As String = clientIPAddr.ToString

        '        Dim client As AAISClient
        '        Dim AAISServerIP As String = MyBase.WSDataAccessObj.usp_GetEnvironment("WEST", MsgInp.Request.strAcctNum, "AAIS")
        '        Dim AAISServer, AAISPort, RMICWServer, RMICWPort As String

        '        Dim strMSg As String
        '        strReturnMsg = " "

        '        RMICWServer = strclientIPAddr
        '        RMICWPort = "11000"

        '        Dim arrIPs As String() = AAISServerIP.Split("#")
        '        Dim arrIP As String()

        '        If (arrIPs.Length > 0) Then
        '            arrIP = arrIPs(arrIPs.Length - 1).Split(",")
        '            Select Case arrIP.Length
        '                Case 2
        '                    AAISServer = arrIP(0)
        '                    AAISPort = arrIP(1)
        '                Case 3
        '                    AAISServer = arrIP(0)
        '                    AAISPort = arrIP(1)
        '                    If (arrIP(2).Trim = ".") Then
        '                        RMICWServer = strclientIPAddr
        '                    Else
        '                        RMICWServer = arrIP(2)
        '                    End If

        '                Case 4
        '                    AAISServer = arrIP(0)
        '                    AAISPort = arrIP(1)
        '                    If (arrIP(2).Trim = ".") Then
        '                        RMICWServer = strclientIPAddr
        '                    Else
        '                        RMICWServer = arrIP(2)
        '                    End If
        '                    RMICWPort = arrIP(3)
        '                Case Else
        '                    LogErrorFile.WriteLog("RMICW-AAIS WS", " Parm specified in the tControlParm for the Server and Port is not valid: " & AAISServerIP)
        '            End Select
        '        Else
        '            LogErrorFile.WriteLog("RMICW-AAIS WS", " Parm specified in the tControlParm for the Server and Port is not valid: " & AAISServerIP)
        '        End If

        '        AcctInfo = objERAAccess.getCBSS_AcctLineInfo(MsgInp.Request.strRegionId, MsgInp.Request.strAcctNum)

        '        If (AcctInfo.RequestStatus.strMessageId.Trim = "") Then

        '            For Each LineInfo In AcctInfo.arrLstLineDetails

        '                Dim strNXX As String = ""
        '                If LineInfo.strTelephoneNo.Length > 6 Then
        '                    strNXX = LineInfo.strTelephoneNo.Substring(3, 3)
        '                End If

        '                Select Case True
        '                    Case LineInfo.strIlIxCrrStCd.Trim = "R" And LineInfo.strIlPreStCd.Trim = "R"
        '                        intSOPChildRequest = MyBase.WSDataAccessObj.usp_InsertSOPChildRequest(MsgInp.intSOPRequestId, MsgInp.Request.strAcctNum, LineInfo.strTelephoneNo, MsgInp.Request.strActn, "SP", "SMRTRNG", MsgInp.Request.strNotationCd, " ", " ", 0)
        '                    Case LineInfo.strSmrgAssocInd.Trim() = "Y"
        '                        intSOPChildRequest = MyBase.WSDataAccessObj.usp_InsertSOPChildRequest(MsgInp.intSOPRequestId, MsgInp.Request.strAcctNum, LineInfo.strTelephoneNo, MsgInp.Request.strActn, "SP", "SMRTRNG", MsgInp.Request.strNotationCd, " ", " ", 0)
        '                    Case LineInfo.dtmSubAccountTermDate < dtmDefaultEndDate
        '                        intSOPChildRequest = MyBase.WSDataAccessObj.usp_InsertSOPChildRequest(MsgInp.intSOPRequestId, MsgInp.Request.strAcctNum, LineInfo.strTelephoneNo, MsgInp.Request.strActn, "SP", "ACCTTRMD", MsgInp.Request.strNotationCd, " ", " ", 0)
        '                    Case LineInfo.strDerivedClecLineType.Trim = "O"
        '                        intSOPChildRequest = MyBase.WSDataAccessObj.usp_InsertSOPChildRequest(MsgInp.intSOPRequestId, MsgInp.Request.strAcctNum, LineInfo.strTelephoneNo, MsgInp.Request.strActn, "SP", "PRTDOUT", MsgInp.Request.strNotationCd, " ", " ", 0)
        '                    Case LineInfo.strTelephoneNo.StartsWith("800") Or LineInfo.strTelephoneNo.StartsWith("888") Or LineInfo.strTelephoneNo.StartsWith("877") Or LineInfo.strTelephoneNo.StartsWith("866") Or LineInfo.strTelephoneNo.StartsWith("855")
        '                        intSOPChildRequest = MyBase.WSDataAccessObj.usp_InsertSOPChildRequest(MsgInp.intSOPRequestId, MsgInp.Request.strAcctNum, LineInfo.strTelephoneNo, MsgInp.Request.strActn, "SP", "TOLLNUM", MsgInp.Request.strNotationCd, " ", " ", 0)

        '                        'if NPA or NXX starts with 0, it's fict num
        '                    Case LineInfo.strTelephoneNo.StartsWith("0") Or strNXX.StartsWith("0")
        '                        intSOPChildRequest = MyBase.WSDataAccessObj.usp_InsertSOPChildRequest(MsgInp.intSOPRequestId, MsgInp.Request.strAcctNum, LineInfo.strTelephoneNo, MsgInp.Request.strActn, "SP", "FICTNUM", MsgInp.Request.strNotationCd, " ", " ", 0)
        '                        'check if num is spaces
        '                    Case LineInfo.strTelephoneNo.Trim = ""
        '                        intSOPChildRequest = MyBase.WSDataAccessObj.usp_InsertSOPChildRequest(MsgInp.intSOPRequestId, MsgInp.Request.strAcctNum, LineInfo.strTelephoneNo, MsgInp.Request.strActn, "SP", "INVLNUM", MsgInp.Request.strNotationCd, " ", " ", 0)

        '                        'if alphanumeric it's invalid in AAIS
        '                    Case Not IsNumeric(LineInfo.strTelephoneNo.Trim)
        '                        intSOPChildRequest = MyBase.WSDataAccessObj.usp_InsertSOPChildRequest(MsgInp.intSOPRequestId, MsgInp.Request.strAcctNum, LineInfo.strTelephoneNo, MsgInp.Request.strActn, "SP", "ALPHANUM", MsgInp.Request.strNotationCd, " ", " ", 0)

        '                        'skip for all except serviceType T or P
        '                    Case LineInfo.strSubAcctServiceType.Trim <> "T" And LineInfo.strSubAcctServiceType.Trim <> "P"
        '                        intSOPChildRequest = MyBase.WSDataAccessObj.usp_InsertSOPChildRequest(MsgInp.intSOPRequestId, MsgInp.Request.strAcctNum, LineInfo.strTelephoneNo, MsgInp.Request.strActn, "SP", "INVLREQ", MsgInp.Request.strNotationCd, " ", " ", 0)

        '                    Case Else

        '                        If (MsgInp.strRequestFrom.Trim = "ORIGINAL") Then
        '                            intSOPChildRequest = MyBase.WSDataAccessObj.usp_InsertSOPChildRequest(MsgInp.intSOPRequestId, MsgInp.Request.strAcctNum, LineInfo.strTelephoneNo, MsgInp.Request.strActn, "SV", "STUDSV00", MsgInp.Request.strNotationCd, " ", " ", 0)

        '                            Dim AAISReq As AAISRequest = New AAISRequest
        '                            AAISReq.strAcctNum = MsgInp.Request.strAcctNum
        '                            AAISReq.strRequestId = intSOPChildRequest.ToString
        '                            AAISReq.strAAISActn = MsgInp.Request.strActn
        '                            AAISReq.strSyncFlag = MsgInp.Request.strSyncFlag
        '                            AAISReq.strWTN = LineInfo.strTelephoneNo
        '                            AAISReq.strAAISServerIP = AAISServer
        '                            AAISReq.strAAISPort = AAISPort
        '                            AAISReq.strRMiCWServerIP = RMICWServer
        '                            AAISReq.strRMICWServerPort = RMICWPort

        '                            Try
        '                                client = New AAISClient(MyBase.RegionId)
        '                                strMSg = client.StartClientSync(AAISReq)

        '                            Catch ex As Exception
        '                                LogErrorFile.WriteLog("AAISClient", ex.ToString())
        '                            Finally
        '                                If Not client Is Nothing Then
        '                                    client.Dispose()
        '                                End If
        '                            End Try
        '                            strReturnMsg += AAISReq.strWTN + " " + strMSg + " "
        '                        Else
        '                            intSOPChildRequest = MyBase.WSDataAccessObj.usp_InsertSOPChildRequest(MsgInp.intSOPRequestId, MsgInp.Request.strAcctNum, LineInfo.strTelephoneNo, MsgInp.Request.strActn, "RQ", "STUDRQ00", MsgInp.Request.strNotationCd, " ", " ", 0)

        '                        End If


        '                End Select

        '            Next LineInfo
        '            MyBase.WSDataAccessObj.usp_UpdateSOPRequest("STATUS", MsgInp.intSOPRequestId, "DN", "STUDDN00", " ", "RMICWWS")
        '        Else
        '            If (AcctInfo.RequestStatus.strMessageId.Trim = "100") Then
        '                MyBase.WSDataAccessObj.usp_UpdateSOPRequest("STATUS", MsgInp.intSOPRequestId, "SE", "NFNDECPS", " ", "RMICWWS")
        '            End If
        '        End If



        '    Catch ex As Exception
        '        LogErrorFile.WriteLog("RMICWWS-SubmitMessageRequest", "AcctNum: " & MsgInp.Request.strAcctNum & " Erroring Out " & ex.ToString)
        '        RequestStatus.strMessageId = "RMIEXPTN"
        '        RequestStatus.strMessageDescription = ex.ToString()
        '    End Try
        '    Return RequestStatus
        'End Function

#End Region


#Region "RMICW to AAIS Communucation thru WebService" ' AR07272009
        Public Function ProcessAAISRequest(ByVal MsgInp As MessagePrcsParm) As StatusOfRequest

            Dim strReturnMsg As String = ""
            Dim RequestStatus As StatusOfRequest = New StatusOfRequest
            Dim dtmDefaultEndDate As DateTime = New DateTime(9998, 12, 31)

            If MsgInp.strRequestFrom Is Nothing Then
                MsgInp.strRequestFrom = ""
            End If

            Try

                Dim objERAAccess As CBSSERAAccess = New CBSSERAAccess(MsgInp.Request.strRegionId)
                Dim AcctInfo As AcctLineLevelInfo
                Dim LineInfo As LineLevelInfo
                Dim intSOPChildRequest As Long
                Dim strMSg As String
                strReturnMsg = " "


                AcctInfo = objERAAccess.getCBSS_AcctLineInfo(MsgInp.Request.strRegionId, MsgInp.Request.strAcctNum)

                If (AcctInfo.RequestStatus.strMessageId.Trim = "") Then

                    'For Each LineInfo In AcctInfo.arrLstLineDetails
                    For i As Integer = 0 To AcctInfo.arrLstLineDetails.Count - 1
                        LineInfo = AcctInfo.arrLstLineDetails(i)
                        Dim strNXX As String = ""
                        If LineInfo.strTelephoneNo.Length > 6 Then
                            strNXX = LineInfo.strTelephoneNo.Substring(3, 3)
                        End If

                        Select Case True
                            Case LineInfo.strIlIxCrrStCd.Trim = "R" And LineInfo.strIlPreStCd.Trim = "R"
                                intSOPChildRequest = MyBase.WSDataAccessObj.usp_InsertSOPChildRequest(MsgInp.intSOPRequestId, MsgInp.Request.strAcctNum, LineInfo.strTelephoneNo, MsgInp.Request.strActn, "SP", "SMRTRNG", MsgInp.Request.strNotationCd, " ", " ", 0)
                            Case LineInfo.strSmrgAssocInd.Trim() = "Y"
                                intSOPChildRequest = MyBase.WSDataAccessObj.usp_InsertSOPChildRequest(MsgInp.intSOPRequestId, MsgInp.Request.strAcctNum, LineInfo.strTelephoneNo, MsgInp.Request.strActn, "SP", "SMRTRNG", MsgInp.Request.strNotationCd, " ", " ", 0)
                            Case LineInfo.dtmSubAccountTermDate < dtmDefaultEndDate
                                intSOPChildRequest = MyBase.WSDataAccessObj.usp_InsertSOPChildRequest(MsgInp.intSOPRequestId, MsgInp.Request.strAcctNum, LineInfo.strTelephoneNo, MsgInp.Request.strActn, "SP", "ACCTTRMD", MsgInp.Request.strNotationCd, " ", " ", 0)
                            Case LineInfo.strDerivedClecLineType.Trim = "O"
                                intSOPChildRequest = MyBase.WSDataAccessObj.usp_InsertSOPChildRequest(MsgInp.intSOPRequestId, MsgInp.Request.strAcctNum, LineInfo.strTelephoneNo, MsgInp.Request.strActn, "SP", "PRTDOUT", MsgInp.Request.strNotationCd, " ", " ", 0)
                            Case LineInfo.strTelephoneNo.StartsWith("800") Or LineInfo.strTelephoneNo.StartsWith("888") Or LineInfo.strTelephoneNo.StartsWith("877") Or LineInfo.strTelephoneNo.StartsWith("866") Or LineInfo.strTelephoneNo.StartsWith("855")
                                intSOPChildRequest = MyBase.WSDataAccessObj.usp_InsertSOPChildRequest(MsgInp.intSOPRequestId, MsgInp.Request.strAcctNum, LineInfo.strTelephoneNo, MsgInp.Request.strActn, "SP", "TOLLNUM", MsgInp.Request.strNotationCd, " ", " ", 0)

                                'if NPA or NXX starts with 0, it's fict num
                            Case LineInfo.strTelephoneNo.StartsWith("0") Or strNXX.StartsWith("0")
                                intSOPChildRequest = MyBase.WSDataAccessObj.usp_InsertSOPChildRequest(MsgInp.intSOPRequestId, MsgInp.Request.strAcctNum, LineInfo.strTelephoneNo, MsgInp.Request.strActn, "SP", "FICTNUM", MsgInp.Request.strNotationCd, " ", " ", 0)
                                'check if num is spaces
                            Case LineInfo.strTelephoneNo.Trim = ""
                                intSOPChildRequest = MyBase.WSDataAccessObj.usp_InsertSOPChildRequest(MsgInp.intSOPRequestId, MsgInp.Request.strAcctNum, LineInfo.strTelephoneNo, MsgInp.Request.strActn, "SP", "INVLNUM", MsgInp.Request.strNotationCd, " ", " ", 0)

                                'if alphanumeric it's invalid in AAIS
                            Case Not IsNumeric(LineInfo.strTelephoneNo.Trim)
                                intSOPChildRequest = MyBase.WSDataAccessObj.usp_InsertSOPChildRequest(MsgInp.intSOPRequestId, MsgInp.Request.strAcctNum, LineInfo.strTelephoneNo, MsgInp.Request.strActn, "SP", "ALPHANUM", MsgInp.Request.strNotationCd, " ", " ", 0)

                                'skip for all except serviceType T or P
                            Case LineInfo.strSubAcctServiceType.Trim <> "T" And LineInfo.strSubAcctServiceType.Trim <> "P"
                                intSOPChildRequest = MyBase.WSDataAccessObj.usp_InsertSOPChildRequest(MsgInp.intSOPRequestId, MsgInp.Request.strAcctNum, LineInfo.strTelephoneNo, MsgInp.Request.strActn, "SP", "INVLREQ", MsgInp.Request.strNotationCd, " ", " ", 0)

                            Case Else

                                If (MsgInp.strRequestFrom.Trim = "ORIGINAL") Then
                                    intSOPChildRequest = MyBase.WSDataAccessObj.usp_InsertSOPChildRequest(MsgInp.intSOPRequestId, MsgInp.Request.strAcctNum, LineInfo.strTelephoneNo, MsgInp.Request.strActn, "SV", "STUDSV00", MsgInp.Request.strNotationCd, " ", " ", 0)
                                    Dim AAISReq As AAISRequest = New AAISRequest
                                    AAISReq.strAcctNum = MsgInp.Request.strAcctNum
                                    AAISReq.strRequestId = intSOPChildRequest.ToString
                                    AAISReq.strAAISActn = MsgInp.Request.strActn
                                    AAISReq.strSyncFlag = MsgInp.Request.strSyncFlag
                                    AAISReq.strWTN = LineInfo.strTelephoneNo

                                    Try
                                        Dim strEnv As String = MsgInp.Request.strEnvironment.ToString()
                                        fnSendAAISRequest(AAISReq, strEnv)
                                    Catch ex As Exception
                                        LogErrorFile.WriteLog("AAISClient", ex.ToString())
                                    Finally
                                    End Try
                                    strReturnMsg += AAISReq.strWTN + " " + strMSg + " "
                                Else
                                    intSOPChildRequest = MyBase.WSDataAccessObj.usp_InsertSOPChildRequest(MsgInp.intSOPRequestId, MsgInp.Request.strAcctNum, LineInfo.strTelephoneNo, MsgInp.Request.strActn, "RQ", "STUDRQ00", MsgInp.Request.strNotationCd, " ", " ", 0)
                                End If
                        End Select

                    Next i

                    MyBase.WSDataAccessObj.usp_UpdateSOPRequest("STATUS", MsgInp.intSOPRequestId, "DN", "STUDDN00", " ", "RMICWWS")
                Else
                    If (AcctInfo.RequestStatus.strMessageId.Trim = "100") Then
                        MyBase.WSDataAccessObj.usp_UpdateSOPRequest("STATUS", MsgInp.intSOPRequestId, "SE", "NFNDECPS", " ", "RMICWWS")
                    End If
                End If



            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-SubmitMessageRequest", "AcctNum: " & MsgInp.Request.strAcctNum & " Erroring Out " & ex.ToString)
                RequestStatus.strMessageId = "RMIEXPTN"
                RequestStatus.strMessageDescription = ex.ToString()
            End Try
            Return RequestStatus
        End Function

#End Region


#Region "fnSendAAISRequest"




        Public Function fnSendAAISRequest(ByVal strAAISRequestvalues As AAISRequest, ByVal strEnv As String) As String
            Dim objTxnMGR As TransactionManagerService = New TransactionManagerService

            Dim objRequestContext As SoapContext
            Dim responseXml As String = ""
            Dim objarrLst As ArrayList = New ArrayList
            Dim strEnvironment As String = ""

            Dim sw As New StringWriter
            Dim strAAISInputXML As String

            Try
                Dim obRmicwRequestArray As RmicwRequestArray = New RmicwRequestArray
                Dim objTNSuspendRestoreRequest As TNSuspendRestoreRequest = New TNSuspendRestoreRequest
                'RMICW WS CallBack URL

                obRmicwRequestArray.rmicwURL = MyBase.WSDataAccessObj.usp_GetControlParmByName("ControlWEST", "RMICWURL")
                obRmicwRequestArray.aaisActn = strAAISRequestvalues.strAAISActn
                obRmicwRequestArray.requestID = strAAISRequestvalues.strRequestId

                'Need to check
                obRmicwRequestArray.compCode = "F" 'strAAISRequestvalues. 
                ''Need to check
                obRmicwRequestArray.syncFlag = strAAISRequestvalues.strSyncFlag
                If (strAAISRequestvalues.strSyncFlag.Trim = "T" Or strAAISRequestvalues.strSyncFlag.Trim = "Y") Then
                    obRmicwRequestArray.syncFlag = "T"
                Else
                    obRmicwRequestArray.syncFlag = "F"
                End If

                obRmicwRequestArray.wkgTN = strAAISRequestvalues.strWTN
                objarrLst.Add(obRmicwRequestArray)

                obRmicwRequestArray = New RmicwRequestArray
                objTNSuspendRestoreRequest.rmicwReq = objarrLst.ToArray(GetType(RmicwRequestArray))

                objRequestContext = objTxnMGR.RequestSoapContext
                objTxnMGR.Proxy = New WebProxy
                objRequestContext.Security.Tokens.Clear()
                Dim unt As Tokens.UsernameToken = New Tokens.UsernameToken("RMW", "rmicw05", Tokens.PasswordOption.SendPlainText)
                objRequestContext.Security.Tokens.Add(unt)
                objRequestContext.Security.MustUnderstand = False

                'AAIS WS URL
                'objTxnMGR.Url = "http://qualinesti.verizon.com/aais-ext-ws/services/TransactionManager"
                'objTxnMGR.Url = "https://aafwpt01.ebiz.verizon.com/aais-ext-ws/services/TransactionManager"

                strEnvironment = "AAIS-WS-" & strEnv.ToString()

                objTxnMGR.Url = MyBase.WSDataAccessObj.usp_GetControlParmByName("ControlWEST", strEnvironment)
                objTxnMGR.RequestSoapContext.Addressing.MustUnderstand = False
                objTxnMGR.Timeout = 90000

                ServicePointManager.ServerCertificateValidationCallback = New Net.Security.RemoteCertificateValidationCallback(AddressOf DTVPolicy.ValidateServerCertificate)


                Dim ser As New XmlSerializer(objTNSuspendRestoreRequest.GetType)
                ser.Serialize(sw, objTNSuspendRestoreRequest)
                strAAISInputXML = sw.ToString()
                'LogErrorFile.WriteLog("RMICWWS-AAISInputXML", strAAISInputXML)

                fnLoggingAAIS(strAAISRequestvalues.strAcctNum, strAAISRequestvalues.strAAISActn, strAAISRequestvalues.strRequestId, strAAISInputXML, "I")


                objTxnMGR.suspendRestoreTN(objTNSuspendRestoreRequest)




            Catch ex As Exception

                LogErrorFile.WriteLog("RMICWWS-fnSendMultipleRequest:Requestid/strActn", strAAISRequestvalues.strRequestId + "/" + strAAISRequestvalues.strAAISActn + ex.ToString())
                Throw (ex)
            End Try

        End Function



        'Public Function fnUpdateAAISResponse(ByVal strAAISResponse As String) As String
        '    Dim objTxnMGR As TransactionManagerService = New TransactionManagerService

        '    Dim objRequestContext As SoapContext
        '    Dim responseXml As String = ""
        '    Dim objarrLst As ArrayList = New ArrayList

        '    Try
        '        Dim obRmicwRequestArray As RmicwRequestArray = New RmicwRequestArray
        '        Dim objTNSuspendRestoreRequest As TNSuspendRestoreRequest = New TNSuspendRestoreRequest
        '        obRmicwRequestArray.aaisActn = "S"
        '        obRmicwRequestArray.compCode = "F"
        '        obRmicwRequestArray.requestID = "1"
        '        obRmicwRequestArray.rmicwURL = "http://113.130.96.58/RMICWWebServices/WsMain.asmx"
        '        obRmicwRequestArray.syncFlag = "F"
        '        obRmicwRequestArray.wkgTN = "9798473200"

        '        objarrLst.Add(obRmicwRequestArray)
        '        obRmicwRequestArray = New RmicwRequestArray
        '        objTNSuspendRestoreRequest.rmicwReq = objarrLst.ToArray(GetType(RmicwRequestArray))


        '        ''test Start

        '        objTNSuspendRestoreRequest = New TNSuspendRestoreRequest
        '        obRmicwRequestArray.aaisActn = "S"
        '        obRmicwRequestArray.compCode = "F"
        '        obRmicwRequestArray.requestID = "2"
        '        obRmicwRequestArray.rmicwURL = "http://113.130.96.58/RMICWWebServices/WsMain.asmx"
        '        obRmicwRequestArray.syncFlag = "F"
        '        obRmicwRequestArray.wkgTN = "9798473210"

        '        objarrLst.Add(obRmicwRequestArray)
        '        obRmicwRequestArray = New RmicwRequestArray
        '        objTNSuspendRestoreRequest.rmicwReq = objarrLst.ToArray(GetType(RmicwRequestArray))




        '        objTNSuspendRestoreRequest = New TNSuspendRestoreRequest
        '        obRmicwRequestArray.aaisActn = "S"
        '        obRmicwRequestArray.compCode = "F"
        '        obRmicwRequestArray.requestID = "3"
        '        obRmicwRequestArray.rmicwURL = "http://113.130.96.58/RMICWWebServices/WsMain.asmx"
        '        obRmicwRequestArray.syncFlag = "F"
        '        obRmicwRequestArray.wkgTN = "9798473210"

        '        objarrLst.Add(obRmicwRequestArray)
        '        obRmicwRequestArray = New RmicwRequestArray
        '        objTNSuspendRestoreRequest.rmicwReq = objarrLst.ToArray(GetType(RmicwRequestArray))



        '        objTNSuspendRestoreRequest = New TNSuspendRestoreRequest
        '        obRmicwRequestArray.aaisActn = "S"
        '        obRmicwRequestArray.compCode = "F"
        '        obRmicwRequestArray.requestID = "4"
        '        obRmicwRequestArray.rmicwURL = "http://113.130.96.58/RMICWWebServices/WsMain.asmx"
        '        obRmicwRequestArray.syncFlag = "F"
        '        obRmicwRequestArray.wkgTN = "9798473210"

        '        objarrLst.Add(obRmicwRequestArray)
        '        obRmicwRequestArray = New RmicwRequestArray
        '        objTNSuspendRestoreRequest.rmicwReq = objarrLst.ToArray(GetType(RmicwRequestArray))

        '        ''test End 





        '        objRequestContext = objTxnMGR.RequestSoapContext
        '        objTxnMGR.Proxy = New WebProxy
        '        objRequestContext.Security.Tokens.Clear()
        '        Dim unt As Tokens.UsernameToken = New Tokens.UsernameToken("RMW", "rmicw05", Tokens.PasswordOption.SendPlainText)
        '        objRequestContext.Security.Tokens.Add(unt)
        '        objRequestContext.Security.MustUnderstand = False
        '        objTxnMGR.Url = "http://qualinesti.verizon.com/aais-ext-ws/services/TransactionManager"
        '        objTxnMGR.Timeout = 60000
        '        objTxnMGR.RequestSoapContext.Addressing.MustUnderstand = False


        '        objTxnMGR.Timeout = 90000
        '        objTxnMGR.suspendRestoreTN(objTNSuspendRestoreRequest)
        '        ' Me.suspendRestoreTNtest(objTNSuspendRestoreRequest)
        '    Catch ex As Exception
        '        LogErrorFile.WriteLog("RMICWWS-RetrievalServiceTxn", ex.ToString())
        '        Throw (ex)
        '    End Try

        'End Function

        Public Function fnSendMultipleRequest(ByVal arrLstAAISRequest As ArrayList, ByVal reqType As AAISRequest, ByVal strEnv As String) As String
            Dim objTxnMGR As TransactionManagerService = New TransactionManagerService

            Dim objRequestContext As SoapContext
            Dim responseXml As String = ""
            Dim objarrLst As ArrayList = New ArrayList
            Dim AAISReq As AAISRequest
            Dim strEnvironment As String = ""

            Dim sw As New StringWriter
            Dim strAAISInputXML As String = ""

            Try
                Dim obRmicwRequestArray As RmicwRequestArray = New RmicwRequestArray
                Dim objTNSuspendRestoreRequest As TNSuspendRestoreRequest


                'RMICW CallBack URL
                'Dim strURL As String = "http://113.130.72.167/RMICWWebServices/WSMain.asmx"
                Dim strURL As String = MyBase.WSDataAccessObj.usp_GetControlParmByName("ControlWEST", "RMICWURL")

                'For Each AAISReq In arrLstAAISRequest
                For i As Integer = 0 To arrLstAAISRequest.Count - 1
                    AAISReq = arrLstAAISRequest(i)
                    objTNSuspendRestoreRequest = New TNSuspendRestoreRequest
                    obRmicwRequestArray.aaisActn = AAISReq.strAAISActn
                    obRmicwRequestArray.compCode = "F"
                    obRmicwRequestArray.requestID = AAISReq.strRequestId
                    obRmicwRequestArray.rmicwURL = strURL
                    obRmicwRequestArray.syncFlag = AAISReq.strSyncFlag
                    obRmicwRequestArray.wkgTN = AAISReq.strWTN
                    objarrLst.Add(obRmicwRequestArray)
                    obRmicwRequestArray = New RmicwRequestArray
                    objTNSuspendRestoreRequest.rmicwReq = objarrLst.ToArray(GetType(RmicwRequestArray))


                Next

                objRequestContext = objTxnMGR.RequestSoapContext
                objTxnMGR.Proxy = New WebProxy
                objRequestContext.Security.Tokens.Clear()
                Dim unt As Tokens.UsernameToken = New Tokens.UsernameToken("RMW", "rmicw05", Tokens.PasswordOption.SendPlainText)
                objRequestContext.Security.Tokens.Add(unt)
                objRequestContext.Security.MustUnderstand = False

                'SIT  URL 'AAIS
                'objTxnMGR.Url = "http://qualinesti.verizon.com/aais-ext-ws/services/TransactionManager"
                'objTxnMGR.Url = "http://pepsistuff.verizon.com/aais-ext-ws/services/TransactionManager"

                'UAT URL 'AAIS    
                '                 https://aafwpt01.ebiz.verizon.com/aais-ext-ws/services/TransactionManager?wsdl
                'objTxnMGR.Url = "https://aafwpt01.ebiz.verizon.com/aais-ext-ws/services/TransactionManager"
                'objTxnMGR.Url = "https://192.76.102.71/aais-ext-ws/services/TransactionManager"
                'objTxnMGR.Url = "https://aafwpp11.verizon.com/aais-ext-ws/services/TransactionManager"
                'objTxnMGR.Url = "https://aafwpt01.ebiz.verizon.com/aais-ext-ws/services/TransactionManager"

                strEnvironment = "AAIS-WS-" & strEnv.ToString()

                objTxnMGR.Url = MyBase.WSDataAccessObj.usp_GetControlParmByName("ControlWEST", strEnvironment)

                'objTxnMGR.Url = MyBase.WSDataAccessObj.usp_GetControlParmByName("ControlWEST", "AAISWSURL")


                objTxnMGR.RequestSoapContext.Addressing.MustUnderstand = False

                objTxnMGR.Timeout = 90000
                objTxnMGR.suspendRestoreTN(objTNSuspendRestoreRequest)

            Catch ex As Exception

                LogErrorFile.WriteLog("RMICWWS-fnSendMultipleRequest:Requestid/strActn", AAISReq.strRequestId + "/" + AAISReq.strAAISActn + ex.ToString())
                Throw (ex)
            End Try

        End Function




#End Region


#Region "fnUpdateAAISResponse"

        Public Function fnUpdateAAISResponse(ByVal strCompanyCode As String, ByVal strNPA As String, ByVal strNXX As String, ByVal strLineNumber As String, ByVal strRequestId As String, ByVal strMitsFeature As String, ByVal strIsdnFeature As String, ByVal strReturnCode As String, ByVal strErrorMsg As String) As String   'AR12152009
            Dim strMsg As String = ""
            Dim strStatusCd As String = ""
            Dim strReturnCd As String = ""
            Dim strResultId As String = ""


            If strRequestId Is Nothing Then
                LogErrorFile.WriteLog("AAISServer", "AAIS Response is Empty.")
                Return "AAIS Response is Empty"
            End If

            Try

                strMsg = "CompanyCode :" & strCompanyCode & ",NPA :" & strNPA & ",NXX : " & strNXX & ",LineNumber :" & strLineNumber
                strMsg &= ",RequestId : " & strRequestId & ",strMitsFeature : " & strMitsFeature & ",strIsdnFeature : " & strIsdnFeature & ",ReturnCode : " & strReturnCode & ",ErrorMsg = " & strErrorMsg

                'WSDataAccessObj.usp_InsertAuditTrail("RMICWWS", "AAISResp", "000", "ALL", "I", "0000000000", strMsg)
                'LogErrorFile.WriteLog("AAISServer", strMsg);
                fnLoggingAAIS(strNPA + strNXX + strLineNumber, "AAISResp", strRequestId, strMsg, "O")

                strResultId = strReturnCode

                If strReturnCode = "3" Or strReturnCode = "0" Or strErrorMsg.ToUpper().Trim() = "NO ERROR" Then
                    strResultId = "0"
                    strStatusCd = "CP"
                    strReturnCd = "STUDCP00"
                Else
                    strStatusCd = "SE"
                    strReturnCd = "STUDSEER"

                    Select Case strErrorMsg.ToUpper().Trim()
                        Case "INVALID HUNTMEMBER"
                            strStatusCd = "CP"
                            strReturnCd = "HUNTMEM"
                        Case "INVALID MEMBER TN"
                            strStatusCd = "SP"
                            strReturnCd = "MEMBTN"
                        Case "MUST PUNCH BY HAND"
                            strStatusCd = "CP"
                            strReturnCd = "PNCHHAND"

                        Case "SMART-RING NUMBER"
                            strStatusCd = "SP"
                            strReturnCd = "SMRTRNG"
                        Case "INVALIID TRANSACTION"
                            strStatusCd = "SP"
                            strReturnCd = "INVTRAN"
                    End Select

                End If

                WSDataAccessObj.usp_UpdateChildRequest("RESULT", strRequestId, strStatusCd, strReturnCd, strResultId, strIsdnFeature, strMitsFeature, strErrorMsg, "AAISListener")

            Catch ex As Exception

                LogErrorFile.WriteLog("AAISServer", "The msg received from AAIS : " + strMsg + " Errored with msg :" + ex.ToString())

            End Try


        End Function

#End Region




    End Class



    Public Class StateObjectClient
        Public workSocket As Socket = Nothing
        Public Const BufferSize As Integer = 59
        'Receive buffer.
        Public buffer(59) As Byte
        'Received data string.
        Public sb As StringBuilder = New StringBuilder
    End Class


    Public Class AAISRequest
        Public strWTN As String
        Public strRequestId As String
        Public strAAISActn As String
        Public strSyncFlag As String
        Public strAAISServerIP As String
        Public strAAISPort As String
        Public strRMiCWServerIP As String
        Public strRMICWServerPort As String
        Public strAcctNum As String
    End Class


    Public Class AAISClient
        Inherits RMICWWSBase

        Public Sub New(ByVal strRegionId As String)
            MyBase.New(strRegionId)
        End Sub



        Private Shared hshSockets As Hashtable


        Public ReadOnly Property getSocket(ByVal strIP As String, ByVal strPort As String) As Socket
            Get
                Return getSocketFromhash(strIP, strPort)
            End Get
        End Property





        'Public Function getSocketFromhash(ByVal strIP As String, ByVal strPort As String) As Socket

        '    Dim AAISSocket As Socket = Nothing
        '    Try

        '        Dim hshKey As String = strIP.Trim + ":" + strPort.Trim

        '        If (hshSockets Is Nothing) Then
        '            hshSockets = New Hashtable()
        '        End If

        '        If (hshSockets.ContainsKey(hshKey)) Then
        '            AAISSocket = hshSockets(hshKey)
        '            If AAISSocket Is Nothing Then
        '                AAISSocket = ReturnSocket(strIP, strPort)
        '                hshSockets(hshKey) = AAISSocket
        '            Else

        '                AAISSocket = ResetSocket(strIP, strPort)
        '            End If
        '        End If

        '    Catch ex As Exception
        '        LogErrorFile.WriteLog("RMICWAAISWS", "IP :" + strIP + " Port:" + strPort + " Socket error " + ex.ToString())
        '    End Try

        '    Return AAISSocket

        'End Function


        Public Function getSocketFromhash(ByVal strIP As String, ByVal strPort As String) As Socket

            Dim AAISSocket As Socket = Nothing
            Dim hshKey As String = strIP.Trim + ":" + strPort.Trim


            If (hshSockets Is Nothing) Then
                hshSockets = New Hashtable()
            End If

            If (hshSockets.ContainsKey(hshKey)) Then
                AAISSocket = hshSockets(hshKey)

                If (Not AAISSocket Is Nothing) Then

                    If (AAISSocket.Connected) Then
                        Return AAISSocket
                    Else
                        Try
                            AAISSocket.Shutdown(SocketShutdown.Both)
                            AAISSocket.Close()

                        Catch ex As Exception
                            LogErrorFile.WriteLog("RMICWWSAAIS-SocketShutdown", ex.ToString())
                        End Try
                        AAISSocket = ReturnSocket(strIP, strPort)
                    End If
                End If

            Else

                AAISSocket = ReturnSocket(strIP, strPort)
                hshSockets.Add(hshKey, AAISSocket)
            End If

            Return AAISSocket
        End Function


        Public Function ReturnSocket(ByVal strIP As String, ByVal strPort As String) As Socket

            Dim AAISSocket As Socket = Nothing
            Try

                Dim ipAddr As IPAddress = IPAddress.Parse(strIP)
                Dim remoteEP As IPEndPoint = New IPEndPoint(ipAddr, Integer.Parse(strPort))

                AAISSocket = New Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp)
                AAISSocket.SetSocketOption(SocketOptionLevel.Tcp, SocketOptionName.KeepAlive, 1)
                AAISSocket.Connect(remoteEP)

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWAAISWS", "IP :" + strIP + " Port:" + strPort + " Socket error " + ex.ToString())
            End Try
            Return AAISSocket
        End Function


        Public Property GetIP() As String
            Get

                If AAISServerIP Is Nothing Then
                    AAISServerIP = MyBase.WSDataAccessObj.usp_GetControlParmByName("ControlWEST", "AAISIP")
                End If
            End Get
            Set(ByVal Value As String)
                AAISServerIP = Value
            End Set
        End Property

        Public AAISServerIP As String

        ' ManualResetEvent instances signal completion.
        Private connectDone As ManualResetEvent = New ManualResetEvent(False)
        Private sendDone As ManualResetEvent = New ManualResetEvent(False)
        Private receiveDone As ManualResetEvent = New ManualResetEvent(False)

        ' The response from the remote device.
        Private response As String = String.Empty

        Public Function StartClient(ByVal Request As AAISRequest) As String

            Dim strmsg As String = " "
            Try

                'Dim ipHostInfo As IPHostEntry = Dns.Resolve(Dns.GetHostName())
                'IPAddress ipAddress = ipHostInfo.AddressList[0];
                'Dim arrIP As String() = GetIP.Split(",")
                'If (arrIP.Length < 2) Then
                '    LogErrorFile.WriteLog("AAISClinet", "IP Adrress and Port Not Specified")
                '    Throw (New Exception("IP Address and Port Not available for commuication to AAIS Server"))
                'End If

                Dim ipAddr As IPAddress = IPAddress.Parse(Request.strAAISServerIP)
                Dim remoteEP As IPEndPoint = New IPEndPoint(ipAddr, Integer.Parse(Request.strAAISPort))
                Dim client As Socket = New Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp)

                ' Connect to the remote endpoint.
                client.BeginConnect(remoteEP, New AsyncCallback(AddressOf ConnectCallback), client)
                connectDone.WaitOne()

                ' Send test data to the remote device.


                'Dim chrMsgName(13) As Char
                'Dim chrCompanyCd(0) As Char
                'Dim chrTNNumber(9) As Char
                'Dim chrActn(2) As Char
                'Dim chrAsyncFlag(0) As Char
                'Dim chrRequestId(9) As Char
                'Dim chrIPAddress(14) As Char
                'Dim chrIPPort(4) As Char



                'chrMsgName = FormatCharArray(chrMsgName, "ROCS_TN_MODIFY")
                'chrCompanyCd = FormatCharArray(chrCompanyCd, "F")
                'chrTNNumber = FormatCharArray(chrTNNumber, Request.strWTN)
                'chrActn = FormatCharArray(chrActn, Request.strAAISActn)
                ''The AsyncFlag is set to False Now.
                ''chrAsyncFlag = FormatCharArray(chrAsyncFlag, Request.strSyncFlag)
                'chrAsyncFlag = FormatCharArray(chrAsyncFlag, "T")
                'chrRequestId = FormatCharArray(chrRequestId, Request.strRequestId)
                'chrIPAddress = FormatCharArray(chrIPAddress, Request.strRMiCWServerIP)
                'chrIPPort = FormatCharArray(chrIPPort, Request.strRMICWServerPort)

                'Dim strBuild As StringBuilder = New StringBuilder(59)
                'strBuild.Append(chrMsgName)
                'strBuild.Append(chrCompanyCd)
                'strBuild.Append(chrTNNumber)
                'strBuild.Append(chrActn)
                'strBuild.Append(chrAsyncFlag)
                'strBuild.Append(chrRequestId)
                'strBuild.Append(chrIPAddress)
                'strBuild.Append(chrIPPort)


                Dim strInpMsg As String = formatMsgTobesentToAAIS(Request)

                'Send(client, "ROCS_TN_MODIFYA8649638572R  T123456789 105.253.5.247  11000")
                Send(client, strInpMsg)
                sendDone.WaitOne()
                MyBase.WSDataAccessObj.usp_InsertAuditTrail("RMICWWS", "AAISCLIENT", "000", Request.strAAISActn, "I", Request.strAcctNum, strInpMsg)

                ' Receive the response from the remote device.
                'Receive(client)
                'receiveDone.WaitOne()

                ' Write the response to the console.
                'LogErrorFile.WriteLog("AAISResponse", response)

                ' Release the socket.
                client.Shutdown(SocketShutdown.Both)
                client.Close()
                strmsg = "Successfully Msg Sent"
            Catch ex As Exception
                strmsg = ex.ToString()
                LogErrorFile.WriteLog("AAISClient", ex.ToString())
                MyBase.WSDataAccessObj.usp_InsertAuditTrail("RMICWWS", "AAISEXCPN", "000", Request.strAAISActn, "I", Request.strAcctNum, ex.ToString())
                'MyBase.WSDataAccessObj.usp_UpdateChildRequest("STATUS", Long.Parse(Request.strRequestId), "RQ", "RMICWERR", " ", ex.Message, "RMICWWS")
            End Try

            Return strmsg
        End Function




        Private Sub ConnectCallback(ByVal ar As IAsyncResult)

            Try
                ' Retrieve the socket from the state object.
                Dim client As Socket = CType(ar.AsyncState, Socket)

                ' Complete the connection.
                client.EndConnect(ar)
                'LogErrorFile.WriteLog("AAISClient", "Socket Connected To : " & client.RemoteEndPoint.ToString())
                ' Signal that the connection has been made.
                connectDone.Set()

            Catch ex As Exception
                LogErrorFile.WriteLog("AAISClient", ex.ToString())
            End Try

        End Sub
        'for testing purpose. called by AAISClientTest webmethod
        Public Function StartClientTest(ByVal Request As AAISRequest) As String

            Dim strmsg As String = " "
            Try




                'MyBase.WSDataAccessObj.usp_InsertSOPAndSOPChildRequest("WEST", Request.strAcctNum, Request.strWTN, Request.strRequestId, Request.strAAISActn, Request.strSyncFlag, " ", " ")

                'Dim strInpMsg As String = formatMsgTobesentToAAIS(Request)
                'Dim AAISSocket As Socket

                'Dim byteData As Byte()
                'Dim bytessent As Integer

                'byteData = Encoding.ASCII.GetBytes(strInpMsg)

                'Try
                '    bytessent = getSocket(Request.strAAISServerIP, Request.strAAISPort).Send(byteData)
                'Catch ex As SocketException
                '    bytessent = getSocket(Request.strAAISServerIP, Request.strAAISPort).Send(byteData)
                'End Try
                'MyBase.WSDataAccessObj.usp_InsertAuditTrail("RMICWWS", "AAISCLIENT", "000", Request.strAAISActn, "I", Request.strAcctNum, strInpMsg)
                'strmsg = "Successfully Msg Sent"



                ''''

                Dim ipAddr As IPAddress = IPAddress.Parse(Request.strAAISServerIP)
                Dim remoteEP As IPEndPoint = New IPEndPoint(ipAddr, Integer.Parse(Request.strAAISPort))
                Dim client As Socket = New Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp)

                ' Connect to the remote endpoint.
                client.BeginConnect(remoteEP, New AsyncCallback(AddressOf ConnectCallback), client)
                connectDone.WaitOne()


                ''capture m/c ip
                'Dim ipHostInfo As IPHostEntry = Dns.Resolve(Dns.GetHostName())
                'Dim clientIPAddr As IPAddress = ipHostInfo.AddressList(0)
                'Dim strclientIPAddr = clientIPAddr.ToString

                'Dim strAAISIPandPort As String = Request.strAAISServerIP '  + ":" + Request.strAAISPort
                'Dim strRMICWIPandPort As String = strclientIPAddr + ":" + "11000"

                'Insert into tSOPRequest and tSOPChildRequest
                MyBase.WSDataAccessObj.usp_InsertSOPAndSOPChildRequest("WEST", Request.strAcctNum, Request.strWTN, Request.strRequestId, Request.strAAISActn, Request.strSyncFlag, " ", " ")

                Dim strInpMsg As String = formatMsgTobesentToAAIS(Request)

                'Send(client, "ROCS_TN_MODIFYA8649638572R  T123456789 105.253.5.247  11000")
                Send(client, strInpMsg)
                sendDone.WaitOne()
                MyBase.WSDataAccessObj.usp_InsertAuditTrail("RMICWWS", "AAISCLIENT", "000", Request.strAAISActn, "I", Request.strAcctNum, strInpMsg)


                ' Release the socket.
                client.Shutdown(SocketShutdown.Both)
                client.Close()
                strmsg = "Successfully Msg Sent"



            Catch ex As Exception
                strmsg = ex.ToString()
                LogErrorFile.WriteLog("AAISClient", ex.ToString())
                MyBase.WSDataAccessObj.usp_InsertAuditTrail("RMICWWS", "AAISEXCPN", "000", Request.strAAISActn, "I", Request.strAcctNum, ex.ToString())
                'MyBase.WSDataAccessObj.usp_UpdateChildRequest("STATUS", Long.Parse(Request.strRequestId), "RQ", "RMICWERR", " ", ex.Message, "RMICWWS")
            End Try

            Return strmsg
        End Function



        Public Function SetSocket(ByVal Request As AAISRequest) As Socket

            Dim client As Socket
            Try

                Dim ipAddr As IPAddress = IPAddress.Parse(Request.strAAISServerIP)
                Dim remoteEP As IPEndPoint = New IPEndPoint(ipAddr, Integer.Parse(Request.strAAISPort))
                client = New Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp)
                client.Connect(remoteEP)
                client.Disconnect(False)
                client.Dispose()
            Catch ex As Exception
                LogErrorFile.WriteLog("AAISClient: SetSocket", ex.ToString())
                Throw ex
            End Try

            Return client
        End Function



        Public Function SendSyncMsg(ByVal client As Socket, ByVal Request As AAISRequest) As Integer

            Dim bytesSent As Integer
            Try



                Dim strInpMsg As String = formatMsgTobesentToAAIS(Request)

                'Send(client, "ROCS_TN_MODIFYA8649638572R  T123456789 105.253.5.247  11000")


                Dim byteData As Byte() = Encoding.ASCII.GetBytes(strInpMsg)
                bytesSent = client.Send(byteData)
                MyBase.WSDataAccessObj.usp_InsertAuditTrail("RMICWWS", "AAISCLIENT", "000", Request.strAAISActn, "I", Request.strAcctNum, strInpMsg)



            Catch ex As Exception
                LogErrorFile.WriteLog("AAISClient: SetSocket", ex.ToString())
                MyBase.WSDataAccessObj.usp_InsertAuditTrail("RMICWWS", "AAISEXCPN", "000", Request.strAAISActn, "I", Request.strAcctNum, ex.ToString())
                Throw ex
            End Try
            Return bytesSent
        End Function


        Public Function CloseSocket(ByVal client As Socket)
            Try

                If (Not client Is Nothing) Then
                    client.Shutdown(SocketShutdown.Both)
                    client.Close()
                End If

            Catch ex As Exception
                LogErrorFile.WriteLog("AAISSyncClose", ex.ToString())
                Throw ex
            End Try
        End Function

        Public Function StartClientSync(ByVal Request As AAISRequest) As String

            Dim strmsg As String = " "
            Try


                Dim ipAddr As IPAddress = IPAddress.Parse(Request.strAAISServerIP)
                Dim remoteEP As IPEndPoint = New IPEndPoint(ipAddr, Integer.Parse(Request.strAAISPort))
                Dim client As Socket = New Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp)





                client.Connect(remoteEP)




                Dim strInpMsg As String = formatMsgTobesentToAAIS(Request)



                Dim byteData As Byte() = Encoding.ASCII.GetBytes(strInpMsg)
                Dim bytesSent As Integer = client.Send(byteData)
                MyBase.WSDataAccessObj.usp_InsertAuditTrail("RMICWWS", "AAISCLIENT", "000", Request.strAAISActn, "I", Request.strAcctNum, strInpMsg)


                client.Shutdown(SocketShutdown.Both)
                client.Close()


                strmsg = "Successfully Msg Sent"
            Catch ex As Exception
                strmsg = ex.ToString()
                LogErrorFile.WriteLog("AAISClient", ex.ToString())
                MyBase.WSDataAccessObj.usp_InsertAuditTrail("RMICWWS", "AAISEXCPN", "000", Request.strAAISActn, "I", Request.strAcctNum, ex.ToString())
                'MyBase.WSDataAccessObj.usp_UpdateChildRequest("STATUS", Long.Parse(Request.strRequestId), "RQ", "RMICWERR", " ", ex.Message, "RMICWWS")
            End Try

            Return strmsg
        End Function


        Public Function SendRequestToAAISSyncMulti(ByVal Request As AAISRequest, ByVal arrLstRequest As ArrayList) As String

            Dim strmsg As String = " "
            Try


                Dim ipAddr As IPAddress = IPAddress.Parse(Request.strAAISServerIP)
                Dim remoteEP As IPEndPoint = New IPEndPoint(ipAddr, Integer.Parse(Request.strAAISPort))
                Dim client As Socket = New Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp)



                'Send(client, "ROCS_TN_MODIFYA8649638572R  T123456789 105.253.5.247  11000")


                client.Connect(remoteEP)
                Dim byteData As Byte()
                Dim bytessent As Integer

                Dim Req As AAISRequest
                'For Each Req In arrLstRequest
                For i As Integer = 0 To arrLstRequest.Count - 1
                    Req = arrLstRequest(i)
                    byteData = Encoding.ASCII.GetBytes(formatMsgTobesentToAAIS(Req))
                    bytessent = client.Send(byteData)
                    LogErrorFile.WriteLog("AAISClient", "No of byest sent is " + bytessent.ToString())

                Next i




                'Dim bytesSent As Integer = client.Send(byteData)
                'MyBase.WSDataAccessObj.usp_InsertAuditTrail("RMICWWS", "AAISCLIENT", "000", Request.strAAISActn, "I", Request.strAcctNum, strBuild.ToString())


                client.Shutdown(SocketShutdown.Both)
                client.Close()


                strmsg = "Successfully Msg Sent"
            Catch ex As Exception
                strmsg = ex.ToString()
                LogErrorFile.WriteLog("AAISClient", ex.ToString())
                'MyBase.WSDataAccessObj.usp_UpdateChildRequest("STATUS", Long.Parse(Request.strRequestId), "RQ", "RMICWERR", " ", ex.Message, "RMICWWS")
            End Try

            Return strmsg
        End Function

        Public Function SendRequestToAAISSyncBatch(ByVal Request As AAISRequest, ByVal arrLstRequest As ArrayList) As String

            Dim strmsg As String = " "
            Try


                Dim ipAddr As IPAddress = IPAddress.Parse(Request.strAAISServerIP)
                Dim remoteEP As IPEndPoint = New IPEndPoint(ipAddr, Integer.Parse(Request.strAAISPort))
                Dim client As Socket = New Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp)

                'Send(client, "ROCS_TN_MODIFYA8649638572R  T123456789 105.253.5.247  11000")
                'Send(client, "RMICW_TNBatch0001A6082544702R  123456789 105.253.5.247  11000")

                client.Connect(remoteEP)
                Dim byteData As Byte()
                Dim bytessent As Integer

                Dim Req As AAISRequest
                'AAIS batch
                Dim chrMsgName(13) As Char
                Dim chrWTNCnt(3) As Char
                Dim intWTNCnt As Integer
                Dim strHeader As String = ""
                Dim strAAISMsg As String = ""
                Dim strBatchMsgToAAIS As String = ""

                'chrMsgName = FormatCharArray(chrMsgName, "RMICW_TNBatch")
                chrMsgName = FormatCharArray(chrMsgName, "RMICW_TN_BATCH")
                'chrWTNCnt = FormatCharArray(chrWTNCnt, arrLstRequest.Count.ToString)
                chrWTNCnt = FormatCharArray(chrWTNCnt, arrLstRequest.Count.ToString("0000"))

                'intWTNCnt = arrLstRequest.Count
                'chrWTNCnt = arrLstRequest.Count.ToString
                'Format(arrLstRequest.Count.ToString, "0000")

                strHeader = chrMsgName + chrWTNCnt


                'For Each Req In arrLstRequest
                For i As Integer = 0 To arrLstRequest.Count - 1
                    Req = arrLstRequest(i)
                    'Dim chrMsgName(13) As Char
                    Dim chrCompanyCd(0) As Char
                    Dim chrTNNumber(9) As Char
                    Dim chrActn(2) As Char
                    'Dim chrAsyncFlag(0) As Char
                    Dim chrRequestId(9) As Char
                    Dim chrIPAddress(14) As Char
                    Dim chrIPPort(4) As Char
                    Dim strRequestType As String
                    Dim strBuild As StringBuilder


                    'chrMsgName = FormatCharArray(chrMsgName, "ROCS_TN_MODIFY")
                    chrCompanyCd = FormatCharArray(chrCompanyCd, "F")
                    chrTNNumber = FormatCharArray(chrTNNumber, Req.strWTN)
                    chrActn = FormatCharArray(chrActn, Req.strAAISActn)


                    'set to Async false for batch response 
                    'If (Request.strSyncFlag.Trim = "T" Or Request.strSyncFlag.Trim = "Y") Then
                    '    chrAsyncFlag = FormatCharArray(chrAsyncFlag, "T")
                    'Else
                    '    chrAsyncFlag = FormatCharArray(chrAsyncFlag, "F")
                    'End If


                    chrRequestId = FormatCharArray(chrRequestId, Req.strRequestId)
                    chrIPAddress = FormatCharArray(chrIPAddress, Req.strRMiCWServerIP)
                    chrIPPort = FormatCharArray(chrIPPort, Req.strRMICWServerPort)


                    'strBuild = New StringBuilder(59)
                    strBuild = New StringBuilder(44)
                    'strBuild.Append(chrMsgName)
                    strBuild.Append(chrCompanyCd)
                    strBuild.Append(chrTNNumber)
                    strBuild.Append(chrActn)
                    'strBuild.Append(chrAsyncFlag)
                    strBuild.Append(chrRequestId)
                    strBuild.Append(chrIPAddress)
                    strBuild.Append(chrIPPort)

                    'Return strBuild.ToString().Trim
                    strAAISMsg += strBuild.ToString().Trim

                    'byteData = Encoding.ASCII.GetBytes(formatMsgTobesentToAAIS(Req))
                    'bytessent = client.Send(byteData)
                    'LogErrorFile.WriteLog("AAISClient", "No of byest sent is " + bytessent.ToString())

                    MyBase.WSDataAccessObj.usp_InsertAuditTrail("RMICWWS", "AAISCLIENT", "000", Req.strAAISActn, "I", Req.strAcctNum, strBuild.ToString())

                Next i

                strBatchMsgToAAIS = strHeader + strAAISMsg


                byteData = Encoding.ASCII.GetBytes(strBatchMsgToAAIS)
                bytessent = client.Send(byteData)
                LogErrorFile.WriteLog("AAISClient", "No of byest sent is " + bytessent.ToString())

                LogErrorFile.WriteLog("AAISClient", "Batch data sent is " + strBatchMsgToAAIS)



                'Dim bytesSent As Integer = client.Send(byteData)
                'MyBase.WSDataAccessObj.usp_InsertAuditTrail("RMICWWS", "AAISCLIENT", "000", Request.strAAISActn, "I", Request.strAcctNum, strBuild.ToString())

                client.Shutdown(SocketShutdown.Both)
                client.Close()


                strmsg = "Successfully Msg Sent"
            Catch ex As Exception
                strmsg = ex.ToString()
                LogErrorFile.WriteLog("AAISClient", ex.ToString())
                'MyBase.WSDataAccessObj.usp_UpdateChildRequest("STATUS", Long.Parse(Request.strRequestId), "RQ", "RMICWERR", " ", ex.Message, "RMICWWS")
            End Try

            Return strmsg
        End Function




        Private Function formatMsgTobesentToAAIS(ByVal Request As AAISRequest) As String


            Dim chrMsgName(13) As Char
            Dim chrCompanyCd(0) As Char
            Dim chrTNNumber(9) As Char
            Dim chrActn(2) As Char
            Dim chrAsyncFlag(0) As Char
            Dim chrRequestId(9) As Char
            Dim chrIPAddress(14) As Char
            Dim chrIPPort(4) As Char
            Dim strRequestType As String
            Dim strBuild As StringBuilder

            chrMsgName = FormatCharArray(chrMsgName, "ROCS_TN_MODIFY")
            chrCompanyCd = FormatCharArray(chrCompanyCd, "F")
            chrTNNumber = FormatCharArray(chrTNNumber, Request.strWTN)
            chrActn = FormatCharArray(chrActn, Request.strAAISActn)

            'set to Async false for batch response 

            If (Request.strSyncFlag.Trim = "T" Or Request.strSyncFlag.Trim = "Y") Then
                chrAsyncFlag = FormatCharArray(chrAsyncFlag, "T")
            Else
                chrAsyncFlag = FormatCharArray(chrAsyncFlag, "F")
            End If

            chrRequestId = FormatCharArray(chrRequestId, Request.strRequestId)
            chrIPAddress = FormatCharArray(chrIPAddress, Request.strRMiCWServerIP)
            chrIPPort = FormatCharArray(chrIPPort, Request.strRMICWServerPort)

            strBuild = New StringBuilder(59)
            strBuild.Append(chrMsgName)
            strBuild.Append(chrCompanyCd)
            strBuild.Append(chrTNNumber)
            strBuild.Append(chrActn)
            strBuild.Append(chrAsyncFlag)
            strBuild.Append(chrRequestId)
            strBuild.Append(chrIPAddress)
            strBuild.Append(chrIPPort)


            Return strBuild.ToString().Trim


        End Function






        Private Function FormatCharArray(ByVal chrArr() As Char, ByVal strInp As String) As Char()


            Dim intChrCount As Integer = chrArr.Length
            Dim intStrCount As Integer = strInp.Length
            Dim i As Integer

            For i = 0 To intChrCount - 1
                If i < intStrCount Then
                    chrArr(i) = strInp.Chars(i)
                Else
                    chrArr(i) = CType(" ", Char)
                End If

            Next i

            Return chrArr

        End Function
        Private Sub Receive(ByVal client As Socket)

            Try

                Dim state As StateObjectClient = New StateObjectClient
                state.workSocket = client

                ' Begin receiving the data from the remote device.
                client.BeginReceive(state.buffer, 0, StateObjectClient.BufferSize, 0, New AsyncCallback(AddressOf ReceiveCallback), state)

            Catch ex As Exception
                LogErrorFile.WriteLog("AAISClient", ex.ToString())
            End Try
        End Sub

        Private Sub ReceiveCallback(ByVal ar As IAsyncResult)

            Try
                Dim state As StateObjectClient = CType(ar.AsyncState, StateObjectClient)
                Dim client As Socket = state.workSocket

                ' Read data from the remote device.
                Dim bytesRead As Integer = client.EndReceive(ar)

                If (bytesRead > 0) Then
                    state.sb.Append(Encoding.ASCII.GetString(state.buffer, 0, bytesRead))
                    client.BeginReceive(state.buffer, 0, StateObjectClient.BufferSize, 0, New AsyncCallback(AddressOf ReceiveCallback), state)

                    If (state.sb.Length > 1) Then
                        response = state.sb.ToString()
                    End If
                    receiveDone.Set()
                End If

            Catch ex As Exception
                LogErrorFile.WriteLog("AAISClient", ex.ToString())
            End Try

        End Sub


        Private Sub Send(ByVal client As Socket, ByVal data As String)

            Try
                Dim byteData As Byte() = Encoding.ASCII.GetBytes(data)
                client.BeginSend(byteData, 0, byteData.Length, 0, New AsyncCallback(AddressOf SendCallback), client)
            Catch ex As Exception
                LogErrorFile.WriteLog("AAISClient", ex.ToString())
            End Try


        End Sub



        Private Sub SendCallback(ByVal ar As IAsyncResult)

            Try
                ' Retrieve the socket from the state object.
                Dim client As Socket = CType(ar.AsyncState, Socket)

                ' Complete sending the data to the remote device.
                Dim bytesSent As Integer = client.EndSend(ar)
                'LogErrorFile.WriteLog("AAISClient", "Bytes Sent to Server :" & bytesSent.ToString())
                sendDone.Set()
            Catch ex As Exception

                LogErrorFile.WriteLog("AAISClient", ex.ToString())
            End Try

        End Sub



    End Class


    <System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "2.0.50727.42"), _
 System.SerializableAttribute(), _
 System.Diagnostics.DebuggerStepThroughAttribute(), _
 System.ComponentModel.DesignerCategoryAttribute("code"), _
 System.Xml.Serialization.XmlTypeAttribute(AnonymousType:=True), _
 System.Xml.Serialization.XmlRootAttribute([Namespace]:="", IsNullable:=False)> _
 Partial Public Class AAISResponseMsg

        Private objAAISResponseMsgResponseField() As AAISResponseMsgResponse

        '''<remarks/>
        <System.Xml.Serialization.XmlElementAttribute("Response", Form:=System.Xml.Schema.XmlSchemaForm.Unqualified)> _
        Public Property Items() As AAISResponseMsgResponse()
            Get
                Return Me.objAAISResponseMsgResponseField
            End Get
            Set(ByVal value As AAISResponseMsgResponse())
                Me.objAAISResponseMsgResponseField = value
            End Set
        End Property
    End Class


    <System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "2.0.50727.42"), _
     System.SerializableAttribute(), _
     System.Diagnostics.DebuggerStepThroughAttribute(), _
     System.ComponentModel.DesignerCategoryAttribute("code"), _
     System.Xml.Serialization.XmlTypeAttribute(AnonymousType:=True)> _
    Partial Public Class AAISResponseMsgResponse

        Private intMasterRequestIdField As String

        Private intRequestIdField As String

        Private strWTNField As String

        Private strErrorCdField As String

        Private strErrorDescriptionField As String

        '''<remarks/>
        <System.Xml.Serialization.XmlElementAttribute(Form:=System.Xml.Schema.XmlSchemaForm.Unqualified)> _
        Public Property intMasterRequestId() As String
            Get
                Return Me.intMasterRequestIdField
            End Get
            Set(ByVal value As String)
                Me.intMasterRequestIdField = value
            End Set
        End Property

        '''<remarks/>
        <System.Xml.Serialization.XmlElementAttribute(Form:=System.Xml.Schema.XmlSchemaForm.Unqualified)> _
        Public Property intRequestId() As String
            Get
                Return Me.intRequestIdField
            End Get
            Set(ByVal value As String)
                Me.intRequestIdField = value
            End Set
        End Property

        '''<remarks/>
        <System.Xml.Serialization.XmlElementAttribute(Form:=System.Xml.Schema.XmlSchemaForm.Unqualified)> _
        Public Property strWTN() As String
            Get
                Return Me.strWTNField
            End Get
            Set(ByVal value As String)
                Me.strWTNField = value
            End Set
        End Property

        '''<remarks/>
        <System.Xml.Serialization.XmlElementAttribute(Form:=System.Xml.Schema.XmlSchemaForm.Unqualified)> _
        Public Property strErrorCd() As String
            Get
                Return Me.strErrorCdField
            End Get
            Set(ByVal value As String)
                Me.strErrorCdField = value
            End Set
        End Property

        '''<remarks/>
        <System.Xml.Serialization.XmlElementAttribute(Form:=System.Xml.Schema.XmlSchemaForm.Unqualified)> _
        Public Property strErrorDescription() As String
            Get
                Return Me.strErrorDescriptionField
            End Get
            Set(ByVal value As String)
                Me.strErrorDescriptionField = value
            End Set
        End Property
    End Class








End Namespace


