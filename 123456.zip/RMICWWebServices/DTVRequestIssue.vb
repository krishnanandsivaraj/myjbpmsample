Option Strict Off
Option Explicit On
Imports System
Imports System.Net
Imports System.Collections
Imports System.Text
Imports System.Security
Imports System.IO
Imports CommonLibrary
Imports System.Xml.Serialization
Imports System.Xml
Imports DTVService1
Imports Verizon.RMICW.DataAccess
Imports System.Data
Imports System.DateTime
Imports System.Security.Cryptography.X509Certificates
Imports System.Text.RegularExpressions


Namespace Verizon.RMICW.WebServices

#Region "Handle Certificate"



    Public Enum CertificateProblem As Long
        CertEXPIRED = &H800B0101
        CertVALIDITYPERIODNESTING = &H800B0102
        CertROLE = &H800B0103
        CertPATHLENCONST = &H800B0104
        CertCRITICAL = &H800B0105
        CertPURPOSE = &H800B0106
        CertISSUERCHAINING = &H800B0107
        CertMALFORMED = &H800B0108
        CertUNTRUSTEDROOT = &H800B0109
        CertCHAINING = &H800B010A
        CertREVOKED = &H800B010C
        CertUNTRUSTEDTESTROOT = &H800B010D
        CertREVOCATION_FAILURE = &H800B010E
        CertCN_NO_MATCH = &H800B010F
        CertWRONG_USAGE = &H800B0110
        CertUNTRUSTEDCA = &H800B0112
    End Enum
    Public Interface ICertificatePolicy
    End Interface

    Public Class DTVPolicy
        Implements ICertificatePolicy
        Public Shared Function ValidateServerCertificate(ByVal sender As Object, ByVal certificate As X509Certificate, ByVal chain As X509Chain, ByVal sslPolicyErrors As Net.Security.SslPolicyErrors) As Boolean
            Return True
        End Function
    End Class



    Public Class TrustAllCertificatePolicy
        Implements ICertificatePolicy
        ' Default policy for certificate validation. 
        Public Shared DefaultValidate As Boolean = False

        Private Function GetProblemMessage(ByVal Problem As CertificateProblem) As String
            Dim ProblemMessage As String = ""
            Dim problemList As New CertificateProblem()
            Dim ProblemCodeName As String = [Enum].GetName(problemList.[GetType](), Problem)
            If ProblemCodeName IsNot Nothing Then
                ProblemMessage = (ProblemMessage & "-Certificateproblem:") + ProblemCodeName
            Else
                ProblemMessage = "Unknown Certificate Problem"
            End If
            Return ProblemMessage
        End Function
    End Class
#End Region


    Partial Public Class DTVWebservices


        Inherits RMICWWSBase
        Public Sub New(ByVal strRegionId As String)
            MyBase.New(strRegionId)
        End Sub

        Public strResponse As String = ""

        Public Function SendAffiliateNotification(ByVal objDTVRqst As AffiliateNotification) As AffiliateResponse

            Dim strXML As String = ""
            Dim strExParm As String = ""
            Dim strResponse As String = ""
            Dim arrValArr As Array
            Dim ds As New DataSet
            Dim blnStatusInd As Boolean = True
            Dim strRequestXMl, strParmValue, strStatus As String
            Dim strRequestUri As String, strResponseXml As String
            Dim struserid, strpwd As String
            Dim strDTVFrontier As String

            Dim xmlDoc As XmlDocument
            Dim xmlEle As XmlElement

            Dim objDA As WSDataAccessGeneric = New WSDataAccessGeneric(objDTVRqst.strRegionId)
            Dim objTrtmntStatus As TreatmentStatus = New TreatmentStatus(objDTVRqst.strRegionId)

            Dim objDTVResponse As AffiliateResponse = New AffiliateResponse
            Dim objTSrequest As TS_Request = New TS_Request
            Dim objTSresponse As TS_Response = New TS_Response

            objDTVRqst.strReturnCd = objDTVRqst.strExtendedParm

            'If acct not found in master file no need to call DTV
            If objDTVRqst.strDTVAcctNum = "" Then
                objDTVRqst.strResultDesc = "NO DAN Found"
                objDTVRqst.strErrorCd = "NO-DAN"
                objDTVRqst.strStatusCd = "VD"
                'objDTVRqst.strExtendedParm = "false"

                objDTVResponse.strErrorCd = objDTVRqst.strErrorCd
                objDTVResponse.strStatusCd = objDTVRqst.strStatusCd
                objDTVResponse.strAcctNum = objDTVRqst.strAcctNum
                objDTVResponse.strRespMessage = "NO DAN Found"

                'LogErrorFile.WriteLog("RMICWWS-DTV", "NO DAN FOUND - exiting")

                UpdateResponse(objDTVRqst)

                Return objDTVResponse

            End If

            'Check the NonBasic Status - if NB denied/Termed no need to call DTV
            Select Case objDTVRqst.strDTVActn.Trim()
                Case "SUSP"
                    blnStatusInd = True
                Case "REIN"
                    objTSrequest.strAcctNum = objDTVRqst.strAcctNum.Trim()
                    objTSrequest.strRegionId = objDTVRqst.strRegionId.Trim()
                    objTSrequest.strOrg = "000"
                    objTSrequest.strApplicationId = "DTV"
                    objTSrequest.strInputRequestType = "A"

                    objTSresponse = objTrtmntStatus.getTreatmentStatus(objTSrequest)

                    'RB,RB1,RB2 or MRB
                    If (objDTVRqst.strActn.Trim() = "RB") Or (objDTVRqst.strActn.Trim() = "RB1") Or (objDTVRqst.strActn.Trim() = "RB2") Or (objDTVRqst.strActn.Trim() = "MRB") Then



                        Select Case objTSrequest.strRegionId.Trim()
                            Case "WEST"
                                If ((objTSresponse.strNonBasicBucketStatusInd = BucketStatus.Denied) Or (objTSresponse.strNonBasicBucketStatusInd = BucketStatus.Terminated)) Then
                                    blnStatusInd = False
                                Else
                                    blnStatusInd = True
                                End If

                            Case "NPD"
                                If ((objTSresponse.strNonBasicBucketStatusInd = BucketStatus.Denied) Or (objTSresponse.strNonBasicBucketStatusInd = BucketStatus.Terminated)) Then
                                    blnStatusInd = False
                                Else
                                    blnStatusInd = True
                                End If

                            Case "MDVW"
                                If objDTVRqst.strOrg.StartsWith("WV") Then
                                    If ((objTSresponse.strNonTelecomStatusInd = BucketStatus.Denied) Or (objTSresponse.strNonTelecomStatusInd = BucketStatus.Terminated)) Then
                                        blnStatusInd = False
                                    Else
                                        blnStatusInd = True
                                    End If
                                Else
                                    If ((objTSresponse.strNonBasicBucketStatusInd = BucketStatus.Denied) Or (objTSresponse.strNonBasicBucketStatusInd = BucketStatus.Terminated)) Then
                                        blnStatusInd = False
                                    Else
                                        blnStatusInd = True
                                    End If
                                End If

                            Case "NY"
                                If ((objTSresponse.strOCARBucketStatusInd = BucketStatus.Denied) Or (objTSresponse.strOCARBucketStatusInd = BucketStatus.Terminated)) Then
                                    blnStatusInd = False
                                Else
                                    blnStatusInd = True
                                End If

                            Case "NE"
                                If objDTVRqst.strOrg.StartsWith("35") Then
                                    If ((objTSresponse.strTollBucketStatusInd = BucketStatus.Denied) Or (objTSresponse.strTollBucketStatusInd = BucketStatus.Terminated)) Then
                                        blnStatusInd = False
                                    Else
                                        blnStatusInd = True
                                    End If
                                Else
                                    If ((objTSresponse.strNonBasicBucketStatusInd = BucketStatus.Denied) Or (objTSresponse.strNonBasicBucketStatusInd = BucketStatus.Terminated)) Then
                                        blnStatusInd = False
                                    Else
                                        blnStatusInd = True
                                    End If
                                End If

                        End Select
                    End If

            End Select

            If (objDTVRqst.strOrg.StartsWith("WV")) Then
                Select Case objDTVRqst.strActn.Trim()
                    Case "RN", "SN", "RTN", "MRN", "MRTN", "DN", "DTN", "MDN", "MDTN", "STN"
                        blnStatusInd = False
                End Select
            End If


            'LogErrorFile.WriteLog("RMICWWS-DTV", "status Check " & blnStatusInd)


            If blnStatusInd = True Then

                Try
                    strParmValue = GetParmValues(objDTVRqst.strRegionId.Trim(), "DTVURL")
                    'strParmValue = "https://mwapiint.directv.com:10018/webservices/RequestTelcoSuspend_V3_0/RequestTelcoSuspend_V3_0"
                    arrValArr = Split(strParmValue, ";")
                    strRequestUri = arrValArr(0)
                    struserid = arrValArr(1)
                    strpwd = arrValArr(2)

                    strDTVFrontier = GetParmValues("WEST", "DTVFrontier")

                    'LogErrorFile.WriteLog("RMICWWS-DTV URL", strRequestUri & " " & struserid & " " & strpwd)

                    Select Case objDTVRqst.strDTVActn.Trim()
                        Case "SUSP"
                            If strDTVFrontier.ToUpper().Trim() = "TRUE" Then
                                strRequestXMl = fn_loadSuspendxmlNCA(objDTVRqst.intRequestId, objDTVRqst.strDTVActn.Trim(), objDTVRqst.strDTVAcctNum.Trim())
                            Else
                                strRequestXMl = fn_loadSuspendxml(objDTVRqst.intRequestId, objDTVRqst.strDTVActn.Trim(), objDTVRqst.strDTVAcctNum.Trim())
                            End If
                            strRequestXMl = Regex.Replace(strRequestXMl, vbCrLf, "").Trim()
                            LogErrorFile.WriteLog("RMICWWS-DTV Input XML", strRequestXMl)
                        Case "REIN"
                            If strDTVFrontier.ToUpper().Trim() = "TRUE" Then
                                strRequestXMl = fn_loadRestorexmlNCA(objDTVRqst.intRequestId, objDTVRqst.strDTVActn.Trim(), objDTVRqst.strDTVAcctNum.Trim())
                            Else
                                strRequestXMl = fn_loadRestorexml(objDTVRqst.intRequestId, objDTVRqst.strDTVActn.Trim(), objDTVRqst.strDTVAcctNum.Trim())
                            End If
                            strRequestXMl = Regex.Replace(strRequestXMl, vbCrLf, "").Trim()
                            LogErrorFile.WriteLog("RMICWWS-DTV Input XML", strRequestXMl)
                    End Select


                    If strRequestXMl Is Nothing Then
                        objDTVRqst.strErrorCd = "INVLDXML"
                        objDTVRqst.strStatusCd = "VD"
                        LogErrorFile.WriteLog("RMICWWS-DTV Invalid XML", "Invalid")
                        Return objDTVResponse
                    End If

                    strResponseXml = GetResponse(strRequestUri, strRequestXMl, struserid, strpwd) 'HTTP POST call

                    'Parse the response
                    Try
                        xmlDoc = New XmlDocument
                        xmlDoc.XmlResolver = Nothing
                        xmlDoc.LoadXml(strResponseXml)
                        xmlEle = xmlDoc.DocumentElement

                        strStatus = xmlEle.GetElementsByTagName("status", "*").Item(0).InnerXml()


                        If (strStatus = "failure") Then
                            objDTVRqst.strNotationCd = strStatus
                            objDTVRqst.strErrorCd = xmlEle.GetElementsByTagName("code", "*").Item(0).InnerXml()
                            objDTVRqst.strResultDesc = xmlEle.GetElementsByTagName("text", "*").Item(0).InnerXml()
                            objDTVRqst.strExtendedParm = xmlEle.GetElementsByTagName("retryAllowed", "*").Item(0).InnerXml()
                            'objDTVRqst.strNotationCd = xmlEle.GetElementsByTagName("additionalInformation", "*").Item(0).InnerXml()
                            objDTVRqst.strStatusCd = "SE"
                            'objDTVRqst.strReturnCd = ""
                        Else
                            objDTVRqst.strNotationCd = strStatus
                            'objDTVRqst.strResultDesc = strStatus
                            objDTVRqst.strErrorCd = "Success"
                            objDTVRqst.strStatusCd = "CP"
                            'objDTVRqst.strReturnCd = "STUDCP00"
                            objDTVRqst.strExtendedParm = "false"
                        End If

                    Catch ex As Exception
                        LogErrorFile.WriteLog("RMICWWS - DTV output parsing ", ex.ToString())
                        objDTVResponse.strRespMessage = ex.ToString()
                        objDTVResponse.strStatusCd = "SE"
                        objDTVResponse.strAcctNum = objDTVRqst.strAcctNum
                        objDTVResponse.strRespMessage = ex.ToString()

                    End Try


                    'Update tAffliateNotification 
                    strResponse = UpdateResponse(objDTVRqst)

                Catch ex As Exception
                    LogErrorFile.WriteLog("RMICWWS - DTV  Request", ex.ToString())
                    objDTVResponse.strRespMessage = ex.ToString()
                    objDTVResponse.strStatusCd = "VC"
                    objDTVResponse.strAcctNum = objDTVRqst.strAcctNum
                    objDTVResponse.strRespMessage = ex.ToString()
                    objDTVRqst.strExtendedParm = "true"
                    objDTVRqst.strReturnCd = objDTVRqst.strExtendedParm
                    strResponse = UpdateResponse(objDTVRqst)

                End Try

                'Logging
                Try
                    objDA.usp_InserttAuditLog("DTV", "I", objDTVRqst.strAcctNum.Trim(), objDTVRqst.strActn.Trim(), "NA", "NA", objDTVRqst.strDTVAcctNum, objDTVRqst.intRequestId, 0, strRequestXMl.Trim(), "WebSvc")
                    objDA.usp_InserttAuditLog("DTV", "O", objDTVRqst.strAcctNum.Trim(), objDTVRqst.strActn.Trim(), "NA", "NA", objDTVRqst.strDTVAcctNum, objDTVRqst.intRequestId, 1, strResponseXml.Trim(), "WebSvc")

                Catch exAudit As Exception
                    LogErrorFile.WriteLog("RMICWWS-DTV", exAudit.ToString())
                    objDTVResponse.strRespMessage = exAudit.ToString()
                End Try

            Else
                ' no need to call dtv due to status
                objDTVRqst.strResultDesc = "Invalid Status"
                objDTVRqst.strErrorCd = "Err01"
                objDTVRqst.strStatusCd = "VD"
                UpdateResponse(objDTVRqst)

                objDTVResponse.strErrorCd = objDTVRqst.strErrorCd
                objDTVResponse.strStatusCd = objDTVRqst.strStatusCd
                objDTVResponse.strAcctNum = objDTVRqst.strAcctNum
                objDTVResponse.strRespMessage = "Invalid status"

                Return objDTVResponse

            End If

            Return objDTVResponse

        End Function

        Private Function fn_loadSuspendxml(ByVal intRequestId As Integer, ByVal strActn As String, ByVal strAcctnum As String) As String
            Dim strRequestXml As String
            strRequestXml = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance""><SOAP-ENV:Header>"
            strRequestXml = strRequestXml & "<ns1:ei xmlns:ns1=""http://ei.directv.com/schemas/envelope/v3_0""><ns1:type>request</ns1:type>"
            strRequestXml = strRequestXml & "<ns1:service><ns1:name>requestTelcoSuspend</ns1:name><ns1:version>3.0</ns1:version></ns1:service>"
            strRequestXml = strRequestXml & "<ns1:originator>verizon</ns1:originator><ns1:businessProcessName>PARTNER_RTM_Suspend</ns1:businessProcessName>"
            strRequestXml = strRequestXml & "<ns1:requestDateTime>" & DateTime.Now().ToString("yyyy-MM-ddThh:mm:ss.fff") & "</ns1:requestDateTime><ns1:sourceSystemTransactionId>" & intRequestId & "</ns1:sourceSystemTransactionId>"
            strRequestXml = strRequestXml & "<ns1:sequenceNumber>001</ns1:sequenceNumber><ns1:user><ns1:id>user</ns1:id><ns1:group>group</ns1:group></ns1:user></ns1:ei></SOAP-ENV:Header>"
            strRequestXml = strRequestXml & "<SOAP-ENV:Body><request xmlns=""http://ei.directv.com/schemas/wsdl/telcoServices/v3_0/requestTelcoSuspend""><ns1:actionCode xmlns:ns1=""http://ei.directv.com/schemas/entities/v3_1"">" & strActn & "</ns1:actionCode><ns2:careCode xmlns:ns2=""http://ei.directv.com/schemas/entities/v3_1"">9876</ns2:careCode><ns3:accountId xmlns:ns3=""http://ei.directv.com/schemas/entities/v3_1"">" & strAcctnum & "</ns3:accountId><ns4:telcoMaintenanceAuditId xmlns:ns4=""http://ei.directv.com/schemas/entities/v3_1"">1234567</ns4:telcoMaintenanceAuditId><ns14:partnerReferenceId xmlns:ns14=""http://ei.directv.com/schemas/entities/v3_1"">3109645555</ns14:partnerReferenceId></request></SOAP-ENV:Body></SOAP-ENV:Envelope>"

            Return strRequestXml

        End Function

        Private Function fn_loadSuspendxmlNCA(ByVal intRequestId As Integer, ByVal strActn As String, ByVal strAcctnum As String) As String
            Dim strRequestXml As String
            strRequestXml = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance""><SOAP-ENV:Header>"
            strRequestXml = strRequestXml & "<ns1:ei xmlns:ns1=""http://ei.directv.com/schemas/envelope/v3_0""><ns1:type>request</ns1:type>"
            strRequestXml = strRequestXml & "<ns1:service><ns1:name>requestTelcoSuspend</ns1:name><ns1:version>3.0</ns1:version></ns1:service>"
            strRequestXml = strRequestXml & "<ns1:originator>FrontierNCA</ns1:originator><ns1:businessProcessName>PARTNER_RTM_Suspend</ns1:businessProcessName>"
            strRequestXml = strRequestXml & "<ns1:requestDateTime>" & DateTime.Now().ToString("yyyy-MM-ddThh:mm:ss.fff") & "</ns1:requestDateTime><ns1:sourceSystemTransactionId>" & intRequestId & "</ns1:sourceSystemTransactionId>"
            strRequestXml = strRequestXml & "<ns1:sequenceNumber>001</ns1:sequenceNumber><ns1:user><ns1:id>user</ns1:id><ns1:group>group</ns1:group></ns1:user></ns1:ei></SOAP-ENV:Header>"
            strRequestXml = strRequestXml & "<SOAP-ENV:Body><request xmlns=""http://ei.directv.com/schemas/wsdl/telcoServices/v3_0/requestTelcoSuspend""><ns1:actionCode xmlns:ns1=""http://ei.directv.com/schemas/entities/v3_1"">" & strActn & "</ns1:actionCode><ns2:careCode xmlns:ns2=""http://ei.directv.com/schemas/entities/v3_1"">9876</ns2:careCode><ns3:accountId xmlns:ns3=""http://ei.directv.com/schemas/entities/v3_1"">" & strAcctnum & "</ns3:accountId><ns4:telcoMaintenanceAuditId xmlns:ns4=""http://ei.directv.com/schemas/entities/v3_1"">1234567</ns4:telcoMaintenanceAuditId><ns14:partnerReferenceId xmlns:ns14=""http://ei.directv.com/schemas/entities/v3_1"">3109645555</ns14:partnerReferenceId></request></SOAP-ENV:Body></SOAP-ENV:Envelope>"

            Return strRequestXml

        End Function

        Private Function fn_loadRestorexml(ByVal intRequestId As Integer, ByVal strActn As String, ByVal strAcctnum As String) As String

            Dim strRequestXml As String
            strRequestXml = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:SOAP-ENC=""http://schemas.xmlsoap.org/soap/encoding/"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" xmlns:m0=""http://ei.directv.com/schemas/entities/v3_1""><SOAP-ENV:Header>"
            strRequestXml = strRequestXml & "<m:ei xmlns:m=""http://ei.directv.com/schemas/envelope/v3_0""><m:type>request</m:type><m:service><m:name>requestTelcoReinstate</m:name><m:version>3.0</m:version></m:service><m:originator>verizon</m:originator><m:businessProcessName>PARTNER_RTM_Reinstate</m:businessProcessName><m:requestDateTime>" & DateTime.Now().ToString("yyyy-MM-ddThh:mm:ss.fff") & "</m:requestDateTime><m:sourceSystemTransactionId>" & intRequestId & "</m:sourceSystemTransactionId><m:sequenceNumber>001</m:sequenceNumber><m:user><m:id>user</m:id><m:group>group</m:group></m:user></m:ei></SOAP-ENV:Header>"
            strRequestXml = strRequestXml & "<SOAP-ENV:Body><m:request><m0:actionCode>REIN</m0:actionCode><m0:careCode>9876</m0:careCode><m0:accountId>" & strAcctnum & "</m0:accountId><m0:telcoMaintenanceAuditId>5</m0:telcoMaintenanceAuditId><m0:obligationId>876</m0:obligationId><m0:partnerReferenceId>3109645555</m0:partnerReferenceId></m:request></SOAP-ENV:Body></SOAP-ENV:Envelope>"

            Return strRequestXml

        End Function

        Private Function fn_loadRestorexmlNCA(ByVal intRequestId As Integer, ByVal strActn As String, ByVal strAcctnum As String) As String

            Dim strRequestXml As String
            strRequestXml = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:SOAP-ENC=""http://schemas.xmlsoap.org/soap/encoding/"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" xmlns:m0=""http://ei.directv.com/schemas/entities/v3_1""><SOAP-ENV:Header>"
            strRequestXml = strRequestXml & "<m:ei xmlns:m=""http://ei.directv.com/schemas/envelope/v3_0""><m:type>request</m:type><m:service><m:name>requestTelcoReinstate</m:name><m:version>3.0</m:version></m:service><m:originator>FrontierNCA</m:originator><m:businessProcessName>PARTNER_RTM_Reinstate</m:businessProcessName><m:requestDateTime>" & DateTime.Now().ToString("yyyy-MM-ddThh:mm:ss.fff") & "</m:requestDateTime><m:sourceSystemTransactionId>" & intRequestId & "</m:sourceSystemTransactionId><m:sequenceNumber>001</m:sequenceNumber><m:user><m:id>user</m:id><m:group>group</m:group></m:user></m:ei></SOAP-ENV:Header>"
            strRequestXml = strRequestXml & "<SOAP-ENV:Body><m:request><m0:actionCode>REIN</m0:actionCode><m0:careCode>9876</m0:careCode><m0:accountId>" & strAcctnum & "</m0:accountId><m0:telcoMaintenanceAuditId>5</m0:telcoMaintenanceAuditId><m0:obligationId>876</m0:obligationId><m0:partnerReferenceId>3109645555</m0:partnerReferenceId></m:request></SOAP-ENV:Body></SOAP-ENV:Envelope>"

            Return strRequestXml

        End Function


        Public Function GetResponse(ByVal strRequestUri As String, ByVal strRequestXml As String, ByVal struserid As String, ByVal strpwd As String) As String
            Dim HRequest As HttpWebRequest = Nothing
            Dim strResponse As String = ""

            Try

                'Dim authBytes As Byte() = System.Text.Encoding.UTF8.GetBytes("verizon:GoingtoHDTV?".ToCharArray())
                Dim authBytes As Byte() = System.Text.Encoding.UTF8.GetBytes(struserid + ":" + strpwd.ToCharArray())
                Dim inputbyte As Byte() = System.Text.Encoding.UTF8.GetBytes(HttpUtility.HtmlEncode(strRequestXml))

                ' set a default CertificatePolicy that accepts ALL Server certificates 
                ServicePointManager.ServerCertificateValidationCallback = New Net.Security.RemoteCertificateValidationCallback(AddressOf DTVPolicy.ValidateServerCertificate)

                HRequest = CType(WebRequest.Create(strRequestUri), HttpWebRequest)
                HRequest.Headers.Set("Pragma", "no-cache")
                HRequest.Headers("Authorization") = "Basic " + Convert.ToBase64String(authBytes)
                HRequest.KeepAlive = False
                HRequest.Method = "POST"
                HRequest.Accept = "application/soap+xml, application/dime, multipart/related, text/*"
                HRequest.ContentType = "text/xml;charset=\""ISO-8859-1\"""
                HRequest.ContentLength = strRequestXml.Length
                HRequest.Timeout = 90000
                HRequest.ConnectionGroupName = Guid.NewGuid.ToString()

                'LogErrorFile.WriteLog("RMICWWS-DTV", "Calling DTV webservice")

                Dim Swriter As System.IO.Stream
                Swriter = HRequest.GetRequestStream()
                Swriter.Write(inputbyte, 0, inputbyte.Length)
                Dim Wresponse As WebResponse = Nothing
                Wresponse = HRequest.GetResponse()
                With (Wresponse)
                    Dim Sreader As New StreamReader(Wresponse.GetResponseStream())
                    With (Sreader)
                        strResponse = Sreader.ReadToEnd()
                        Sreader.Close()
                    End With

                End With
                Swriter.Flush()
                Swriter.Close()
            Catch ex As Exception
                If (Not IsNothing(HRequest)) Then
                    HRequest = Nothing
                    Throw ex
                End If
            Finally

            End Try

            'LogErrorFile.WriteLog("RMICWWS-DTV response", strResponse)
            Return strResponse

        End Function



        Public Function UpdateResponse(ByVal objDTVRqst As AffiliateNotification) As String
            ''update back to the tAffliateNotification Table
            Dim strMsgBody As String
            Dim objXmlSer As XmlSerializer
            objXmlSer = New XmlSerializer(GetType(CommonLibrary.AffiliateNotification))

            Dim objAff As AffiliateNotification = New AffiliateNotification()
            Dim objDA As WSDataAccessGeneric = New WSDataAccessGeneric(objDTVRqst.strRegionId)

            '  Variable populated for update
            objAff.intRequestId = objDTVRqst.intRequestId
            objAff.intRetryCnt = objDTVRqst.intRetryCnt
            objAff.strAcctNum = objDTVRqst.strAcctNum
            objAff.strActn = objDTVRqst.strActn
            objAff.strBQTActn = objDTVRqst.strBQTActn
            objAff.strBTNNum = objDTVRqst.strBTNNum
            objAff.strDestSystem = "DTV" 'objDTVRqst.strDestSystem
            objAff.strDTVAcctNum = objDTVRqst.strDTVAcctNum
            objAff.strDTVActn = objDTVRqst.strDTVActn
            objAff.strEnvironment = objDTVRqst.strEnvironment
            objAff.strErrorCd = objDTVRqst.strErrorCd
            objAff.strExtendedParm = objDTVRqst.strExtendedParm
            objAff.strLogonId = objDTVRqst.strLogonId
            objAff.strNotationCd = objDTVRqst.strNotationCd
            objAff.strOrg = objDTVRqst.strOrg
            objAff.strOriginationId = objDTVRqst.strOriginationId
            objAff.strRegionId = objDTVRqst.strRegionId
            objAff.strResultDesc = objDTVRqst.strResultDesc
            objAff.strStatusCd = objDTVRqst.strStatusCd

            strMsgBody = CommonLibrary.GeneralRoutine.SerializeTxn(objXmlSer, objAff)
            Try
                objDA.usp_InsertAffiliateRequests(objDTVRqst.strRegionId, strMsgBody, objDTVRqst.strReturnCd, "")
                strResponse = ""
            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-DTV-Update", ex.ToString())
                strResponse = ex.ToString()
            End Try

            'LogErrorFile.WriteLog("RMICWWS-DTV Update", "updating aff notify")

            Return strResponse

        End Function

        Public Function GetParmValues(ByVal strRegionID As String, ByVal strParmname As String) As String
            'Dim strParmName As String = "DTVURL"
            Dim strURL As String = ""
            Dim strCntl As String = "Control" + strRegionID

            Dim WSDataAccessObj As WSDataAccessGeneric = New WSDataAccessGeneric(strRegionID)
            Try
                strURL = WSDataAccessObj.usp_GetControlParmByName(strCntl, strParmName)
            Catch ex As Exception
                strURL = "https://mwapiint.directv.com:10018/webservices/RequestTelcoSuspend_V3_0/RequestTelcoSuspend_V3_0"
            End Try
            Return strURL
        End Function



        Public Function GetDTVAccountStatus(ByVal objDTVStatusReq As AffiliateStatus) As AffiliateStatus

            Dim ObjReq As AffiliateStatus = New AffiliateStatus
            Dim strAcctnum, strRegionCd, strDTVAcctnum, strRequestXml As String

            Dim strXML As String = ""
            Dim strExParm As String = ""
            Dim strResponse As String = ""
            Dim arrValArr As Array
            Dim ds As New DataSet
            Dim blnStatusInd As Boolean = True
            Dim strParmValue, strStatus As String
            Dim strRequestUri As String, strResponseXml As String
            Dim xmlDoc As XmlDocument
            Dim xmlEle As XmlElement
            Dim struserid, strpwd As String
            Dim strDTVFrontier As String

            strDTVAcctnum = objDTVStatusReq.strDTVAcctNum
            strRegionCd = objDTVStatusReq.StrRegioncd

            Dim objDA As WSDataAccessGeneric = New WSDataAccessGeneric(objDTVStatusReq.StrRegioncd)


            Try
                strParmValue = GetParmValues(strRegionCd, "DTVStatusURL")
                'strParmValue = "https://mwapiint.directv.com:10018/webservices/GetTelcoAccountProfile_V3_0/GetTelcoAccountProfile_V3_0"
                arrValArr = Split(strParmValue, ";")
                strRequestUri = arrValArr(0)
                struserid = arrValArr(1)
                strpwd = arrValArr(2)

                strDTVFrontier = GetParmValues("WEST", "DTVStatusURL")

                LogErrorFile.WriteLog("RMICWWS-DTV Status URL", strRequestUri & " " & struserid & " " & strpwd)


                If strDTVFrontier.ToUpper().Trim() = "TRUE" Then
                    strRequestXml = fn_loadAccountStatusxml(objDTVStatusReq.strDTVAcctNum)
                Else
                    strRequestXml = fn_loadAccountStatusxmlNCA(objDTVStatusReq.strDTVAcctNum)
                End If

                LogErrorFile.WriteLog("RMICWWS-DTV Status", strRequestXml)

                strResponseXml = GetResponse(HttpUtility.HtmlEncode(strRequestUri), HttpUtility.HtmlEncode(strRequestXml), struserid, strpwd) 'HTTP POST call

                LogErrorFile.WriteLog("RMICWWS-DTV Status", strResponseXml)

                'Parse the response

                xmlDoc = New XmlDocument
                xmlDoc.XmlResolver = Nothing
                xmlDoc.LoadXml(strResponseXml)
                xmlEle = xmlDoc.DocumentElement

                strStatus = xmlEle.GetElementsByTagName("status", "*").Item(0).InnerXml()

                If (strStatus = "failure") Then
                    objDTVStatusReq.strStatus = strStatus
                    objDTVStatusReq.strErrorCd = xmlEle.GetElementsByTagName("code", "*").Item(0).InnerXml()
                    objDTVStatusReq.strRespMessage = xmlEle.GetElementsByTagName("retryAllowed", "*").Item(0).InnerXml()
                Else
                    objDTVStatusReq.strStatus = xmlEle.GetElementsByTagName("accountStatus", "*").Item(0).InnerXml()
                    objDTVStatusReq.strErrorCd = "Success"
                    objDTVStatusReq.strStatusCd = "CP"

                End If


                'Logging
                Try
                    objDA.usp_InserttAuditLog("DTV", "I", objDTVStatusReq.strAcctNum.Trim(), "Status", "NA", "NA", objDTVStatusReq.strDTVAcctNum, 0, 0, strRequestXml.Trim(), "WebSvc")
                    objDA.usp_InserttAuditLog("DTV", "O", objDTVStatusReq.strAcctNum.Trim(), "Status", "NA", "NA", objDTVStatusReq.strDTVAcctNum, 0, 1, strResponseXml.Trim(), "WebSvc")

                Catch exAudit As Exception
                    LogErrorFile.WriteLog("RMICWWS-DTV", exAudit.ToString())
                End Try

            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS - DTV output parsing ", ex.ToString())
            End Try


            Return objDTVStatusReq

        End Function


        Private Function fn_loadAccountStatusxml(ByVal strDTVAcctnum As String) As String

            Dim strRequestXml As String

            strRequestXml = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:SOAP-ENC=""http://schemas.xmlsoap.org/soap/encoding/"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" xmlns:m0=""http://ei.directv.com/schemas/entities/v3_1""><SOAP-ENV:Header><m:ei xmlns:m=""http://ei.directv.com/schemas/envelope/v3_0""><m:type>request</m:type><m:service><m:name>getTelcoAccountProfile</m:name><m:version>3.0</m:version></m:service><m:originator>verizon</m:originator><m:businessProcessName>PARTNER_RTM_GetTelcoProfile</m:businessProcessName><m:requestDateTime>" & DateTime.Now().ToString("yyyy-MM-ddThh:mm:ss.fff") & "</m:requestDateTime><m:sourceSystemTransactionId>PPP123</m:sourceSystemTransactionId><m:sequenceNumber>001</m:sequenceNumber><m:user><m:id>user</m:id><m:group>group</m:group></m:user></m:ei></SOAP-ENV:Header><SOAP-ENV:Body><m:request xmlns:m=""http://ei.directv.com/schemas/wsdl/telcoServices/v3_0/getTelcoAccountProfile""><m0:accountId>" & strDTVAcctnum & "</m0:accountId></m:request></SOAP-ENV:Body></SOAP-ENV:Envelope>"
            Return strRequestXml

        End Function

        Private Function fn_loadAccountStatusxmlNCA(ByVal strDTVAcctnum As String) As String

            Dim strRequestXml As String

            strRequestXml = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:SOAP-ENC=""http://schemas.xmlsoap.org/soap/encoding/"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" xmlns:m0=""http://ei.directv.com/schemas/entities/v3_1""><SOAP-ENV:Header><m:ei xmlns:m=""http://ei.directv.com/schemas/envelope/v3_0""><m:type>request</m:type><m:service><m:name>getTelcoAccountProfile</m:name><m:version>3.0</m:version></m:service><m:originator>FrontierNCA</m:originator><m:businessProcessName>PARTNER_RTM_GetTelcoProfile</m:businessProcessName><m:requestDateTime>" & DateTime.Now().ToString("yyyy-MM-ddThh:mm:ss.fff") & "</m:requestDateTime><m:sourceSystemTransactionId>PPP123</m:sourceSystemTransactionId><m:sequenceNumber>001</m:sequenceNumber><m:user><m:id>user</m:id><m:group>group</m:group></m:user></m:ei></SOAP-ENV:Header><SOAP-ENV:Body><m:request xmlns:m=""http://ei.directv.com/schemas/wsdl/telcoServices/v3_0/getTelcoAccountProfile""><m0:accountId>" & strDTVAcctnum & "</m0:accountId></m:request></SOAP-ENV:Body></SOAP-ENV:Envelope>"
            Return strRequestXml

        End Function



        'Public Function CheckBucketStatus(ByVal StrRegionId As String, ByVal Stracctnum As String, ByVal strOrg As String) As Boolean

        '    Dim objTSResp As TS_Response = New TS_Response
        '    Dim objTSStatusDesc As TS_Response.TS_Status_Description = New TS_Response.TS_Status_Description
        '    Dim objTSRespStatus As TS_Response.TS_Response_Status = New TS_Response.TS_Response_Status
        '    objTSResp.ResponseStatus = objTSRespStatus
        '    Dim objWSCommon As WSCommonClasses = New WSCommonClasses


        '    Try
        '        Dim dsTS As DataSet = MyBase.WSDataAccessObj.usp_GetTreatmentStatus(StrRegionId, "A", Stracctnum, strOrg, "DTV")
        '        Dim dtTS As DataTable
        '        Dim drTS As DataRow
        '        Dim strValue As String

        '        If (MyBase.WSDataAccessObj.IsEmptyRecordSet(dsTS)) Then
        '            Return True
        '        End If

        '        Select Case StrRegionId

        '            Case "WEST"

        '                For Each dtTS In dsTS.Tables
        '                    For Each drTS In dtTS.Rows

        '                        strValue = drTS("strCategoryCd")
        '                        Select Case strValue.Trim()
        '                            Case "N"
        '                                objTSResp.strNonBasicBucketStatusInd = objWSCommon.getBucketStatus(drTS("strTrtStatusDesc"), drTS("strActn"))
        '                        End Select

        '                    Next drTS
        '                Next dtTS

        '                If objTSResp.strNonBasicBucketStatusInd = BucketStatus.Denied Or objTSResp.strNonBasicBucketStatusInd = BucketStatus.Terminated Then
        '                    'todo
        '                    Return False
        '                Else
        '                    Return True
        '                End If

        '            Case "MDVW"

        '                For Each dtTS In dsTS.Tables
        '                    For Each drTS In dtTS.Rows
        '                        If strOrg = "WV1" Then
        '                            strValue = drTS("strCategoryCd")
        '                            Select Case strValue.Trim()
        '                                Case "O"
        '                                    objTSResp.strNonTelecomStatusInd = objWSCommon.getBucketStatus(drTS("strTrtStatusDesc"), drTS("strActn"))
        '                            End Select
        '                            If objTSResp.strNonTelecomStatusInd = BucketStatus.Denied Or objTSResp.strNonTelecomStatusInd = BucketStatus.Terminated Then
        '                                'todo
        '                                Return False
        '                            Else
        '                                Return True
        '                            End If
        '                        Else
        '                            strValue = drTS("strCategoryCd")
        '                            Select Case strValue.Trim()
        '                                Case "N"
        '                                    objTSResp.strNonBasicBucketStatusInd = objWSCommon.getBucketStatus(drTS("strTrtStatusDesc"), drTS("strActn"))
        '                            End Select
        '                            If objTSResp.strNonBasicBucketStatusInd = BucketStatus.Denied Or objTSResp.strNonBasicBucketStatusInd = BucketStatus.Terminated Then
        '                                'todo
        '                                Return False
        '                            Else
        '                                Return True
        '                            End If

        '                        End If

        '                    Next drTS
        '                Next dtTS




        '            Case "NY"
        '                For Each dtTS In dsTS.Tables
        '                    For Each drTS In dtTS.Rows

        '                        strValue = drTS("strCategoryCd")
        '                        Select Case strValue.Trim()
        '                            Case "O"
        '                                objTSResp.strOCARBucketStatusInd = objWSCommon.getBucketStatus(drTS("strTrtStatusDesc"), drTS("strActn"))
        '                        End Select

        '                    Next drTS
        '                Next dtTS

        '                If objTSResp.strOCARBucketStatusInd = BucketStatus.Denied Or objTSResp.strOCARBucketStatusInd = BucketStatus.Terminated Then
        '                    'todo
        '                    Return False
        '                Else
        '                    Return True
        '                End If

        '            Case "NE"
        '                For Each dtTS In dsTS.Tables
        '                    For Each drTS In dtTS.Rows
        '                        If strOrg = "351" Or strOrg = "355" Then
        '                            strValue = drTS("strCategoryCd")
        '                            Select Case strValue.Trim()
        '                                Case "T"
        '                                    objTSResp.strTollBucketStatusInd = objWSCommon.getBucketStatus(drTS("strTrtStatusDesc"), drTS("strActn"))
        '                            End Select
        '                            If objTSResp.strTollBucketStatusInd = BucketStatus.Denied Or objTSResp.strTollBucketStatusInd = BucketStatus.Terminated Then
        '                                'todo
        '                                Return False
        '                            Else
        '                                Return True
        '                            End If
        '                        Else
        '                            strValue = drTS("strCategoryCd")
        '                            Select Case strValue.Trim()
        '                                Case "N"
        '                                    objTSResp.strNonBasicBucketStatusInd = objWSCommon.getBucketStatus(drTS("strTrtStatusDesc"), drTS("strActn"))
        '                            End Select
        '                            If objTSResp.strNonBasicBucketStatusInd = BucketStatus.Denied Or objTSResp.strNonBasicBucketStatusInd = BucketStatus.Terminated Then
        '                                'todo
        '                                Return False
        '                            Else
        '                                Return True
        '                            End If

        '                        End If

        '                    Next drTS
        '                Next dtTS

        '        End Select

        '    Catch ex As Exception
        '        LogErrorFile.WriteLog("RMICWWS - CheckStatusForDTV", ex.ToString())
        '    End Try



        'End Function

        'Public Function CheckBucketStatusForRestore(ByVal StrRegionId As String, ByVal Stracctnum As String, ByVal strOrg As String) As Boolean

        '    Dim objTSResp As TS_Response = New TS_Response
        '    Dim objTSStatusDesc As TS_Response.TS_Status_Description = New TS_Response.TS_Status_Description
        '    Dim objTSRespStatus As TS_Response.TS_Response_Status = New TS_Response.TS_Response_Status
        '    objTSResp.ResponseStatus = objTSRespStatus
        '    Dim objWSCommon As WSCommonClasses = New WSCommonClasses


        '    Try
        '        Dim dsTS As DataSet = MyBase.WSDataAccessObj.usp_GetTreatmentStatus(StrRegionId, "A", Stracctnum, strOrg, "DTV")
        '        Dim dtTS As DataTable
        '        Dim drTS As DataRow
        '        Dim strValue As String

        '        If (MyBase.WSDataAccessObj.IsEmptyRecordSet(dsTS)) Then
        '            Return True
        '        End If

        '        Select Case StrRegionId

        '            Case "WEST"

        '                For Each dtTS In dsTS.Tables
        '                    For Each drTS In dtTS.Rows

        '                        strValue = drTS("strCategoryCd")
        '                        Select Case strValue.Trim()
        '                            Case "B"
        '                                objTSResp.strBasicBucketStatusInd = objWSCommon.getBucketStatus(drTS("strTrtStatusDesc"), drTS("strActn"))
        '                        End Select

        '                        Select Case strValue.Trim()
        '                            Case "N"
        '                                objTSResp.strNonBasicBucketStatusInd = objWSCommon.getBucketStatus(drTS("strTrtStatusDesc"), drTS("strActn"))
        '                        End Select

        '                    Next drTS
        '                Next dtTS

        '                If (objTSResp.strBasicBucketStatusInd = BucketStatus.Live) Then
        '                    If (objTSResp.strNonBasicBucketStatusInd = BucketStatus.Live) Then
        '                        Return True
        '                    Else
        '                        Return False
        '                    End If
        '                    'todo

        '                Else
        '                    Return False
        '                End If

        '            Case "MDVW"

        '                For Each dtTS In dsTS.Tables
        '                    For Each drTS In dtTS.Rows
        '                        If strOrg = "WV1" Then
        '                            strValue = drTS("strCategoryCd")
        '                            Select Case strValue.Trim()
        '                                Case "B"
        '                                    objTSResp.strBasicBucketStatusInd = objWSCommon.getBucketStatus(drTS("strTrtStatusDesc"), drTS("strActn"))
        '                            End Select
        '                            Select Case strValue.Trim()
        '                                Case "O"
        '                                    objTSResp.strNonTelecomStatusInd = objWSCommon.getBucketStatus(drTS("strTrtStatusDesc"), drTS("strActn"))
        '                            End Select

        '                            If (objTSResp.strBasicBucketStatusInd = BucketStatus.Live) And (objTSResp.strNonTelecomStatusInd = BucketStatus.Live) Then
        '                                Return True
        '                            Else
        '                                Return False
        '                            End If
        '                        Else
        '                            strValue = drTS("strCategoryCd")
        '                            Select Case strValue.Trim()
        '                                Case "N"
        '                                    objTSResp.strNonBasicBucketStatusInd = objWSCommon.getBucketStatus(drTS("strTrtStatusDesc"), drTS("strActn"))
        '                            End Select
        '                            If (objTSResp.strBasicBucketStatusInd = BucketStatus.Live) Then
        '                                If (objTSResp.strBasicBucketStatusInd = BucketStatus.Live) Then
        '                                    Return True
        '                                Else
        '                                    Return False
        '                                End If
        '                            Else
        '                                Return False
        '                            End If

        '                        End If

        '                    Next drTS
        '                Next dtTS

        '            Case "NY"
        '                For Each dtTS In dsTS.Tables
        '                    For Each drTS In dtTS.Rows

        '                        strValue = drTS("strCategoryCd")
        '                        Select Case strValue.Trim()
        '                            Case "N"
        '                                objTSResp.strNonBasicBucketStatusInd = objWSCommon.getBucketStatus(drTS("strTrtStatusDesc"), drTS("strActn"))
        '                        End Select

        '                    Next drTS
        '                Next dtTS

        '                If (objTSResp.strBasicBucketStatusInd = BucketStatus.Live) And (objTSResp.strNonBasicBucketStatusInd = BucketStatus.Live) Then
        '                    Return True
        '                Else
        '                    Return False
        '                End If


        '            Case "NPD"
        '                For Each dtTS In dsTS.Tables
        '                    For Each drTS In dtTS.Rows

        '                        strValue = drTS("strCategoryCd")
        '                        Select Case strValue.Trim()
        '                            Case "N"
        '                                objTSResp.strNonBasicBucketStatusInd = objWSCommon.getBucketStatus(drTS("strTrtStatusDesc"), drTS("strActn"))
        '                        End Select

        '                    Next drTS
        '                Next dtTS

        '                If (objTSResp.strBasicBucketStatusInd = BucketStatus.Live) And (objTSResp.strNonBasicBucketStatusInd = BucketStatus.Live) Then
        '                    Return True
        '                Else
        '                    Return False
        '                End If

        '            Case "NE"
        '                For Each dtTS In dsTS.Tables
        '                    For Each drTS In dtTS.Rows
        '                        If strOrg = "351" Or strOrg = "355" Then
        '                            strValue = drTS("strCategoryCd")
        '                            Select Case strValue.Trim()
        '                                Case "T"
        '                                    objTSResp.strTollBucketStatusInd = objWSCommon.getBucketStatus(drTS("strTrtStatusDesc"), drTS("strActn"))
        '                            End Select
        '                            If (objTSResp.strBasicBucketStatusInd = BucketStatus.Live) And (objTSResp.strTollBucketStatusInd = BucketStatus.Live) Then

        '                                Return True
        '                            Else
        '                                Return False
        '                            End If
        '                        Else
        '                            strValue = drTS("strCategoryCd")
        '                            Select Case strValue.Trim()
        '                                Case "N"
        '                                    objTSResp.strNonBasicBucketStatusInd = objWSCommon.getBucketStatus(drTS("strTrtStatusDesc"), drTS("strActn"))
        '                            End Select
        '                            If (objTSResp.strBasicBucketStatusInd = BucketStatus.Live) And (objTSResp.strNonBasicBucketStatusInd = BucketStatus.Live) Then
        '                                Return True
        '                            Else
        '                                Return False
        '                            End If

        '                        End If

        '                    Next drTS
        '                Next dtTS

        '        End Select

        '    Catch ex As Exception
        '        LogErrorFile.WriteLog("RMICWWS - CheckStatusForDTV", ex.ToString())
        '    End Try


        'End Function

        'Public Function GetResponse(ByVal strRequestUri As String, ByVal strRequestXml As String) As String
        '    Dim HRequest As HttpWebRequest = Nothing
        '    Dim strResponse As String = ""

        '    Try
        '        HRequest = CType(WebRequest.Create(strRequestUri), HttpWebRequest)
        '        HRequest.KeepAlive = False
        '        HRequest.Method = "POST"

        '        ' UserName + ":" + Password;
        '        Dim sAuth As String = "verizon" + ":" + "GoingtoHDTV?"
        '        Dim binaryData() As Byte = {sAuth.Length}
        '        binaryData = Encoding.UTF8.GetBytes(sAuth)
        '        sAuth = Convert.ToBase64String(binaryData)
        '        sAuth = "Basic" + sAuth
        '        HRequest.Headers.Add("AUTHORIZATION", sAuth)

        '        HRequest.ContentType = "application/x-www-form-urlencoded"
        '        HRequest.ContentLength = strRequestXml.Length
        '        HRequest.Timeout = 9999999
        '        HRequest.ConnectionGroupName = Guid.NewGuid.ToString()

        '        Dim i As Integer

        '        Dim Swriter As New StreamWriter(HRequest.GetRequestStream())

        '        With (Swriter)
        '            Swriter.Write(strRequestXml)
        '            Swriter.Flush()
        '            Swriter.Close()
        '        End With

        '        Dim Wresponse As WebResponse = HRequest.GetResponse()

        '        With (Wresponse)
        '            Dim Sreader As New StreamReader(Wresponse.GetResponseStream())
        '            With (Sreader)
        '                strResponse = Sreader.ReadToEnd()
        '                Sreader.Close()
        '            End With

        '        End With
        '    Catch ex As Exception
        '        If (Not IsNothing(HRequest)) Then
        '            HRequest = Nothing
        '            Throw ex
        '        End If
        '    Finally

        '    End Try
        '    Return strResponse
        'End Function


    End Class


    Public Class AffiliateStatus

        Public strAcctNum As String
        Public strDTVAcctNum As String
        Public StrRegioncd As String
        Public intRequestId As Long
        Public strStatus As String
        Public strStatusCd As String
        Public strRespMessage As String
        Public strTrackingId As String
        Public strReturnCd As String
        Public strErrorCd As String
    End Class


End Namespace
