Imports Microsoft.VisualBasic
Namespace Verizon.RMICW.WebServices

    <System.Xml.Serialization.XmlTypeAttribute([Namespace]:="http://www.verizon.com/MOGService"), _
     System.Xml.Serialization.XmlRootAttribute([Namespace]:="http://www.verizon.com/MOGService", IsNullable:=False)> _
    Public Class MOGServiceResponse

        '<remarks/>
        Public Comment As String

        '<remarks/>
        Public ClientRequestId As String

        '<remarks/>
        Public SSPTrackingId As String

        '<remarks/>
        <System.Xml.Serialization.XmlElementAttribute("ResponseInfo")> _
        Public ResponseInfo() As MOGServiceResponseResponseInfo

        '<remarks/>
        <System.Xml.Serialization.XmlElementAttribute("MOGServiceAccepted")> _
        Public MOGServiceAccepted As MOGServiceResponseMOGServiceAccepted
        'Public MOGServiceAccepted() As MOGServiceResponseMOGServiceAccepted
    End Class

    '<remarks/>
    <System.Xml.Serialization.XmlTypeAttribute([Namespace]:="http://www.verizon.com/MOGService")> _
    Public Class MOGServiceResponseResponseInfo

        '<remarks/>
        Public Category As String

        '<remarks/>
        Public Code As String

        '<remarks/>
        Public Description As String
    End Class

    '<remarks/>
    <System.Xml.Serialization.XmlTypeAttribute([Namespace]:="http://www.verizon.com/MOGService")> _
    Public Class MOGServiceResponseMOGServiceAccepted

        '<remarks/>
        Public ChangeAccount As String

        Public ChangeService As String 'WR54590
        Public Sub New()
            ChangeAccount = ""
            ChangeService = ""
        End Sub

    End Class


End Namespace
