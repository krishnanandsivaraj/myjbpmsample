﻿'-----------------------------------------------------------------------------
'12/14/09 - BALA - New webmethod to get Product Status Prod Spnsnlvl
'-----------------------------------------------------------------------------
Imports CommonLibrary
Imports System.Xml
Imports System.Xml.Serialization
Imports System.IO
Imports System.Web.Services
Imports System.Globalization
Imports System.Net
Imports System.Text.RegularExpressions
Imports Microsoft.Web.Services2.Security
Imports Microsoft.Web.Services2
Imports Microsoft.Web.Services2.Dime
Imports System.Web.Services.Protocols
Imports System.Diagnostics
Imports System.Data


Namespace Verizon.RMICW.WebServices


    Public Class ProductStatus
        Inherits RMICWWSBase

        Public arrBucket() As String = {"Basic", "Non-Basic", "Toll", "OCAR", "NonTelecom", "DA"}

        Public Sub New(ByVal strRegionId As String)
            MyBase.New(strRegionId)
        End Sub

#Region "GetWireless1BillStatus"
        Public Function GetRMICWProductStatus(ByVal Request As ProductStatus_Request) As ProductStatus_Response
            'As W1B_Response

            Dim objProdResp As ProductStatus_Response = New ProductStatus_Response
            Dim objProdStatusDesc As ProductStatus_Response.Product_Status_Description = New ProductStatus_Response.Product_Status_Description
            Dim objProdRespStatus As ProductStatus_Response.Product_Response_Status = New ProductStatus_Response.Product_Response_Status
            objProdResp.ResponseStatus = objProdRespStatus

            Dim objWSCommon As WSCommonClasses = New WSCommonClasses
            Dim arrLstStatus As ArrayList = New ArrayList

            Dim strMsgBody As String

            Try
                objProdResp.strRegionId = Request.strRegionId
                objProdResp.strAcctNum = Request.strAcctNum


                If (Not WSCommonClasses.CheckRegionType(Request.strRegionId.Trim)) Then
                    'objBQTResp.Header.Result.Message 
                    strMsgBody = "Invalid RegionId Specified"
                    Return objProdResp
                End If

                If (Request.strFIOSInd = "Y" Or Request.strFIOSInd = "N") Then
                Else
                    objProdRespStatus.strMessageId = "RMWTS002"
                    objProdRespStatus.strMessageDescription = "Invalid FIOS Type. Should be Y or N"
                    Return objProdResp
                End If

                '----------------         call usp_GetProductStatus  -------------------
                Dim ds As DataSet = MyBase.WSDataAccessObj.usp_GetProductStatus(Request.strRegionId, Request.strAcctNum, Request.strFIOSInd)
                Dim dt As DataTable
                Dim dr, dr1 As DataRow
                Dim strColValue As String
                Dim strTableName As String
                Dim blnDTVProdCnt, blnVZWProdCnt As Boolean
                Dim intDTVProdCnt, intVZWProdCnt As Integer

                If (MyBase.WSDataAccessObj.IsEmptyRecordSet(ds)) Then
                    objProdRespStatus.strMessageDescription = "NO DATA FOUND"
                    Return objProdResp

                End If

                'For Each dt In ds.Tables
                For i As Integer = 0 To ds.Tables.Count - 1
                    dt = ds.Tables(i)
                    'For Each dr In dt.Rows
                    For j As Integer = 0 To dt.Rows.Count - 1
                        dr = dt.Rows(j)
                        strTableName = dr("strTableName")
                        objProdResp.strRegionId = Request.strRegionId
                        objProdResp.strAcctNum = Request.strAcctNum

                        Select Case strTableName.Trim()

                            Case "DTVACCT"
                                objProdResp.strDTVNum = dr("DTVAcctNum")


                            Case "VZWACCT"
                                objProdResp.strVZWNum = dr("VZWAcctNum")


                            Case "DTVCOUNT"
                                intDTVProdCnt = dr("DTVCOUNT")

                            Case "VZWCOUNT"
                                intVZWProdCnt = dr("VZWCOUNT")

                            Case "STATUS"
                                If dr("strProfileCAN") <> "" Then
                                    objProdResp.strProfileCAN = dr("strProfileCAN")
                                End If
                                If dr("strSSPBAN") <> "" Then
                                    objProdResp.strSSPBAN = dr("strSSPBAN")
                                End If
                                If dr("strSSPAcctID") <> "" Then
                                    objProdResp.strSSPAcctID = dr("strSSPAcctID")
                                End If

                                If dr("strVideoCAN") <> "" Then
                                    objProdResp.strVideoCAN = dr("strVideoCAN")
                                End If

                                Dim objPSDesc As ProductStatus_Response.Product_Status_Description = New ProductStatus_Response.Product_Status_Description



                                objPSDesc.strProductName = dr("strActn")
                                objPSDesc.dtmBeginDate = dr("dtmBeginDate")
                                objPSDesc.dtmEndDate = dr("dtmEndDate")
                                objPSDesc.strTrtDesc = dr("strTrtStatusDesc")

                                arrLstStatus.Add(objPSDesc)



                                If objPSDesc.strProductName = "DTV" Then
                                    blnDTVProdCnt = True
                                End If

                                If objPSDesc.strProductName = "VZW" Then
                                    blnVZWProdCnt = True
                                End If

                        End Select


                    Next j
                Next i


                If (objProdResp.strDTVNum <> "") And (blnDTVProdCnt = False) Then

                    Dim objPSDesc As ProductStatus_Response.Product_Status_Description = New ProductStatus_Response.Product_Status_Description

                    objPSDesc.strProductName = "DTV"
                    objPSDesc.strTrtDesc = "LIVE"
                    objPSDesc.dtmBeginDate = "1900/01/01"
                    objPSDesc.dtmEndDate = objPSDesc.dtmBeginDate.AddHours(4)
                    arrLstStatus.Add(objPSDesc)

                    'objProdResp.strDTVTreatmentStatus = "LIVE"
                End If

                If (objProdResp.strVZWNum <> "") And (blnVZWProdCnt = False) Then

                    Dim objPSDesc As ProductStatus_Response.Product_Status_Description = New ProductStatus_Response.Product_Status_Description

                    objPSDesc.strProductName = "VZW"
                    objPSDesc.strTrtDesc = "LIVE"
                    objPSDesc.dtmBeginDate = "1900/01/01"
                    objPSDesc.dtmEndDate = objPSDesc.dtmBeginDate.AddHours(4)

                    arrLstStatus.Add(objPSDesc)

                    'objProdResp.strVZWTreatmentStatus = "LIVE"
                End If

                objProdResp.arrStatusDesc = CType(arrLstStatus.ToArray(GetType(ProductStatus_Response.Product_Status_Description)), ProductStatus_Response.Product_Status_Description())


            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS - getTreatmentStatus", ex.ToString())
            End Try

            Return objProdResp

            'objW1BResp

        End Function



#End Region


    End Class

End Namespace

