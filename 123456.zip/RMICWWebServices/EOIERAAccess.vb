Imports CommonLibrary
Imports IBM.Data.DB2

Namespace Verizon.RMICW.WebServices

    Public Enum EOIOrderStatus
        NA
        Order_New
        Order_Completed
        Order_OnHold
        Order_Cancelled
        Order_Released
        Order_CompletedSentToBilling
    End Enum

    Public Enum EOIOrderType
        NA
        C_Change_Order
        E_Intercept_Order
        I_Install_Order
        L_FinLOB_Order
        M_Move_Order
        O_Out_Order
        P_PCut_Order
        S_Supercedure_Order
        Z_Order
    End Enum

    Public Class EOIFS010_Order_Output

        Public strFiller1 As String
        Public strLogOrderNum As String
        Public strFiller2 As String
        Public strOrderStatus As String
        Public strFiller3 As String
        Public strOrderType As String
        Public strFiller4 As String
        Public dtmCompletionDate As DateTime

        Public strFiller5 As String
        Public strFiller6 As String
        Public strFiller7 As String
        Public strFiller8 As String
        Public strFiller9 As String
        Public strOrderBlgPosNo As String
        Public strOrderBlgTypeCd As String
        Public dtmOrderCreationDate As DateTime
        Public dtmOrderDueDate As DateTime

    End Class

    Public Class EOIFS010

        Public strAcctNum As String
        <System.Xml.Serialization.XmlElement(ElementName:="OrderDetails", Type:=GetType(EOIOrderDetails))> _
        Public arrLstOrderDetails As ArrayList
        Public RequestStatus As StatusOfRequest

        Public Sub New()

            arrLstOrderDetails = New ArrayList
            RequestStatus = New StatusOfRequest
        End Sub
    End Class

    Public Class EOIOrderDetails
        Public strOrderNum As String
        Public enOrderType As EOIOrderType
        Public enOrderStatus As EOIOrderStatus
        Public dtmCompletionDate As DateTime

        Public strOrderBlgPosNo As String
        Public strOrderBlgTypeCd As String
        Public dtmOrderCreationDate As DateTime
        Public dtmOrderDueDate As DateTime

        '--strLogOrderNum
        'strOrderBlgPosNo
        'strOrderBlgTypeCd
        '--dtmCompletionDate
        'dtmOrderCreationDate
        'dtmOrderDueDate
        'strOrderNumber
        '--strOrderStatus
        '--strOrderType

        Public Sub New()
            enOrderType = EOIOrderType.NA
            enOrderStatus = EOIOrderStatus.NA
            strOrderNum = " "
            dtmCompletionDate = "1900-01-01"

            strOrderBlgPosNo = " "
            strOrderBlgTypeCd = " "
            dtmOrderCreationDate = "1900-01-01"
            dtmOrderDueDate = "1900-01-01"

        End Sub
    End Class

    Public Class EOIERAAccess
        Inherits RMICWWSBase

        Public Sub New(ByVal strRegionId As String)
            MyBase.New(strRegionId)
        End Sub


        Public Function getEOI_EOIFS010(ByVal strRegionId As String, ByVal strAcctNum As String) As EOIFS010

            Dim objEOIFS010 As EOIFS010 = New EOIFS010
            Try
                Dim reqObj As ERARequest = New ERARequest
                Dim resObj As ERAResponse
                Dim DB2DT As DataTable
                Dim DB2DR As DataRow
                Dim strInpValue As String

                Select Case True

                    Case strRegionId Is Nothing Or strRegionId.Trim = ""
                        objEOIFS010.RequestStatus.strMessageId = "INVRGNID"
                        objEOIFS010.RequestStatus.strMessageDescription = "Invalid Region Id passed."
                        Return objEOIFS010
                    Case strAcctNum Is Nothing Or strAcctNum.Trim = ""
                        objEOIFS010.RequestStatus.strMessageId = "INVACNBR"
                        objEOIFS010.RequestStatus.strMessageDescription = "Invalid Account Number passed as Input."
                        Return objEOIFS010
                End Select

                reqObj.strAcctNum = strAcctNum
                reqObj.strERAName = "EOIFS010"
                reqObj.strExtInput = "NNNNN"
                reqObj.strInpTyp = "2"
                reqObj.strReqType = "00"
                reqObj.strRegionId = strRegionId
                reqObj.strStartInstance = "0000000"
                reqObj.strFmtType = "0"

                objEOIFS010.strAcctNum = strAcctNum
                Dim obj As BrokerDB2Data = New BrokerDB2Data(reqObj)
                resObj = obj.EOIDB2Connect()



                Select Case True

                    Case Not resObj.intSQLRC = 0
                        objEOIFS010.RequestStatus.strMessageId = resObj.intSQLRC.ToString
                        objEOIFS010.RequestStatus.strMessageDescription = resObj.strMsgText
                        Return objEOIFS010
                    Case resObj.intSQLRC = 100
                        objEOIFS010.RequestStatus.strMessageId = "100"
                        objEOIFS010.RequestStatus.strMessageDescription = "No Matching Record Found in EOI"
                        Return objEOIFS010
                    Case MyBase.WSDataAccessObj.IsEmptyRecordSet(resObj.DB2DS)
                        objEOIFS010.RequestStatus.strMessageId = "100"
                        objEOIFS010.RequestStatus.strMessageDescription = "No Matching Record Found in EOI"
                        Return objEOIFS010
                End Select

                Dim arrLst As ArrayList = New ArrayList
                Dim fxdFld As _fixedField = New _fixedField
                Dim objCommon As CommonFunctions = New CommonFunctions
                Dim objEOIOrder As EOIFS010_Order_Output = New EOIFS010_Order_Output
                Dim objEOIOrderDetails As EOIOrderDetails

                'fxdFld.strFldName = "strFiller1"
                'fxdFld.fldType = Type.GetType("System.String")
                'fxdFld.intLength = 34
                'arrLst.Add(fxdFld)

                'fxdFld = New _fixedField
                'fxdFld.strFldName = "strLogOrderNum"
                'fxdFld.fldType = Type.GetType("System.String")
                'fxdFld.intLength = 6
                'arrLst.Add(fxdFld)

                'fxdFld = New _fixedField
                'fxdFld.strFldName = "strFiller2"
                'fxdFld.fldType = Type.GetType("System.String")
                'fxdFld.intLength = 113
                'arrLst.Add(fxdFld)

                'fxdFld = New _fixedField
                'fxdFld.strFldName = "dtmCompletionDate"
                'fxdFld.fldType = Type.GetType("System.String")
                'fxdFld.intLength = 10
                'arrLst.Add(fxdFld)

                'fxdFld = New _fixedField
                'fxdFld.strFldName = "strFiller3"
                'fxdFld.fldType = Type.GetType("System.String")
                'fxdFld.intLength = 349
                'arrLst.Add(fxdFld)

                'fxdFld = New _fixedField
                'fxdFld.strFldName = "strOrderStatus"
                'fxdFld.fldType = Type.GetType("System.String")
                'fxdFld.intLength = 1
                'arrLst.Add(fxdFld)

                'fxdFld = New _fixedField
                'fxdFld.strFldName = "strFiller4"
                'fxdFld.fldType = Type.GetType("System.String")
                'fxdFld.intLength = 33
                'arrLst.Add(fxdFld)



                'fxdFld = New _fixedField
                'fxdFld.strFldName = "strOrderType"
                'fxdFld.fldType = Type.GetType("System.String")
                'fxdFld.intLength = 1
                'arrLst.Add(fxdFld)

                '--strLogOrderNum
                fxdFld.strFldName = "strFiller1"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 34
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strLogOrderNum"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 6
                arrLst.Add(fxdFld)

                'CA-ORDR-BLG-POS-NO
                fxdFld = New _fixedField
                fxdFld.strFldName = "strFiller2"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 53
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strOrderBlgPosNo"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 2
                arrLst.Add(fxdFld)

                ''CA(-ORDR - BLG - Type - CD)
                'fxdFld = New _fixedField
                'fxdFld.strFldName = "strFiller3"
                'fxdFld.fldType = Type.GetType("System.String")
                'fxdFld.intLength = 0
                ''fxdFld.intLength = 2
                'arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strOrderBlgTypeCd"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                '--CA-ORDR-COMPLETION-DT
                fxdFld = New _fixedField
                fxdFld.strFldName = "strFiller4"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 57
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "dtmCompletionDate"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 10
                arrLst.Add(fxdFld)


                'CA-ORDR-CREATION-DT
                fxdFld = New _fixedField
                fxdFld.strFldName = "strFiller5"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 9
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "dtmOrderCreationDate"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 10
                arrLst.Add(fxdFld)

                'CA-ORDR-DUE-DT
                fxdFld = New _fixedField
                fxdFld.strFldName = "strFiller6"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 65
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "dtmOrderDueDate"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 10
                arrLst.Add(fxdFld)

                'CA-ORDR-NO
                fxdFld = New _fixedField
                fxdFld.strFldName = "strFiller7"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 84
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strOrderNumber"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 9
                arrLst.Add(fxdFld)

                '--CA-ORDR-STAT-CD
                fxdFld = New _fixedField
                fxdFld.strFldName = "strFiller8"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 162
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strOrderStatus"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)

                '--CA-ORDR-TYPE-CD 
                fxdFld = New _fixedField
                fxdFld.strFldName = "strFiller9"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 33
                arrLst.Add(fxdFld)

                fxdFld = New _fixedField
                fxdFld.strFldName = "strOrderType"
                fxdFld.fldType = Type.GetType("System.String")
                fxdFld.intLength = 1
                arrLst.Add(fxdFld)


                'For Each DB2DT In resObj.DB2DS.Tables
                For i As Integer = 0 To resObj.DB2DS.Tables.Count - 1
                    DB2DT = resObj.DB2DS.Tables(i)
                    'For Each DB2DR In DB2DT.Rows
                    For j As Integer = 0 To DB2DT.Rows.Count - 1
                        DB2DR = DB2DT.Rows(j)

                        objEOIOrder = New EOIFS010_Order_Output
                        objCommon.ParseFixedLayout(DB2DR(2), arrLst)
                        objCommon.getTheFileFormat(arrLst, "EOIFS010_Order_Output", objEOIOrder)

                        objEOIOrderDetails = New EOIOrderDetails
                        objEOIOrderDetails.strOrderNum = DB2DR(0).ToString().Substring(8, 9)
                        objEOIOrderDetails.dtmCompletionDate = objEOIOrder.dtmCompletionDate

                        objEOIOrderDetails.strOrderBlgPosNo = objEOIOrder.strOrderBlgPosNo
                        objEOIOrderDetails.strOrderBlgTypeCd = objEOIOrder.strOrderBlgTypeCd
                        objEOIOrderDetails.dtmOrderCreationDate = objEOIOrder.dtmOrderCreationDate
                        objEOIOrderDetails.dtmOrderDueDate = objEOIOrder.dtmOrderDueDate

                        Select Case objEOIOrder.strOrderStatus.Trim
                            Case ""
                                objEOIOrderDetails.enOrderStatus = EOIOrderStatus.Order_New
                            Case "1"
                                objEOIOrderDetails.enOrderStatus = EOIOrderStatus.Order_Released
                            Case "2"
                                objEOIOrderDetails.enOrderStatus = EOIOrderStatus.Order_Cancelled
                            Case "3"
                                objEOIOrderDetails.enOrderStatus = EOIOrderStatus.Order_OnHold
                            Case "4"
                                objEOIOrderDetails.enOrderStatus = EOIOrderStatus.Order_Completed
                            Case "5"
                                objEOIOrderDetails.enOrderStatus = EOIOrderStatus.Order_CompletedSentToBilling
                            Case Else
                                objEOIOrderDetails.enOrderStatus = EOIOrderStatus.NA
                        End Select

                        Select Case objEOIOrder.strOrderType.Trim
                            Case "C"
                                objEOIOrderDetails.enOrderType = EOIOrderType.C_Change_Order
                            Case "E"
                                objEOIOrderDetails.enOrderType = EOIOrderType.E_Intercept_Order
                            Case "I"
                                objEOIOrderDetails.enOrderType = EOIOrderType.I_Install_Order
                            Case "L"
                                objEOIOrderDetails.enOrderType = EOIOrderType.L_FinLOB_Order
                            Case "M"
                                objEOIOrderDetails.enOrderType = EOIOrderType.M_Move_Order
                            Case "O"
                                objEOIOrderDetails.enOrderType = EOIOrderType.O_Out_Order
                            Case "P"
                                objEOIOrderDetails.enOrderType = EOIOrderType.P_PCut_Order
                            Case "S"
                                objEOIOrderDetails.enOrderType = EOIOrderType.S_Supercedure_Order
                            Case "Z"
                                objEOIOrderDetails.enOrderType = EOIOrderType.Z_Order
                            Case Else
                                objEOIOrderDetails.enOrderType = EOIOrderStatus.NA
                        End Select

                        objEOIFS010.arrLstOrderDetails.Add(objEOIOrderDetails)
                    Next j
                Next i



            Catch ex As Exception
                LogErrorFile.WriteLog("RMICWWS-EOIFS010", "AcctNum: " & strAcctNum & " Erroring Out " & ex.ToString)
                objEOIFS010.RequestStatus.strMessageId = "RMIEXPTN"
                objEOIFS010.RequestStatus.strMessageDescription = ex.ToString

            End Try
            Return objEOIFS010

        End Function
    End Class
End Namespace

