package com.sample;

public class HelloProcessModel {

	private String userlocation;
	private Integer count;
	private Integer loopcondition;
	
	
	public String getUserlocation() {
		return userlocation;
	}
	public void setUserlocation(String userlocation) {
		this.userlocation = userlocation;
	}
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	public Integer getLoopcondition() {
		return loopcondition;
	}
	public void setLoopcondition(Integer loopcondition) {
		this.loopcondition = loopcondition;
	}
	
}
