﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Core1Angular2CRUDTest.Models
{
    public class StudentMastersAppContext : DbContext
    {
        public DbSet<StudentMasters> Students { get; set; }
    }
}
